"""
Condition Evaluator — the heart of the decision tree engine.
Operator registry pattern: each operator is a callable, looked up by name.
"""

import re
import math
import logging
from typing import Any, Callable, Dict, Optional

from models.schemas import SimpleCondition, CompoundCondition, Condition

logger = logging.getLogger(__name__)

RowData = Dict[str, Any]


class OperatorRegistry:
    """Extensible operator registry."""

    def __init__(self):
        self._operators: Dict[str, Callable] = {}
        self._register_defaults()

    def register(self, name: str, func: Callable):
        self._operators[name] = func

    def get(self, name: str) -> Callable:
        if name not in self._operators:
            raise ValueError(f"Unknown operator: '{name}'")
        return self._operators[name]

    def _register_defaults(self):
        # Comparison
        self.register("gt",  lambda l, r, **_: _safe_compare(l, r, lambda a, b: a > b))
        self.register("gte", lambda l, r, **_: _safe_compare(l, r, lambda a, b: a >= b))
        self.register("lt",  lambda l, r, **_: _safe_compare(l, r, lambda a, b: a < b))
        self.register("lte", lambda l, r, **_: _safe_compare(l, r, lambda a, b: a <= b))
        self.register("eq",  lambda l, r, **_: _safe_eq(l, r))
        self.register("neq", lambda l, r, **_: not _safe_eq(l, r))

        # String
        self.register("contains",    lambda l, r, **_: _str_op(l, r, lambda s, v: v in s))
        self.register("starts_with", lambda l, r, **_: _str_op(l, r, lambda s, v: s.startswith(v)))
        self.register("ends_with",   lambda l, r, **_: _str_op(l, r, lambda s, v: s.endswith(v)))
        self.register("is_empty",    lambda l, **_: l is None or str(l).strip() == "")
        self.register("regex",       lambda l, pattern=None, **_: bool(re.match(pattern, str(l or ""))))

        # Null
        self.register("is_null",     lambda l, **_: _is_null(l))
        self.register("is_not_null", lambda l, **_: not _is_null(l))

        # Range
        self.register("between", lambda l, low=None, high=None, **_: _between(l, low, high))

        # Set
        self.register("in",     lambda l, values=None, **_: l in (values or []))
        self.register("not_in", lambda l, values=None, **_: l not in (values or []))


def _is_null(value: Any) -> bool:
    if value is None:
        return True
    if isinstance(value, float) and math.isnan(value):
        return True
    return False


def _safe_compare(left: Any, right: Any, op: Callable) -> bool:
    if _is_null(left) or _is_null(right):
        return False
    try:
        return op(float(left), float(right))
    except (ValueError, TypeError):
        return op(str(left), str(right))


def _safe_eq(left: Any, right: Any) -> bool:
    if _is_null(left) and _is_null(right):
        return True
    if _is_null(left) or _is_null(right):
        return False
    try:
        return float(left) == float(right)
    except (ValueError, TypeError):
        return str(left).strip() == str(right).strip()


def _str_op(left: Any, right: Any, op: Callable) -> bool:
    if _is_null(left):
        return False
    return op(str(left), str(right))


def _between(value: Any, low: Any, high: Any) -> bool:
    if _is_null(value):
        return False
    try:
        v = float(value)
        return float(low) <= v <= float(high)
    except (ValueError, TypeError):
        return False


class ConditionEvaluator:
    """Evaluates conditions against row data using the operator registry."""

    def __init__(self, registry: Optional[OperatorRegistry] = None):
        self.registry = registry or OperatorRegistry()

    def evaluate(self, condition: Condition, row: RowData) -> bool:
        if isinstance(condition, CompoundCondition):
            return self._evaluate_compound(condition, row)
        elif isinstance(condition, SimpleCondition):
            return self._evaluate_simple(condition, row)
        else:
            raise TypeError(f"Unknown condition type: {type(condition)}")

    def _evaluate_simple(self, cond: SimpleCondition, row: RowData) -> bool:
        left_val = row.get(cond.left_column)

        right_val = None
        if cond.right_column:
            right_val = row.get(cond.right_column)
        elif cond.right_value is not None:
            right_val = cond.right_value

        kwargs = {
            "pattern": cond.pattern,
            "low": cond.low,
            "high": cond.high,
            "values": cond.values,
        }

        op_func = self.registry.get(cond.operator)

        # Categorize by arity
        unary_ops = ("is_null", "is_not_null", "is_empty", "regex")
        kwargs_only_ops = ("between", "in", "not_in")

        if cond.operator in unary_ops:
            result = op_func(left_val, **kwargs)
        elif cond.operator in kwargs_only_ops:
            result = op_func(left_val, **kwargs)
        else:
            result = op_func(left_val, right_val, **kwargs)

        logger.debug(
            f"  [{cond.operator}] {cond.left_column}={left_val} "
            f"vs {right_val} → {result}"
        )
        return result

    def _evaluate_compound(self, cond: CompoundCondition, row: RowData) -> bool:
        if cond.operator == "and":
            result = all(self.evaluate(c, row) for c in cond.conditions)
        else:
            result = any(self.evaluate(c, row) for c in cond.conditions)
        logger.debug(f"  [compound:{cond.operator}] → {result}")
        return result
