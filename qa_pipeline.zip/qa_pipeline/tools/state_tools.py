"""
QA Pipeline - State Management Tools
Helpers for reading and writing answers across the session state chain.
"""

import json
import logging
from typing import Any

from google.adk.tools import FunctionTool

logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────
# State key naming convention
# ─────────────────────────────────────────────

QA_DATA_KEY = "qa_raw_data"
ANSWER_KEY_PREFIX = "answer_q"
REASONING_KEY_PREFIX = "reasoning_q"
PIPELINE_META_KEY = "pipeline_metadata"


def make_answer_key(question_number: int) -> str:
    return f"{ANSWER_KEY_PREFIX}{question_number}"


def make_reasoning_key(question_number: int) -> str:
    return f"{REASONING_KEY_PREFIX}{question_number}"


# ─────────────────────────────────────────────
# Tool functions
# ─────────────────────────────────────────────

def format_prior_answers(answers_json: str) -> str:
    """
    Format prior answers into a structured context block for agent prompts.

    Args:
        answers_json: JSON string containing dict of {question_num: answer_text}

    Returns:
        Formatted string for injection into agent prompts.
    """
    try:
        answers: dict[str, str] = json.loads(answers_json)
    except (json.JSONDecodeError, TypeError):
        return "No prior answers available."

    if not answers:
        return "No prior answers available."

    lines = ["=== PRIOR ANSWERS FROM THIS QA CHAIN ==="]
    for q_num in sorted(answers.keys(), key=lambda x: int(x)):
        answer_text = answers[q_num]
        lines.append(f"\nQuestion {q_num} Answer:\n{answer_text}")
    lines.append("\n=== END PRIOR ANSWERS ===")

    return "\n".join(lines)


def extract_answer_section(full_response: str) -> dict[str, str]:
    """
    Parse the structured REASONING / ANSWER response format from question agents.

    Args:
        full_response: Raw LLM response text.

    Returns:
        Dict with 'reasoning' and 'answer' keys.
    """
    result = {"reasoning": "", "answer": full_response.strip()}

    if "REASONING:" in full_response and "ANSWER:" in full_response:
        try:
            reasoning_start = full_response.index("REASONING:") + len("REASONING:")
            answer_start = full_response.index("ANSWER:")
            result["reasoning"] = full_response[reasoning_start:answer_start].strip()
            result["answer"] = full_response[answer_start + len("ANSWER:"):].strip()
        except ValueError:
            pass

    return result


def build_context_for_agent(
    qa_data_json: str,
    prior_answers: dict[int, str],
    depends_on: list[int],
) -> str:
    """
    Build a comprehensive context string for a question agent.

    Args:
        qa_data_json: Serialized QA process data.
        prior_answers: All prior answers keyed by question number.
        depends_on: Question numbers this agent depends on.

    Returns:
        Formatted context block.
    """
    sections = []

    # QA Data
    try:
        qa_data = json.loads(qa_data_json)
        qa_data.pop("status", None)
        sections.append("=== QA PROCESS DATA ===")
        sections.append(json.dumps(qa_data, indent=2))
        sections.append("=== END QA PROCESS DATA ===\n")
    except Exception:
        sections.append(f"QA DATA (raw): {qa_data_json[:2000]}\n")

    # Dependent answers
    if depends_on and prior_answers:
        sections.append("=== REQUIRED PRIOR ANSWERS ===")
        for q_num in depends_on:
            if q_num in prior_answers:
                sections.append(f"\nQ{q_num} Answer:\n{prior_answers[q_num]}")
            else:
                sections.append(f"\nQ{q_num} Answer: [NOT YET AVAILABLE - answer independently]")
        sections.append("=== END PRIOR ANSWERS ===")

    return "\n".join(sections)


format_prior_answers_tool = FunctionTool(func=format_prior_answers)
