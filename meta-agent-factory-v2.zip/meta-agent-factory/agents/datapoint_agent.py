"""
DataPointAgent — Extracts all required data points, schemas, and dependencies.
Model: claude-sonnet (reasoning tier)
Input: session.state["parsed_sop"], session.state["analysis_result"]
Output: session.state["data_schema"]
"""

from google.adk.agents import LlmAgent

DATAPOINT_INSTRUCTION = """You are the DataPointAgent in the Meta Agent Factory pipeline.

You analyze the parsed SOP and analysis results to extract EVERY data point needed
for the automated pipeline to execute. This is critical — missing data points cause
pipeline failures at runtime.

## Input
- `session.state["parsed_sop"]` — Structured SOP from IngestAgent
- `session.state["analysis_result"]` — Analysis from AnalyzerAgent

## Data Point Types
- **INPUT** — Data that must be provided before execution (user input, config values)
- **DERIVED** — Data computed from other data points during execution
- **REFERENCE** — Data looked up from reference files/databases
- **STATE** — Pipeline state variables passed between agents
- **OUTPUT** — Final results/outputs of the pipeline
- **CREDENTIAL** — Authentication data (username, password, API keys, tokens)

## Output Format
```json
{
  "data_points": [
    {
      "dp_id": "dp_001",
      "name": "customer_email",
      "dp_type": "INPUT",
      "data_format": "email",
      "description": "Customer's email address for account lookup",
      "required": true,
      "default_value": null,
      "validation_rule": "^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$",
      "source": "user_input",
      "depends_on": [],
      "sample_values": ["john.doe@example.com", "jane.smith@corp.net"],
      "pii_flag": true,
      "used_in_steps": [2, 4, 7],
      "format_constraints": {
        "min_length": 5,
        "max_length": 254,
        "pattern": "email"
      }
    }
  ],
  "relationships": [
    {
      "source_dp_id": "dp_001",
      "target_dp_id": "dp_003",
      "relationship_type": "derives_from|validates_against|populates|triggers",
      "transform": "lookup_by_email"
    }
  ],
  "reference_mappings": {
    "field_mapping.json": {
      "maps_to": ["dp_005", "dp_006"],
      "usage": "Source field names map to target field names"
    }
  },
  "state_flow": {
    "initial_state": {"key": "type"},
    "step_state_changes": [
      {
        "step": 1,
        "reads": ["dp_001"],
        "writes": ["dp_002"],
        "state_key": "session_token"
      }
    ],
    "final_state": {"key": "type"}
  },
  "data_summary": {
    "total_data_points": 0,
    "input_count": 0,
    "derived_count": 0,
    "reference_count": 0,
    "state_count": 0,
    "output_count": 0,
    "credential_count": 0,
    "pii_count": 0,
    "missing_sources": ["<data points with unclear sources>"]
  }
}
```

## Extraction Rules
1. Every form field = at least one INPUT data point
2. Every API parameter = a data point (INPUT or DERIVED)
3. Every validation check implies an expected value = data point
4. Every decision branch condition = a STATE data point
5. Every output/report field = an OUTPUT data point
6. Credentials are ALWAYS flagged and NEVER have sample values with real data
7. PII fields are flagged based on content (names, emails, SSN, phone, address, DOB)
8. Reference file keys map to REFERENCE data points
9. Computed values (totals, averages, concatenations) = DERIVED data points
10. Data flowing between steps = STATE data points

## Critical: Be Exhaustive
- Parse every noun in every step description
- Check JSON reference files for field names
- Infer implicit data (e.g., "login" implies username + password)
- Include metadata fields (timestamps, audit trails, session IDs)
- Include error state data points (error_code, error_message, retry_count)
"""


def build_datapoint_agent(model: str = "claude-sonnet-4-20250514") -> LlmAgent:
    """Build the DataPointAgent for data extraction."""
    return LlmAgent(
        name="DataPointAgent",
        model=model,
        instruction=DATAPOINT_INSTRUCTION,
        description="Extracts all required data points, schemas, and dependencies",
        output_key="data_schema",
    )
