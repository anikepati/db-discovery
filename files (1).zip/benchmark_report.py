"""
BenchmarkReportGenerator — Auto-generated PDF + CSV Reports

Creates professional benchmark reports after each evolution run with:
- Executive summary
- Metric comparisons (before/after)
- Per-agent improvement breakdown
- Pareto frontier analysis
- Evolution trace charts
- Full CSV data export
"""

from __future__ import annotations

import csv
import io
import json
import os
from datetime import datetime
from pathlib import Path
from typing import Any

from core.gepa_adapter import (
    EvolutionTrace,
    FitnessResult,
    SystemGenome,
)


class BenchmarkReportGenerator:
    """Generates PDF and CSV benchmark reports from evolution results."""

    def __init__(self, output_dir: str = "exports"):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def generate_pdf_report(
        self,
        original_genome: SystemGenome,
        evolved_genome: SystemGenome,
        original_fitness: FitnessResult | None,
        evolved_fitness: FitnessResult,
        traces: list[EvolutionTrace],
        run_id: str = "",
        comparison: dict | None = None,
    ) -> str:
        """
        Generate a professional PDF benchmark report.

        Returns: Path to the generated PDF file.
        """
        try:
            from fpdf import FPDF
        except ImportError:
            return self._generate_text_report(
                original_genome, evolved_genome, original_fitness,
                evolved_fitness, traces, run_id, comparison
            )

        pdf = FPDF()
        pdf.set_auto_page_break(auto=True, margin=20)

        # --- Title Page ---
        pdf.add_page()
        pdf.set_font("Helvetica", "B", 24)
        pdf.cell(0, 20, "GEPA Forge", ln=True, align="C")
        pdf.set_font("Helvetica", "B", 16)
        pdf.cell(0, 10, "Evolution Benchmark Report", ln=True, align="C")
        pdf.set_font("Helvetica", "", 11)
        pdf.cell(0, 8, f"Run ID: {run_id}", ln=True, align="C")
        pdf.cell(0, 8, f"Generated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}", ln=True, align="C")
        pdf.ln(15)

        # --- Executive Summary ---
        pdf.set_font("Helvetica", "B", 14)
        pdf.cell(0, 10, "Executive Summary", ln=True)
        pdf.set_font("Helvetica", "", 10)

        orig_score = original_fitness.weighted_score() if original_fitness else 0.0
        evolved_score = evolved_fitness.weighted_score()
        improvement = ((evolved_score - orig_score) / max(orig_score, 0.001)) * 100

        summary_lines = [
            f"Total Generations: {len(traces)}",
            f"Population Size: {traces[0].population_size if traces else 'N/A'}",
            f"Original Weighted Score: {orig_score:.4f}",
            f"Evolved Weighted Score: {evolved_score:.4f}",
            f"Improvement: {improvement:+.1f}%",
            f"Final Pareto Front Size: {traces[-1].pareto_front_size if traces else 'N/A'}",
            f"Agents in System: {len(evolved_genome.agents)}",
        ]
        for line in summary_lines:
            pdf.cell(0, 6, f"  {line}", ln=True)
        pdf.ln(10)

        # --- Metric Comparison Table ---
        pdf.set_font("Helvetica", "B", 14)
        pdf.cell(0, 10, "Metric Comparison (Before vs After)", ln=True)

        # Table header
        col_widths = [50, 35, 35, 35]
        headers = ["Metric", "Original", "Evolved", "Change"]
        pdf.set_font("Helvetica", "B", 9)
        pdf.set_fill_color(240, 240, 240)
        for i, h in enumerate(headers):
            pdf.cell(col_widths[i], 8, h, border=1, fill=True, align="C")
        pdf.ln()

        # Table rows
        pdf.set_font("Helvetica", "", 9)
        orig_dict = original_fitness.as_dict() if original_fitness else {}
        evolved_dict = evolved_fitness.as_dict()

        for metric in ["accuracy", "cost", "latency", "compliance", "revenue_impact",
                        "tool_usage_efficiency", "delegation_quality"]:
            orig_val = orig_dict.get(metric, 0.0)
            evol_val = evolved_dict.get(metric, 0.0)
            change = evol_val - orig_val
            change_str = f"{change:+.4f}"

            pdf.cell(col_widths[0], 7, metric.replace("_", " ").title(), border=1)
            pdf.cell(col_widths[1], 7, f"{orig_val:.4f}", border=1, align="C")
            pdf.cell(col_widths[2], 7, f"{evol_val:.4f}", border=1, align="C")
            pdf.cell(col_widths[3], 7, change_str, border=1, align="C")
            pdf.ln()

        pdf.ln(10)

        # --- Per-Agent Changes ---
        if comparison and comparison.get("agents"):
            pdf.set_font("Helvetica", "B", 14)
            pdf.cell(0, 10, "Per-Agent Evolution Details", ln=True)

            for agent_info in comparison["agents"]:
                if agent_info.get("changed"):
                    pdf.set_font("Helvetica", "B", 10)
                    name = agent_info.get("name", "Unknown")
                    mutation = agent_info.get("mutation_applied", "")
                    pdf.cell(0, 7, f"Agent: {name} (mutation: {mutation})", ln=True)

                    pdf.set_font("Helvetica", "I", 8)
                    pdf.cell(0, 5, "Original instruction (preview):", ln=True)
                    pdf.set_font("Helvetica", "", 8)
                    orig_preview = agent_info.get("original_instruction", "")[:300]
                    pdf.multi_cell(0, 4, orig_preview)
                    pdf.ln(2)

                    pdf.set_font("Helvetica", "I", 8)
                    pdf.cell(0, 5, "Evolved instruction (preview):", ln=True)
                    pdf.set_font("Helvetica", "", 8)
                    evol_preview = agent_info.get("evolved_instruction", "")[:300]
                    pdf.multi_cell(0, 4, evol_preview)
                    pdf.ln(5)

        # --- Evolution Trace ---
        if traces:
            pdf.add_page()
            pdf.set_font("Helvetica", "B", 14)
            pdf.cell(0, 10, "Evolution Trace (Generation-by-Generation)", ln=True)

            col_widths_trace = [20, 30, 30, 30, 50]
            trace_headers = ["Gen", "Best", "Average", "Pareto Front", "Top Metric"]
            pdf.set_font("Helvetica", "B", 9)
            pdf.set_fill_color(240, 240, 240)
            for i, h in enumerate(trace_headers):
                pdf.cell(col_widths_trace[i], 8, h, border=1, fill=True, align="C")
            pdf.ln()

            pdf.set_font("Helvetica", "", 9)
            for trace in traces:
                top_metric = max(trace.fitness_breakdown, key=trace.fitness_breakdown.get) if trace.fitness_breakdown else "N/A"
                top_val = trace.fitness_breakdown.get(top_metric, 0) if trace.fitness_breakdown else 0
                pdf.cell(col_widths_trace[0], 7, str(trace.generation), border=1, align="C")
                pdf.cell(col_widths_trace[1], 7, f"{trace.best_fitness:.4f}", border=1, align="C")
                pdf.cell(col_widths_trace[2], 7, f"{trace.avg_fitness:.4f}", border=1, align="C")
                pdf.cell(col_widths_trace[3], 7, str(trace.pareto_front_size), border=1, align="C")
                pdf.cell(col_widths_trace[4], 7, f"{top_metric}: {top_val:.3f}", border=1, align="C")
                pdf.ln()

        # Save
        filename = f"benchmark_report_{run_id or datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.pdf"
        filepath = self.output_dir / filename
        pdf.output(str(filepath))
        return str(filepath)

    def generate_csv_export(
        self,
        traces: list[EvolutionTrace],
        evolved_fitness: FitnessResult,
        run_id: str = "",
    ) -> str:
        """
        Export evolution data as CSV.

        Returns: Path to the generated CSV file.
        """
        filename = f"evolution_data_{run_id or datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.csv"
        filepath = self.output_dir / filename

        with open(filepath, "w", newline="") as f:
            writer = csv.writer(f)

            # Generation traces
            writer.writerow(["=== Generation Traces ==="])
            writer.writerow(["Generation", "Best Fitness", "Avg Fitness", "Pareto Front Size",
                             "Accuracy", "Cost", "Latency", "Compliance", "Revenue Impact",
                             "Tool Efficiency", "Delegation Quality", "Timestamp"])

            for trace in traces:
                fb = trace.fitness_breakdown or {}
                writer.writerow([
                    trace.generation, trace.best_fitness, trace.avg_fitness,
                    trace.pareto_front_size,
                    fb.get("accuracy", ""), fb.get("cost", ""), fb.get("latency", ""),
                    fb.get("compliance", ""), fb.get("revenue_impact", ""),
                    fb.get("tool_usage_efficiency", ""), fb.get("delegation_quality", ""),
                    trace.timestamp,
                ])

            writer.writerow([])
            writer.writerow(["=== Final Fitness Scores ==="])
            for k, v in evolved_fitness.as_dict().items():
                writer.writerow([k, v])

            # Test case results
            if evolved_fitness.test_case_results:
                writer.writerow([])
                writer.writerow(["=== Test Case Results ==="])
                if evolved_fitness.test_case_results:
                    keys = list(evolved_fitness.test_case_results[0].keys())
                    writer.writerow(keys)
                    for tc_result in evolved_fitness.test_case_results:
                        writer.writerow([tc_result.get(k, "") for k in keys])

        return str(filepath)

    def _generate_text_report(
        self,
        original_genome: SystemGenome,
        evolved_genome: SystemGenome,
        original_fitness: FitnessResult | None,
        evolved_fitness: FitnessResult,
        traces: list[EvolutionTrace],
        run_id: str = "",
        comparison: dict | None = None,
    ) -> str:
        """Fallback text report when fpdf2 is not available."""
        filename = f"benchmark_report_{run_id or datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.txt"
        filepath = self.output_dir / filename

        lines = [
            "=" * 70,
            "GEPA Forge — Evolution Benchmark Report",
            "=" * 70,
            f"Run ID: {run_id}",
            f"Generated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}",
            "",
            "--- Executive Summary ---",
            f"Generations: {len(traces)}",
            f"Original Score: {original_fitness.weighted_score() if original_fitness else 'N/A'}",
            f"Evolved Score: {evolved_fitness.weighted_score()}",
            "",
            "--- Metric Comparison ---",
        ]

        orig_dict = original_fitness.as_dict() if original_fitness else {}
        for metric, val in evolved_fitness.as_dict().items():
            orig_val = orig_dict.get(metric, 0.0)
            lines.append(f"  {metric:30s}  {orig_val:.4f} → {val:.4f}  ({val - orig_val:+.4f})")

        if traces:
            lines.append("")
            lines.append("--- Generation Trace ---")
            for t in traces:
                lines.append(f"  Gen {t.generation:3d}: best={t.best_fitness:.4f}  avg={t.avg_fitness:.4f}  pareto={t.pareto_front_size}")

        with open(filepath, "w") as f:
            f.write("\n".join(lines))

        return str(filepath)
