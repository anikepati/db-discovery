"""
QA Pipeline - Question Definitions
Centralized registry of all 10 QA questions, their logic, and dependencies.

Modify this file to customize the QA questions for your specific process.
"""

from dataclasses import dataclass, field


@dataclass
class QuestionDefinition:
    """Defines a single QA question in the chain."""
    number: int
    title: str
    question: str
    depends_on: list[int]
    evaluation_criteria: str
    expected_output_format: str


# ─────────────────────────────────────────────
# QA Question Registry
# Questions are designed in a progressive reasoning chain where
# later questions build on earlier answers.
# ─────────────────────────────────────────────

QA_QUESTIONS: list[QuestionDefinition] = [

    QuestionDefinition(
        number=1,
        title="Process Status & Eligibility",
        question=(
            "What is the current status of the process, and is it eligible for QA review? "
            "Evaluate the process status, environment, version, and operational readiness. "
            "Is it in a state that warrants a full QA evaluation, or should it be deferred?"
        ),
        depends_on=[],
        evaluation_criteria=(
            "Check: process status (active/inactive/pending), environment (production vs staging), "
            "version stability, owner assignment, and business unit registration."
        ),
        expected_output_format=(
            "State the process status clearly. Declare ELIGIBLE or DEFERRED with justification."
        ),
    ),

    QuestionDefinition(
        number=2,
        title="Applicable Compliance Framework & Obligations",
        question=(
            "Based on the process status and operational context from Q1, which compliance "
            "frameworks and regulatory obligations apply to this process? "
            "What are the minimum compliance thresholds that must be met?"
        ),
        depends_on=[1],
        evaluation_criteria=(
            "Identify the compliance framework (SOX, GDPR, ISO27001, etc.), "
            "applicable certifications, minimum score thresholds, and any active exceptions."
        ),
        expected_output_format=(
            "List the applicable frameworks and their minimum thresholds. "
            "Note any exceptions or exemptions."
        ),
    ),

    QuestionDefinition(
        number=3,
        title="Compliance Score Evaluation",
        question=(
            "Using the compliance framework obligations identified in Q2, evaluate the current "
            "compliance score of the process. Does it meet the minimum threshold? "
            "What are the specific compliance gaps and open findings?"
        ),
        depends_on=[1, 2],
        evaluation_criteria=(
            "Compare actual compliance score against framework minimums from Q2. "
            "Enumerate open findings by severity. Flag critical findings individually."
        ),
        expected_output_format=(
            "COMPLIANT / NON-COMPLIANT declaration. Score vs threshold. "
            "List of critical and high findings."
        ),
    ),

    QuestionDefinition(
        number=4,
        title="Risk Assessment & Severity Classification",
        question=(
            "Based on the process context (Q1) and compliance status (Q3), assess the risk "
            "profile of this process. Are the existing mitigating controls adequate given the "
            "inherent and residual risk levels? Are there unmitigated risks?"
        ),
        depends_on=[1, 3],
        evaluation_criteria=(
            "Evaluate inherent vs residual risk, risk score, risk categories, "
            "adequacy of mitigating controls, and any unaddressed risk vectors."
        ),
        expected_output_format=(
            "Risk rating: ACCEPTABLE / ELEVATED / CRITICAL. "
            "List control gaps and unmitigated risks."
        ),
    ),

    QuestionDefinition(
        number=5,
        title="Security Controls Assessment",
        question=(
            "Given the data classification and risk level (Q4), evaluate the security posture "
            "of this process. Are encryption, access control, MFA, and vulnerability management "
            "controls appropriate for the data sensitivity?"
        ),
        depends_on=[4],
        evaluation_criteria=(
            "Assess: encryption at rest & in transit vs data classification, "
            "MFA enforcement, open vulnerabilities (especially critical), "
            "pen test recency, and privileged access user count."
        ),
        expected_output_format=(
            "Security posture: STRONG / ADEQUATE / INADEQUATE / CRITICAL. "
            "List specific security deficiencies."
        ),
    ),

    QuestionDefinition(
        number=6,
        title="Performance & SLA Compliance",
        question=(
            "Evaluate the operational performance of the process against its SLA commitments. "
            "Are SLA breach counts, error rates, and availability within acceptable thresholds "
            "given the business criticality and risk profile identified in Q4?"
        ),
        depends_on=[1, 4],
        evaluation_criteria=(
            "Compare avg completion time vs SLA threshold, SLA breach count, "
            "error rate (threshold: <5% for standard, <1% for high-risk), "
            "and availability (threshold: >99.5% for critical, >98% for standard)."
        ),
        expected_output_format=(
            "Performance verdict: MEETING SLA / SLA AT RISK / SLA FAILING. "
            "List breached metrics with actual vs target values."
        ),
    ),

    QuestionDefinition(
        number=7,
        title="Audit Trail & Policy Violation Analysis",
        question=(
            "Analyze the audit trail for signs of unauthorized activity, policy violations, "
            "and governance failures. Given the compliance gaps (Q3) and security posture (Q5), "
            "do the audit findings indicate systemic control failures or isolated incidents?"
        ),
        depends_on=[3, 5],
        evaluation_criteria=(
            "Evaluate: unauthorized access attempts, policy violations in 90 days, "
            "change volume vs expected, recent audit findings, and patterns suggesting "
            "systemic vs isolated issues."
        ),
        expected_output_format=(
            "Audit verdict: CLEAN / MINOR CONCERNS / SIGNIFICANT CONCERNS / SYSTEMIC FAILURE. "
            "Distinguish systemic from isolated issues."
        ),
    ),

    QuestionDefinition(
        number=8,
        title="Aggregated Risk & Violation Summary",
        question=(
            "Synthesize findings from compliance (Q3), risk (Q4), security (Q5), "
            "performance (Q6), and audit (Q7) into a consolidated violation summary. "
            "What is the total impact and which issues are blocking vs non-blocking?"
        ),
        depends_on=[3, 4, 5, 6, 7],
        evaluation_criteria=(
            "Categorize all identified issues as: BLOCKING (must be resolved before approval) "
            "vs NON-BLOCKING (must be tracked but don't prevent approval). "
            "Assign overall impact score."
        ),
        expected_output_format=(
            "BLOCKING issues list. NON-BLOCKING issues list. "
            "Aggregate impact: LOW / MEDIUM / HIGH / CRITICAL."
        ),
    ),

    QuestionDefinition(
        number=9,
        title="Remediation Plan & Timeline",
        question=(
            "Based on the blocking and non-blocking violations from Q8, propose a prioritized "
            "remediation plan. What actions must be taken, by whom, and within what timeframe "
            "to bring this process into compliance and reduce risk to acceptable levels?"
        ),
        depends_on=[8],
        evaluation_criteria=(
            "Each remediation action should be: specific, measurable, assigned to a role, "
            "time-bound, and prioritized (P1/P2/P3). "
            "Critical security issues: <7 days. Compliance gaps: <30 days. "
            "Performance improvements: <90 days."
        ),
        expected_output_format=(
            "Prioritized action list: P1 (immediate), P2 (short-term), P3 (long-term). "
            "Each with: action, owner role, and deadline."
        ),
    ),

    QuestionDefinition(
        number=10,
        title="Final QA Verdict & Next Steps",
        question=(
            "Based on all prior analysis (Q1-Q9), deliver the final QA verdict for this process. "
            "Is it PASS, CONDITIONAL PASS, FAIL, or REQUIRES ESCALATION? "
            "Provide the definitive recommendation and executive summary."
        ),
        depends_on=[1, 2, 3, 4, 5, 6, 7, 8, 9],
        evaluation_criteria=(
            "PASS: No blocking issues, minor non-blocking items tracked. "
            "CONDITIONAL PASS: Non-critical blocking items with remediation plan accepted. "
            "FAIL: Critical blocking items unresolved. "
            "REQUIRES ESCALATION: Systemic failures, regulatory risk, or ambiguous critical findings."
        ),
        expected_output_format=(
            "VERDICT: [PASS|CONDITIONAL PASS|FAIL|REQUIRES ESCALATION]. "
            "Score: X/100. "
            "Executive summary (3-5 sentences). "
            "Top 3 next steps."
        ),
    ),
]


# Quick lookup by question number
QUESTION_MAP: dict[int, QuestionDefinition] = {q.number: q for q in QA_QUESTIONS}
