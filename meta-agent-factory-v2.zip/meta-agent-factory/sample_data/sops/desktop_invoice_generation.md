# SOP: Monthly Invoice Generation in Desktop Billing Application

## Version: 1.3
## Domain: Finance / Billing
## Last Updated: 2025-05-20

## Prerequisites
- BillingPro Desktop Application installed (v4.2+)
- Database connection configured
- User has "Invoice Manager" role
- Customer billing data up to date in the system

## Procedure

### Step 1: Launch Application
1. Double-click the "BillingPro" icon on the desktop
2. Wait for the splash screen to complete loading
3. **Expected**: Login dialog appears

### Step 2: Authenticate
1. Enter username in the "User ID" field
2. Enter password in the "Password" field
3. Select "Production" from the "Environment" dropdown
4. Click the "Login" button
5. **Expected**: Main application window opens with menu bar visible

### Step 3: Open Invoice Generator
1. Click "Tools" in the menu bar
2. Hover over "Billing" in the dropdown menu
3. Click "Invoice Generator" from the submenu
4. Wait for Invoice Generator dialog to load
5. **Expected**: Invoice Generator window opens with date range fields

### Step 4: Set Date Range
1. Click on "Start Date" field
2. Type the first day of the billing month (MM/DD/YYYY format)
3. Press Tab to move to "End Date" field
4. Type the last day of the billing month (MM/DD/YYYY format)
5. **Validation**: End date must be after start date

### Step 5: Select Customer Segment
1. Click "Customer Segment" dropdown
2. Select the target segment (All / Enterprise / SMB / Individual)
3. If "Enterprise" selected, additional filter dialog appears:
   - Select industry from "Industry" dropdown
   - Select region from "Region" dropdown
   - Click "Apply Filters"

### Step 6: Configure Invoice Options
1. Check "Include line item details" checkbox
2. Check "Apply applicable discounts" checkbox
3. Select "PDF" from "Output Format" dropdown
4. Enter output directory path in "Save To" field
5. Check "Send email notification" if auto-send is required
6. **Note**: For amounts over $10,000, "Manager Approval" checkbox auto-enables

### Step 7: Generate Invoices
1. Click "Generate" button
2. Progress bar appears showing generation status
3. Wait for generation to complete (may take 5-15 minutes for large batches)
4. **Expected**: "Generation Complete" dialog shows with summary:
   - Total invoices generated
   - Total amount
   - Any errors/skipped records

### Step 8: Review Generated Invoices
1. Click "View Report" button in the completion dialog
2. Review the summary report in the built-in viewer
3. Scroll through the list to check for anomalies
4. Right-click any invoice row to "Preview" individual invoice
5. **Validation**: Spot-check at least 3 random invoices for accuracy

### Step 9: Approve and Send
1. Click "Approve All" button (requires manager credentials if amounts > $10,000)
2. If approval dialog appears:
   - Enter manager username
   - Enter manager password
   - Click "Authorize"
3. Click "Send Invoices" button
4. Confirm in the "Are you sure?" dialog by clicking "Yes"
5. **Expected**: "Invoices Sent Successfully" message

### Step 10: Export Summary
1. Press Ctrl+E to open export dialog
2. Select "CSV" format
3. Enter filename: "invoice_summary_YYYYMM.csv"
4. Click "Export"
5. Close the Invoice Generator window

## Error Handling
- If application freezes during generation, press Ctrl+Alt+Del and force restart
- If email sending fails, export invoice PDFs and send manually
- If database connection drops, wait 30 seconds and retry

## Output
- Generated invoice PDFs in the specified output directory
- Invoice summary CSV file
- Email notifications sent to customers (if enabled)
- Audit log entry in BillingPro system
