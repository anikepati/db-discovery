"""
yaml_runtime.py
---------------
Secure execution engine for YAML-defined tools.

Extends the AgentMCP pattern with one new tool type:

  edr_state  — read/write the per-run RunState shared in-memory dict.
               Allows YAML tools to store answers, edr_data, and
               metadata without any external persistence layer.

Original types retained:
  http_api   — REST API calls via httpx  (e.g. Actimize REST)
  sql        — Parameterised DB queries via SQLAlchemy  (e.g. Actimize DB)
  python     — Sandboxed Python via RestrictedPython  (computation/parsing)

RunState injection:
  YAMLFunctionRuntime is created with an optional run_state parameter.
  When present, edr_state tools read/write that shared dict.
  All other tool types remain stateless and unaware of run_state.
"""

import os
import yaml
import json
import httpx
import sqlalchemy
import asyncio
from typing import Any
from jinja2 import sandbox as jinja_sandbox
from dotenv import load_dotenv

load_dotenv()

# ── RestrictedPython setup ────────────────────────────────────────────────────
try:
    import RestrictedPython
    RESTRICTED_AVAILABLE = True

    SAFE_BUILTINS = RestrictedPython.safe_builtins.copy()
    SAFE_BUILTINS.update({
        "len": len, "range": range, "enumerate": enumerate,
        "zip": zip, "map": map, "filter": filter,
        "sum": sum, "min": min, "max": max, "round": round,
        "list": list, "dict": dict, "set": set, "tuple": tuple,
        "str": str, "int": int, "float": float, "bool": bool,
        "sorted": sorted, "reversed": reversed,
        "isinstance": isinstance, "type": type,
        "abs": abs, "any": any, "all": all,
        "print": print,
    })
except ImportError:
    RESTRICTED_AVAILABLE = False

ALLOWED_IMPORTS = {
    "json", "statistics", "math", "datetime",
    "re", "collections", "itertools", "functools",
}


class YAMLFunctionRuntime:
    """
    Executes YAML-defined tools securely.

    Args:
        yaml_path:  Path to the YAML tool definition file.
        run_state:  Optional RunState instance — required for edr_state tools.
                    Injected by tool_registry so all agents in a run share
                    the same state object.
    """

    def __init__(self, yaml_path: str, run_state=None) -> None:
        with open(yaml_path) as f:
            raw = yaml.safe_load(f)

        self.registry: dict[str, dict] = {
            fn["id"]: fn for fn in raw["functions"]
        }
        self.run_state = run_state  # May be None for stateless tool sets

        # Secrets from env only — never from YAML or MCP messages
        self.secrets: dict[str, str] = {k: v for k, v in os.environ.items() if v}

        # Sandboxed Jinja2 — blocks os/subprocess/file access in templates
        self.jinja = jinja_sandbox.SandboxedEnvironment()

    # ── Input resolution ──────────────────────────────────────────────────────

    def _resolve(self, template: Any, ctx: dict) -> str:
        return self.jinja.from_string(str(template)).render(
            inputs=ctx.get("inputs", {}),
            secrets=self.secrets,
        )

    def _resolve_inputs(self, fn_def: dict, raw_inputs: dict) -> dict:
        resolved = {}
        for name, schema in fn_def.get("inputs", {}).items():
            if name in raw_inputs:
                resolved[name] = raw_inputs[name]
            elif "default" in schema:
                resolved[name] = schema["default"]
            elif schema.get("required", False):
                raise ValueError(
                    f"[{fn_def['id']}] Missing required input: '{name}'"
                )
        return resolved

    # ── Public execute ────────────────────────────────────────────────────────

    def execute(self, function_id: str, inputs: dict) -> Any:
        """Execute a YAML-defined tool by ID. Thread-safe."""
        fn = self.registry.get(function_id)
        if not fn:
            raise ValueError(f"Unknown function: '{function_id}'")

        inputs = self._resolve_inputs(fn, inputs)
        ctx    = {"inputs": inputs}
        fn_type = fn["type"]

        if fn_type == "http_api":
            return self._run_http(fn["config"], ctx)
        elif fn_type == "sql":
            return self._run_sql(fn["config"], ctx)
        elif fn_type == "python":
            return self._run_python(fn["python"], inputs)
        elif fn_type == "edr_state":
            return self._run_edr_state(fn["state"], inputs)
        else:
            raise ValueError(f"Unsupported tool type: '{fn_type}'")

    # ── HTTP executor (unchanged from AgentMCP) ───────────────────────────────

    def _run_http(self, config: dict, ctx: dict) -> Any:
        url     = self._resolve(config["url"], ctx)
        method  = config.get("method", "GET").upper()
        params  = {k: self._resolve(v, ctx) for k, v in config.get("params",  {}).items()}
        headers = {k: self._resolve(v, ctx) for k, v in config.get("headers", {}).items()}
        body    = {k: self._resolve(v, ctx) for k, v in config.get("body",    {}).items()} or None

        with httpx.Client(timeout=30) as client:
            resp = client.request(method, url, params=params, headers=headers, json=body)
            resp.raise_for_status()
            return resp.json()

    # ── SQL executor (unchanged from AgentMCP) ────────────────────────────────

    def _run_sql(self, config: dict, ctx: dict) -> list[dict]:
        conn_str = self._resolve(config["connection"], ctx)
        query    = config["query"]
        bound    = {k: self._resolve(v, ctx) for k, v in config.get("params", {}).items()}

        engine = sqlalchemy.create_engine(conn_str)
        with engine.connect() as conn:
            result = conn.execute(sqlalchemy.text(query), bound)
            return [dict(row._mapping) for row in result]

    # ── Python executor (unchanged from AgentMCP) ─────────────────────────────

    def _run_python(self, python_def: dict, inputs: dict) -> Any:
        if not RESTRICTED_AVAILABLE:
            raise RuntimeError("RestrictedPython not installed.")

        code     = python_def["code"]
        compiled = RestrictedPython.compile_restricted(code, "<yaml_tool>", "exec")

        def _safe_import(name, *args, **kwargs):
            if name not in ALLOWED_IMPORTS:
                raise ImportError(
                    f"Import '{name}' not allowed. Allowed: {sorted(ALLOWED_IMPORTS)}"
                )
            return __import__(name, *args, **kwargs)

        local_ns = {"inputs": inputs, "result": None}
        global_ns = {
            "__builtins__": SAFE_BUILTINS,
            "__import__":   _safe_import,
            "_print_":      RestrictedPython.PrintCollector,
            "_getiter_":    iter,
            "_getattr_":    getattr,
            "_inplacevar_": RestrictedPython.Guards.guarded_inplacevar,
        }

        exec(compiled, global_ns, local_ns)  # noqa: S102

        if local_ns.get("result") is None:
            raise ValueError("Python tool did not assign to `result`.")

        return local_ns["result"]

    # ── EDR State executor (NEW — EDR-specific) ───────────────────────────────

    def _run_edr_state(self, state_def: dict, inputs: dict) -> Any:
        """
        Read or write the per-run RunState shared dict.

        YAML state block supports:
          operation: get          → return value at key
          operation: set          → write inputs[value_field] to key
          operation: merge        → merge dict into existing key
          operation: get_answers  → return all answers dict
          operation: set_answer   → store a full answer record under answers.qN

        Key supports Jinja2 templating against inputs:
          key: "answers.q{{ inputs.question_number }}"
        """
        if self.run_state is None:
            raise RuntimeError(
                "edr_state tool called but no RunState was injected. "
                "Ensure tool_registry passes run_state to YAMLFunctionRuntime."
            )

        operation = state_def["operation"]
        raw_key   = state_def.get("key", "")

        # Resolve key template against inputs (e.g. "answers.q3")
        key = self.jinja.from_string(raw_key).render(inputs=inputs) if raw_key else ""

        if operation == "get":
            value = self.run_state.get(key)
            return {"key": key, "value": value, "found": value is not None}

        elif operation == "set":
            value_field = state_def.get("value_field", "value")
            value = inputs.get(value_field, inputs)
            self.run_state.set(key, value)
            return {"key": key, "stored": True}

        elif operation == "merge":
            value_field = state_def.get("value_field", "data")
            value = inputs.get(value_field, {})
            if isinstance(value, dict):
                self.run_state.merge(key, value)
            else:
                self.run_state.set(key, value)
            return {"key": key, "merged": True}

        elif operation == "get_answers":
            answers = self.run_state.get("answers") or {}
            return {"answers": answers, "count": len(answers)}

        elif operation == "set_answer":
            # Store a full structured answer record for one question
            q_num   = int(inputs["question_number"])
            q_key   = f"answers.q{q_num}"
            record  = {
                "question_number": q_num,
                "answer":          inputs.get("answer", "NEEDS_HUMAN"),
                "reasoning":       inputs.get("reasoning", ""),
                "requires_human":  inputs.get("requires_human", False),
                "human_action":    inputs.get("human_action", ""),
                "category":        inputs.get("category", ""),
            }
            self.run_state.set(q_key, record)
            return {"question_number": q_num, "stored": True, "answer": record["answer"]}

        elif operation == "get_edr_data":
            edr = self.run_state.get("edr_data") or {}
            return {"edr_data": edr, "found": bool(edr)}

        elif operation == "set_edr_data":
            edr_data = inputs.get("edr_data", inputs)
            self.run_state.set("edr_data", edr_data)
            return {"stored": True, "ecn_id": edr_data.get("ecn_id", "unknown")}

        elif operation == "snapshot":
            return self.run_state.snapshot()

        else:
            raise ValueError(f"Unknown edr_state operation: '{operation}'")
