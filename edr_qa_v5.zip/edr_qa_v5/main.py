"""
EDR QA Pipeline v5 — CLI.

Usage:
    python main.py --ecn-id ECN-2024-001
    python main.py --ecn-id ECN-2024-002 --output result.json --quiet
    python main.py --concurrent          # all 3 demo ECNs concurrently
    python main.py --generate-skills     # regenerate all SKILL.md files
    python main.py --check-skills        # verify all SKILL.md files exist
"""

import argparse
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from config import settings, configure_logging
from pipeline_runner import PipelineRunner

DEMO_ECNS = ["ECN-2024-001", "ECN-2024-002", "ECN-2024-003"]


def _args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="EDR QA Pipeline v5")
    p.add_argument("--ecn-id",         default=None,        help="ECN to evaluate")
    p.add_argument("--output",         default=None,        help="Output JSON path")
    p.add_argument("--quiet",          action="store_true", help="Suppress per-agent output")
    p.add_argument("--concurrent",     action="store_true", help="Run 3 demo ECNs concurrently")
    p.add_argument("--generate-skills",action="store_true", help="Regenerate all SKILL.md files from questions.py")
    p.add_argument("--check-skills",   action="store_true", help="Verify all SKILL.md files exist")
    return p.parse_args()


async def run_single(ecn_id: str, output: str | None, quiet: bool) -> int:
    result = await PipelineRunner().run(ecn_id=ecn_id, output_path=output, verbose=not quiet)
    return 0 if result.passed else 2


async def run_concurrent(quiet: bool) -> int:
    print("\n🚀  Launching concurrent runs for all 3 demo ECNs…\n")
    results = await asyncio.gather(*[
        PipelineRunner().run(ecn_id=ecn, verbose=not quiet)
        for ecn in DEMO_ECNS
    ], return_exceptions=True)
    print(f"\n{'═' * 50}\n  CONCURRENT RESULTS\n{'═' * 50}")
    exit_code = 0
    for ecn, res in zip(DEMO_ECNS, results):
        if isinstance(res, Exception):
            print(f"  ❌  {ecn}: FAILED — {res}")
            exit_code = 1
        else:
            icon = "✅" if res.passed else ("👤" if "HUMAN" in res.verdict.value else "❌")
            print(f"  {icon}  {ecn}: {res.verdict.value} ({res.overall_pass_rate:.1f}%)")
            if not res.passed:
                exit_code = 2
    print()
    return exit_code


async def main() -> int:
    args = _args()

    if args.generate_skills:
        from skill_generator import generate_all
        generate_all()
        return 0

    if args.check_skills:
        from skill_generator import check_all
        return 0 if check_all() else 1

    try:
        settings.validate()
    except ValueError as e:
        print(f"\n❌  Config error: {e}\n", file=sys.stderr)
        return 1

    configure_logging()

    try:
        if args.concurrent:
            return await run_concurrent(args.quiet)
        elif args.ecn_id:
            return await run_single(args.ecn_id, args.output, args.quiet)
        else:
            print("❌  Provide --ecn-id <ECN> or --concurrent\n", file=sys.stderr)
            return 1
    except KeyboardInterrupt:
        print("\n⏹  Interrupted.\n")
        return 130


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
