from .config_loader import MAFConfig

__all__ = ["MAFConfig"]
