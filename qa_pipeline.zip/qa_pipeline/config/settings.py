"""
QA Pipeline - Configuration Settings
Production-grade configuration with environment variable support.
"""

import os
from dataclasses import dataclass, field
from typing import Optional
from dotenv import load_dotenv

load_dotenv()


@dataclass
class DatabaseConfig:
    host: str = field(default_factory=lambda: os.getenv("DB_HOST", "localhost"))
    port: int = field(default_factory=lambda: int(os.getenv("DB_PORT", "5432")))
    database: str = field(default_factory=lambda: os.getenv("DB_NAME", "qa_pipeline"))
    username: str = field(default_factory=lambda: os.getenv("DB_USER", "qa_user"))
    password: str = field(default_factory=lambda: os.getenv("DB_PASSWORD", ""))
    pool_size: int = field(default_factory=lambda: int(os.getenv("DB_POOL_SIZE", "5")))
    max_overflow: int = field(default_factory=lambda: int(os.getenv("DB_MAX_OVERFLOW", "10")))

    @property
    def connection_string(self) -> str:
        return (
            f"postgresql+asyncpg://{self.username}:{self.password}"
            f"@{self.host}:{self.port}/{self.database}"
        )


@dataclass
class AgentConfig:
    model: str = field(default_factory=lambda: os.getenv("AGENT_MODEL", "gemini-2.0-flash"))
    max_retries: int = field(default_factory=lambda: int(os.getenv("AGENT_MAX_RETRIES", "3")))
    retry_delay: float = field(default_factory=lambda: float(os.getenv("AGENT_RETRY_DELAY", "2.0")))
    timeout_seconds: int = field(default_factory=lambda: int(os.getenv("AGENT_TIMEOUT", "120")))
    temperature: float = field(default_factory=lambda: float(os.getenv("AGENT_TEMPERATURE", "0.1")))


@dataclass
class AppConfig:
    app_name: str = field(default_factory=lambda: os.getenv("APP_NAME", "qa_pipeline"))
    environment: str = field(default_factory=lambda: os.getenv("ENVIRONMENT", "development"))
    log_level: str = field(default_factory=lambda: os.getenv("LOG_LEVEL", "INFO"))
    log_dir: str = field(default_factory=lambda: os.getenv("LOG_DIR", "logs"))
    google_api_key: Optional[str] = field(default_factory=lambda: os.getenv("GOOGLE_API_KEY"))
    enable_audit_trail: bool = field(default_factory=lambda: os.getenv("ENABLE_AUDIT", "true").lower() == "true")
    session_ttl_hours: int = field(default_factory=lambda: int(os.getenv("SESSION_TTL_HOURS", "24")))

    def validate(self) -> None:
        if not self.google_api_key:
            raise ValueError(
                "GOOGLE_API_KEY environment variable is required. "
                "Set it in your .env file or environment."
            )

    @property
    def is_production(self) -> bool:
        return self.environment.lower() == "production"


# Singleton instances
db_config = DatabaseConfig()
agent_config = AgentConfig()
app_config = AppConfig()
