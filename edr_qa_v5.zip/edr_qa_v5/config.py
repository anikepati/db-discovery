"""Configuration and logging for EDR QA v5."""

import json
import logging
import logging.handlers
import os
import sys
from dataclasses import dataclass, field
from datetime import datetime, timezone

from dotenv import load_dotenv

load_dotenv()


@dataclass(frozen=True)
class Settings:
    anthropic_api_key: str = field(default_factory=lambda: os.getenv("ANTHROPIC_API_KEY", ""))
    claude_model:      str = field(default_factory=lambda: os.getenv("CLAUDE_MODEL", "claude-sonnet-4-6"))
    google_api_key:    str = field(default_factory=lambda: os.getenv("GOOGLE_API_KEY", ""))
    adk_model:         str = field(default_factory=lambda: os.getenv("ADK_MODEL", "gemini-2.0-flash"))

    # MS SQL — Actimize
    mssql_conn: str = field(default_factory=lambda: os.getenv("MSSQL_CONN", ""))

    # App
    app_name:    str   = field(default_factory=lambda: os.getenv("APP_NAME",    "edr_qa"))
    environment: str   = field(default_factory=lambda: os.getenv("ENVIRONMENT", "development"))
    log_level:   str   = field(default_factory=lambda: os.getenv("LOG_LEVEL",   "INFO"))
    log_dir:     str   = field(default_factory=lambda: os.getenv("LOG_DIR",     "logs"))
    audit_dir:   str   = field(default_factory=lambda: os.getenv("AUDIT_DIR",   "audit"))
    outputs_dir: str   = field(default_factory=lambda: os.getenv("OUTPUTS_DIR", "outputs"))
    max_retries: int   = field(default_factory=lambda: int(os.getenv("MAX_RETRIES",  "3")))
    retry_delay: float = field(default_factory=lambda: float(os.getenv("RETRY_DELAY", "2.0")))

    def validate(self) -> None:
        missing = [k for k, v in [
            ("ANTHROPIC_API_KEY", self.anthropic_api_key),
            ("GOOGLE_API_KEY",    self.google_api_key),
        ] if not v]
        if missing:
            raise ValueError(f"Missing required env vars: {', '.join(missing)}")
        if not self.mssql_conn:
            print("⚠️  MSSQL_CONN not set — will use mock data (dev mode)")

    @property
    def is_production(self) -> bool:
        return self.environment.lower() == "production"


settings = Settings()


class _JSON(logging.Formatter):
    def format(self, r: logging.LogRecord) -> str:
        p = {"ts": datetime.now(timezone.utc).isoformat(),
             "level": r.levelname, "logger": r.name, "msg": r.getMessage()}
        for k in ("run_id", "ecn_id", "agent"):
            if hasattr(r, k):
                p[k] = getattr(r, k)
        if r.exc_info:
            p["exc"] = self.formatException(r.exc_info)
        return json.dumps(p)


class _Console(logging.Formatter):
    _C = {"DEBUG": "\033[36m", "INFO": "\033[32m", "WARNING": "\033[33m",
          "ERROR": "\033[31m", "CRITICAL": "\033[35m", "RESET": "\033[0m"}

    def format(self, r: logging.LogRecord) -> str:
        c, rst = self._C.get(r.levelname, ""), self._C["RESET"]
        ts = datetime.now().strftime("%H:%M:%S")
        extras = " ".join(f"{k}={getattr(r, k)}"
                         for k in ("run_id", "ecn_id", "agent")
                         if hasattr(r, k))
        return (f"{c}{ts} {r.levelname:<8}{rst} {r.name:<28} {r.getMessage()}"
                + (f"  [{extras}]" if extras else ""))


def configure_logging() -> None:
    os.makedirs(settings.log_dir, exist_ok=True)
    level = getattr(logging, settings.log_level.upper(), logging.INFO)
    root  = logging.getLogger()
    root.setLevel(logging.DEBUG)
    root.handlers.clear()

    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(level)
    ch.setFormatter(_JSON() if settings.is_production else _Console())
    root.addHandler(ch)

    fh = logging.handlers.RotatingFileHandler(
        os.path.join(settings.log_dir, f"{settings.app_name}.log"),
        maxBytes=50 * 1024 * 1024, backupCount=5, encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(_JSON())
    root.addHandler(fh)

    for name in ("httpx", "httpcore", "google", "urllib3"):
        logging.getLogger(name).setLevel(logging.WARNING)
