# Q07 Full Reference — Level 2 Review

## Question

Validate the decision rationale is reasonable based on the details of the event description.

## Validation

Assess if L2 rationale aligns to recommended action and event description.

## Check Logic (apply exactly)

If l2_decision = 'Accept': l2_rationale should align to l1_recommended_action. If l2_decision = 'Amend': l2_rationale should explain the amendment reason. If aligned: Y. Else: N.

## Depends On

Q05, Q06

## Output Hint

Confirm l2_rationale aligns with event_description and l1_recommended_action. Answer Y or N.

## Requires Human Review

No — answer should be Y, N, or N/A only.

## DB Fields

- `l2_decision`
- `l2_rationale`
- `l1_recommended_action`
- `event_description`

## Authorization Grid (relevant for Q2, Q3, Q5, Q8)

See `skills/edr-ingest/references/schema.md` for the full authorization grid
mapping EDR type + brokerage type → authorized recommending groups.
