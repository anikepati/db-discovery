"""
Action Dispatcher — routes actions from decision tree outcomes.

Each action type is a pluggable handler. Add new action types
(email, slack, webhook) by registering a handler — zero engine changes.
"""

import logging
from typing import Any, Callable, Dict, Optional

from models.schemas import ActionBranch

logger = logging.getLogger(__name__)

# Type alias
RowData = Dict[str, Any]
ActionHandler = Callable[[ActionBranch, RowData, str, dict], dict]


class ActionDispatcher:
    """Dispatches actions to registered handlers."""

    def __init__(self, dry_run: bool = False):
        self.dry_run = dry_run
        self._handlers: Dict[str, ActionHandler] = {}
        self._register_defaults()

    def register_handler(self, action_type: str, handler: ActionHandler):
        """Register a custom action handler."""
        self._handlers[action_type] = handler
        logger.debug(f"Registered action handler: {action_type}")

    def dispatch(
        self,
        branch: ActionBranch,
        row: RowData,
        row_id: str,
        context: dict,
    ) -> dict:
        """Execute the action defined in a branch."""
        action_type = branch.action

        if action_type == "none":
            return {"action": "none", "status": "skipped"}

        handler = self._handlers.get(action_type)
        if not handler:
            logger.warning(f"No handler for action type: {action_type}")
            return {"action": action_type, "status": "no_handler"}

        if self.dry_run:
            logger.info(f"  [DRY RUN] Would execute: {action_type} for row {row_id}")
            return {
                "action": action_type,
                "status": "dry_run",
                "would_execute": _serialize_branch(branch, row),
            }

        return handler(branch, row, row_id, context)

    def _register_defaults(self):
        """Register built-in action handlers."""
        self.register_handler("api_call", _handle_api_call)
        self.register_handler("db_update", _handle_db_update)
        self.register_handler("log_only", _handle_log_only)


# ── Built-in Action Handlers ────────────────────────────────────────────────

def _handle_api_call(
    branch: ActionBranch,
    row: RowData,
    row_id: str,
    context: dict,
) -> dict:
    """Handle API call action."""
    from actions.api_action import call_api

    base_url = context.get("api_base_url", "")
    endpoint = branch.endpoint or ""
    url = f"{base_url}{endpoint}"

    # Merge row_id into payload
    payload = dict(branch.payload or {})
    payload["row_id"] = row_id

    result = call_api(
        url=url,
        method=branch.method or "POST",
        payload=payload,
    )

    return {
        "action": "api_call",
        "url": url,
        "status": result.get("status"),
        "response": result,
    }


def _handle_db_update(
    branch: ActionBranch,
    row: RowData,
    row_id: str,
    context: dict,
) -> dict:
    """Handle database update action."""
    from actions.db_action import update_db

    table = branch.table or context.get("db_table", "validation_results")
    set_values = dict(branch.set or {})
    set_values["row_id"] = row_id

    result = update_db(
        connection_string=context.get("db_connection_string", ""),
        table=table,
        row_id=row_id,
        row_id_column=context.get("row_id_column", "ID"),
        values=set_values,
    )

    return {
        "action": "db_update",
        "table": table,
        "status": result.get("status"),
        "values": set_values,
    }


def _handle_log_only(
    branch: ActionBranch,
    row: RowData,
    row_id: str,
    context: dict,
) -> dict:
    """Log action without side effects."""
    msg = f"[LOG] Row {row_id}: {branch.set or branch.payload or 'no data'}"
    logger.info(msg)
    return {"action": "log_only", "status": "logged", "message": msg}


def _serialize_branch(branch: ActionBranch, row: RowData) -> dict:
    """Serialize branch for dry-run logging."""
    return {
        "method": branch.method,
        "endpoint": branch.endpoint,
        "payload": branch.payload,
        "set": branch.set,
    }
