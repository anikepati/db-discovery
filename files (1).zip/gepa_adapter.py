"""
EnterpriseGEPAAdapter — ADK + Genetic-Pareto Evolution Bridge

Wraps any Google ADK multi-agent system and applies genetic-Pareto
optimization across prompt instructions, delegation logic, and tool
usage patterns. Agents & tools remain 100% unchanged.

Architecture:
    ADK Agent Graph → Genome Extraction → Population Init →
    Mutation/Crossover → Fitness Eval (multi-objective) →
    Pareto Selection → Next Generation → Best Candidate
"""

from __future__ import annotations

import ast
import copy
import hashlib
import importlib.util
import inspect
import json
import math
import os
import random
import re
import sqlite3
import textwrap
import time
import traceback
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

from dotenv import load_dotenv

load_dotenv()

# ---------------------------------------------------------------------------
# Data Structures
# ---------------------------------------------------------------------------

@dataclass
class AgentGenome:
    """Represents a single agent's evolvable configuration."""
    agent_name: str
    agent_type: str  # LlmAgent, SequentialAgent, etc.
    instruction: str
    description: str
    sub_agent_names: list[str] = field(default_factory=list)
    tool_names: list[str] = field(default_factory=list)
    model_id: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)

    def fingerprint(self) -> str:
        blob = f"{self.agent_name}:{self.instruction}:{self.description}"
        return hashlib.md5(blob.encode()).hexdigest()[:12]


@dataclass
class SystemGenome:
    """Complete evolvable representation of a multi-agent system."""
    agents: list[AgentGenome] = field(default_factory=list)
    root_agent_name: str = ""
    generation: int = 0
    fitness_scores: dict[str, float] = field(default_factory=dict)
    pareto_rank: int = 0

    def fingerprint(self) -> str:
        parts = sorted(a.fingerprint() for a in self.agents)
        return hashlib.md5(":".join(parts).encode()).hexdigest()[:16]

    def deep_copy(self) -> "SystemGenome":
        return copy.deepcopy(self)


@dataclass
class FitnessResult:
    """Multi-objective fitness evaluation result."""
    accuracy: float = 0.0
    cost: float = 0.0
    latency: float = 0.0
    compliance: float = 0.0
    revenue_impact: float = 0.0
    tool_usage_efficiency: float = 0.0
    delegation_quality: float = 0.0
    raw_scores: dict[str, float] = field(default_factory=dict)
    test_case_results: list[dict] = field(default_factory=list)

    def as_dict(self) -> dict[str, float]:
        return {
            "accuracy": self.accuracy,
            "cost": self.cost,
            "latency": self.latency,
            "compliance": self.compliance,
            "revenue_impact": self.revenue_impact,
            "tool_usage_efficiency": self.tool_usage_efficiency,
            "delegation_quality": self.delegation_quality,
        }

    def weighted_score(self, weights: dict[str, float] | None = None) -> float:
        w = weights or {
            "accuracy": 0.30,
            "cost": 0.10,
            "latency": 0.10,
            "compliance": 0.20,
            "revenue_impact": 0.15,
            "tool_usage_efficiency": 0.08,
            "delegation_quality": 0.07,
        }
        total = sum(self.as_dict().get(k, 0.0) * v for k, v in w.items())
        return round(total, 4)


@dataclass
class EvolutionConfig:
    """Configuration for the genetic-Pareto evolution run."""
    population_size: int = 6
    generations: int = 10
    mutation_rate: float = 0.3
    crossover_rate: float = 0.7
    elite_count: int = 2
    model_id: str = "gemini-2.0-flash"
    eval_model_id: str = "gemini-2.0-flash"
    fitness_weights: dict[str, float] = field(default_factory=lambda: {
        "accuracy": 0.30, "cost": 0.10, "latency": 0.10,
        "compliance": 0.20, "revenue_impact": 0.15,
        "tool_usage_efficiency": 0.08, "delegation_quality": 0.07,
    })
    safety_gate_enabled: bool = True

    @classmethod
    def from_env(cls) -> "EvolutionConfig":
        return cls(
            population_size=int(os.getenv("GEPA_POPULATION_SIZE", "6")),
            generations=int(os.getenv("GEPA_GENERATIONS", "10")),
            mutation_rate=float(os.getenv("GEPA_MUTATION_RATE", "0.3")),
            crossover_rate=float(os.getenv("GEPA_CROSSOVER_RATE", "0.7")),
            elite_count=int(os.getenv("GEPA_ELITE_COUNT", "2")),
            model_id=os.getenv("GEPA_MODEL_ID", "gemini-2.0-flash"),
            eval_model_id=os.getenv("GEPA_EVAL_MODEL_ID", "gemini-2.0-flash"),
        )


@dataclass
class EvolutionTrace:
    """Captures a single generation's state for history/visualization."""
    generation: int
    population_size: int
    best_fitness: float
    avg_fitness: float
    pareto_front_size: int
    best_genome_fingerprint: str
    fitness_breakdown: dict[str, float]
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())


# ---------------------------------------------------------------------------
# Agent Graph Parser — Extracts genome from Python source or live objects
# ---------------------------------------------------------------------------

class AgentGraphParser:
    """Parses ADK agent definitions from Python source files."""

    # Recognized ADK agent classes
    AGENT_CLASSES = {
        "LlmAgent", "Agent", "SequentialAgent", "ParallelAgent",
        "LoopAgent", "SupervisorAgent",
    }

    @staticmethod
    def parse_source_file(filepath: str) -> tuple[list[AgentGenome], str, list[str], str]:
        """
        Parse a Python file to extract agent definitions.

        Returns:
            (agents, root_agent_name, tool_names, raw_source)
        """
        path = Path(filepath)
        if not path.exists():
            raise FileNotFoundError(f"Agent file not found: {filepath}")

        source = path.read_text(encoding="utf-8")
        tree = ast.parse(source)

        agents: list[AgentGenome] = []
        tool_funcs: list[str] = []
        root_agent_name = ""

        for node in ast.walk(tree):
            # Detect function definitions decorated or named as tools
            if isinstance(node, ast.FunctionDef):
                tool_funcs.append(node.name)

            # Detect agent instantiation via assignment
            if isinstance(node, ast.Assign) and len(node.targets) == 1:
                target = node.targets[0]
                if isinstance(node.value, ast.Call):
                    func = node.value.func
                    class_name = ""
                    if isinstance(func, ast.Name):
                        class_name = func.id
                    elif isinstance(func, ast.Attribute):
                        class_name = func.attr

                    if class_name in AgentGraphParser.AGENT_CLASSES:
                        genome = AgentGraphParser._extract_agent_kwargs(
                            node.value, class_name, source
                        )
                        if isinstance(target, ast.Name):
                            genome.metadata["var_name"] = target.id
                        agents.append(genome)

            # Detect root_agent assignment
            if isinstance(node, ast.Assign):
                for t in node.targets:
                    if isinstance(t, ast.Name) and t.id == "root_agent":
                        if isinstance(node.value, ast.Name):
                            root_agent_name = node.value.id

        # Resolve root agent
        if not root_agent_name and agents:
            root_agent_name = agents[-1].agent_name or agents[-1].metadata.get("var_name", "")

        return agents, root_agent_name, tool_funcs, source

    @staticmethod
    def _extract_agent_kwargs(call: ast.Call, class_name: str, source: str) -> AgentGenome:
        """Extract keyword arguments from an ADK agent constructor call."""
        genome = AgentGenome(agent_name="", agent_type=class_name, instruction="", description="")

        for kw in call.keywords:
            if kw.arg == "name" and isinstance(kw.value, (ast.Constant, ast.Str)):
                genome.agent_name = getattr(kw.value, "value", getattr(kw.value, "s", ""))
            elif kw.arg == "instruction" and isinstance(kw.value, (ast.Constant, ast.Str)):
                genome.instruction = getattr(kw.value, "value", getattr(kw.value, "s", ""))
            elif kw.arg == "description" and isinstance(kw.value, (ast.Constant, ast.Str)):
                genome.description = getattr(kw.value, "value", getattr(kw.value, "s", ""))
            elif kw.arg == "model" and isinstance(kw.value, (ast.Constant, ast.Str)):
                genome.model_id = getattr(kw.value, "value", getattr(kw.value, "s", ""))
            elif kw.arg == "sub_agents" and isinstance(kw.value, ast.List):
                for elt in kw.value.elts:
                    if isinstance(elt, ast.Name):
                        genome.sub_agent_names.append(elt.id)
            elif kw.arg == "tools" and isinstance(kw.value, ast.List):
                for elt in kw.value.elts:
                    if isinstance(elt, ast.Name):
                        genome.tool_names.append(elt.id)

        # Attempt to extract multi-line instructions via source segment
        if not genome.instruction:
            try:
                segment = ast.get_source_segment(source, call)
                if segment:
                    match = re.search(
                        r'instruction\s*=\s*(?:textwrap\.dedent\s*\()?\s*"""(.*?)"""',
                        segment, re.DOTALL,
                    )
                    if match:
                        genome.instruction = textwrap.dedent(match.group(1)).strip()
            except Exception:
                pass

        return genome

    @staticmethod
    def parse_live_agent(agent_obj: Any) -> list[AgentGenome]:
        """Parse a live ADK agent object (already imported)."""
        agents = []

        def _walk(agent: Any):
            genome = AgentGenome(
                agent_name=getattr(agent, "name", "unknown"),
                agent_type=type(agent).__name__,
                instruction=getattr(agent, "instruction", "") or "",
                description=getattr(agent, "description", "") or "",
                model_id=getattr(agent, "model", "") or "",
            )
            # Sub-agents
            for sa in getattr(agent, "sub_agents", []) or []:
                genome.sub_agent_names.append(getattr(sa, "name", ""))
                _walk(sa)
            # Tools
            for tool in getattr(agent, "tools", []) or []:
                name = getattr(tool, "name", None) or getattr(tool, "__name__", "tool")
                genome.tool_names.append(name)

            agents.append(genome)

        _walk(agent_obj)
        return agents


# ---------------------------------------------------------------------------
# Genetic Operators
# ---------------------------------------------------------------------------

class GeneticOperators:
    """Mutation and crossover operators for agent system genomes."""

    # Prompt mutation strategies
    MUTATION_STRATEGIES = [
        "rephrase_concise",
        "add_constraint",
        "add_example",
        "change_persona",
        "strengthen_delegation",
        "add_error_handling",
        "optimize_tool_usage",
        "add_compliance_guardrail",
    ]

    @staticmethod
    def mutate_instruction(instruction: str, strategy: str, model_id: str = "") -> str:
        """
        Apply a mutation strategy to an agent instruction.
        Uses LLM if available, otherwise rule-based fallback.
        """
        try:
            from google import genai
            client = genai.Client()
            prompt = GeneticOperators._build_mutation_prompt(instruction, strategy)
            response = client.models.generate_content(
                model=model_id or "gemini-2.0-flash",
                contents=prompt,
            )
            result = response.text.strip()
            if len(result) > 20:
                return result
        except Exception:
            pass

        # Rule-based fallback mutations
        return GeneticOperators._rule_based_mutation(instruction, strategy)

    @staticmethod
    def _build_mutation_prompt(instruction: str, strategy: str) -> str:
        strategy_prompts = {
            "rephrase_concise": "Rephrase this agent instruction to be more concise and clear while preserving all meaning.",
            "add_constraint": "Add one important constraint or guardrail to this agent instruction that improves reliability.",
            "add_example": "Add a brief concrete example to this instruction that clarifies expected behavior.",
            "change_persona": "Adjust the persona/role framing to be more authoritative and professional.",
            "strengthen_delegation": "Strengthen the delegation instructions — make it clearer when and how to delegate to sub-agents.",
            "add_error_handling": "Add explicit error handling instructions for edge cases.",
            "optimize_tool_usage": "Add guidance on when and how to optimally use available tools.",
            "add_compliance_guardrail": "Add a compliance/safety guardrail instruction.",
        }
        guidance = strategy_prompts.get(strategy, "Improve this instruction.")
        return f"""You are an expert prompt engineer optimizing multi-agent system instructions.

TASK: {guidance}

ORIGINAL INSTRUCTION:
{instruction}

Return ONLY the improved instruction text. No explanations, no markdown fences."""

    @staticmethod
    def _rule_based_mutation(instruction: str, strategy: str) -> str:
        """Deterministic fallback mutations."""
        additions = {
            "add_constraint": "\nAlways validate inputs before processing. If data is missing or malformed, report the issue clearly.",
            "add_error_handling": "\nIf any step fails, provide a clear error description and suggest remediation steps.",
            "add_compliance_guardrail": "\nEnsure all outputs comply with regulatory requirements. Flag any potential compliance issues.",
            "optimize_tool_usage": "\nUse available tools efficiently — prefer batch operations when possible and cache repeated lookups.",
            "strengthen_delegation": "\nWhen delegating to sub-agents, provide clear context about the task scope and expected output format.",
        }
        suffix = additions.get(strategy, "")
        if suffix and suffix.strip() not in instruction:
            return instruction + suffix
        return instruction

    @staticmethod
    def crossover(parent_a: SystemGenome, parent_b: SystemGenome) -> SystemGenome:
        """
        Uniform crossover between two system genomes.
        For each agent position, randomly pick from parent A or B.
        """
        child = parent_a.deep_copy()
        agents_b = {a.agent_name: a for a in parent_b.agents}

        for i, agent in enumerate(child.agents):
            if agent.agent_name in agents_b and random.random() < 0.5:
                donor = agents_b[agent.agent_name]
                # Crossover instruction at sentence level
                sentences_a = agent.instruction.split(". ")
                sentences_b = donor.instruction.split(". ")
                merged = []
                max_len = max(len(sentences_a), len(sentences_b))
                for j in range(max_len):
                    if j < len(sentences_a) and j < len(sentences_b):
                        merged.append(sentences_a[j] if random.random() < 0.5 else sentences_b[j])
                    elif j < len(sentences_a):
                        merged.append(sentences_a[j])
                    else:
                        merged.append(sentences_b[j])
                child.agents[i].instruction = ". ".join(merged)

                # Crossover description
                if random.random() < 0.5:
                    child.agents[i].description = donor.description

        return child

    @staticmethod
    def mutate_system(
        genome: SystemGenome,
        mutation_rate: float = 0.3,
        model_id: str = "",
    ) -> SystemGenome:
        """Apply mutations to a system genome."""
        mutated = genome.deep_copy()
        for agent in mutated.agents:
            if agent.agent_type in ("LlmAgent", "Agent") and random.random() < mutation_rate:
                strategy = random.choice(GeneticOperators.MUTATION_STRATEGIES)
                agent.instruction = GeneticOperators.mutate_instruction(
                    agent.instruction, strategy, model_id
                )
                agent.metadata["last_mutation"] = strategy
        mutated.generation = genome.generation + 1
        return mutated


# ---------------------------------------------------------------------------
# Fitness Evaluator
# ---------------------------------------------------------------------------

class FitnessEvaluator:
    """Evaluates a system genome against test cases using business KPIs."""

    def __init__(self, model_id: str = "gemini-2.0-flash"):
        self.model_id = model_id

    def evaluate(
        self,
        genome: SystemGenome,
        test_cases: list[dict],
        agent_source: str = "",
    ) -> FitnessResult:
        """
        Run all test cases against the genome's agent configuration.
        Returns multi-objective fitness scores.
        """
        result = FitnessResult()
        if not test_cases:
            return result

        case_results = []
        total_accuracy = 0.0
        total_latency = 0.0
        total_compliance = 0.0
        total_tool_eff = 0.0
        total_delegation = 0.0

        for tc in test_cases:
            start = time.time()
            try:
                score = self._evaluate_single(genome, tc)
                elapsed = time.time() - start
                score["latency_s"] = elapsed
                case_results.append(score)

                total_accuracy += score.get("accuracy", 0.0)
                total_latency += min(1.0, max(0.0, 1.0 - (elapsed / 30.0)))
                total_compliance += score.get("compliance", 0.0)
                total_tool_eff += score.get("tool_efficiency", 0.0)
                total_delegation += score.get("delegation_quality", 0.0)
            except Exception as e:
                case_results.append({"error": str(e), "accuracy": 0.0})

        n = len(test_cases)
        result.accuracy = round(total_accuracy / n, 4) if n else 0.0
        result.latency = round(total_latency / n, 4) if n else 0.0
        result.compliance = round(total_compliance / n, 4) if n else 0.0
        result.tool_usage_efficiency = round(total_tool_eff / n, 4) if n else 0.0
        result.delegation_quality = round(total_delegation / n, 4) if n else 0.0
        result.cost = round(self._estimate_cost(genome, n), 4)
        result.revenue_impact = round(result.accuracy * 0.8 + result.compliance * 0.2, 4)
        result.test_case_results = case_results
        result.raw_scores = result.as_dict()
        return result

    def _evaluate_single(self, genome: SystemGenome, test_case: dict) -> dict:
        """Evaluate a single test case using LLM-as-judge."""
        user_input = test_case.get("input", "")
        expected = test_case.get("expected_output", "")
        kpis = test_case.get("business_kpis", {})

        # Build the agent system prompt from genome
        system_context = self._genome_to_system_prompt(genome)

        try:
            from google import genai
            client = genai.Client()

            # Step 1: Generate agent response
            agent_response = client.models.generate_content(
                model=self.model_id,
                contents=f"{system_context}\n\nUser Query: {user_input}",
            )
            response_text = agent_response.text.strip() if agent_response.text else ""

            # Step 2: LLM-as-judge scoring
            judge_prompt = f"""You are an expert evaluator. Score the agent response against the expected output.

User Input: {user_input}
Expected Output: {expected}
Agent Response: {response_text}
Business KPIs: {json.dumps(kpis)}

Score each dimension 0.0-1.0:
- accuracy: How well does the response match expected output?
- compliance: Does it follow regulatory/business rules?
- tool_efficiency: Does it suggest appropriate tool usage?
- delegation_quality: Does it properly scope multi-agent responsibilities?

Return ONLY a JSON object with these four keys. No markdown."""

            judge_response = client.models.generate_content(
                model=self.model_id,
                contents=judge_prompt,
            )
            raw = judge_response.text.strip()
            # Clean potential markdown fences
            raw = re.sub(r"```json\s*", "", raw)
            raw = re.sub(r"```\s*$", "", raw)
            scores = json.loads(raw)
            return {
                "accuracy": float(scores.get("accuracy", 0.5)),
                "compliance": float(scores.get("compliance", 0.5)),
                "tool_efficiency": float(scores.get("tool_efficiency", 0.5)),
                "delegation_quality": float(scores.get("delegation_quality", 0.5)),
                "response_preview": response_text[:300],
            }
        except Exception as e:
            # Fallback: heuristic scoring
            return self._heuristic_score(user_input, expected, genome)

    def _heuristic_score(self, user_input: str, expected: str, genome: SystemGenome) -> dict:
        """Fallback heuristic scoring when LLM evaluation fails."""
        # Simple overlap-based scoring
        expected_words = set(expected.lower().split())
        instruction_words = set()
        for a in genome.agents:
            instruction_words.update(a.instruction.lower().split())

        overlap = len(expected_words & instruction_words) / max(len(expected_words), 1)
        has_tools = any(a.tool_names for a in genome.agents)
        has_delegation = any(a.sub_agent_names for a in genome.agents)

        return {
            "accuracy": min(1.0, overlap * 2 + 0.3),
            "compliance": 0.6 if "compliance" in " ".join(a.instruction for a in genome.agents).lower() else 0.4,
            "tool_efficiency": 0.7 if has_tools else 0.3,
            "delegation_quality": 0.7 if has_delegation else 0.3,
        }

    def _genome_to_system_prompt(self, genome: SystemGenome) -> str:
        """Convert genome to a system prompt that simulates the multi-agent team."""
        parts = ["You are a multi-agent system with the following team:\n"]
        for ag in genome.agents:
            parts.append(f"## Agent: {ag.agent_name} ({ag.agent_type})")
            parts.append(f"Role: {ag.description}")
            parts.append(f"Instructions: {ag.instruction}")
            if ag.tool_names:
                parts.append(f"Tools: {', '.join(ag.tool_names)}")
            if ag.sub_agent_names:
                parts.append(f"Delegates to: {', '.join(ag.sub_agent_names)}")
            parts.append("")
        return "\n".join(parts)

    @staticmethod
    def _estimate_cost(genome: SystemGenome, num_cases: int) -> float:
        """Estimate relative token cost (normalized 0-1, lower is better)."""
        total_tokens = sum(len(a.instruction.split()) for a in genome.agents)
        # Normalized: 500 tokens = 0.5, 1000+ = approaching 1.0
        raw_cost = total_tokens * num_cases / 5000.0
        return min(1.0, max(0.0, 1.0 - raw_cost))


# ---------------------------------------------------------------------------
# Pareto Ranker
# ---------------------------------------------------------------------------

class ParetoRanker:
    """Non-dominated sorting for multi-objective optimization."""

    @staticmethod
    def compute_pareto_ranks(population: list[SystemGenome]) -> list[SystemGenome]:
        """Assign pareto ranks to each genome in the population."""
        n = len(population)
        if n == 0:
            return population

        objectives = []
        for g in population:
            scores = g.fitness_scores
            # All objectives should be maximized
            objectives.append([
                scores.get("accuracy", 0),
                scores.get("cost", 0),
                scores.get("latency", 0),
                scores.get("compliance", 0),
                scores.get("revenue_impact", 0),
            ])

        # Non-dominated sorting
        domination_count = [0] * n
        dominated_by = [[] for _ in range(n)]
        fronts: list[list[int]] = [[]]

        for i in range(n):
            for j in range(i + 1, n):
                if ParetoRanker._dominates(objectives[i], objectives[j]):
                    dominated_by[i].append(j)
                    domination_count[j] += 1
                elif ParetoRanker._dominates(objectives[j], objectives[i]):
                    dominated_by[j].append(i)
                    domination_count[i] += 1

            if domination_count[i] == 0:
                fronts[0].append(i)

        rank = 0
        while fronts[rank]:
            next_front = []
            for i in fronts[rank]:
                population[i].pareto_rank = rank
                for j in dominated_by[i]:
                    domination_count[j] -= 1
                    if domination_count[j] == 0:
                        next_front.append(j)
            rank += 1
            fronts.append(next_front)

        return population

    @staticmethod
    def _dominates(a: list[float], b: list[float]) -> bool:
        """Returns True if a dominates b (all >= and at least one >)."""
        at_least_one_better = False
        for ai, bi in zip(a, b):
            if ai < bi:
                return False
            if ai > bi:
                at_least_one_better = True
        return at_least_one_better

    @staticmethod
    def get_pareto_front(population: list[SystemGenome]) -> list[SystemGenome]:
        """Return only the Pareto-optimal (rank 0) genomes."""
        return [g for g in population if g.pareto_rank == 0]


# ---------------------------------------------------------------------------
# Evolution History (SQLite)
# ---------------------------------------------------------------------------

class EvolutionHistory:
    """Persists evolution runs and traces to SQLite."""

    def __init__(self, db_path: str = "evolution_history.db"):
        self.db_path = db_path
        self._init_db()

    def _init_db(self):
        conn = sqlite3.connect(self.db_path)
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS evolution_runs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                run_id TEXT UNIQUE,
                started_at TEXT,
                completed_at TEXT,
                config_json TEXT,
                status TEXT DEFAULT 'running',
                source_file TEXT
            );
            CREATE TABLE IF NOT EXISTS generation_traces (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                run_id TEXT,
                generation INTEGER,
                best_fitness REAL,
                avg_fitness REAL,
                pareto_front_size INTEGER,
                best_genome_json TEXT,
                fitness_breakdown_json TEXT,
                timestamp TEXT,
                FOREIGN KEY (run_id) REFERENCES evolution_runs(run_id)
            );
            CREATE TABLE IF NOT EXISTS best_genomes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                run_id TEXT,
                genome_json TEXT,
                fitness_json TEXT,
                pareto_rank INTEGER,
                timestamp TEXT,
                FOREIGN KEY (run_id) REFERENCES evolution_runs(run_id)
            );
        """)
        conn.commit()
        conn.close()

    def start_run(self, run_id: str, config: EvolutionConfig, source_file: str = "") -> None:
        conn = sqlite3.connect(self.db_path)
        conn.execute(
            "INSERT OR REPLACE INTO evolution_runs (run_id, started_at, config_json, source_file) VALUES (?, ?, ?, ?)",
            (run_id, datetime.utcnow().isoformat(), json.dumps(config.__dict__, default=str), source_file),
        )
        conn.commit()
        conn.close()

    def record_generation(self, run_id: str, trace: EvolutionTrace, best_genome: SystemGenome) -> None:
        conn = sqlite3.connect(self.db_path)
        conn.execute(
            """INSERT INTO generation_traces
               (run_id, generation, best_fitness, avg_fitness, pareto_front_size,
                best_genome_json, fitness_breakdown_json, timestamp)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                run_id, trace.generation, trace.best_fitness, trace.avg_fitness,
                trace.pareto_front_size,
                json.dumps([a.__dict__ for a in best_genome.agents], default=str),
                json.dumps(trace.fitness_breakdown),
                trace.timestamp,
            ),
        )
        conn.commit()
        conn.close()

    def complete_run(self, run_id: str, best_genome: SystemGenome, fitness: FitnessResult) -> None:
        conn = sqlite3.connect(self.db_path)
        conn.execute(
            "UPDATE evolution_runs SET completed_at = ?, status = 'completed' WHERE run_id = ?",
            (datetime.utcnow().isoformat(), run_id),
        )
        conn.execute(
            """INSERT INTO best_genomes (run_id, genome_json, fitness_json, pareto_rank, timestamp)
               VALUES (?, ?, ?, ?, ?)""",
            (
                run_id,
                json.dumps([a.__dict__ for a in best_genome.agents], default=str),
                json.dumps(fitness.as_dict()),
                best_genome.pareto_rank,
                datetime.utcnow().isoformat(),
            ),
        )
        conn.commit()
        conn.close()

    def list_runs(self) -> list[dict]:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        rows = conn.execute(
            "SELECT * FROM evolution_runs ORDER BY started_at DESC LIMIT 50"
        ).fetchall()
        conn.close()
        return [dict(r) for r in rows]

    def get_run_traces(self, run_id: str) -> list[dict]:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        rows = conn.execute(
            "SELECT * FROM generation_traces WHERE run_id = ? ORDER BY generation",
            (run_id,),
        ).fetchall()
        conn.close()
        return [dict(r) for r in rows]

    def get_best_genome(self, run_id: str) -> dict | None:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        row = conn.execute(
            "SELECT * FROM best_genomes WHERE run_id = ? ORDER BY id DESC LIMIT 1",
            (run_id,),
        ).fetchone()
        conn.close()
        return dict(row) if row else None


# ---------------------------------------------------------------------------
# Main Adapter — Orchestrates the full evolution pipeline
# ---------------------------------------------------------------------------

class EnterpriseGEPAAdapter:
    """
    Enterprise-grade bridge between ADK multi-agent systems and
    genetic-Pareto evolution.

    Usage:
        adapter = EnterpriseGEPAAdapter(config)
        adapter.load_agents("my_team.py")
        adapter.load_test_cases(test_cases)
        best = adapter.evolve(progress_callback=my_callback)
    """

    def __init__(self, config: EvolutionConfig | None = None):
        self.config = config or EvolutionConfig.from_env()
        self.evaluator = FitnessEvaluator(self.config.eval_model_id)
        self.history = EvolutionHistory(os.getenv("HISTORY_DB_PATH", "evolution_history.db"))
        self.parser = AgentGraphParser()

        # State
        self.original_genome: SystemGenome | None = None
        self.population: list[SystemGenome] = []
        self.test_cases: list[dict] = []
        self.evolution_traces: list[EvolutionTrace] = []
        self.best_genome: SystemGenome | None = None
        self.best_fitness: FitnessResult | None = None
        self.source_file: str = ""
        self.raw_source: str = ""

    def load_agents(self, filepath: str) -> SystemGenome:
        """Parse an ADK agent Python file and extract the system genome."""
        self.source_file = filepath
        agents, root_name, tools, source = self.parser.parse_source_file(filepath)
        self.raw_source = source

        genome = SystemGenome(agents=agents, root_agent_name=root_name)
        self.original_genome = genome
        return genome

    def load_agents_from_source(self, source: str, filename: str = "agents.py") -> SystemGenome:
        """Parse agent source code directly (for pasted code)."""
        tmp_path = Path("/tmp") / filename
        tmp_path.write_text(source, encoding="utf-8")
        return self.load_agents(str(tmp_path))

    def load_test_cases(self, test_cases: list[dict]) -> None:
        """Load test cases for fitness evaluation."""
        self.test_cases = test_cases

    def evolve(
        self,
        progress_callback: Callable[[EvolutionTrace], None] | None = None,
        safety_checker: Any = None,
    ) -> tuple[SystemGenome, FitnessResult]:
        """
        Run the full genetic-Pareto evolution loop.

        Args:
            progress_callback: Called after each generation with trace data
            safety_checker: Optional SafetyChecker instance for pre-flight

        Returns:
            (best_genome, best_fitness)
        """
        if not self.original_genome:
            raise ValueError("No agents loaded. Call load_agents() first.")
        if not self.test_cases:
            raise ValueError("No test cases loaded. Call load_test_cases() first.")

        run_id = f"run_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}_{random.randint(1000,9999)}"
        self.history.start_run(run_id, self.config, self.source_file)
        self.evolution_traces.clear()

        # Initialize population with mutations of original
        self.population = [self.original_genome.deep_copy()]
        for _ in range(self.config.population_size - 1):
            mutated = GeneticOperators.mutate_system(
                self.original_genome, self.config.mutation_rate, self.config.model_id
            )
            self.population.append(mutated)

        best_overall: SystemGenome | None = None
        best_overall_fitness: FitnessResult | None = None

        for gen in range(self.config.generations):
            # Evaluate fitness for each genome
            for genome in self.population:
                fitness = self.evaluator.evaluate(genome, self.test_cases, self.raw_source)
                genome.fitness_scores = fitness.as_dict()

            # Pareto ranking
            self.population = ParetoRanker.compute_pareto_ranks(self.population)

            # Track best
            scored = [
                (g, FitnessResult(**{k: v for k, v in g.fitness_scores.items() if k in FitnessResult.__dataclass_fields__}))
                for g in self.population
            ]
            scored.sort(key=lambda x: x[1].weighted_score(self.config.fitness_weights), reverse=True)
            gen_best, gen_best_fitness = scored[0]

            if best_overall is None or gen_best_fitness.weighted_score(self.config.fitness_weights) > (
                best_overall_fitness.weighted_score(self.config.fitness_weights) if best_overall_fitness else 0
            ):
                best_overall = gen_best.deep_copy()
                best_overall_fitness = gen_best_fitness

            # Record trace
            avg_score = sum(
                FitnessResult(**{k: v for k, v in g.fitness_scores.items() if k in FitnessResult.__dataclass_fields__}).weighted_score(self.config.fitness_weights)
                for g in self.population
            ) / len(self.population)

            pareto_front = ParetoRanker.get_pareto_front(self.population)
            trace = EvolutionTrace(
                generation=gen,
                population_size=len(self.population),
                best_fitness=gen_best_fitness.weighted_score(self.config.fitness_weights),
                avg_fitness=round(avg_score, 4),
                pareto_front_size=len(pareto_front),
                best_genome_fingerprint=gen_best.fingerprint(),
                fitness_breakdown=gen_best_fitness.as_dict(),
            )
            self.evolution_traces.append(trace)
            self.history.record_generation(run_id, trace, gen_best)

            if progress_callback:
                progress_callback(trace)

            # Selection + reproduction for next generation
            if gen < self.config.generations - 1:
                self.population = self._next_generation(scored)

        # Safety gate
        if safety_checker and self.config.safety_gate_enabled and best_overall:
            issues = safety_checker.check_genome(best_overall)
            if issues.get("critical_issues"):
                # Fall back to original if safety fails
                best_overall = self.original_genome
                best_overall_fitness = self.evaluator.evaluate(
                    self.original_genome, self.test_cases, self.raw_source
                )

        self.best_genome = best_overall
        self.best_fitness = best_overall_fitness

        if best_overall and best_overall_fitness:
            self.history.complete_run(run_id, best_overall, best_overall_fitness)

        return best_overall, best_overall_fitness  # type: ignore

    def _next_generation(
        self, scored: list[tuple[SystemGenome, FitnessResult]]
    ) -> list[SystemGenome]:
        """Build next generation via elitism + crossover + mutation."""
        next_pop: list[SystemGenome] = []

        # Elitism — keep top N
        for i in range(min(self.config.elite_count, len(scored))):
            next_pop.append(scored[i][0].deep_copy())

        # Fill rest with crossover + mutation
        while len(next_pop) < self.config.population_size:
            if len(scored) >= 2 and random.random() < self.config.crossover_rate:
                # Tournament selection
                p1 = self._tournament_select(scored)
                p2 = self._tournament_select(scored)
                child = GeneticOperators.crossover(p1, p2)
            else:
                parent = self._tournament_select(scored)
                child = parent.deep_copy()

            child = GeneticOperators.mutate_system(
                child, self.config.mutation_rate, self.config.model_id
            )
            next_pop.append(child)

        return next_pop

    def _tournament_select(
        self, scored: list[tuple[SystemGenome, FitnessResult]], k: int = 3
    ) -> SystemGenome:
        """Tournament selection: pick k random, return the best."""
        tournament = random.sample(scored, min(k, len(scored)))
        tournament.sort(
            key=lambda x: x[1].weighted_score(self.config.fitness_weights), reverse=True
        )
        return tournament[0][0]

    def get_before_after_comparison(self) -> dict:
        """Generate a before/after comparison of the original vs evolved system."""
        if not self.original_genome or not self.best_genome:
            return {}

        comparison = {"agents": []}
        orig_map = {a.agent_name: a for a in self.original_genome.agents}
        best_map = {a.agent_name: a for a in self.best_genome.agents}

        all_names = set(orig_map.keys()) | set(best_map.keys())
        for name in sorted(all_names):
            orig = orig_map.get(name)
            best = best_map.get(name)
            comparison["agents"].append({
                "name": name,
                "original_instruction": orig.instruction if orig else "(not present)",
                "evolved_instruction": best.instruction if best else "(not present)",
                "original_description": orig.description if orig else "",
                "evolved_description": best.description if best else "",
                "changed": (orig.instruction if orig else "") != (best.instruction if best else ""),
                "mutation_applied": best.metadata.get("last_mutation", "") if best else "",
            })

        return comparison

    def export_evolved_source(self) -> str:
        """Generate a new Python source file with evolved instructions."""
        if not self.best_genome or not self.raw_source:
            return ""

        source = self.raw_source
        orig_map = {a.agent_name: a for a in (self.original_genome.agents if self.original_genome else [])}

        for agent in self.best_genome.agents:
            orig = orig_map.get(agent.agent_name)
            if orig and orig.instruction and orig.instruction != agent.instruction:
                # Replace instruction in source
                escaped_old = re.escape(orig.instruction[:80])
                pattern = rf'(instruction\s*=\s*(?:textwrap\.dedent\s*\()?\s*["\']{{1,3}}){escaped_old}'
                if re.search(pattern, source):
                    source = source.replace(orig.instruction, agent.instruction, 1)

        return source
