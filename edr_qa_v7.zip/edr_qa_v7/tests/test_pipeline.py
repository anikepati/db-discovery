"""
EDR QA Pipeline v7 — test suite.
Run:   pytest tests/ -v
"""

import json
import sys
import yaml
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))


# ── tool_generator ────────────────────────────────────────────────────────────

class TestToolGenerator:

    def test_generates_15_yaml_files(self, tmp_path):
        from tool_generator import generate_all_question_yamls
        assert len(generate_all_question_yamls(tools_dir=tmp_path, force=True)) == 15

    def test_files_named_correctly(self, tmp_path):
        from tool_generator import generate_all_question_yamls
        generate_all_question_yamls(tools_dir=tmp_path, force=True)
        for n in range(1, 16):
            assert (tmp_path / f"edr_q{n:02d}_tools.yaml").exists()

    def test_default_yaml_has_empty_functions(self, tmp_path):
        """By default Q agents have no tools — they reason from conversation."""
        from tool_generator import generate_all_question_yamls
        generate_all_question_yamls(tools_dir=tmp_path, force=True)
        for n in range(1, 16):
            with open(tmp_path / f"edr_q{n:02d}_tools.yaml") as f:
                data = yaml.safe_load(f)
            assert data["functions"] == [], (
                f"Q{n} YAML should have empty functions by default"
            )

    def test_no_edr_state_tools_in_any_yaml(self, tmp_path):
        """edr_state is gone in v7 — SequentialAgent handles state passing."""
        from tool_generator import generate_all_question_yamls
        generate_all_question_yamls(tools_dir=tmp_path, force=True)
        for n in range(1, 16):
            with open(tmp_path / f"edr_q{n:02d}_tools.yaml") as f:
                content = f.read()
            assert "edr_state" not in content, (
                f"Q{n} YAML contains edr_state — removed in v7"
            )

    def test_no_anthropic_in_any_yaml(self, tmp_path):
        from tool_generator import generate_all_question_yamls
        generate_all_question_yamls(tools_dir=tmp_path, force=True)
        for n in range(1, 16):
            content = (tmp_path / f"edr_q{n:02d}_tools.yaml").read_text()
            assert "anthropic" not in content.lower()

    def test_extra_tools_included_when_configured(self, tmp_path):
        """Adding to Q_EXTRA_TOOLS should put tools into the YAML."""
        import tool_generator as tg
        original = tg.Q_EXTRA_TOOLS.copy()
        try:
            tg.Q_EXTRA_TOOLS[3] = [
                {
                    "id": "test_tool", "description": "test",
                    "type": "sql", "inputs": {},
                    "config": {"connection": "sqlite://", "query": "SELECT 1", "params": {}},
                }
            ]
            tg.generate_all_question_yamls(tools_dir=tmp_path, force=True)
            with open(tmp_path / "edr_q03_tools.yaml") as f:
                data = yaml.safe_load(f)
            assert len(data["functions"]) == 1
            assert data["functions"][0]["id"] == "test_tool"
        finally:
            tg.Q_EXTRA_TOOLS.clear()
            tg.Q_EXTRA_TOOLS.update(original)

    def test_skip_existing_without_force(self, tmp_path):
        from tool_generator import generate_all_question_yamls
        generate_all_question_yamls(tools_dir=tmp_path, force=True)
        mtime = (tmp_path / "edr_q01_tools.yaml").stat().st_mtime
        generate_all_question_yamls(tools_dir=tmp_path, force=False)
        assert (tmp_path / "edr_q01_tools.yaml").stat().st_mtime == mtime


# ── No SDK calls / no edr_state anywhere ─────────────────────────────────────

class TestCleanArchitecture:

    _CORE = [
        "yaml_runtime.py", "mcp_factory.py", "tool_registry.py",
        "tool_generator.py", "agents/agent.py", "pipeline_runner.py", "main.py",
    ]

    def test_no_anthropic_sdk_imports(self):
        for f in self._CORE:
            content = Path(f).read_text()
            assert "import anthropic" not in content
            assert "from anthropic"   not in content
            assert "messages.create"  not in content

    def test_no_edr_state_in_yaml_runtime(self):
        content = Path("yaml_runtime.py").read_text()
        assert "edr_state" not in content

    def test_no_context_state_in_agent(self):
        content = Path("agents/agent.py").read_text()
        assert "context.state" not in content
        assert "ToolContext"   not in content

    def test_sequential_agent_used(self):
        content = Path("agents/agent.py").read_text()
        assert "SequentialAgent" in content

    def test_no_agenttool_orchestrator(self):
        """v7 has no orchestrator wrapping sub-agents in AgentTool."""
        content = Path("agents/agent.py").read_text()
        assert "AgentTool" not in content


# ── yaml_runtime — sql + python only ─────────────────────────────────────────

class TestYAMLRuntime:

    def test_mcp_tool_types_is_sql_and_python_only(self):
        from yaml_runtime import MCP_TOOL_TYPES
        assert MCP_TOOL_TYPES == {"sql", "python"}

    def test_execute_raises_for_unknown_type(self, tmp_path):
        from yaml_runtime import YAMLFunctionRuntime
        p = tmp_path / "t.yaml"
        p.write_text("""
functions:
  - id: bad
    type: edr_state
    inputs: {}
    state: {operation: get}
""")
        rt = YAMLFunctionRuntime(str(p))
        # edr_state is silently filtered out of registry
        assert "bad" not in rt.registry

    def test_empty_functions_yaml_loads_cleanly(self, tmp_path):
        from yaml_runtime import YAMLFunctionRuntime
        p = tmp_path / "t.yaml"
        p.write_text("functions: []")
        rt = YAMLFunctionRuntime(str(p))
        assert rt.registry == {}

    def test_sql_tool_registered(self, tmp_path):
        from yaml_runtime import YAMLFunctionRuntime
        p = tmp_path / "t.yaml"
        p.write_text("""
functions:
  - id: my_query
    type: sql
    inputs:
      ecn_id:
        type: string
        required: true
    config:
      connection: "sqlite://"
      query: "SELECT 1"
      params: {}
""")
        rt = YAMLFunctionRuntime(str(p))
        assert "my_query" in rt.registry

    def test_python_tool_registered(self, tmp_path):
        from yaml_runtime import YAMLFunctionRuntime
        p = tmp_path / "t.yaml"
        p.write_text("""
functions:
  - id: compute
    type: python
    inputs: {}
    python:
      code: "result = 42"
""")
        rt = YAMLFunctionRuntime(str(p))
        assert "compute" in rt.registry

    def test_python_tool_executes(self, tmp_path):
        from yaml_runtime import YAMLFunctionRuntime
        p = tmp_path / "t.yaml"
        p.write_text("""
functions:
  - id: add
    type: python
    inputs:
      a:
        type: integer
        required: true
      b:
        type: integer
        required: true
    python:
      code: "result = inputs['a'] + inputs['b']"
""")
        rt  = YAMLFunctionRuntime(str(p))
        res = rt.execute("add", {"a": 3, "b": 4})
        assert res == 7


# ── tool_registry ─────────────────────────────────────────────────────────────

class TestToolRegistry:

    def test_17_entries(self):
        from tool_registry import build_registry
        assert len(build_registry()) == 17

    def test_order(self):
        from tool_registry import build_registry
        reg = build_registry()
        assert reg[0].name  == "ingest_agent"
        assert reg[1].name  == "q01_agent"
        assert reg[15].name == "q15_agent"
        assert reg[16].name == "report_agent"

    def test_q_agents_use_claude(self):
        from tool_registry import build_registry, QA_MODEL
        for cfg in build_registry()[1:16]:
            assert cfg.model == QA_MODEL

    def test_ingest_uses_gemini(self):
        from tool_registry import build_registry, INGEST_MODEL
        assert build_registry()[0].model == INGEST_MODEL

    def test_q_instructions_contain_question_text(self):
        from tool_registry import build_registry
        from questions import EDR_QUESTION_MAP
        for cfg in build_registry()[1:16]:
            n = int(cfg.name[1:3])
            assert EDR_QUESTION_MAP[n].question[:40] in cfg.instruction

    def test_q_instructions_contain_check_logic(self):
        from tool_registry import build_registry
        from questions import EDR_QUESTION_MAP
        for cfg in build_registry()[1:16]:
            n = int(cfg.name[1:3])
            assert EDR_QUESTION_MAP[n].check[:40] in cfg.instruction

    def test_instructions_reference_conversation_history(self):
        """v7 agents read from conversation — instruction must reflect that."""
        from tool_registry import build_registry
        for cfg in build_registry()[1:16]:
            assert "conversation" in cfg.instruction.lower(), (
                f"{cfg.name} instruction doesn't mention conversation history"
            )

    def test_human_review_questions_flagged(self):
        from tool_registry import build_registry
        from questions import HUMAN_REVIEW_QUESTION_NUMBERS
        for cfg in build_registry()[1:16]:
            n = int(cfg.name[1:3])
            if n in HUMAN_REVIEW_QUESTION_NUMBERS:
                assert "NEEDS_HUMAN" in cfg.instruction or "HUMAN REVIEW" in cfg.instruction

    def test_report_instruction_mentions_build_report(self):
        from tool_registry import build_registry
        assert "build_report" in build_registry()[-1].instruction

    def test_report_instruction_mentions_conversation(self):
        from tool_registry import build_registry
        assert "conversation" in build_registry()[-1].instruction.lower()


# ── Questions ─────────────────────────────────────────────────────────────────

class TestQuestions:

    def test_exactly_15(self):
        from questions import EDR_QUESTIONS
        assert len(EDR_QUESTIONS) == 15

    def test_dependency_chains(self):
        from questions import EDR_QUESTION_MAP
        expected = {
            1: (), 2: (1,), 3: (1,2), 4: (1,2), 5: (1,4),
            6: (4,5), 7: (5,6), 8: (6,7), 9: (6,7,8),
            10: (6,7), 11: (6,7), 12: (6,7),
            13: (10,), 14: (11,), 15: (12,),
        }
        for n, deps in expected.items():
            assert EDR_QUESTION_MAP[n].depends_on == deps

    def test_human_review_questions(self):
        from questions import HUMAN_REVIEW_QUESTION_NUMBERS
        assert HUMAN_REVIEW_QUESTION_NUMBERS == {10, 12, 13, 15}


# ── build_report ──────────────────────────────────────────────────────────────

class TestBuildReport:

    def _run(self, answers, tmp_path):
        with open("tools/edr_report_tools.yaml") as f:
            fn = next(x for x in yaml.safe_load(f)["functions"] if x["id"] == "build_report")
        ns = {
            "inputs": {
                "answers": answers, "edr_data": {"ecn_number": "ECN-TEST"},
                "output_path": str(tmp_path / "result.json"),
            },
            "result": None,
        }
        exec(compile(fn["python"]["code"], "<t>", "exec"), {
            "__builtins__": __builtins__,
            "os": __import__("os"), "json": __import__("json"),
        }, ns)
        return ns["result"]

    def _a(self, mapping):
        return {
            f"q{n}": {"answer": v, "requires_human": v == "NEEDS_HUMAN", "category": ""}
            for n, v in mapping.items()
        }

    def test_all_yes_pass(self, tmp_path):
        r = self._run(self._a({i: "Y" for i in range(1, 16)}), tmp_path)
        assert r["verdict"] == "PASS" and r["overall_pass_rate"] == 100.0

    def test_any_no_fail(self, tmp_path):
        a = self._a({i: "Y" for i in range(1, 16)})
        a["q7"]["answer"] = "N"
        r = self._run(a, tmp_path)
        assert r["verdict"] == "FAIL" and 7 in r["failed_questions"]

    def test_needs_human(self, tmp_path):
        a = self._a({i: "Y" for i in range(1, 16)})
        a["q10"].update({"answer": "NEEDS_HUMAN", "requires_human": True})
        assert self._run(a, tmp_path)["verdict"] == "REQUIRES_HUMAN_REVIEW"

    def test_fail_beats_human(self, tmp_path):
        a = self._a({i: "Y" for i in range(1, 16)})
        a["q3"]["answer"] = "N"
        a["q10"].update({"answer": "NEEDS_HUMAN", "requires_human": True})
        assert self._run(a, tmp_path)["verdict"] == "FAIL"

    def test_na_excluded_from_rate(self, tmp_path):
        a = self._a({i: "Y" for i in range(1, 11)})
        for i in range(11, 16):
            a[f"q{i}"] = {"answer": "N/A", "requires_human": False}
        r = self._run(a, tmp_path)
        assert r["overall_pass_rate"] == 100.0

    def test_output_json_written(self, tmp_path):
        self._run(self._a({i: "Y" for i in range(1, 16)}), tmp_path)
        data = json.loads((tmp_path / "result.json").read_text())
        assert len(data["answers"]) == 15
        assert "category_breakdown" in data


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
