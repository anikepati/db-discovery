"""
Pydantic models for decision tree YAML schema validation.
Ensures config is correct at load time — fail fast, not at row 10,000.
"""

from __future__ import annotations
from typing import Any, Dict, List, Literal, Optional, Union
from pydantic import BaseModel, Field, model_validator


# ── Condition Models ─────────────────────────────────────────────────────────

class SimpleCondition(BaseModel):
    """A leaf condition comparing column values."""
    operator: Literal[
        "gt", "gte", "lt", "lte", "eq", "neq",
        "contains", "starts_with", "ends_with", "regex", "is_empty",
        "is_null", "is_not_null",
        "between",
        "in", "not_in",
    ]
    left_column: str
    right_column: Optional[str] = None
    right_value: Optional[Any] = None
    pattern: Optional[str] = None        # for regex
    low: Optional[Union[int, float]] = None  # for between
    high: Optional[Union[int, float]] = None # for between
    values: Optional[List[Any]] = None   # for in / not_in

    @model_validator(mode="after")
    def validate_operands(self):
        op = self.operator
        if op in ("gt", "gte", "lt", "lte", "eq", "neq",
                   "contains", "starts_with", "ends_with"):
            if self.right_column is None and self.right_value is None:
                raise ValueError(
                    f"Operator '{op}' requires right_column or right_value"
                )
        if op == "regex" and not self.pattern:
            raise ValueError("Operator 'regex' requires 'pattern'")
        if op == "between" and (self.low is None or self.high is None):
            raise ValueError("Operator 'between' requires 'low' and 'high'")
        if op in ("in", "not_in") and not self.values:
            raise ValueError(f"Operator '{op}' requires 'values' list")
        return self


class CompoundCondition(BaseModel):
    """AND / OR wrapper around a list of child conditions."""
    operator: Literal["and", "or"]
    conditions: List[Union[SimpleCondition, "CompoundCondition"]]


Condition = Union[SimpleCondition, CompoundCondition]


# ── Action Models ────────────────────────────────────────────────────────────

class ActionBranch(BaseModel):
    """What to do when a condition evaluates true or false."""
    action: Literal["api_call", "db_update", "log_only", "none"]
    method: Optional[str] = "POST"
    endpoint: Optional[str] = None
    payload: Optional[Dict[str, Any]] = None
    set: Optional[Dict[str, Any]] = None      # for db_update
    table: Optional[str] = None
    next_decision: Optional["DecisionNode"] = None  # recursive child tree


# ── Decision Node ────────────────────────────────────────────────────────────

class DecisionNode(BaseModel):
    """A single node in the decision tree."""
    id: str
    name: str
    description: Optional[str] = None
    condition: Condition
    on_true: ActionBranch
    on_false: ActionBranch


# ── Top-Level Config ─────────────────────────────────────────────────────────

class Settings(BaseModel):
    excel_file: str
    sheet_name: str = "Sheet1"
    row_id_column: str = "ID"
    api_base_url: str = ""
    db_connection_string: str = "sqlite:///results.db"
    db_table: str = "validation_results"
    log_level: str = "INFO"
    batch_size: int = 100
    dry_run: bool = False


class DecisionTreeConfig(BaseModel):
    settings: Settings
    decision_trees: List[DecisionNode]


# Rebuild models to resolve forward references
CompoundCondition.model_rebuild()
ActionBranch.model_rebuild()
DecisionNode.model_rebuild()
DecisionTreeConfig.model_rebuild()
