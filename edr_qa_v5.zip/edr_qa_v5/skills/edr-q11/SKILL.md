---
name: edr-q11
description: >
  EDR QA Question 11 of 15 (Initiation of Decision Execution): Is a risk rating override request present in the risk rating override Actimize workflow for this event..
  Reads EDR data from context.state, reasons using Claude claude-sonnet-4-6, writes
  answer to context.state["answers"]["q11"]. Use only in EDR QA pipeline.
license: Proprietary
metadata:
  author: edr-qa-team
  version: "5.0"
  pipeline: edr-qa-v5
  question_number: "11"
  category: "Initiation of Decision Execution"
  requires_human: "false"
compatibility: Requires ADK ToolContext, Anthropic API, context.state with edr_data populated
allowed-tools: get_edr_data get_prior_answers answer_question store_answer
---

# EDR QA — Question 11: Initiation of Decision Execution

**Is a risk rating override request present in the risk rating override Actimize workflow for this event.**

## Dependencies

Depends on: Q06, Q07

Prior answers for dependent questions MUST be in `context.state["answers"]` before this agent runs.

## Steps

1. Call `get_edr_data()` — reads `context.state["edr_data"]` (populated by IngestAgent)
2. Call `get_prior_answers()` — reads `context.state["answers"]` for dependent Q answers
3. Call `answer_question(question_number=11, edr_data=<step1>, prior_answers=<step2>)`
   - This calls Claude claude-sonnet-4-6 with the check logic and EDR data
   - Returns: `answer`, `reasoning`, `requires_human`, `human_action`
4. Call `store_answer(question_number=11, answer=..., reasoning=..., ...)` 
   - Writes to `context.state["answers"]["q11"]`
5. Respond with exactly:

```
Q11 [Initiation of Decision Execution]: <answer>
REASONING: <1-2 sentence summary>
```

## Check Logic

```
If final_recommended_action = 'Increase Risk Rating':   If rro_number is populated: Y.   If rro_number is blank: NEEDS_HUMAN. If risk_rating_amended_in_l2 = True: confirm final_risk_rating is stated with rro_number. Else: N/A.
```

## Validation

Check rro_number presence for Increase Risk Rating actions.

## Output Format

State final_recommended_action, rro_number (populated or blank), risk_rating_amended_in_l2. Answer Y, NEEDS_HUMAN, or N/A.

Valid answers: `Y` | `N` | `N/A` | `NEEDS_HUMAN`

## DB Fields Used

| Column | Notes |
|--------|-------|
| `final_recommended_action` |
| `rro_number` |
| `risk_rating_amended_in_l2` |
| `final_risk_rating` |

## Gotchas

- Always call `get_edr_data()` first — never use stale data from a prior step.
- Always call `get_prior_answers()` before `answer_question` — dependency answers may affect the result.
- Never skip this question even if a dependency answered N or NEEDS_HUMAN.
- Do NOT write to `context.state` directly — use `store_answer` tool only.
- See [references/question.md](references/question.md) for full question text and validation grid.
