"""
agents/registry.py
------------------
Builds the full agent registry for EDR QA v5.

17 agents total:
  1 IngestAgent   — edr-ingest skill
  15 Q agents     — edr-q01 through edr-q15 skills (auto-generated from questions.py)
  1 ReportAgent   — edr-report skill

Each AgentConfig carries:
  - name          used as LlmAgent name
  - skill_name    maps to skills/<skill_name>/SKILL.md
  - instruction   loaded from SKILL.md body at build time
  - tools         subset of FunctionTools this agent needs
  - depends_on    (Q agents only) prior question numbers that must complete first

Tool subsets per agent type:
  IngestAgent     fetch_edr_data, store_edr_data, get_edr_data
  Q agents        get_edr_data, get_prior_answers, answer_question, store_answer
  ReportAgent     get_all_answers, get_edr_data, build_report, store_verdict
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

from questions import EDR_QUESTIONS, EDRQuestion

SKILLS_DIR = Path(__file__).parent.parent / "skills"


@dataclass
class AgentConfig:
    name:       str
    skill_name: str
    tool_names: list[str]
    depends_on: tuple[int, ...] = ()

    @property
    def skill_dir(self) -> Path:
        return SKILLS_DIR / self.skill_name

    def load_instruction(self) -> str:
        """Load the SKILL.md body (after frontmatter) as the agent instruction."""
        skill_path = self.skill_dir / "SKILL.md"
        if not skill_path.exists():
            raise FileNotFoundError(
                f"Skill file not found: {skill_path}\n"
                f"Run: python skill_generator.py"
            )
        content = skill_path.read_text(encoding="utf-8")
        # Strip YAML frontmatter (between --- delimiters)
        if content.startswith("---"):
            end = content.find("---", 3)
            if end != -1:
                content = content[end + 3:].lstrip()
        return content

    def load_description(self) -> str:
        """Load the description field from SKILL.md frontmatter."""
        skill_path = self.skill_dir / "SKILL.md"
        if not skill_path.exists():
            return self.name
        content = skill_path.read_text(encoding="utf-8")
        match = re.search(r"^description:\s*[>|]?\s*\n?(.*?)(?=\n\w|\Z)", content, re.DOTALL | re.MULTILINE)
        if match:
            # Collapse YAML block scalar indentation
            lines = [l.strip() for l in match.group(1).strip().splitlines()]
            return " ".join(l for l in lines if l)
        return self.name


def _q_agent_name(n: int) -> str:
    return f"q{n:02d}_agent"


def build_registry() -> list[AgentConfig]:
    """
    Build the full ordered list of 17 AgentConfigs.
    Order: ingest → q01 → q02 → ... → q15 → report
    """
    configs: list[AgentConfig] = []

    # 1. IngestAgent
    configs.append(AgentConfig(
        name="ingest_agent",
        skill_name="edr-ingest",
        tool_names=["fetch_edr_data", "store_edr_data", "get_edr_data"],
    ))

    # 2–16. Q01–Q15 agents (generated from questions.py)
    for q in EDR_QUESTIONS:
        configs.append(AgentConfig(
            name=_q_agent_name(q.number),
            skill_name=f"edr-q{q.number:02d}",
            tool_names=["get_edr_data", "get_prior_answers", "answer_question", "store_answer"],
            depends_on=q.depends_on,
        ))

    # 17. ReportAgent
    configs.append(AgentConfig(
        name="report_agent",
        skill_name="edr-report",
        tool_names=["get_all_answers", "get_edr_data", "build_report", "store_verdict"],
    ))

    return configs


# Eager singleton — built once at import time
AGENT_REGISTRY: list[AgentConfig] = build_registry()

# Fast lookup by name
AGENT_MAP: dict[str, AgentConfig] = {cfg.name: cfg for cfg in AGENT_REGISTRY}

# Q-agent configs in order
Q_AGENT_CONFIGS: list[AgentConfig] = [
    cfg for cfg in AGENT_REGISTRY
    if cfg.name.startswith("q") and cfg.name.endswith("_agent")
]
