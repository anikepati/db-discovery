---
name: edr-q01
description: >
  EDR QA Question 1 of 15 (Event Creation): Validate the event description is complete for purposes of review..
  Reads EDR data from context.state, reasons using Claude claude-sonnet-4-6, writes
  answer to context.state["answers"]["q1"]. Use only in EDR QA pipeline.
license: Proprietary
metadata:
  author: edr-qa-team
  version: "5.0"
  pipeline: edr-qa-v5
  question_number: "1"
  category: "Event Creation"
  requires_human: "false"
compatibility: Requires ADK ToolContext, Anthropic API, context.state with edr_data populated
allowed-tools: get_edr_data get_prior_answers answer_question store_answer
---

# EDR QA — Question 1: Event Creation

**Validate the event description is complete for purposes of review.**

## Dependencies

Depends on: None (first question in chain)

Prior answers for dependent questions MUST be in `context.state["answers"]` before this agent runs.

## Steps

1. Call `get_edr_data()` — reads `context.state["edr_data"]` (populated by IngestAgent)
2. Call `get_prior_answers()` — reads `context.state["answers"]` for dependent Q answers
3. Call `answer_question(question_number=1, edr_data=<step1>, prior_answers=<step2>)`
   - This calls Claude claude-sonnet-4-6 with the check logic and EDR data
   - Returns: `answer`, `reasoning`, `requires_human`, `human_action`
4. Call `store_answer(question_number=1, answer=..., reasoning=..., ...)` 
   - Writes to `context.state["answers"]["q1"]`
5. Respond with exactly:

```
Q01 [Event Creation]: <answer>
REASONING: <1-2 sentence summary>
```

## Check Logic

```
Compare ecn_number vs input_file_ecn, event_type vs input_file_event_type, workflow_status vs input_file_workflow_status. If ALL 3 match: Y. If any mismatch: N.
```

## Validation

Match ECN #, Event Type & Subtype, and Workflow Status against Input File fields.

## Output Format

State each of the 3 field comparisons explicitly then give Y or N.

Valid answers: `Y` | `N` | `N/A` | `NEEDS_HUMAN`

## DB Fields Used

| Column | Notes |
|--------|-------|
| `ecn_number` |
| `event_type` |
| `event_subtype` |
| `workflow_status` |
| `input_file_ecn` |
| `input_file_event_type` |
| `input_file_workflow_status` |

## Gotchas

- Always call `get_edr_data()` first — never use stale data from a prior step.
- Always call `get_prior_answers()` before `answer_question` — dependency answers may affect the result.
- Never skip this question even if a dependency answered N or NEEDS_HUMAN.
- Do NOT write to `context.state` directly — use `store_answer` tool only.
- See [references/question.md](references/question.md) for full question text and validation grid.
