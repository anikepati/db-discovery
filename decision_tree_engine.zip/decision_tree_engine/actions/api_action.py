"""
API Action Handler — makes HTTP calls via httpx.
Includes retry logic, timeout, and structured response.
"""

import logging
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

# Try httpx first, fall back to requests
try:
    import httpx
    HTTP_CLIENT = "httpx"
except ImportError:
    import requests
    HTTP_CLIENT = "requests"


def call_api(
    url: str,
    method: str = "POST",
    payload: Optional[Dict[str, Any]] = None,
    headers: Optional[Dict[str, str]] = None,
    timeout: int = 30,
    retries: int = 3,
) -> Dict[str, Any]:
    """
    Make an HTTP API call with retry logic.

    Returns:
        dict with keys: status, status_code, response_body, error
    """
    default_headers = {"Content-Type": "application/json"}
    if headers:
        default_headers.update(headers)

    for attempt in range(1, retries + 1):
        try:
            logger.info(
                f"  [API] {method} {url} | attempt {attempt}/{retries}"
            )

            if HTTP_CLIENT == "httpx":
                response = _call_httpx(url, method, payload, default_headers, timeout)
            else:
                response = _call_requests(url, method, payload, default_headers, timeout)

            if response["status_code"] in (200, 201, 202, 204):
                response["status"] = "success"
                logger.info(f"  [API] Success: {response['status_code']}")
                return response
            else:
                logger.warning(
                    f"  [API] HTTP {response['status_code']} on attempt {attempt}"
                )
                if attempt == retries:
                    response["status"] = "failed"
                    return response

        except Exception as e:
            logger.error(f"  [API] Error on attempt {attempt}: {e}")
            if attempt == retries:
                return {
                    "status": "error",
                    "status_code": None,
                    "response_body": None,
                    "error": str(e),
                }

    return {"status": "error", "error": "exhausted retries"}


def _call_httpx(url, method, payload, headers, timeout):
    """HTTP call using httpx."""
    with httpx.Client(timeout=timeout) as client:
        resp = client.request(
            method=method.upper(),
            url=url,
            json=payload,
            headers=headers,
        )
        return {
            "status_code": resp.status_code,
            "response_body": resp.text,
            "error": None,
        }


def _call_requests(url, method, payload, headers, timeout):
    """HTTP call using requests (fallback)."""
    import requests as req
    resp = req.request(
        method=method.upper(),
        url=url,
        json=payload,
        headers=headers,
        timeout=timeout,
    )
    return {
        "status_code": resp.status_code,
        "response_body": resp.text,
        "error": None,
    }
