# Q09 Full Reference — Level 2 Review

## Question

Confirm if approver decision and rationale were obtained for elevated approvals.

## Validation

Assess elevated approval decision and rationale alignment.

## Check Logic (apply exactly)

If elevated_approval_required = False or blank: answer N/A. If elevated_approval_required = True:   check elevated_approval_decision is populated AND   elevated_approval_rationale aligns to the decision. If aligned: Y. Else: N.

## Depends On

Q06, Q07, Q08

## Output Hint

State elevated_approval_required, elevated_approval_decision, elevated_approval_rationale alignment. Answer Y, N, or N/A.

## Requires Human Review

No — answer should be Y, N, or N/A only.

## DB Fields

- `elevated_approval_required`
- `elevated_approval_decision`
- `elevated_approval_rationale`

## Authorization Grid (relevant for Q2, Q3, Q5, Q8)

See `skills/edr-ingest/references/schema.md` for the full authorization grid
mapping EDR type + brokerage type → authorized recommending groups.
