"""
Domain models for the QA pipeline.
Only models that are constructed AND consumed by the pipeline are defined here.
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any


class QAVerdict(str, Enum):
    PASS = "pass"
    CONDITIONAL_PASS = "conditional_pass"
    FAIL = "fail"
    REQUIRES_ESCALATION = "requires_escalation"
    INCONCLUSIVE = "inconclusive"

    @property
    def passed(self) -> bool:
        return self in (QAVerdict.PASS, QAVerdict.CONDITIONAL_PASS)

    @classmethod
    def from_string(cls, value: str) -> "QAVerdict":
        """Parse a verdict string tolerantly (handles spaces, mixed case)."""
        normalized = value.upper().strip().replace(" ", "_")
        try:
            return cls(normalized.lower())
        except ValueError:
            return cls.INCONCLUSIVE


@dataclass
class QuestionAnswer:
    """One answered question from the reasoning chain."""
    number: int
    title: str
    question: str
    depends_on: list[int]
    reasoning: str
    answer: str
    raw_response: str


@dataclass
class QAResult:
    """Final output of the complete pipeline run."""
    process_id: str
    session_id: str
    verdict: QAVerdict
    overall_score: float
    executive_summary: str
    blocking_issues: list[str]
    remediation_actions: list[dict[str, Any]]
    next_steps: list[str]
    answers: list[QuestionAnswer]
    started_at: datetime
    completed_at: datetime
    duration_seconds: float

    @property
    def passed(self) -> bool:
        return self.verdict.passed

    def one_line_summary(self) -> str:
        return (
            f"[{self.verdict.value.upper()}] {self.process_id} | "
            f"Score: {self.overall_score:.1f}/100 | "
            f"Blocking: {len(self.blocking_issues)} | "
            f"{self.duration_seconds:.1f}s"
        )
