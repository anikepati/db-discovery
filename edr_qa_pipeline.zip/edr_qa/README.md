# EDR QA Pipeline

Agentic QA evaluator for EDR (Event Decision Review) processes built with **Google ADK**.  
Answers all 15 QA questions from your EDR QA spreadsheet in a sequential reasoning chain,  
with special human-review flagging for Profile Refresh and Exit Decision questions.

---

## Architecture

```
EDRQAPipeline (SequentialAgent)
│
├── DataFetcherAgent
│     Calls fetch_edr_data(ecn_id) → stores Actimize data as 'edr_data' in session state
│
├── QA_Q01  [Event Creation]          Event description complete?
├── QA_Q02  [Event Creation]          Recommendation rationale aligns with risk action type?
├── QA_Q03  [Event Creation]          Recommendation rationale aligns with event description?
├── QA_Q04  [Level 1 Review]          L1 rationale aligns with risk action type?
├── QA_Q05  [Level 1 Review]          L1 rationale reasonable vs event description?
├── QA_Q06  [Level 2 Review]          L2 decision rationale aligns with risk decision type?
├── QA_Q07  [Level 2 Review]          L2 decision rationale reasonable vs event description?
├── QA_Q08  [Level 2 Review]          L2 rationale does not reference incorrect group?
├── QA_Q09  [Level 2 Review]          Elevated approval obtained if required?
├── QA_Q10  [Decision Execution]      Profile Refresh referred to appropriate group? ⚠️ HUMAN
├── QA_Q11  [Decision Execution]      Risk Rating Override present in Actimize (RRO #)?
├── QA_Q12  [Decision Execution]      Exit Decision referred to appropriate group? ⚠️ HUMAN
├── QA_Q13  [Decision Execution]      Profile Refresh after decision change? ⚠️ HUMAN
├── QA_Q14  [Decision Execution]      Risk Rating Override after decision change?
├── QA_Q15  [Decision Execution]      Exit Decision after decision change? ⚠️ HUMAN
│
└── VerdictSynthesizerAgent
      Reads all 15 answers → produces verdict_json → EDRQAResult
```

**⚠️ HUMAN questions (10, 12, 13, 15):** Profile Refresh and Exit Decision validations
require a human to send emails and obtain evidence. The pipeline answers `NEEDS_HUMAN`
with a specific action description rather than auto-answering.

---

## File structure

```
edr_qa/
├── main.py               Entry point (CLI)
├── pipeline_runner.py    Execution engine
├── models.py             EDRQAResult, QAAnswer, EDRVerdict
├── config.py             Settings + logging
├── questions.py          All 15 EDRQuestion definitions ← only file to edit for question changes
├── fetch_tool.py         fetch_edr_data() ← replace mock with real Actimize call
├── data_fetcher.py       DataFetcherAgent
├── question_agents.py    QA_Q01…QA_Q15 factory
├── verdict_synthesizer.py VerdictSynthesizerAgent
├── orchestrator.py       SequentialAgent assembly
└── tests/
    └── test_pipeline.py  Unit tests (no API calls required)
```

---

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env        # set GOOGLE_API_KEY
python main.py --ecn-id ECN-2024-001
python main.py --ecn-id ECN-2024-002 --output result.json
```

Demo ECN IDs:

| ECN | Type | Expected verdict |
|-----|------|-----------------|
| `ECN-2024-001` | Priority FC Business Approval | PASS |
| `ECN-2024-002` | Increase Risk Rating | REQUIRES_HUMAN_REVIEW |
| `ECN-2024-003` | Exit Decision | REQUIRES_HUMAN_REVIEW |

---

## Tests

```bash
pytest tests/ -v
pytest tests/ -v --cov=. --cov-report=term-missing
```

---

## Connecting real Actimize data

Replace `_load_from_actimize()` in `fetch_tool.py`:

```python
def _load_from_actimize(ecn_id: str) -> dict | None:
    # Actimize API:
    return actimize_client.get_edr_record(ecn_id)

    # Or database:
    return db.fetchone("SELECT * FROM actimize_edr WHERE ecn_id = %s", ecn_id)
```

The returned dict keys must match what `questions.py` and agent prompts reference.

---

## Verdict logic

| Verdict | Condition |
|---------|-----------|
| `PASS` | All applicable questions = Y, zero NEEDS_HUMAN |
| `PASS_WITH_EXCEPTIONS` | Pass rate ≥ 80%, zero N answers, only N/A or NEEDS_HUMAN |
| `REQUIRES_HUMAN_REVIEW` | Any NEEDS_HUMAN answer present |
| `FAIL` | Any N answer present |
