"""
pipeline_runner.py
------------------
Top-level execution engine.

Responsibilities:
  - Generate a unique run_id for each ECN run
  - Create the per-run RunState (shared in-memory dict)
  - Create the AuditWriter for this run
  - Call run_edr_qa() with retry logic
  - Parse the final result from RunState + output JSON
  - Return a typed EDRQAResult
"""

import asyncio
import json
import logging
import os
import time
from datetime import datetime
from pathlib import Path
from uuid import uuid4

from config import settings, configure_logging
from models import EDRQAResult, QAAnswer, QuestionResult, RunState, Verdict
from audit.audit_writer import AuditWriter
from agents.agent import run_edr_qa

logger = logging.getLogger(__name__)

_VERDICT_ICONS = {
    Verdict.PASS:                  "✅",
    Verdict.PASS_WITH_EXCEPTIONS:  "⚠️ ",
    Verdict.FAIL:                  "❌",
    Verdict.REQUIRES_HUMAN_REVIEW: "👤",
}


class PipelineRunner:
    """
    Executes the EDR QA pipeline for a given ECN.
    Each call is fully isolated — separate RunState, audit dir, output file.
    """

    async def run(
        self,
        ecn_id:      str,
        output_path: str | None = None,
        verbose:     bool = True,
    ) -> EDRQAResult:
        """
        Run the full EDR QA pipeline.

        Args:
            ecn_id:       ECN identifier e.g. 'ECN-2024-001'.
            output_path:  Where to write result JSON. Auto-generated if None.
            verbose:      Stream per-agent output to stdout.

        Returns:
            Typed EDRQAResult.

        Raises:
            RuntimeError: If the pipeline fails after all retries.
        """
        # ── Setup ─────────────────────────────────────────────────────────────
        ts      = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        run_id  = f"run_{ts}_{ecn_id}"
        started = datetime.utcnow()
        t0      = time.time()

        if output_path is None:
            os.makedirs(settings.outputs_dir, exist_ok=True)
            output_path = os.path.join(settings.outputs_dir, f"edr_{ecn_id}_{ts}.json")

        run_state = RunState(run_id=run_id, ecn_id=ecn_id)
        audit     = AuditWriter(run_id=run_id, ecn_id=ecn_id, audit_dir=settings.audit_dir)

        audit.write_manifest(ecn_id=ecn_id, questions_count=15)

        logger.info(
            "Pipeline started",
            extra={"run_id": run_id, "ecn_id": ecn_id},
        )

        if verbose:
            print(f"\n{'═' * 60}")
            print(f"  EDR QA PIPELINE  v4")
            print(f"  ECN      : {ecn_id}")
            print(f"  Run ID   : {run_id}")
            print(f"  Output   : {output_path}")
            print(f"  Started  : {started.strftime('%H:%M:%S UTC')}")
            print(f"{'═' * 60}")

        # ── Run with retry ────────────────────────────────────────────────────
        last_exc: Exception | None = None
        for attempt in range(1, settings.max_retries + 1):
            try:
                await run_edr_qa(
                    ecn_id=ecn_id,
                    run_id=run_id,
                    run_state=run_state,
                    output_path=output_path,
                    audit=audit,
                    verbose=verbose,
                )
                break
            except Exception as exc:
                last_exc = exc
                logger.error(
                    "Attempt %d/%d failed: %s",
                    attempt, settings.max_retries, exc,
                    extra={"run_id": run_id, "ecn_id": ecn_id},
                    exc_info=True,
                )
                if attempt < settings.max_retries:
                    delay = settings.retry_delay * attempt
                    if verbose:
                        print(f"\n⟳  Retry {attempt}/{settings.max_retries} in {delay:.0f}s…")
                    await asyncio.sleep(delay)
                else:
                    raise RuntimeError(
                        f"Pipeline failed after {settings.max_retries} attempts: {exc}"
                    ) from last_exc

        duration = time.time() - t0

        # ── Parse result ──────────────────────────────────────────────────────
        result = self._load_result(
            ecn_id=ecn_id,
            run_id=run_id,
            output_path=output_path,
            started_at=started,
            duration=duration,
        )

        # ── Write audit summary ───────────────────────────────────────────────
        audit.write_run_summary(
            verdict=result.verdict.value,
            pass_rate=result.overall_pass_rate,
            failed_questions=result.failed_questions,
            human_items=result.human_review_items,
            duration_seconds=duration,
            state_snapshot=run_state.snapshot(),
        )

        logger.info(
            "Pipeline complete: %s",
            result.one_line(),
            extra={"run_id": run_id, "ecn_id": ecn_id},
        )

        if verbose:
            self._print_result(result, output_path, audit.audit_path())

        return result

    # ── Result loading ────────────────────────────────────────────────────────

    def _load_result(
        self,
        ecn_id:     str,
        run_id:     str,
        output_path: str,
        started_at: datetime,
        duration:   float,
    ) -> EDRQAResult:
        try:
            data = json.loads(Path(output_path).read_text(encoding="utf-8"))
        except Exception as e:
            logger.error("Could not read result JSON: %s", e)
            data = {}

        verdict = Verdict.from_string(data.get("verdict", "REQUIRES_HUMAN_REVIEW"))

        question_results = [
            QuestionResult(
                number=a["number"],
                category=a.get("category", ""),
                question=a.get("question", ""),    # may be empty in compact output
                depends_on=[],
                answer=QAAnswer.from_string(a.get("answer", "NEEDS_HUMAN")),
                reasoning=a.get("reasoning", ""),
                requires_human=a.get("requires_human", False),
                human_action=a.get("human_action", ""),
            )
            for a in data.get("answers", [])
        ]

        return EDRQAResult(
            run_id=run_id,
            ecn_id=ecn_id,
            verdict=verdict,
            overall_pass_rate=float(data.get("overall_pass_rate", 0.0)),
            question_results=question_results,
            failed_questions=data.get("failed_questions", []),
            human_review_items=data.get("human_review_required", []),
            output_path=output_path,
            started_at=started_at,
            completed_at=datetime.utcnow(),
            duration_seconds=duration,
        )

    # ── Pretty printing ───────────────────────────────────────────────────────

    def _print_result(
        self,
        result:     EDRQAResult,
        output_path: str,
        audit_path: str,
    ) -> None:
        icon = _VERDICT_ICONS.get(result.verdict, "❓")
        print(f"\n{'═' * 60}")
        print(f"  {icon}  {result.verdict.value}")
        print(f"  ECN      : {result.ecn_id}")
        print(f"  Run ID   : {result.run_id}")
        print(f"  Pass Rate: {result.overall_pass_rate:.1f}%")
        print(f"  Duration : {result.duration_seconds:.1f}s")
        print(f"{'═' * 60}")

        if result.failed_questions:
            print(f"\n❌ Failed   : Q{result.failed_questions}")

        if result.human_review_items:
            print(f"\n👤 Human review ({len(result.human_review_items)}):")
            for item in result.human_review_items:
                print(f"   Q{item['question']}: {item['action_required']}")

        print(f"\n💾 Report   : {output_path}")
        print(f"🗂  Audit    : {audit_path}/\n")
