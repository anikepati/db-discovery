"""
runtime/yaml_runtime.py
-----------------------
Connection type system for the meta-agent system's own tools.
Identical pattern to the pipelines it generates.
"""
import os, re, yaml, sqlalchemy, logging
from typing import Any
from jinja2 import sandbox as jinja_sandbox
from dotenv import load_dotenv

load_dotenv()
logger = logging.getLogger(__name__)

try:
    import RestrictedPython
    RESTRICTED_AVAILABLE = True
    SAFE_BUILTINS = RestrictedPython.safe_builtins.copy()
    SAFE_BUILTINS.update({
        k: v for k, v in {
            "len":len,"range":range,"enumerate":enumerate,"zip":zip,
            "map":map,"filter":filter,"sum":sum,"min":min,"max":max,
            "round":round,"list":list,"dict":dict,"set":set,"tuple":tuple,
            "str":str,"int":int,"float":float,"bool":bool,"sorted":sorted,
            "reversed":reversed,"isinstance":isinstance,"type":type,
            "abs":abs,"any":any,"all":all,"print":print,
        }.items()
    })
except ImportError:
    RESTRICTED_AVAILABLE = False

ALLOWED_IMPORTS = {"json","re","os","pathlib","subprocess","sys","py_compile",
                   "statistics","math","datetime","collections","itertools","functools"}
MCP_TOOL_TYPES = {"sql","rest_api","sftp","python"}
_ENV_VAR_RE = re.compile(r"\$\{([A-Z0-9_]+)\}")


def _resolve_secret(value: Any, context: str) -> Any:
    if not isinstance(value, str):
        return value
    def _replace(m):
        var = m.group(1)
        val = os.environ.get(var)
        if val is None:
            raise ValueError(f"[{context}] Missing env var: '{var}'. Add to .env")
        return val
    return _ENV_VAR_RE.sub(_replace, value)


def _resolve_recursive(obj: Any, ctx: str) -> Any:
    if isinstance(obj, str):   return _resolve_secret(obj, ctx)
    if isinstance(obj, dict):  return {k: _resolve_recursive(v, ctx) for k, v in obj.items()}
    if isinstance(obj, list):  return [_resolve_recursive(v, ctx) for v in obj]
    return obj


class _DBConnection:
    def __init__(self, name, config, auth):
        if auth.get("type") == "connection_string":
            self.conn_str = auth["value"]
        else:
            d = config.get("driver","mssql+pyodbc")
            h = config.get("host","localhost")
            p = config.get("port","")
            db = config.get("database","db")
            u  = auth.get("username","")
            pw = auth.get("password","")
            hp = f"{h}:{p}" if p else h
            odbc = config.get("odbc_driver","ODBC Driver 18 for SQL Server")
            self.conn_str = f"{d}://{u}:{pw}@{hp}/{db}?driver={odbc.replace(' ','+')}"

    def execute(self, query, params):
        engine = sqlalchemy.create_engine(self.conn_str, fast_executemany=True)
        with engine.connect() as conn:
            result = conn.execute(sqlalchemy.text(query), params)
            return [dict(row._mapping) for row in result]


class YAMLFunctionRuntime:
    def __init__(self, yaml_path: str) -> None:
        with open(yaml_path) as f:
            raw = yaml.safe_load(f)
        self.yaml_path = yaml_path
        self.jinja = jinja_sandbox.SandboxedEnvironment()
        self._connections: dict[str, Any] = {}
        for conn_def in raw.get("connections", []):
            name = conn_def["name"]
            ctx  = f"connection '{name}'"
            cfg  = _resolve_recursive(conn_def.get("config", {}), ctx)
            auth = _resolve_recursive(conn_def.get("auth",   {}), ctx)
            t    = conn_def.get("type","db")
            if t == "db":
                self._connections[name] = _DBConnection(name, cfg, auth)
            else:
                self._connections[name] = {"type": t, "config": cfg, "auth": auth}
        self.registry = {
            fn["id"]: fn
            for fn in raw.get("functions", [])
            if fn.get("type") in MCP_TOOL_TYPES
        }

    def _render(self, tmpl, inputs):
        return self.jinja.from_string(str(tmpl)).render(inputs=inputs)

    def _resolve_inputs(self, fn_def, raw):
        resolved = {}
        for name, schema in fn_def.get("inputs", {}).items():
            if name in raw:
                resolved[name] = raw[name]
            elif "default" in schema:
                resolved[name] = schema["default"]
            elif schema.get("required", False):
                raise ValueError(f"Tool '{fn_def['id']}' missing required input: '{name}'")
        return resolved

    def execute(self, function_id: str, inputs: dict) -> Any:
        fn = self.registry.get(function_id)
        if not fn:
            raise ValueError(f"Unknown function: '{function_id}'")
        inputs  = self._resolve_inputs(fn, inputs)
        fn_type = fn.get("type")
        if fn_type == "sql":
            conn   = self._connections.get(fn.get("connection_ref",""))
            cfg    = fn["config"]
            params = {k: self._render(v, inputs) for k, v in cfg.get("params", {}).items()}
            return conn.execute(cfg["query"], params)
        elif fn_type == "python":
            return self._run_python(fn["python"], inputs)
        raise ValueError(f"Unsupported type: '{fn_type}'")

    def _run_python(self, python_def, inputs):
        if not RESTRICTED_AVAILABLE:
            # Fall back to exec with expanded builtins for meta-system tools
            local_ns  = {"inputs": inputs, "result": None}
            global_ns = {
                "__builtins__": __builtins__,
                "os": __import__("os"),
                "json": __import__("json"),
                "re": __import__("re"),
                "subprocess": __import__("subprocess"),
                "sys": __import__("sys"),
            }
            try:
                global_ns["pathlib"] = __import__("pathlib")
                global_ns["py_compile"] = __import__("py_compile")
            except ImportError:
                pass
            exec(compile(python_def["code"], "<yaml_tool>", "exec"), global_ns, local_ns)
            if local_ns.get("result") is None:
                raise ValueError("Python tool did not assign to `result`.")
            return local_ns["result"]

        compiled = RestrictedPython.compile_restricted(python_def["code"], "<yaml_tool>", "exec")
        def _safe_import(name, *a, **kw):
            if name not in ALLOWED_IMPORTS:
                raise ImportError(f"'{name}' not allowed")
            return __import__(name, *a, **kw)
        local_ns  = {"inputs": inputs, "result": None}
        global_ns = {
            "__builtins__": SAFE_BUILTINS, "__import__": _safe_import,
            "_print_": RestrictedPython.PrintCollector,
            "_getiter_": iter, "_getattr_": getattr,
            "_inplacevar_": RestrictedPython.Guards.guarded_inplacevar,
        }
        exec(compiled, global_ns, local_ns)
        if local_ns.get("result") is None:
            raise ValueError("Python tool did not assign to `result`.")
        return local_ns["result"]
