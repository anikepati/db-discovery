---
name: edr-ingest
description: >
  Fetches all EDR data for a given ECN from the Actimize MS SQL view
  vw_get_qa_actimize_data and stores it in ADK context.state["edr_data"]
  for all downstream QA agents to read. Use when starting an EDR QA pipeline run.
license: Proprietary
metadata:
  author: edr-qa-team
  version: "5.0"
  pipeline: edr-qa-v5
compatibility: Requires pyodbc, MS SQL Server access, ADK ToolContext
allowed-tools: fetch_edr_data store_edr_data get_edr_data
---

# EDR Ingest Skill

Fetches one EDR record from Actimize and seeds shared context state.

## Inputs

- `ecn_id` — ECN identifier e.g. `ECN-2024-001`

## Steps

1. Call `fetch_edr_data(ecn_id)` — queries `vw_get_qa_actimize_data WHERE ecn_number = ?`
2. If the result is empty or an error: respond `INGEST FAILED: <reason>` and stop.
3. Call `store_edr_data(edr_data)` — writes the record to `context.state["edr_data"]`
4. Call `get_edr_data()` — reads back to confirm storage succeeded
5. Respond with exactly this format:

```
INGEST OK
ECN:                    <ecn_number>
Event Type:             <event_type>
Event Subtype:          <event_subtype>
Brokerage Type:         <brokerage_type>
Workflow Status:        <workflow_status>
Recommended Action:     <recommended_action>
Recommending Group:     <recommending_group>
L1 Recommended Action: <l1_recommended_action>
L2 Decision:            <l2_decision>
L2 Action:              <l2_action>
Final Action:           <final_recommended_action>
Elevated Approval:      <elevated_approval_required>
RRO Number:             <rro_number or NONE>
```

## Gotchas

- `vw_get_qa_actimize_data` returns one row per ECN. If you get 0 rows the ECN does not exist — respond `INGEST FAILED: ECN not found`.
- All column names are lowercase in the view. Do not use camelCase.
- `rro_number` may be NULL — treat NULL as NONE, not as empty string.
- `elevated_approval_required` is a bit field — 1 = True, 0 = False.
- Do NOT analyse or interpret the data — QA agents do that.

## DB schema reference

See [references/schema.md](references/schema.md) for all column names and types from `vw_get_qa_actimize_data`.
