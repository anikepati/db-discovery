#!/usr/bin/env python3
"""
AgentForge — SOP.md → Google ADK Pipeline via Real Agents
===========================================================
Six ADK LlmAgents that read a SOP, reason about it, plan the pipeline
structure, generate all code files, validate, and self-correct.

HOW IT WORKS:
  The system IS a Google ADK SequentialAgent pipeline.
  Each agent communicates via conversation history — same pattern
  as the pipelines it generates.

  Agent 1 (IntentAgent):    reads SOP → emits INTENT_SPEC JSON
  Agent 2 (PlannerAgent):   reads INTENT_SPEC → emits AGENT_PLAN JSON
  Agent 3 (GeneratorAgent): reads AGENT_PLAN → calls write_file tool
  Agent 4 (ValidatorAgent): reads files → calls check_python_syntax tool
  [Agents 3+4 loop up to 3x if validation fails]
  Agent 5 (MockDataAgent):  writes mock_data.json + mock_runner.py
  Agent 6 (WriterAgent):    runs pytest + mock → emits DELIVERY_MANIFEST

MODES:
  --mode system   Backend agents: SQL/API data sources
  --mode surface  UI agents: browser (Playwright) / desktop (pyautogui) / QA checks

USAGE:
  # System mode — DB-backed compliance pipeline
  python run.py --sop sops/edr_qa.md --name edr_qa --mode system

  # Surface mode — auto-detect from SOP content
  python run.py --sop sops/portal.md --name portal_auto --mode surface

  # Force surface type
  python run.py --sop sops/sap.md --name sap_auto --mode surface --surface thick_client

  # Show what agents detect without generating files
  python run.py --sop sops/edr_qa.md --name edr_qa --mode system --dry-run

AFTER GENERATION:
  cd output/edr_qa
  cp .env.example .env && nano .env
  python tool_generator.py
  python mock/mock_runner.py
  pytest tests/ -v
  python main.py --ecn-id ECN-2024-001
"""

import argparse
import asyncio
import json
import logging
import os
import sys
import textwrap
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from agentforge_meta.agents.pipeline import run_agentforge

SURFACE_TYPES = ["qa_qc", "thin_client", "thick_client", "db_system", "api_system", "general"]


def _load_sop(path: str) -> str:
    """Load SOP file — supports .md, .txt, .xlsx."""
    p = Path(path)
    if p.suffix.lower() in (".xlsx", ".xls"):
        return _excel_to_text(str(p))
    return p.read_text(encoding="utf-8", errors="replace")


def _excel_to_text(path: str) -> str:
    """Convert Excel to structured text for the IntentAgent."""
    try:
        import openpyxl
    except ImportError:
        print("Install openpyxl: pip install openpyxl", file=sys.stderr)
        sys.exit(1)
    wb    = openpyxl.load_workbook(path, data_only=True)
    parts = []
    for sheet in wb.sheetnames:
        ws      = wb[sheet]
        rows    = list(ws.iter_rows(values_only=True))
        cleaned = [[str(c).strip() if c else "" for c in row] for row in rows if any(row)]
        if not cleaned:
            continue
        parts.append(f"\n=== SHEET: {sheet} ===")
        parts.append("COLUMNS: " + " | ".join(c for c in cleaned[0] if c))
        for row in cleaned[1:]:
            pairs = [f"{cleaned[0][i]}: {v}"
                     for i, v in enumerate(row)
                     if i < len(cleaned[0]) and cleaned[0][i] and v]
            if pairs:
                parts.append("ROW: " + " | ".join(pairs))
    return "\n".join(parts)


def _args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="AgentForge — SOP.md → Google ADK Pipeline (agentic)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=textwrap.dedent("""\
        examples:
          python run.py --sop sops/edr_qa.md       --name edr_qa       --mode system
          python run.py --sop sops/portal.md        --name portal_auto  --mode surface
          python run.py --sop sops/sap_steps.md     --name sap_auto     --mode surface --surface thick_client
          python run.py --sop sops/api_steps.md     --name case_api     --mode surface --surface api_system
          python run.py --sop sops/edr_qa.md        --name edr_qa       --mode system --dry-run
        """),
    )
    p.add_argument("--sop",     required=True,
                   help="Path to SOP: Markdown (.md) or Excel (.xlsx)")
    p.add_argument("--name",    required=True,
                   help="Pipeline name in snake_case e.g. edr_qa, rro_qa, portal_auto")
    p.add_argument("--mode",    required=True, choices=["system", "surface"],
                   help="system=DB/API backend | surface=UI automation")
    p.add_argument("--surface", choices=SURFACE_TYPES, default=None,
                   help="Override surface detection (surface mode only)")
    p.add_argument("--out",     default="./output",
                   help="Output base directory (default: ./output)")
    p.add_argument("--dry-run", action="store_true",
                   help="Show INTENT_SPEC + AGENT_PLAN without writing files")
    p.add_argument("--quiet",   action="store_true",
                   help="Suppress per-agent streaming output")
    p.add_argument("--run-id",  default=None,
                   help="Custom run ID for audit trail")
    return p.parse_args()


async def main() -> int:
    args = _args()

    # Validate API keys
    for key in ["ANTHROPIC_API_KEY", "GOOGLE_API_KEY"]:
        if not os.environ.get(key):
            print(f"ERROR: {key} not set in environment.", file=sys.stderr)
            print(f"  export {key}=your_key_here", file=sys.stderr)
            return 1

    # Load SOP
    sop_path = Path(args.sop)
    if not sop_path.exists():
        print(f"ERROR: SOP file not found: {sop_path}", file=sys.stderr)
        return 1

    print(f"\nLoading SOP: {sop_path}")
    sop_text = _load_sop(str(sop_path))
    print(f"Loaded: {len(sop_text):,} characters\n")

    if args.dry_run:
        sop_text = "[DRY RUN — analyse only, do not write files]\n\n" + sop_text

    # Configure logging
    if not args.quiet:
        logging.basicConfig(
            level=logging.WARNING,
            format="%(levelname)s %(name)s %(message)s",
        )

    # Run the meta-pipeline
    manifest = await run_agentforge(
        sop_text=sop_text,
        pipeline_name=args.name.lower().replace("-", "_"),
        mode=args.mode,
        output_dir=args.out,
        surface=args.surface,
        run_id=args.run_id,
        verbose=not args.quiet,
    )

    # Print results
    print(f"\n{'━'*64}")
    print(f"  AgentForge Complete")
    print(f"{'━'*64}")

    if isinstance(manifest, dict):
        print(f"  Pipeline  : {manifest.get('pipeline_name', args.name)}")
        print(f"  Surface   : {manifest.get('surface_type', '?')}")
        print(f"  Output    : {manifest.get('output_directory', '')}")
        print(f"  Files     : {manifest.get('total_files', '?')}")
        print(f"  Tests     : {manifest.get('test_results', '?')}")

        mock = manifest.get("mock_results", {})
        if mock:
            print(f"\n  Mock test results:")
            for scenario, result in mock.items():
                icon = "✅" if "PASS" in result and "FAIL" not in result else (
                    "👤" if "HUMAN" in result else "❌"
                )
                print(f"    {icon}  {scenario}: {result}")

        steps = manifest.get("next_steps", [])
        if steps:
            print(f"\n  Next steps:")
            for step in steps:
                print(f"    {step}")

    print()
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
