"""
Generate a sample Excel file with test data for the decision tree engine.
"""

import pandas as pd
import numpy as np
from pathlib import Path


def generate_sample_data():
    """Create a realistic test dataset."""
    np.random.seed(42)
    n = 20

    data = {
        "ID": [f"ROW-{i:04d}" for i in range(1, n + 1)],
        "BB": np.random.randint(100, 10000, n),
        "BC": np.random.randint(100, 10000, n),
        "Amount": np.random.choice(
            [500, 5000, 15000, 75000, 150000, 600000], n
        ),
        "Currency": np.random.choice(["USD", "EUR", "GBP", "JPY"], n),
        "Status": np.random.choice(["Active", "Inactive", "Pending"], n),
        "Balance": np.random.randint(1000, 200000, n),
        "Email": [
            f"user{i}@example.com" if i % 5 != 0 else None
            for i in range(1, n + 1)
        ],
        "TransactionRef": [
            f"TXN-{''.join(np.random.choice(list('ABCDEFGHIJKLMNOPQRSTUVWXYZ'), 3))}-{np.random.randint(100000, 999999)}"
            if i % 4 != 0
            else f"BAD-REF-{i}"
            for i in range(1, n + 1)
        ],
        "RiskScore": np.random.choice(
            [10, 25, 50, 75, 90, 105, -5], n  # some out of range
        ),
        "Country": np.random.choice(
            ["US", "UK", "CA", "BR", "CN", "IN", "DE"], n
        ),
        "FlagStatus": np.random.choice(
            ["CLEAR", "SUSPICIOUS", "REVIEW"], n
        ),
        "Description": [
            "Normal transaction" if i % 3 != 0
            else "RESTRICTED content flagged"
            for i in range(1, n + 1)
        ],
        "Debit": np.random.randint(100, 50000, n),
        "Credit": np.random.randint(100, 50000, n),
        "Variance": np.random.randint(0, 5000, n),
        "VarianceApproved": np.random.choice(["Yes", "No"], n),
    }

    df = pd.DataFrame(data)

    output_dir = Path("data")
    output_dir.mkdir(exist_ok=True)
    output_path = output_dir / "input.xlsx"
    df.to_excel(output_path, index=False, sheet_name="Sheet1")
    print(f"✓ Generated {n} rows → {output_path}")
    print(f"  Columns: {list(df.columns)}")
    print(f"\nSample rows:")
    print(df.head(5).to_string(index=False))
    return output_path


if __name__ == "__main__":
    generate_sample_data()
