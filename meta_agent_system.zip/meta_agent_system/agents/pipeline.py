"""
agents/pipeline.py
==================
AgentForge Meta-Agent System — 7-agent SequentialAgent pipeline.

Each agent has a real job. Each agent's output is read by all downstream
agents via conversation history (ADK SequentialAgent pattern).

Agent 1 — IntentAgent
  Reads raw input (doc text + table rows).
  Determines: automation type, domain, what system is involved,
  what the record identifier is, what the output should be.
  Produces: IntentSpec JSON in conversation.

Agent 2 — DatabaseDiscoveryAgent
  Reads IntentSpec from conversation.
  Calls db_discovery tools: list_tables, get_schema, sample_data,
  infer_view_name, check_existing_views.
  Produces: SchemaSpec JSON — every column, type, sample value,
  which columns are relevant to the questions.

Agent 3 — PlannerAgent
  Reads IntentSpec + SchemaSpec from conversation.
  Decides: how many agents, what categories, what the dependency
  graph looks like, which questions need human review,
  what connection type to generate, which columns map to which questions.
  Challenges its own plan: are the dependencies correct? are there
  circular deps? are all schema fields accounted for?
  Produces: AgentPlan JSON — the full blueprint for generation.

Agent 4 — GeneratorAgent
  Reads AgentPlan from conversation.
  Generates ALL files: questions.py, tool_registry.py,
  tool_generator.py, ingest_tools.yaml, report_tools.yaml,
  agents/agent.py, pipeline_runner.py, main.py, config.py,
  models.py, audit_writer.py, .env.example, requirements.txt.
  Does NOT write files — emits GeneratedArtifacts JSON with
  file paths and content as strings.

Agent 5 — ValidatorAgent
  Reads GeneratedArtifacts from conversation.
  Checks: Python syntax (compile()), YAML validity (yaml.safe_load()),
  connection_ref integrity, question count matches plan,
  depends_on is acyclic, all schema fields used.
  Produces: ValidationReport JSON — pass/fail per file, issues list.
  If issues found: produces a specific FixRequest for Agent 4 to retry.

Agent 6 — MockDataAgent
  Reads GeneratedArtifacts + SchemaSpec + AgentPlan from conversation.
  Generates: mock_data.json with 5 realistic records (PASS, FAIL,
  NEEDS_HUMAN×2, PARTIAL) whose field values actually exercise the
  check logic of each question.
  Generates: mock_runner.py that patches yaml_runtime.execute() to
  serve mock records instead of hitting the real database.
  Produces: MockArtifacts JSON.

Agent 7 — WriterAgent
  Reads GeneratedArtifacts + MockArtifacts + ValidationReport.
  Only runs if ValidationReport shows all-pass.
  Writes every file to disk at the configured output directory.
  Generates: tests/test_pipeline.py with real pytest tests.
  Produces: final DeliveryManifest JSON — file count, run instructions,
  next steps for the operator.

Loop: if ValidatorAgent reports failures, the pipeline does NOT proceed
to MockDataAgent. Instead it returns to GeneratorAgent with the
ValidationReport as context for a retry (max 3 iterations).
This loop is implemented via a custom LoopAgent wrapping agents 4+5.
"""

import asyncio
import json
import logging
import os
from contextlib import AsyncExitStack
from pathlib import Path

import yaml as _yaml
from google.adk.agents import LlmAgent, SequentialAgent, LoopAgent
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.adk.tools.mcp_tool.mcp_toolset import MCPToolset
from google.genai import types
from mcp.shared.memory import create_connected_server_and_client_session as create_in_memory_pair

from runtime.yaml_runtime import YAMLFunctionRuntime, MCP_TOOL_TYPES
from runtime.mcp_factory import create_mcp_server
from audit.writer import AuditWriter

logger = logging.getLogger(__name__)

# ── Model assignments ─────────────────────────────────────────────────────────
FAST_MODEL     = "gemini-2.0-flash"        # discovery, writing to disk
REASON_MODEL   = "claude-sonnet-4-6"   # intent, planning, generation, validation


async def _build_tool_agent(
    name: str,
    model: str,
    description: str,
    instruction: str,
    yaml_path: str,
    exit_stack: AsyncExitStack,
) -> LlmAgent:
    """Build an LlmAgent that has MCP tools from a YAML file."""
    tools = []
    if yaml_path and Path(yaml_path).exists():
        with open(yaml_path) as f:
            fns = _yaml.safe_load(f).get("functions", [])
        mcp_fns = [fn for fn in fns if fn.get("type") in MCP_TOOL_TYPES]
        if mcp_fns:
            server         = create_mcp_server(yaml_path)
            client_session = await exit_stack.enter_async_context(create_in_memory_pair(server))
            mcp_tools      = await exit_stack.enter_async_context(MCPToolset(client_session=client_session))
            tools.extend(mcp_tools)
    return LlmAgent(
        name=name, model=model,
        description=description, instruction=instruction,
        tools=tools,
    )


def _build_pure_agent(
    name: str, model: str, description: str, instruction: str
) -> LlmAgent:
    """Build an LlmAgent with no tools — reasons from conversation only."""
    return LlmAgent(
        name=name, model=model,
        description=description, instruction=instruction,
        tools=[],
    )


# ── Agent instructions ────────────────────────────────────────────────────────

INTENT_INSTRUCTION = """You are the IntentAgent — the first agent in the AgentForge meta-system.

Your job: read the raw input document and produce a precise IntentSpec JSON.
This JSON drives every downstream agent. Be thorough — missing information here
causes wrong pipelines downstream.

INPUT: The user's message contains the raw document text (Excel rows, markdown, etc.)

PRODUCE: A single JSON block tagged INTENT_SPEC: followed by the JSON.

IntentSpec schema:
{
  "automation_type": "qa | qc | data_pipeline | browser | workflow | report",
  "domain": "one-sentence domain description e.g. 'Actimize EDR compliance review'",
  "system_name": "primary system being automated e.g. 'Actimize', 'Salesforce', 'SAP'",
  "record_identifier": {
    "field":       "snake_case field name e.g. ecn_id, case_id, rro_id",
    "label":       "human label e.g. ECN, Case ID, RRO Number",
    "example":     "e.g. ECN-2024-001, CASE-12345"
  },
  "data_source": {
    "type":        "mssql | postgresql | mysql | sqlite | rest_api | sftp | file",
    "system":      "system name that hosts the data",
    "hint":        "any table/view/endpoint names mentioned in the document"
  },
  "questions_count": <integer — count of distinct questions/checks>,
  "categories":      ["ordered list", "of category names"],
  "has_human_review": <true|false — any checks require human action>,
  "output_format":   "json | pdf | excel | webhook",
  "pipeline_name":   "snake_case_name e.g. edr_qa, rro_qa, case_review",
  "questions_summary": [
    {
      "number": 1,
      "category": "...",
      "question_text": "...",
      "check_summary": "one sentence: what Y/N/NA rule applies",
      "requires_human": false,
      "depends_on": []
    }
  ]
}

RULES:
- Count every distinct question. Do not skip any.
- Set requires_human=true if the check says "leave blank", "send email", "human to validate", "notify team"
- depends_on should reflect explicit references like "if Q3 is N/A" or implied ordering within categories
- Extract the pipeline_name from the domain (e.g. edr_qa, rro_removed, case_qa)
- Output INTENT_SPEC: then the JSON on the next line. No other text after the JSON.
"""


DB_DISCOVERY_INSTRUCTION = """You are the DatabaseDiscoveryAgent — the second agent in the AgentForge meta-system.

Your job: discover the exact database schema needed by the pipeline.
You have tools to probe the database. Use them systematically.

READ from conversation history:
- Find the INTENT_SPEC: block from the previous agent.
- Extract: system_name, data_source.type, data_source.hint, record_identifier.field

DISCOVERY STEPS:
1. Call list_tables — see what tables/views exist. Focus on QA or data views.
2. For the most relevant table/view, call get_schema — get every column name and type.
3. Call sample_data on that table — see real values to understand the data shape.
4. If no obvious view found, call infer_view_name with the domain hint from IntentSpec.
5. Map each column to whether it relates to any question in questions_summary.

PRODUCE: A single JSON block tagged SCHEMA_SPEC: followed by the JSON.

SchemaSpec schema:
{
  "connection_name":   "e.g. actimize_db",
  "env_var":           "e.g. MSSQL_CONN",
  "driver":            "mssql+pyodbc | postgresql | sqlite",
  "table_or_view":     "exact name e.g. vw_get_qa_actimize_data",
  "record_id_column":  "exact column name for the primary identifier",
  "columns": [
    {
      "name":           "exact column name",
      "type":           "string | integer | boolean | date | decimal",
      "nullable":       true,
      "sample_value":   "example value or null",
      "used_by_questions": [1, 3, 6]
    }
  ],
  "discovery_notes":   "anything unusual found during discovery"
}

FALLBACK: If the database is not reachable (no real credentials), call
infer_schema_from_questions with the IntentSpec questions to generate a
best-guess schema from the check logic language. Mark discovery_notes
with "INFERRED — no live database connection".

Output SCHEMA_SPEC: then the JSON. No other text after the JSON.
"""


PLANNER_INSTRUCTION = """You are the PlannerAgent — the third agent in the AgentForge meta-system.
You are the most critical agent. You decide the complete structure of the pipeline.

READ from conversation history:
- INTENT_SPEC: block (from IntentAgent)
- SCHEMA_SPEC: block (from DatabaseDiscoveryAgent)

YOUR JOB: Produce a complete AgentPlan that tells GeneratorAgent exactly what to build.

PLANNING PROCESS:
1. Reconcile question count: IntentSpec says N questions. Verify all are in questions_summary.
2. Build dependency graph: for each question, which prior questions does its check logic reference?
   Check for: "if Q{N}", "depends on", category ordering, "if the above is N/A".
3. Validate graph is acyclic: if circular dependency found, break it by removing the weaker edge.
4. Assign models: Gemini Flash for ingest (fast I/O), Claude claude-sonnet-4-6 for all check agents.
5. Map schema columns to questions: which columns does each check agent need to see?
6. Decide connection type: db for SQL, rest_api for APIs, sftp for file drops.
7. Build the full question list with verbatim check logic from IntentSpec.

SELF-CHALLENGE (do this before outputting):
- Are there any questions I missed? Re-read the document excerpt in INTENT_SPEC.
- Is the dependency graph correct? Trace through each path.
- Does every check agent have the columns it needs from SchemaSpec?
- Are there any human-review questions I should flag?

PRODUCE: A single JSON block tagged AGENT_PLAN: followed by the JSON.

AgentPlan schema:
{
  "pipeline_name": "...",
  "total_agents": <N+2 — ingest + N check + report>,
  "check_agent_count": N,
  "ingest_agent": {
    "model": "gemini-2.0-flash",
    "tool_yaml": "tools/ingest_tools.yaml",
    "columns_to_fetch": ["col1", "col2", ...]
  },
  "check_agents": [
    {
      "number":         1,
      "name":           "q01_agent",
      "category":       "...",
      "question":       "verbatim question text",
      "validation":     "verbatim validation text",
      "check":          "VERBATIM check logic — copy exactly, do not paraphrase",
      "notes":          "verbatim notes or empty string",
      "depends_on":     [],
      "requires_human": false,
      "output_hint":    "Answer Y, N, or N/A with reasoning.",
      "model":          "claude-sonnet-4-6",
      "columns_needed": ["col1", "col3"]
    }
  ],
  "report_agent": {
    "model": "claude-sonnet-4-6",
    "tool_yaml": "tools/report_tools.yaml",
    "output_format": "json"
  },
  "connection": {
    "name":          "actimize_db",
    "type":          "db",
    "auth_type":     "connection_string",
    "env_var":       "MSSQL_CONN",
    "driver":        "mssql+pyodbc",
    "table_or_view": "vw_get_qa_actimize_data"
  },
  "categories": ["...", "..."],
  "human_review_questions": [10, 12],
  "dependency_graph": {"q1": [], "q2": [1], "q3": [1,2]},
  "planner_notes": "any decisions made during planning"
}

Output AGENT_PLAN: then the JSON. Nothing after the JSON.
"""


GENERATOR_INSTRUCTION = """You are the GeneratorAgent — the fourth agent in the AgentForge meta-system.
You write production-grade Python and YAML code.

READ from conversation history:
- AGENT_PLAN: block (from PlannerAgent)
- SCHEMA_SPEC: block (from DatabaseDiscoveryAgent)
- If a VALIDATION_REPORT: block exists with issues, fix those specific issues.

YOUR JOB: Generate every file needed for a complete ADK SequentialAgent pipeline.
The generated code must be IDENTICAL IN PATTERN to the EDR QA v7 reference implementation.

GENERATE THESE FILES (emit each as FILE: <path> then the content):

FILE: questions.py
  - @dataclass(frozen=True) class {PipelineName}Question
  - Fields: number, category, question, validation, check, notes, depends_on, requires_human, output_hint
  - Tuple of all questions from AGENT_PLAN with VERBATIM check logic
  - {NAME}_QUESTIONS tuple, {NAME}_QUESTION_MAP dict, HUMAN_REVIEW_QUESTION_NUMBERS frozenset

FILE: tool_registry.py
  - INGEST_MODEL = "gemini-2.0-flash"
  - QA_MODEL = "claude-sonnet-4-6"
  - @dataclass class ToolConfig: name, yaml_path, description, instruction, model
  - _ingest_config() → ToolConfig with full ingest instruction listing all columns
  - _build_q_instruction(q) → full instruction with check logic verbatim
  - _question_config(q) → ToolConfig per question
  - _report_config() → ToolConfig with full report instruction
  - build_registry() → list[ToolConfig]  (N+2 entries in order)
  - validate_yaml_files(registry)

FILE: tool_generator.py
  - generate_all_question_yamls(tools_dir, force) → list[str]
  - Q_EXTRA_TOOLS: dict[int, list[dict]] = {} with comment showing how to add
  - if __name__ == "__main__": block

FILE: tools/ingest_tools.yaml
  - connections: block with typed auth, ${ENV_VAR}
  - functions: fetch_record with SELECT of ALL columns from SCHEMA_SPEC

FILE: tools/report_tools.yaml
  - functions: build_report python tool
  - Verdict logic: FAIL > REQUIRES_HUMAN_REVIEW > PASS_WITH_EXCEPTIONS > PASS
  - Category breakdown from AGENT_PLAN.categories
  - Writes JSON output file

FILE: yaml_runtime.py
  - Full connection type system: db, rest_api, sftp, file
  - _DBConnection, _RESTConnection, _SFTPConnection classes
  - ${ENV_VAR} resolved at __init__ time — raises ValueError if missing
  - {{ inputs.x }} Jinja at call time only
  - YAMLFunctionRuntime.execute() dispatches to connection type

FILE: mcp_factory.py
  - create_mcp_server(yaml_path) → Server
  - Registers only sql/python/rest_api/sftp tools via MCP

FILE: agents/agent.py
  - _build_agent(config, exit_stack) → LlmAgent (loads YAML, creates MCP server)
  - run_pipeline(record_id, run_id, output_path, registry, audit) → str
  - SequentialAgent with all N+2 sub-agents
  - InMemorySessionService per run
  - Streams audit events

FILE: pipeline_runner.py
  - _get_registry() singleton — calls generate_all_question_yamls + build_registry
  - PipelineRunner.run(record_id, output_path, verbose) → dict

FILE: main.py
  - argparse CLI: --record-id, --output, --quiet, --concurrent, --generate-only
  - asyncio.run(main())

FILE: config.py  (Settings dataclass, configure_logging)
FILE: models.py  (Verdict enum, QAAnswer enum, PipelineResult dataclass)
FILE: audit/audit_writer.py  (AuditWriter class)
FILE: audit/__init__.py  (empty)
FILE: agents/__init__.py  (empty)
FILE: tests/__init__.py   (empty)
FILE: .env.example
FILE: requirements.txt
FILE: pytest.ini

EMIT each file as:
FILE: <relative_path>
```python
<content>
```

After all files, emit:
GENERATION_COMPLETE: {"files_generated": N, "pipeline_name": "..."}
"""


VALIDATOR_INSTRUCTION = """You are the ValidatorAgent — the fifth agent in the AgentForge meta-system.

READ from conversation history:
- AGENT_PLAN: block — the intended structure
- All FILE: blocks emitted by GeneratorAgent

YOUR JOB: Validate every generated file. Be strict. Any issue that would cause
a runtime failure must be flagged.

VALIDATION CHECKS:

For questions.py:
  □ Correct number of questions (matches AGENT_PLAN.check_agent_count)
  □ All questions have non-empty check field
  □ depends_on values reference valid question numbers
  □ requires_human questions are in HUMAN_REVIEW_QUESTION_NUMBERS
  □ Python syntax valid (mentally compile: dataclass, tuple, dict, frozenset)

For tool_registry.py:
  □ build_registry() returns exactly N+2 entries
  □ First entry is ingest_agent, last is report_agent
  □ All check agents use QA_MODEL
  □ Each instruction contains the check logic (not paraphrased)
  □ Python syntax valid

For tools/ingest_tools.yaml:
  □ connections block present with correct env_var
  □ connection_ref in functions matches connections[].name
  □ SELECT query includes all columns from SCHEMA_SPEC
  □ params uses {{ inputs.record_id }} Jinja syntax (NOT ${...})

For tools/report_tools.yaml:
  □ build_report python tool present
  □ Verdict logic covers FAIL, REQUIRES_HUMAN_REVIEW, PASS_WITH_EXCEPTIONS, PASS
  □ result dict assigned before end of code block

For yaml_runtime.py:
  □ _resolve_secret raises ValueError on missing env var
  □ ${ENV_VAR} pattern used in connections, NOT {{ secrets.X }}
  □ MCP_TOOL_TYPES = {"sql", "rest_api", "sftp", "python"} or similar

For agents/agent.py:
  □ SequentialAgent used (not manual orchestration)
  □ No context.state references
  □ No edr_state tool type
  □ InMemorySessionService.create_session called per run

For dependency graph:
  □ No circular dependencies (trace all depends_on paths)
  □ All depends_on numbers exist as questions

PRODUCE: A JSON block tagged VALIDATION_REPORT: followed by the JSON.

ValidationReport schema:
{
  "passed": true|false,
  "file_results": {
    "questions.py": {"ok": true, "issues": []},
    "tool_registry.py": {"ok": false, "issues": ["build_registry returns 16 entries, expected 17"]},
    ...
  },
  "critical_issues": ["list of issues that must be fixed before proceeding"],
  "fix_request": "If passed=false: specific instructions for GeneratorAgent to fix. Be exact."
}

If passed=true: output VALIDATION_REPORT: then JSON.
If passed=false: output VALIDATION_REPORT: then JSON, then NEEDS_REGENERATION: true
"""


MOCK_DATA_INSTRUCTION = """You are the MockDataAgent — the sixth agent in the AgentForge meta-system.

READ from conversation history:
- AGENT_PLAN: — question structure, categories, human review questions
- SCHEMA_SPEC: — column names, types, sample values
- VALIDATION_REPORT: — must be passed=true before you proceed

YOUR JOB: Generate mock data that actually exercises the check logic.
Not random values — values specifically designed so that:
  - Record 1 (MOCK-PASS-001): all checks pass. Y on everything.
  - Record 2 (MOCK-FAIL-001): Q2 fails. The field values should cause check logic to return N.
  - Record 3 (MOCK-FAIL-002): Q6 fails (or the first Level 2 question). Different failure mode.
  - Record 4 (MOCK-HUMAN-001): triggers requires_human=true on at least one question.
  - Record 5 (MOCK-PARTIAL-001): mix of Y, N/A, and NEEDS_HUMAN.

For each record, set field values based on the check logic in AGENT_PLAN.check_agents[].check.
Read the check logic literally:
  "If EDR Type = Priority FC Business Approval → N/A" means:
    MOCK-PASS: event_type = "Priority FC Business Approval" 
    MOCK-FAIL: event_type = "Standard" + make rationale NOT align

PRODUCE TWO FILES tagged as FILE: mock/mock_data.json and FILE: mock/mock_runner.py

mock_data.json: {
  "_generated_by": "MockDataAgent",
  "_schema_version": "1.0",
  "records": [
    {
      "<record_id_field>": "MOCK-PASS-001",
      "_scenario": "all_pass",
      "_expected_verdict": "PASS",
      "<col1>": "<value that causes PASS>",
      ...all columns...
    },
    ... 4 more records
  ]
}

mock_runner.py:
  - import yaml_runtime and monkey-patch YAMLFunctionRuntime.execute
  - When function_id == "fetch_record": return matching record from mock_data.json
  - Otherwise call original execute
  - asyncio.run(main()) that runs all 5 mock records and prints results table
  - --record-id arg to run a single record

After files, emit MOCK_COMPLETE: {"records_generated": 5}
"""


WRITER_INSTRUCTION = """You are the WriterAgent — the seventh and final agent in the AgentForge meta-system.

READ from conversation history:
- All FILE: blocks from GeneratorAgent
- FILE: mock/mock_data.json and FILE: mock/mock_runner.py from MockDataAgent
- VALIDATION_REPORT: — must be passed=true
- AGENT_PLAN: — for test generation

YOUR JOB:
1. Write every file to disk at the configured output directory.
   Call write_file(path, content) for each FILE: block found in conversation history.
   
2. Generate tests/test_pipeline.py:
   - TestQuestions: test question count, all have check logic, human review flagged
   - TestRegistry: test N+2 entries, order, models
   - TestBuildReport: test PASS/FAIL/NEEDS_HUMAN/NA scenarios using report_tools.yaml
   - TestToolGenerator: test generates N YAML files, all empty by default
   - TestArchitecture: test no context.state, SequentialAgent present, no SDK imports
   Write it with write_file("tests/test_pipeline.py", content).

3. Run the mock pipeline:
   Call run_mock_test() which executes mock/mock_runner.py and captures output.
   If it fails: emit the error and the specific file to fix.
   If it passes: emit the results table.

4. Produce final delivery manifest.

PRODUCE: DELIVERY_MANIFEST: followed by JSON.

{
  "pipeline_name": "...",
  "output_directory": "...",
  "files_written": ["questions.py", "tool_registry.py", ...],
  "total_files": N,
  "mock_test_results": {
    "MOCK-PASS-001": "PASS (100.0%)",
    "MOCK-FAIL-001": "FAIL (80.0%)",
    ...
  },
  "test_suite": "tests/test_pipeline.py",
  "next_steps": [
    "cd <output_dir>",
    "cp .env.example .env && nano .env  # fill in MSSQL_CONN",
    "python tool_generator.py",
    "pytest tests/ -v",
    "python main.py --record-id <REAL_ID>"
  ]
}
"""


async def run_meta_pipeline(
    document_text: str,
    pipeline_name:  str,
    output_dir:     str,
    db_yaml_path:   str | None = None,
    run_id:         str | None = None,
    verbose:        bool = True,
) -> dict:
    """
    Run the full 7-agent meta pipeline.

    Args:
        document_text: Raw text from Excel/markdown document
        pipeline_name: e.g. "edr_qa", "rro_qa"
        output_dir:    Where to write generated files
        db_yaml_path:  Optional YAML with real DB connection for discovery
        run_id:        Run identifier
        verbose:       Print agent progress

    Returns:
        DeliveryManifest dict
    """
    import time
    from datetime import datetime

    run_id  = run_id or f"meta_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}"
    out_dir = Path(output_dir) / pipeline_name
    out_dir.mkdir(parents=True, exist_ok=True)

    audit = AuditWriter(run_id=run_id, output_dir=str(out_dir / "meta_audit"))
    audit.start()

    # The discovery YAML — has tools for probing DB and inferring schema
    # Falls back to inference tools if no real DB
    discovery_yaml = db_yaml_path or str(
        Path(__file__).parent.parent / "tools" / "discovery_tools.yaml"
    )
    writer_yaml = str(
        Path(__file__).parent.parent / "tools" / "writer_tools.yaml"
    )

    user_message = (
        f"Pipeline name: {pipeline_name}\n"
        f"Output directory: {out_dir}\n\n"
        f"DOCUMENT:\n{document_text}"
    )

    async with AsyncExitStack() as stack:

        intent_agent = _build_pure_agent(
            name="intent_agent",
            model=REASON_MODEL,
            description="Extracts automation intent, question list, and system context from raw document",
            instruction=INTENT_INSTRUCTION,
        )

        db_discovery_agent = await _build_tool_agent(
            name="db_discovery_agent",
            model=REASON_MODEL,
            description="Discovers database schema — tables, columns, types, sample values",
            instruction=DB_DISCOVERY_INSTRUCTION,
            yaml_path=discovery_yaml,
            exit_stack=stack,
        )

        planner_agent = _build_pure_agent(
            name="planner_agent",
            model=REASON_MODEL,
            description="Plans the complete pipeline structure — dependency graph, agent count, column mapping",
            instruction=PLANNER_INSTRUCTION,
        )

        generator_agent = _build_pure_agent(
            name="generator_agent",
            model=REASON_MODEL,
            description="Generates all pipeline files — Python, YAML, config, models",
            instruction=GENERATOR_INSTRUCTION,
        )

        validator_agent = _build_pure_agent(
            name="validator_agent",
            model=REASON_MODEL,
            description="Validates all generated files — syntax, structure, dependency graph, schema coverage",
            instruction=VALIDATOR_INSTRUCTION,
        )

        # Generator + Validator wrapped in a LoopAgent — retries on validation failure
        gen_val_loop = LoopAgent(
            name="gen_val_loop",
            sub_agents=[generator_agent, validator_agent],
            max_iterations=3,
        )

        mock_data_agent = _build_pure_agent(
            name="mock_data_agent",
            model=REASON_MODEL,
            description="Generates mock records that exercise each check agent's logic",
            instruction=MOCK_DATA_INSTRUCTION,
        )

        writer_agent = await _build_tool_agent(
            name="writer_agent",
            model=REASON_MODEL,
            description="Writes all generated files to disk, runs mock tests, produces delivery manifest",
            instruction=WRITER_INSTRUCTION,
            yaml_path=writer_yaml,
            exit_stack=stack,
        )

        # Full pipeline
        meta_pipeline = SequentialAgent(
            name="agentforge_meta_pipeline",
            sub_agents=[
                intent_agent,
                db_discovery_agent,
                planner_agent,
                gen_val_loop,      # generator + validator loop
                mock_data_agent,
                writer_agent,
            ],
        )

        session_svc = InMemorySessionService()
        await session_svc.create_session(
            app_name="agentforge", user_id=run_id, session_id=run_id,
        )

        runner = Runner(
            agent=meta_pipeline,
            app_name="agentforge",
            session_service=session_svc,
        )

        message = types.Content(
            role="user",
            parts=[types.Part(text=user_message)],
        )

        if verbose:
            print(f"\n{'='*62}")
            print(f"  AgentForge Meta-Pipeline  |  {pipeline_name}")
            print(f"  Run ID : {run_id}")
            print(f"  Output : {out_dir}")
            print(f"  Agents : IntentAgent → DB Discovery → Planner →")
            print(f"           [Generator ↔ Validator] → MockData → Writer")
            print(f"{'='*62}\n")

        final_text     = ""
        current_author = None
        agent_outputs  = {}

        async for event in runner.run_async(
            user_id=run_id, session_id=run_id, new_message=message
        ):
            author = getattr(event, "author", None)

            if author and author != current_author:
                if current_author:
                    audit.record_agent(current_author, agent_outputs.get(current_author, ""))
                current_author = author
                if verbose and author not in ("agentforge_meta_pipeline", "gen_val_loop"):
                    icons = {
                        "intent_agent":       "🧠",
                        "db_discovery_agent": "🔍",
                        "planner_agent":      "📐",
                        "generator_agent":    "⚙️ ",
                        "validator_agent":    "✅",
                        "mock_data_agent":    "🎭",
                        "writer_agent":       "✍️ ",
                    }
                    icon = icons.get(author, "▶")
                    print(f"\n  {icon}  {author}")

            if event.get_function_calls() and verbose:
                for call in event.get_function_calls():
                    print(f"       🔧 {call.name}({str(call.args)[:80]})")

            if event.is_final_response() and event.content:
                for part in event.content.parts:
                    if hasattr(part, "text") and part.text:
                        text = part.text.strip()
                        if current_author:
                            agent_outputs[current_author] = text
                        final_text = text
                        if verbose:
                            preview = text[:300]
                            print(f"       → {preview}{'…' if len(text) > 300 else ''}")

        audit.finish(final_text)

        # Parse delivery manifest from final output
        manifest = _extract_json_block(final_text, "DELIVERY_MANIFEST")
        if not manifest:
            manifest = {
                "pipeline_name": pipeline_name,
                "output_directory": str(out_dir),
                "status": "completed",
                "raw_output": final_text[:500],
            }

        return manifest


def _extract_json_block(text: str, tag: str) -> dict | None:
    """Extract a tagged JSON block from agent output text."""
    import re
    pattern = rf"{tag}:\s*```(?:json)?\s*(.*?)```"
    m = re.search(pattern, text, re.DOTALL)
    if not m:
        # Try without code fence
        idx = text.find(f"{tag}:")
        if idx != -1:
            rest = text[idx + len(tag) + 1:].strip()
            try:
                return json.loads(rest[:rest.rfind("}") + 1])
            except Exception:
                pass
        return None
    try:
        return json.loads(m.group(1))
    except Exception:
        return None
