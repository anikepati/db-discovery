"""
DAG Executor — Directed Acyclic Graph orchestrator for decision trees.

Instead of running all trees sequentially, the DAG:
  1. Topologically sorts nodes based on declared dependencies
  2. Groups nodes into execution layers (nodes in same layer can run in parallel)
  3. Tracks pass/fail per node for dependency-aware skip logic
  4. Produces a per-row execution plan showing the DAG traversal

This is the evolution from flat-list → DAG-driven orchestration.
"""

import logging
from collections import defaultdict, deque
from typing import Any, Dict, List, Optional, Set, Tuple

from models.schemas import DecisionNode

logger = logging.getLogger(__name__)


class DAGNode:
    """A node in the execution DAG."""
    def __init__(self, id: str, tree_ids: List[str], depends_on: List[str]):
        self.id = id
        self.tree_ids = tree_ids
        self.depends_on = depends_on
        self.status: str = "pending"  # pending | running | completed | skipped | failed
        self.results: List[Dict] = []


class DAGExecutor:
    """
    Executes decision trees in DAG order.
    Resolves dependencies via topological sort, groups into parallel layers.
    """

    def __init__(self, dag_config: Dict[str, Any], on_failure: str = "skip"):
        """
        Args:
            dag_config: The 'dag' section from YAML
            on_failure: What to do when a dependency fails: skip | continue | abort
        """
        self.on_failure = on_failure
        self.nodes: Dict[str, DAGNode] = {}
        self.layers: List[List[str]] = []

        self._parse_config(dag_config)
        self._validate_dag()
        self.layers = self._topological_layers()

        logger.info(f"DAG initialized: {len(self.nodes)} nodes, {len(self.layers)} layers")
        for i, layer in enumerate(self.layers):
            logger.info(f"  Layer {i}: {layer} (parallel-ready)")

    def _parse_config(self, dag_config: Dict):
        """Parse DAG node definitions from YAML."""
        for node_def in dag_config.get("nodes", []):
            node_id = node_def["id"]
            # Support both single tree_id and multiple tree_ids
            tree_ids = node_def.get("tree_ids", [])
            if not tree_ids and "tree_id" in node_def:
                tree_ids = [node_def["tree_id"]]
            depends_on = node_def.get("depends_on", [])
            self.nodes[node_id] = DAGNode(node_id, tree_ids, depends_on)

        self.on_failure = dag_config.get("on_dependency_failure", self.on_failure)

    def _validate_dag(self):
        """Validate there are no cycles and all dependencies exist."""
        all_ids = set(self.nodes.keys())
        for node in self.nodes.values():
            for dep in node.depends_on:
                if dep not in all_ids:
                    raise ValueError(
                        f"DAG node '{node.id}' depends on '{dep}' which doesn't exist"
                    )

        # Cycle detection via topological sort attempt
        try:
            self._topological_layers()
        except ValueError as e:
            raise ValueError(f"DAG has a cycle: {e}")

    def _topological_layers(self) -> List[List[str]]:
        """
        Kahn's algorithm — topological sort into layers.
        Each layer contains nodes whose dependencies are all in earlier layers.
        Nodes within a layer can execute in parallel.
        """
        in_degree: Dict[str, int] = {nid: 0 for nid in self.nodes}
        adjacency: Dict[str, List[str]] = defaultdict(list)

        for node in self.nodes.values():
            for dep in node.depends_on:
                adjacency[dep].append(node.id)
                in_degree[node.id] += 1

        # Start with nodes that have no dependencies
        queue = deque([nid for nid, deg in in_degree.items() if deg == 0])
        layers: List[List[str]] = []
        processed = 0

        while queue:
            # All nodes currently in the queue form one parallel layer
            layer = list(queue)
            layers.append(layer)
            queue.clear()

            for nid in layer:
                processed += 1
                for neighbor in adjacency[nid]:
                    in_degree[neighbor] -= 1
                    if in_degree[neighbor] == 0:
                        queue.append(neighbor)

        if processed != len(self.nodes):
            raise ValueError("Cycle detected in DAG — not all nodes were processed")

        return layers

    def get_execution_plan(self) -> List[List[str]]:
        """Return the execution layers for inspection."""
        return self.layers

    def execute_for_row(
        self,
        row: Dict[str, Any],
        row_id: str,
        tree_map: Dict[str, DecisionNode],
        walker,
    ) -> Dict[str, Any]:
        """
        Execute the DAG for a single row.

        Args:
            row: The data row
            row_id: Row identifier
            tree_map: Mapping of tree_id → DecisionNode
            walker: DecisionTreeWalker instance

        Returns:
            DAG execution report with per-node results
        """
        # Reset node states
        for node in self.nodes.values():
            node.status = "pending"
            node.results = []

        dag_report = {
            "row_id": row_id,
            "layers": [],
            "node_results": {},
            "total_nodes_executed": 0,
            "total_skipped": 0,
        }

        for layer_idx, layer in enumerate(self.layers):
            layer_report = {"layer": layer_idx, "nodes": []}

            for node_id in layer:
                node = self.nodes[node_id]

                # Check dependencies
                deps_ok = self._check_dependencies(node)
                if not deps_ok:
                    node.status = "skipped"
                    dag_report["total_skipped"] += 1
                    layer_report["nodes"].append({
                        "node_id": node_id,
                        "status": "skipped",
                        "reason": "dependency_failed",
                    })
                    logger.info(f"  [DAG] Skipping {node_id} — dependency failed")
                    continue

                # Execute all trees in this DAG node
                node.status = "running"
                node_results = []

                for tree_id in node.tree_ids:
                    tree = tree_map.get(tree_id)
                    if not tree:
                        logger.warning(f"  [DAG] Tree '{tree_id}' not found in config")
                        continue

                    result = walker.walk_tree(tree, row, row_id)
                    node_results.append(result)

                node.results = node_results
                node.status = "completed"
                dag_report["total_nodes_executed"] += 1

                layer_report["nodes"].append({
                    "node_id": node_id,
                    "status": "completed",
                    "trees_executed": len(node_results),
                })

            dag_report["layers"].append(layer_report)

        # Collect all node results
        for nid, node in self.nodes.items():
            dag_report["node_results"][nid] = {
                "status": node.status,
                "tree_count": len(node.results),
            }

        return dag_report

    def _check_dependencies(self, node: DAGNode) -> bool:
        """Check if all dependencies completed successfully."""
        for dep_id in node.depends_on:
            dep_node = self.nodes.get(dep_id)
            if not dep_node:
                return False

            if dep_node.status == "skipped":
                if self.on_failure == "skip":
                    return False
                elif self.on_failure == "abort":
                    raise RuntimeError(
                        f"DAG abort: dependency '{dep_id}' failed for node '{node.id}'"
                    )
                # continue: proceed anyway

            if dep_node.status != "completed":
                return False

        return True

    def print_dag(self):
        """Pretty-print the DAG structure."""
        print("\n┌─────────────────────────────────────┐")
        print("│        DAG EXECUTION PLAN           │")
        print("├─────────────────────────────────────┤")
        for i, layer in enumerate(self.layers):
            nodes_str = ", ".join(layer)
            parallel = " (parallel)" if len(layer) > 1 else ""
            print(f"│ Layer {i}: {nodes_str}{parallel}")
            if i < len(self.layers) - 1:
                print("│    ↓")
        print("└─────────────────────────────────────┘")
