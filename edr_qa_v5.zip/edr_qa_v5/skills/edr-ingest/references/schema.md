# vw_get_qa_actimize_data — Column Reference

SQL view on Actimize MS SQL Server. Returns one row per ECN.

## Query

```sql
SELECT *
FROM vw_get_qa_actimize_data
WHERE ecn_number = ?   -- parameterised, ecn_id bound here
```

## Columns

| Column | Type | Notes |
|--------|------|-------|
| `ecn_number` | varchar | Primary identifier e.g. `ECN-2024-001` |
| `event_type` | varchar | e.g. `Standard Referral`, `Priority FC Business Approval` |
| `event_subtype` | varchar | Sub-classification of event type |
| `workflow_status` | varchar | Current status in Actimize workflow |
| `brokerage_type` | varchar | Type of brokerage relationship |
| `event_description` | varchar | Full text description of the event |
| `recommended_action` | varchar | Action recommended at event creation |
| `recommended_rationale` | varchar | Rationale for the recommended action |
| `recommending_group` | varchar | Group that made the recommendation |
| `input_file_ecn` | varchar | ECN from input file — used for Q1 cross-check |
| `input_file_event_type` | varchar | Event type from input file — used for Q1 |
| `input_file_workflow_status` | varchar | Workflow status from input file — used for Q1 |
| `l1_recommended_action` | varchar | Level 1 recommended action (Priority FC Business only) |
| `l1_rationale` | varchar | Level 1 rationale |
| `l2_decision` | varchar | Level 2 decision: `Accept` or `Amend` |
| `l2_action` | varchar | Level 2 action (populated only if Amend) |
| `l2_rationale` | varchar | Level 2 rationale |
| `l2_lob` | varchar | Line of business (populated if multiple LOB rows) |
| `l2_multiple_rows` | bit | 1 if multiple L2 rows exist for this ECN |
| `elevated_approval_required` | bit | 1 if elevated approval was required |
| `elevated_approval_decision` | varchar | Decision from elevated approver |
| `elevated_approval_rationale` | varchar | Rationale from elevated approver |
| `final_recommended_action` | varchar | Final action after all reviews |
| `rro_number` | varchar | Risk Rating Override number (NULL if not applicable) |
| `risk_rating_amended_in_l2` | bit | 1 if risk rating was amended during L2 review |
| `final_risk_rating` | varchar | Final risk rating (populated if amended) |

## Authorization Grid (used by Q2, Q3, Q5, Q8)

| EDR Type | Brokerage Type | Authorized Recommending Groups |
|----------|---------------|-------------------------------|
| Standard Referral | Retail | Risk, Compliance, Front Office |
| Standard Referral | Institutional | Risk, Senior Risk, Compliance |
| Priority FC Business Approval | Any | FC Business, Senior Risk |

## Null handling

- `rro_number` NULL → treat as NONE (not applicable)
- `l2_lob` NULL → treat as single LOB row
- `elevated_approval_decision` NULL when `elevated_approval_required` = 0 → normal (N/A)
- `l1_recommended_action` NULL when `event_type` != `Priority FC Business Approval` → N/A
