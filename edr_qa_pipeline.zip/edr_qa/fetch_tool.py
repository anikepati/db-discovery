"""
EDR data fetch tool.

fetch_edr_data(ecn_id) is the single tool given to DataFetcherAgent.
It loads all Actimize EDR fields needed by the 15 QA questions.

Replace _load_from_actimize() with your real Actimize / database call.
The returned dict keys must remain stable — all agents read from them.
"""

import json
import logging
from typing import Any

from google.adk.tools import FunctionTool

logger = logging.getLogger(__name__)

# ── Mock Actimize data ────────────────────────────────────────────────────────
# Represents what you'd pull from Actimize EDR Script / API for a given ECN.

_MOCK_ACTIMIZE: dict[str, dict[str, Any]] = {
    "ECN-2024-001": {
        # Event Creation fields
        "ecn_number": "ECN-2024-001",
        "event_type": "Priority FC Business Approval",
        "event_subtype": "High Risk",
        "workflow_status": "Closed",
        "event_description": (
            "Customer flagged for unusual transaction pattern. "
            "Multiple high-value transfers to unrelated accounts over 30 days."
        ),
        "brokerage_type": "Non-brokerage",
        # Recommendation fields
        "recommended_action": "No Further Action Required",
        "recommended_rationale": (
            "TRIG recommends no further action. Transactions reviewed and deemed "
            "consistent with customer profile and business activity."
        ),
        "recommending_group": "TRIG",
        # L1 Review (Priority FC Business)
        "l1_recommended_action": "No Further Action Required",
        "l1_rationale": (
            "TRIG recommends no further action. Risk assessment complete. "
            "No suspicious activity confirmed."
        ),
        # L2 Review
        "l2_decision": "Accept",
        "l2_action": "",            # blank when Accept
        "l2_rationale": (
            "L2 concurs with TRIG recommendation. No further action required."
        ),
        "l2_lob": "Retail",
        "l2_multiple_rows": False,
        # Elevated approvals
        "elevated_approval_required": False,
        "elevated_approval_decision": "",
        "elevated_approval_rationale": "",
        # Decision execution
        "final_recommended_action": "No Further Action Required",
        # History tab / RRO
        "rro_number": "",
        "risk_rating_amended_in_l2": False,
        "final_risk_rating": "",
        # Input file match fields
        "input_file_ecn": "ECN-2024-001",
        "input_file_event_type": "Priority FC Business Approval",
        "input_file_workflow_status": "Closed",
    },
    "ECN-2024-002": {
        "ecn_number": "ECN-2024-002",
        "event_type": "Standard Referral",
        "event_subtype": "Transaction Monitoring",
        "workflow_status": "Closed",
        "event_description": (
            "Customer conducting frequent cash deposits below reporting threshold. "
            "Pattern suggests possible structuring."
        ),
        "brokerage_type": "Brokerage",
        "recommended_action": "Increase Risk Rating",
        "recommended_rationale": (
            "Pattern of transactions consistent with structuring. "
            "Risk rating should be elevated to High."
        ),
        "recommending_group": "AML Operations",
        # L1 Review
        "l1_recommended_action": "Increase Risk Rating",
        "l1_rationale": "AML Operations recommends risk rating increase due to structuring pattern.",
        # L2 Review
        "l2_decision": "Amend",
        "l2_action": "Increase Risk Rating to High",
        "l2_rationale": "Agreed with L1 recommendation. Risk rating amended to High.",
        "l2_lob": "Brokerage",
        "l2_multiple_rows": True,
        "l2_all_lob_rows": ["Retail", "Brokerage"],
        # Elevated approvals
        "elevated_approval_required": True,
        "elevated_approval_decision": "Accept",
        "elevated_approval_rationale": "Senior Manager approved risk rating increase.",
        # Decision execution
        "final_recommended_action": "Increase Risk Rating",
        # History tab / RRO
        "rro_number": "RRO-2024-0445",
        "risk_rating_amended_in_l2": True,
        "final_risk_rating": "High",
        # Input file match
        "input_file_ecn": "ECN-2024-002",
        "input_file_event_type": "Standard Referral",
        "input_file_workflow_status": "Closed",
    },
    "ECN-2024-003": {
        "ecn_number": "ECN-2024-003",
        "event_type": "Standard Referral",
        "event_subtype": "Customer Exit",
        "workflow_status": "Closed",
        "event_description": (
            "Customer identified as high risk following enhanced due diligence. "
            "Business recommends exit."
        ),
        "brokerage_type": "Non-brokerage",
        "recommended_action": "Exit Decision",
        "recommended_rationale": "TRIG recommends exit. Customer risk unacceptable.",
        "recommending_group": "TRIG",
        # L1 Review
        "l1_recommended_action": "Exit Decision",
        "l1_rationale": "TRIG recommends exit. Enhanced due diligence confirms unacceptable risk.",
        # L2 Review
        "l2_decision": "Accept",
        "l2_action": "",
        "l2_rationale": "L2 concurs with TRIG exit recommendation.",
        "l2_lob": "Retail",
        "l2_multiple_rows": False,
        # Elevated approvals
        "elevated_approval_required": False,
        "elevated_approval_decision": "",
        "elevated_approval_rationale": "",
        # Decision execution
        "final_recommended_action": "Exit Decision",
        # RRO not applicable for Exit
        "rro_number": "",
        "risk_rating_amended_in_l2": False,
        "final_risk_rating": "",
        # Input file match
        "input_file_ecn": "ECN-2024-003",
        "input_file_event_type": "Standard Referral",
        "input_file_workflow_status": "Closed",
    },
}


def _load_from_actimize(ecn_id: str) -> dict[str, Any] | None:
    """
    Load EDR data for a given ECN from Actimize.

    Replace this function body with your real implementation:
      - Actimize API:  return actimize_client.get_edr(ecn_id)
      - Database:      return db.fetchone("SELECT * FROM edr WHERE ecn_id = %s", ecn_id)
      - EDR Script:    return edr_script_parser.extract(ecn_id)
    """
    return _MOCK_ACTIMIZE.get(ecn_id)


def fetch_edr_data(ecn_id: str) -> str:
    """
    Fetch complete EDR data for a given ECN ID from Actimize.

    Returns a JSON string. On success: status='ok' with all EDR fields.
    On failure: status='error' with error description.

    Args:
        ecn_id: The ECN identifier (e.g. 'ECN-2024-001').
    """
    logger.info("Fetching EDR data", extra={"ecn_id": ecn_id})

    data = _load_from_actimize(ecn_id)
    if data is None:
        available = list(_MOCK_ACTIMIZE.keys())
        logger.warning("ECN not found", extra={"ecn_id": ecn_id})
        return json.dumps({
            "status": "error",
            "error": f"ECN '{ecn_id}' not found in Actimize.",
            "available_ecns": available,
        })

    result = {"status": "ok", "ecn_id": ecn_id, **data}
    logger.info("EDR data fetched successfully", extra={"ecn_id": ecn_id})
    return json.dumps(result, indent=2, default=str)


fetch_edr_data_tool = FunctionTool(func=fetch_edr_data)
