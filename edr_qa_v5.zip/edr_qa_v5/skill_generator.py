"""
skill_generator.py
------------------
Auto-generates Agent Skills SKILL.md files for all 15 EDR QA question agents
from questions.py. Run once at project setup or whenever questions.py changes.

Usage:
    python skill_generator.py               # generates into skills/edr-q01/ ... skills/edr-q15/
    python skill_generator.py --check       # verify all skill files exist and are current
    python skill_generator.py --dry-run     # print without writing
"""

import argparse
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from questions import EDR_QUESTIONS, EDRQuestion

SKILLS_DIR = Path(__file__).parent / "skills"


def _depends_on_str(q: EDRQuestion) -> str:
    if not q.depends_on:
        return "None (first question in chain)"
    return ", ".join(f"Q{d:02d}" for d in q.depends_on)


def _db_fields_table(q: EDRQuestion) -> str:
    rows = "\n".join(f"| `{f}` |" for f in q.db_fields)
    return f"| Column | Notes |\n|--------|-------|\n{rows}"


def _human_note(q: EDRQuestion) -> str:
    if not q.requires_human:
        return ""
    return (
        "\n## ⚠️ Human Review Required\n\n"
        "If the condition applies, answer **NEEDS_HUMAN** and include a "
        "`HUMAN_ACTION:` line specifying the exact action required. "
        "Only answer N/A if the condition clearly does not apply.\n"
    )


def generate_skill_md(q: EDRQuestion) -> str:
    slug = f"edr-q{q.number:02d}"
    return f"""---
name: {slug}
description: >
  EDR QA Question {q.number} of 15 ({q.category}): {q.question[:120].rstrip()}.
  Reads EDR data from context.state, reasons using Claude claude-sonnet-4-6, writes
  answer to context.state["answers"]["q{q.number}"]. Use only in EDR QA pipeline.
license: Proprietary
metadata:
  author: edr-qa-team
  version: "5.0"
  pipeline: edr-qa-v5
  question_number: "{q.number}"
  category: "{q.category}"
  requires_human: "{'true' if q.requires_human else 'false'}"
compatibility: Requires ADK ToolContext, Anthropic API, context.state with edr_data populated
allowed-tools: get_edr_data get_prior_answers answer_question store_answer
---

# EDR QA — Question {q.number}: {q.category}

**{q.question}**

## Dependencies

Depends on: {_depends_on_str(q)}

Prior answers for dependent questions MUST be in `context.state["answers"]` before this agent runs.
{_human_note(q)}
## Steps

1. Call `get_edr_data()` — reads `context.state["edr_data"]` (populated by IngestAgent)
2. Call `get_prior_answers()` — reads `context.state["answers"]` for dependent Q answers
3. Call `answer_question(question_number={q.number}, edr_data=<step1>, prior_answers=<step2>)`
   - This calls Claude claude-sonnet-4-6 with the check logic and EDR data
   - Returns: `answer`, `reasoning`, `requires_human`, `human_action`
4. Call `store_answer(question_number={q.number}, answer=..., reasoning=..., ...)` 
   - Writes to `context.state["answers"]["q{q.number}"]`
5. Respond with exactly:

```
Q{q.number:02d} [{q.category}]: <answer>
REASONING: <1-2 sentence summary>
```

## Check Logic

```
{q.check}
```

## Validation

{q.validation}

## Output Format

{q.output_hint}

Valid answers: `Y` | `N` | `N/A` | `NEEDS_HUMAN`

## DB Fields Used

{_db_fields_table(q)}

## Gotchas

- Always call `get_edr_data()` first — never use stale data from a prior step.
- Always call `get_prior_answers()` before `answer_question` — dependency answers may affect the result.
- Never skip this question even if a dependency answered N or NEEDS_HUMAN.
- Do NOT write to `context.state` directly — use `store_answer` tool only.
- See [references/question.md](references/question.md) for full question text and validation grid.
"""


def generate_question_reference(q: EDRQuestion) -> str:
    return f"""# Q{q.number:02d} Full Reference — {q.category}

## Question

{q.question}

## Validation

{q.validation}

## Check Logic (apply exactly)

{q.check}

## Depends On

{_depends_on_str(q)}

## Output Hint

{q.output_hint}

## Requires Human Review

{'Yes — if condition applies, answer must be NEEDS_HUMAN with HUMAN_ACTION specified.' if q.requires_human else 'No — answer should be Y, N, or N/A only.'}

## DB Fields

{chr(10).join(f'- `{f}`' for f in q.db_fields)}

## Authorization Grid (relevant for Q2, Q3, Q5, Q8)

See `skills/edr-ingest/references/schema.md` for the full authorization grid
mapping EDR type + brokerage type → authorized recommending groups.
"""


def generate_all(dry_run: bool = False) -> int:
    count = 0
    for q in EDR_QUESTIONS:
        slug     = f"edr-q{q.number:02d}"
        skill_dir = SKILLS_DIR / slug
        ref_dir   = skill_dir / "references"

        skill_md = generate_skill_md(q)
        ref_md   = generate_question_reference(q)

        if dry_run:
            print(f"\n{'─'*60}")
            print(f"  {skill_dir}/SKILL.md  ({len(skill_md)} chars)")
            print(skill_md[:300] + "...")
        else:
            ref_dir.mkdir(parents=True, exist_ok=True)
            (skill_dir / "SKILL.md").write_text(skill_md, encoding="utf-8")
            (ref_dir / "question.md").write_text(ref_md, encoding="utf-8")
            print(f"  ✓  {slug}/SKILL.md + references/question.md")
            count += 1

    if not dry_run:
        print(f"\nGenerated {count} question skills.")
    return count


def check_all() -> bool:
    missing = []
    for q in EDR_QUESTIONS:
        slug = f"edr-q{q.number:02d}"
        skill_file = SKILLS_DIR / slug / "SKILL.md"
        ref_file   = SKILLS_DIR / slug / "references" / "question.md"
        if not skill_file.exists():
            missing.append(str(skill_file))
        if not ref_file.exists():
            missing.append(str(ref_file))

    if missing:
        print("Missing skill files:")
        for m in missing:
            print(f"  ✗  {m}")
        print("\nRun: python skill_generator.py")
        return False

    print(f"All {len(EDR_QUESTIONS) * 2} skill files present.")
    return True


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generate EDR QA question skill files")
    parser.add_argument("--dry-run", action="store_true", help="Print without writing")
    parser.add_argument("--check",   action="store_true", help="Verify files exist")
    args = parser.parse_args()

    if args.check:
        ok = check_all()
        sys.exit(0 if ok else 1)
    else:
        generate_all(dry_run=args.dry_run)
