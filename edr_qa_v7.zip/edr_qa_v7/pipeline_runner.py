"""
pipeline_runner.py
------------------
Startup: generates 15 question YAMLs + builds 17-entry registry (once).
Per run: creates session, calls run_edr_qa, parses result, writes audit.
"""

import asyncio
import json
import logging
import os
import time
from datetime import datetime
from pathlib import Path

from config import settings
from models import EDRQAResult, QAAnswer, QuestionResult, Verdict
from audit.audit_writer import AuditWriter
from tool_generator import generate_all_question_yamls
from tool_registry import build_registry, validate_yaml_files, ToolConfig
from agents.agent import run_edr_qa

logger = logging.getLogger(__name__)

_ICONS = {
    Verdict.PASS:                  "✅",
    Verdict.PASS_WITH_EXCEPTIONS:  "⚠️ ",
    Verdict.FAIL:                  "❌",
    Verdict.REQUIRES_HUMAN_REVIEW: "👤",
}

_REGISTRY: list[ToolConfig] | None = None


def _get_registry() -> list[ToolConfig]:
    global _REGISTRY
    if _REGISTRY is None:
        generated = generate_all_question_yamls(tools_dir="tools", force=False)
        logger.info("Question YAMLs ready: %d", len(generated))
        _REGISTRY = build_registry()
        validate_yaml_files(_REGISTRY)
        logger.info("Registry ready: %d agents", len(_REGISTRY))
    return _REGISTRY


class PipelineRunner:

    async def run(
        self,
        ecn_id:      str,
        output_path: str | None = None,
        verbose:     bool = True,
    ) -> EDRQAResult:

        registry = _get_registry()
        ts       = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        run_id   = f"run_{ts}_{ecn_id}"
        started  = datetime.utcnow()
        t0       = time.time()

        if output_path is None:
            os.makedirs(settings.outputs_dir, exist_ok=True)
            output_path = os.path.join(
                settings.outputs_dir, f"edr_{ecn_id}_{ts}.json"
            )

        audit = AuditWriter(run_id=run_id, ecn_id=ecn_id,
                            audit_dir=settings.audit_dir)
        audit.write_manifest(ecn_id=ecn_id, questions_count=15)

        if verbose:
            print(f"\n{'═' * 62}")
            print(f"  EDR QA PIPELINE  v7  |  {ecn_id}")
            print(f"  Run    : {run_id}")
            print(f"  Output : {output_path}")
            print(f"  Agents : SequentialAgent — 17 agents, conversation history")
            print(f"  Models : Gemini Flash (ingest) + Claude claude-sonnet-4-6 (Q agents / report)
            print(f"{'═' * 62}")

        last_exc: Exception | None = None
        for attempt in range(1, settings.max_retries + 1):
            try:
                await run_edr_qa(
                    ecn_id=ecn_id,
                    run_id=run_id,
                    output_path=output_path,
                    registry=registry,
                    audit=audit,
                    verbose=verbose,
                )
                break
            except Exception as exc:
                last_exc = exc
                logger.error("Attempt %d/%d failed: %s",
                             attempt, settings.max_retries, exc, exc_info=True)
                if attempt < settings.max_retries:
                    delay = settings.retry_delay * attempt
                    if verbose:
                        print(f"\n⟳  Retry {attempt}/{settings.max_retries} in {delay:.0f}s…")
                    await asyncio.sleep(delay)
                else:
                    raise RuntimeError(
                        f"Pipeline failed after {settings.max_retries} attempts."
                    ) from last_exc

        duration = time.time() - t0
        result   = self._load_result(ecn_id, run_id, output_path, started, duration)

        audit.write_run_summary(
            verdict=result.verdict.value,
            pass_rate=result.overall_pass_rate,
            failed_questions=result.failed_questions,
            human_items=result.human_review_items,
            duration_seconds=duration,
            state_snapshot={},
        )

        if verbose:
            self._print_result(result, output_path, audit.audit_path())

        return result

    def _load_result(self, ecn_id, run_id, output_path, started_at, duration):
        try:
            data = json.loads(Path(output_path).read_text(encoding="utf-8"))
        except Exception:
            data = {}
        verdict = Verdict.from_string(data.get("verdict", "REQUIRES_HUMAN_REVIEW"))
        qr = [
            QuestionResult(
                number=a["number"], category=a.get("category",""),
                question="", depends_on=[],
                answer=QAAnswer.from_string(a.get("answer","NEEDS_HUMAN")),
                reasoning=a.get("reasoning",""),
                requires_human=a.get("requires_human",False),
                human_action=a.get("human_action",""),
            )
            for a in data.get("answers", [])
        ]
        return EDRQAResult(
            run_id=run_id, ecn_id=ecn_id, verdict=verdict,
            overall_pass_rate=float(data.get("overall_pass_rate", 0.0)),
            question_results=qr,
            failed_questions=data.get("failed_questions",[]),
            human_review_items=data.get("human_review_required",[]),
            output_path=output_path,
            started_at=started_at, completed_at=datetime.utcnow(),
            duration_seconds=duration,
        )

    def _print_result(self, result, output_path, audit_path):
        icon = _ICONS.get(result.verdict, "❓")
        print(f"\n{'═' * 62}")
        print(f"  {icon}  {result.verdict.value}")
        print(f"  ECN      : {result.ecn_id}")
        print(f"  Pass Rate: {result.overall_pass_rate:.1f}%")
        print(f"  Duration : {result.duration_seconds:.1f}s")
        print(f"{'═' * 62}")
        if result.failed_questions:
            print(f"\n❌ Failed   : Q{result.failed_questions}")
        if result.human_review_items:
            print(f"\n👤 Human review ({len(result.human_review_items)}):")
            for item in result.human_review_items:
                print(f"   Q{item['question']}: {item['action_required']}")
        print(f"\n💾 Report   : {output_path}")
        print(f"🗂  Audit    : {audit_path}/\n")
