"""
Question agent factory for all 15 EDR QA questions.

Each agent:
  - Receives the full EDR data from session state key 'edr_data'
  - Receives required prior answers from session state (answer_q1 … answer_qN)
  - Writes its answer to session state via output_key = 'answer_q<N>'

Special handling:
  - Questions 10, 12, 13, 15 (Profile Refresh / Exit Decision) must flag for
    human review rather than auto-answering — this is enforced in the prompt.
"""

import logging

from google.adk.agents import LlmAgent

from config import settings
from questions import EDR_QUESTIONS, EDRQuestion

logger = logging.getLogger(__name__)

_EDR_DATA_KEY = "edr_data"

# Questions that must NOT be auto-answered — require human validation
_HUMAN_REVIEW_QUESTIONS = {10, 12, 13, 15}


def _prior_section(q: EDRQuestion) -> str:
    if not q.depends_on:
        return ""
    lines = [
        "",
        "## Prior Answers Available in Session State",
        "Use these answers as context. Do not re-derive what was already established.",
    ]
    for dep in q.depends_on:
        lines.append(f"  - Q{dep} answer → session state key: 'answer_q{dep}'")
    return "\n".join(lines)


def _human_review_note(q: EDRQuestion) -> str:
    if q.number not in _HUMAN_REVIEW_QUESTIONS:
        return ""
    return (
        "\n## ⚠️ HUMAN REVIEW REQUIRED\n"
        "This question MUST NOT be auto-answered by you. "
        "If the condition applies (see check logic), respond with:\n"
        "  ANSWER: NEEDS_HUMAN\n"
        "  HUMAN_ACTION: <specific email/action the human reviewer must take>\n"
        "Only answer 'N/A' if the condition clearly does not apply."
    )


def _build_instruction(q: EDRQuestion) -> str:
    return f"""You are EDR QA Agent for Question {q.number}: {q.category}

## EDR Data
Full Actimize EDR data is in your session context under key '{_EDR_DATA_KEY}'.
Use actual field values — never fabricate data.
{_prior_section(q)}

## Question
{q.question}

## Validation to Perform
{q.validation}

## Check Logic
{q.check}
{_human_review_note(q)}

## Required Output Format
Structure your response exactly as:

REASONING:
<Step-by-step analysis. Reference actual field values from the EDR data.
Apply the check logic precisely. For Y/N/N/A decisions, state which condition triggered.
Minimum 3 sentences.>

ANSWER: <Y | N | N/A | NEEDS_HUMAN>
{f"HUMAN_ACTION: <what the human reviewer must do>" if q.number in _HUMAN_REVIEW_QUESTIONS else ""}

## Rules
- Reference actual values (e.g. "event_type = 'Priority FC Business Approval'")
- Apply the exact Y/N/N/A decision rules from the check logic
- For NEEDS_HUMAN: clearly state what email/action is required and to which group
- Never guess or assume fields not present in the data
"""


def create_question_agent(q: EDRQuestion) -> LlmAgent:
    return LlmAgent(
        name=f"QA_Q{q.number:02d}",
        model=settings.model,
        instruction=_build_instruction(q),
        tools=[],
        output_key=f"answer_q{q.number}",
        description=f"Q{q.number} [{q.category}]: {q.question[:60]}…",
    )


def create_all_question_agents() -> list[LlmAgent]:
    agents = [create_question_agent(q) for q in EDR_QUESTIONS]
    logger.info("Created %d EDR question agents", len(agents))
    return agents
