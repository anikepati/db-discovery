"""
QA Pipeline - Data Fetching Tools
Retrieves QA process data from the data source using Process ID.
Replace the mock implementation with your actual data source (DB, API, etc.)
"""

import json
import logging
from datetime import datetime, timedelta
from typing import Any

from google.adk.tools import FunctionTool

from models import (
    AuditTrail,
    ComplianceRecord,
    PerformanceMetrics,
    ProcessMetadata,
    ProcessStatus,
    QAProcessData,
    RiskProfile,
    SecurityAssessment,
    Severity,
)

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────
# Mock data store — replace with real DB/API
# ─────────────────────────────────────────────

MOCK_PROCESSES: dict[str, dict[str, Any]] = {
    "PROC-2024-001": {
        "process_name": "Customer Onboarding Workflow",
        "business_unit": "Retail Banking",
        "owner": "Jane Smith",
        "status": "active",
        "version": "3.2.1",
        "environment": "production",
        "tags": ["customer-facing", "regulated", "kyc"],
        "compliance_framework": "SOX",
        "compliance_score": 72.5,
        "open_findings": 4,
        "critical_findings": 1,
        "certifications": ["ISO27001", "PCI-DSS"],
        "exceptions": ["Manual override allowed for VIP customers"],
        "inherent_risk": "high",
        "residual_risk": "medium",
        "risk_score": 6.8,
        "risk_categories": ["Operational", "Compliance", "Reputational"],
        "mitigating_controls": [
            "Four-eyes approval for high-value accounts",
            "Daily reconciliation reports",
            "Automated KYC checks",
        ],
        "avg_completion_time_min": 45.2,
        "sla_threshold_min": 60.0,
        "sla_breach_count_30d": 12,
        "error_rate_pct": 2.3,
        "throughput_per_day": 450,
        "availability_pct": 99.1,
        "encryption_at_rest": True,
        "encryption_in_transit": True,
        "mfa_enabled": True,
        "last_pen_test_days_ago": 45,
        "open_vulnerabilities": 3,
        "critical_vulnerabilities": 0,
        "data_classification": "confidential",
        "privileged_access_users": 5,
        "total_changes_30d": 23,
        "unauthorized_access_attempts": 2,
        "policy_violations_90d": 1,
        "last_reviewed_by": "QA Team Alpha",
        "last_review_outcome": "Conditional Pass",
        "recent_findings": [
            {"date": "2024-10-15", "type": "Policy Gap", "severity": "medium",
             "description": "Missing escalation path for failed KYC"},
            {"date": "2024-11-02", "type": "SLA Breach", "severity": "low",
             "description": "12 SLA breaches in October due to system slowdown"},
        ],
    },
    "PROC-2024-002": {
        "process_name": "Loan Approval Pipeline",
        "business_unit": "Consumer Lending",
        "owner": "Bob Johnson",
        "status": "pending_review",
        "version": "1.0.0",
        "environment": "staging",
        "tags": ["financial", "regulated", "high-risk"],
        "compliance_framework": "GDPR",
        "compliance_score": 55.0,
        "open_findings": 8,
        "critical_findings": 3,
        "certifications": [],
        "exceptions": [],
        "inherent_risk": "critical",
        "residual_risk": "high",
        "risk_score": 8.9,
        "risk_categories": ["Credit", "Compliance", "Operational", "Legal"],
        "mitigating_controls": ["Manual approval above $50k"],
        "avg_completion_time_min": 120.0,
        "sla_threshold_min": 90.0,
        "sla_breach_count_30d": 35,
        "error_rate_pct": 8.7,
        "throughput_per_day": 80,
        "availability_pct": 96.5,
        "encryption_at_rest": False,
        "encryption_in_transit": True,
        "mfa_enabled": False,
        "last_pen_test_days_ago": 200,
        "open_vulnerabilities": 12,
        "critical_vulnerabilities": 2,
        "data_classification": "restricted",
        "privileged_access_users": 15,
        "total_changes_30d": 67,
        "unauthorized_access_attempts": 11,
        "policy_violations_90d": 9,
        "last_reviewed_by": "External Audit Firm",
        "last_review_outcome": "Fail",
        "recent_findings": [
            {"date": "2024-11-20", "type": "Data Exposure Risk", "severity": "critical",
             "description": "PII data not encrypted at rest"},
            {"date": "2024-11-18", "type": "Access Control", "severity": "critical",
             "description": "No MFA for privileged users"},
            {"date": "2024-11-10", "type": "Compliance", "severity": "high",
             "description": "GDPR consent records incomplete"},
        ],
    },
}


# ─────────────────────────────────────────────
# Tool functions (called by agents)
# ─────────────────────────────────────────────

def fetch_qa_process_data(process_id: str) -> str:
    """
    Fetch all QA process data for a given Process ID.

    Retrieves metadata, compliance records, risk profile, performance metrics,
    security assessment, and audit trail needed for QA evaluation.

    Args:
        process_id: The unique identifier of the business process (e.g., 'PROC-2024-001')

    Returns:
        JSON string containing the complete QA dataset, or an error message.
    """
    logger.info(f"Fetching QA data for process_id={process_id}")

    if process_id not in MOCK_PROCESSES:
        error = {
            "status": "error",
            "process_id": process_id,
            "message": f"Process '{process_id}' not found. Available: {list(MOCK_PROCESSES.keys())}",
        }
        logger.warning(f"Process not found: {process_id}")
        return json.dumps(error)

    raw = MOCK_PROCESSES[process_id]
    now = datetime.utcnow()

    qa_data = QAProcessData(
        metadata=ProcessMetadata(
            process_id=process_id,
            process_name=raw["process_name"],
            business_unit=raw["business_unit"],
            owner=raw["owner"],
            created_date=now - timedelta(days=365),
            last_modified=now - timedelta(days=7),
            status=ProcessStatus(raw["status"]),
            version=raw["version"],
            environment=raw["environment"],
            tags=raw.get("tags", []),
        ),
        compliance=ComplianceRecord(
            framework=raw["compliance_framework"],
            last_audit_date=now - timedelta(days=90),
            next_audit_due=now + timedelta(days=90),
            compliance_score=raw["compliance_score"],
            open_findings=raw["open_findings"],
            critical_findings=raw["critical_findings"],
            certifications=raw.get("certifications", []),
            exceptions=raw.get("exceptions", []),
        ),
        risk_profile=RiskProfile(
            inherent_risk=Severity(raw["inherent_risk"]),
            residual_risk=Severity(raw["residual_risk"]),
            risk_score=raw["risk_score"],
            risk_categories=raw.get("risk_categories", []),
            mitigating_controls=raw.get("mitigating_controls", []),
            last_assessed=now - timedelta(days=30),
        ),
        performance=PerformanceMetrics(
            avg_completion_time_minutes=raw["avg_completion_time_min"],
            sla_threshold_minutes=raw["sla_threshold_min"],
            sla_breach_count_30d=raw["sla_breach_count_30d"],
            error_rate_percent=raw["error_rate_pct"],
            throughput_per_day=raw["throughput_per_day"],
            availability_percent=raw["availability_pct"],
        ),
        security=SecurityAssessment(
            access_control_level="role-based",
            encryption_at_rest=raw["encryption_at_rest"],
            encryption_in_transit=raw["encryption_in_transit"],
            mfa_enabled=raw["mfa_enabled"],
            last_pen_test_date=now - timedelta(days=raw["last_pen_test_days_ago"]),
            open_vulnerabilities=raw["open_vulnerabilities"],
            critical_vulnerabilities=raw["critical_vulnerabilities"],
            data_classification=raw["data_classification"],
            privileged_access_users=raw["privileged_access_users"],
        ),
        audit_trail=AuditTrail(
            total_changes_30d=raw["total_changes_30d"],
            unauthorized_access_attempts=raw["unauthorized_access_attempts"],
            policy_violations_90d=raw["policy_violations_90d"],
            last_reviewed_by=raw["last_reviewed_by"],
            last_review_date=now - timedelta(days=45),
            review_outcome=raw["last_review_outcome"],
            findings=raw.get("recent_findings", []),
        ),
        raw_data=raw,
    )

    summary = qa_data.to_summary_dict()
    summary["status"] = "success"
    summary["process_id"] = process_id
    summary["findings"] = raw.get("recent_findings", [])
    summary["risk_categories"] = raw.get("risk_categories", [])
    summary["mitigating_controls"] = raw.get("mitigating_controls", [])
    summary["certifications"] = raw.get("certifications", [])
    summary["exceptions"] = raw.get("exceptions", [])

    logger.info(f"Successfully fetched data for process_id={process_id}")
    return json.dumps(summary, indent=2, default=str)


def validate_process_exists(process_id: str) -> str:
    """
    Quick validation check — does this Process ID exist?

    Args:
        process_id: Process ID to validate

    Returns:
        JSON with exists flag and basic info.
    """
    exists = process_id in MOCK_PROCESSES
    result = {
        "process_id": process_id,
        "exists": exists,
        "message": "Process found." if exists else f"Process '{process_id}' does not exist.",
    }
    if exists:
        raw = MOCK_PROCESSES[process_id]
        result["process_name"] = raw["process_name"]
        result["business_unit"] = raw["business_unit"]
        result["status"] = raw["status"]

    return json.dumps(result)


# ─────────────────────────────────────────────
# ADK Tool registrations
# ─────────────────────────────────────────────

fetch_qa_process_data_tool = FunctionTool(func=fetch_qa_process_data)
validate_process_exists_tool = FunctionTool(func=validate_process_exists)
