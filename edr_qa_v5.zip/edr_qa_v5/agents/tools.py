"""
agents/tools.py
---------------
All ADK FunctionTools for the EDR QA v5 pipeline.

Design principles:
  1. context.state is the ONLY shared state mechanism.
     Every tool that reads or writes pipeline data goes through
     tool_context.state — ADK injects ToolContext automatically
     when a function parameter is typed as ToolContext.

  2. MS SQL via pyodbc — one fetch against vw_get_qa_actimize_data.
     Connection string from MSSQL_CONN env var.

  3. Claude claude-sonnet-4-6 for QA reasoning — called inside answer_question().
     question_number param determines which of the 15 questions is evaluated.

  4. All tools return str (JSON) — ADK FunctionTool requirement.

State layout in context.state:
  {
    "ecn_id":    str,
    "edr_data":  dict,       ← written by store_edr_data
    "answers":   {           ← written by store_answer
      "q1":  {answer, reasoning, requires_human, human_action, category},
      ...
      "q15": {...}
    },
    "verdict":   dict | None ← written by store_verdict
  }
"""

import json
import logging
import os
from typing import Any

try:
    from google.adk.tools.tool_context import ToolContext
except ImportError:
    class ToolContext:  # test stub
        def __init__(self): self.state = {}

logger = logging.getLogger(__name__)


# ── MS SQL fetch ──────────────────────────────────────────────────────────────

def fetch_edr_data(ecn_id: str, tool_context: ToolContext) -> str:
    """
    Fetch one EDR record from vw_get_qa_actimize_data for the given ECN.

    Connects via pyodbc using MSSQL_CONN env var.
    Returns JSON with all columns from the view.
    On failure returns {"error": "..."}.

    ADK injects tool_context — do not pass it manually.
    """
    conn_str = os.environ.get("MSSQL_CONN", "")
    if not conn_str:
        logger.warning("MSSQL_CONN not set — using mock data for %s", ecn_id)
        return _mock_fetch(ecn_id)

    try:
        import pyodbc
        with pyodbc.connect(conn_str, timeout=30) as conn:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT * FROM vw_get_qa_actimize_data WHERE ecn_number = ?",
                ecn_id,
            )
            columns = [desc[0].lower() for desc in cursor.description]
            row = cursor.fetchone()
            if row is None:
                return json.dumps({"error": f"ECN not found: {ecn_id}"})
            record = dict(zip(columns, row))
            # Normalise types: bit → bool, None → null
            for k, v in record.items():
                if isinstance(v, bytes) and len(v) == 1:
                    record[k] = bool(v[0])
            logger.info("Fetched EDR record for %s (%d fields)", ecn_id, len(record))
            return json.dumps(record, default=str)

    except Exception as exc:
        logger.error("MS SQL fetch failed for %s: %s", ecn_id, exc)
        return json.dumps({"error": str(exc)})


def _mock_fetch(ecn_id: str) -> str:
    """Return mock EDR data when MSSQL_CONN is not configured (dev/test only)."""
    mocks = {
        "ECN-2024-001": {
            "ecn_number": "ECN-2024-001",
            "event_type": "Priority FC Business Approval",
            "event_subtype": "Annual Review",
            "workflow_status": "Completed",
            "brokerage_type": "Retail",
            "event_description": "Annual review for high-risk retail client. Suspicious transaction patterns identified.",
            "recommended_action": "Accept",
            "recommended_rationale": "All documentation reviewed. Risk level acceptable per FC Business criteria.",
            "recommending_group": "FC Business",
            "input_file_ecn": "ECN-2024-001",
            "input_file_event_type": "Priority FC Business Approval",
            "input_file_workflow_status": "Completed",
            "l1_recommended_action": "Accept",
            "l1_rationale": "FC Business reviewed all documentation. Risk level acceptable.",
            "l2_decision": "Accept",
            "l2_action": None,
            "l2_rationale": "Concur with FC Business recommendation. Documentation complete.",
            "l2_lob": None,
            "l2_multiple_rows": False,
            "elevated_approval_required": False,
            "elevated_approval_decision": None,
            "elevated_approval_rationale": None,
            "final_recommended_action": "Accept",
            "rro_number": None,
            "risk_rating_amended_in_l2": False,
            "final_risk_rating": None,
        },
        "ECN-2024-002": {
            "ecn_number": "ECN-2024-002",
            "event_type": "Standard Referral",
            "event_subtype": "Transaction Alert",
            "workflow_status": "Completed",
            "brokerage_type": "Institutional",
            "event_description": "Institutional client with multiple large wire transfers to high-risk jurisdictions.",
            "recommended_action": "Increase Risk Rating",
            "recommended_rationale": "Transaction patterns indicate elevated risk. Risk rating increase recommended.",
            "recommending_group": "Risk",
            "input_file_ecn": "ECN-2024-002",
            "input_file_event_type": "Standard Referral",
            "input_file_workflow_status": "Completed",
            "l1_recommended_action": None,
            "l1_rationale": None,
            "l2_decision": "Accept",
            "l2_action": None,
            "l2_rationale": "Concur with Risk recommendation. Risk rating increase appropriate.",
            "l2_lob": None,
            "l2_multiple_rows": False,
            "elevated_approval_required": False,
            "elevated_approval_decision": None,
            "elevated_approval_rationale": None,
            "final_recommended_action": "Increase Risk Rating",
            "rro_number": None,   # blank → NEEDS_HUMAN for Q11
            "risk_rating_amended_in_l2": False,
            "final_risk_rating": None,
        },
        "ECN-2024-003": {
            "ecn_number": "ECN-2024-003",
            "event_type": "Standard Referral",
            "event_subtype": "Exit Review",
            "workflow_status": "Completed",
            "brokerage_type": "Retail",
            "event_description": "Retail client with sustained suspicious activity. Exit recommended.",
            "recommended_action": "Exit Decision",
            "recommended_rationale": "Sustained suspicious activity pattern. Client relationship not viable.",
            "recommending_group": "Risk",
            "input_file_ecn": "ECN-2024-003",
            "input_file_event_type": "Standard Referral",
            "input_file_workflow_status": "Completed",
            "l1_recommended_action": None,
            "l1_rationale": None,
            "l2_decision": "Accept",
            "l2_action": None,
            "l2_rationale": "Concur with Risk. Exit Decision is appropriate.",
            "l2_lob": None,
            "l2_multiple_rows": False,
            "elevated_approval_required": True,
            "elevated_approval_decision": "Approved",
            "elevated_approval_rationale": "Senior approval granted for exit.",
            "final_recommended_action": "Exit Decision",
            "rro_number": None,
            "risk_rating_amended_in_l2": False,
            "final_risk_rating": None,
        },
    }
    record = mocks.get(ecn_id)
    if record is None:
        return json.dumps({"error": f"ECN not found in mock data: {ecn_id}"})
    logger.info("Mock fetch for %s", ecn_id)
    return json.dumps(record, default=str)


# ── context.state read/write tools ────────────────────────────────────────────

def store_edr_data(edr_data_json: str, tool_context: ToolContext) -> str:
    """
    Write fetched EDR data into context.state["edr_data"].
    edr_data_json must be the JSON string returned by fetch_edr_data.
    ADK injects tool_context automatically.
    """
    try:
        data = json.loads(edr_data_json)
        if "error" in data:
            return json.dumps({"stored": False, "error": data["error"]})
        tool_context.state["edr_data"] = data
        ecn = data.get("ecn_number", "unknown")
        logger.info("Stored EDR data for ECN %s (%d fields)", ecn, len(data))
        return json.dumps({"stored": True, "ecn_id": ecn, "fields": len(data)})
    except Exception as exc:
        return json.dumps({"stored": False, "error": str(exc)})


def get_edr_data(tool_context: ToolContext) -> str:
    """
    Read EDR data from context.state["edr_data"].
    Returns JSON of the full EDR record, or {"found": false} if not stored.
    ADK injects tool_context automatically.
    """
    data = tool_context.state.get("edr_data", {})
    if not data:
        return json.dumps({"found": False, "edr_data": {}})
    return json.dumps({"found": True, "edr_data": data})


def get_prior_answers(tool_context: ToolContext) -> str:
    """
    Read all answers stored so far from context.state["answers"].
    Returns JSON dict keyed by question number e.g. {"q1": {...}, "q3": {...}}.
    ADK injects tool_context automatically.
    """
    answers = tool_context.state.get("answers", {})
    return json.dumps({"answers": answers, "count": len(answers)})


def store_answer(
    question_number: int,
    answer:          str,
    reasoning:       str,
    category:        str,
    requires_human:  bool,
    human_action:    str,
    tool_context:    ToolContext,
) -> str:
    """
    Write one question answer into context.state["answers"]["q{N}"].
    ADK injects tool_context automatically.
    """
    try:
        answers = tool_context.state.get("answers", {})
        key     = f"q{question_number}"
        answers[key] = {
            "question_number": question_number,
            "answer":          answer.strip().upper(),
            "reasoning":       reasoning,
            "category":        category,
            "requires_human":  requires_human,
            "human_action":    human_action,
        }
        tool_context.state["answers"] = answers
        logger.info("Stored Q%d answer: %s", question_number, answer)
        return json.dumps({"stored": True, "question": question_number, "answer": answer})
    except Exception as exc:
        return json.dumps({"stored": False, "error": str(exc)})


def get_all_answers(tool_context: ToolContext) -> str:
    """
    Read all 15 answers from context.state["answers"].
    ADK injects tool_context automatically.
    """
    answers = tool_context.state.get("answers", {})
    return json.dumps({"answers": answers, "count": len(answers)})


def store_verdict(
    verdict:            str,
    overall_pass_rate:  float,
    failed_questions:   str,   # JSON array string e.g. "[3, 7]"
    human_review_count: int,
    tool_context:       ToolContext,
) -> str:
    """
    Write final verdict summary into context.state["verdict"].
    ADK injects tool_context automatically.
    """
    try:
        failed = json.loads(failed_questions) if failed_questions else []
    except Exception:
        failed = []
    tool_context.state["verdict"] = {
        "verdict":            verdict,
        "overall_pass_rate":  overall_pass_rate,
        "failed_questions":   failed,
        "human_review_count": human_review_count,
    }
    return json.dumps({"stored": True, "verdict": verdict})


# ── QA reasoning tool — calls Claude claude-sonnet-4-6 ─────────────────────────────────

def answer_question(
    question_number: int,
    edr_data_json:   str,
    prior_answers_json: str,
    tool_context:    ToolContext,
) -> str:
    """
    Reason about one EDR QA question using Claude claude-sonnet-4-6.

    Reads check logic from questions.py by question_number.
    Calls Anthropic API with the EDR data and prior answers as context.
    Returns structured JSON: {answer, reasoning, requires_human, human_action, category}.

    ADK injects tool_context automatically.
    """
    from questions import EDR_QUESTION_MAP
    import anthropic

    q = EDR_QUESTION_MAP.get(question_number)
    if not q:
        return json.dumps({"error": f"Question {question_number} not found"})

    try:
        edr_data     = json.loads(edr_data_json)   if isinstance(edr_data_json,    str) else edr_data_json
        prior_answers = json.loads(prior_answers_json) if isinstance(prior_answers_json, str) else prior_answers_json
    except Exception as exc:
        return json.dumps({"error": f"JSON parse error: {exc}"})

    # Build prior answers context for depends_on questions
    prior_block = ""
    for dep in q.depends_on:
        dep_rec = prior_answers.get(f"q{dep}")
        if dep_rec:
            prior_block += (
                f"\nQ{dep} [{dep_rec.get('category','')}]: {dep_rec.get('answer','?')}\n"
                f"  Reasoning: {dep_rec.get('reasoning','')[:200]}\n"
            )

    human_note = ""
    if q.requires_human:
        human_note = (
            "\n⚠️  HUMAN REVIEW REQUIRED: If the condition in the check logic applies, "
            "you MUST answer NEEDS_HUMAN and include a HUMAN_ACTION line specifying "
            "the exact action required. Only answer N/A if the condition clearly does NOT apply."
        )

    # Filter EDR data to only the fields this question uses
    relevant = {k: edr_data.get(k) for k in q.db_fields if k in edr_data}
    if not relevant:
        relevant = edr_data   # fallback to full record

    prompt = f"""EDR QA Analysis — Question {question_number} of 15

Category: {q.category}
Question: {q.question}

Check Logic (apply exactly as written):
{q.check}
{human_note}
{"Prior answers (dependency context):" + prior_block if prior_block else ""}

EDR Record fields relevant to this question:
{json.dumps(relevant, indent=2, default=str)}

Full EDR Record (for additional context if needed):
ECN: {edr_data.get('ecn_number', 'unknown')}
Event Type: {edr_data.get('event_type', '')}
Brokerage Type: {edr_data.get('brokerage_type', '')}
Final Action: {edr_data.get('final_recommended_action', '')}

Output format: {q.output_hint}

Respond EXACTLY in this format:
REASONING:
<Detailed step-by-step analysis referencing specific field values from the EDR record. Minimum 3 sentences. Quote actual field values.>

ANSWER: <Y | N | N/A | NEEDS_HUMAN>
{"HUMAN_ACTION: <exact action to take — which team/group, what to do>" if q.requires_human else ""}"""

    try:
        client = anthropic.Anthropic(api_key=os.environ.get("ANTHROPIC_API_KEY", ""))
        response = client.messages.create(
            model=os.environ.get("CLAUDE_MODEL", "claude-sonnet-4-6"),
            max_tokens=1200,
            system=(
                "You are a senior QA analyst reviewing Actimize EDR compliance records. "
                "Apply the check logic exactly as written — do not interpret or paraphrase it. "
                "Always reference specific field values from the EDR record in your reasoning. "
                "Never fabricate data not present in the record."
            ),
            messages=[{"role": "user", "content": prompt}],
        )
        raw = response.content[0].text.strip()
    except Exception as exc:
        logger.error("Claude API error on Q%d: %s", question_number, exc)
        return json.dumps({
            "question_number": question_number,
            "category":        q.category,
            "answer":          "NEEDS_HUMAN",
            "reasoning":       f"API error: {exc}",
            "requires_human":  True,
            "human_action":    f"API error on Q{question_number} — manual review required.",
        })

    # Parse the structured response
    reasoning    = ""
    answer_str   = "NEEDS_HUMAN"
    human_action = ""

    if "REASONING:" in raw:
        r0 = raw.index("REASONING:") + len("REASONING:")
        a0 = raw.find("ANSWER:", r0)
        reasoning = raw[r0: a0 if a0 != -1 else None].strip()

    if "ANSWER:" in raw:
        a0  = raw.index("ANSWER:") + len("ANSWER:")
        h0  = raw.find("HUMAN_ACTION:", a0)
        end = h0 if h0 != -1 else None
        answer_str = raw[a0:end].strip().splitlines()[0].strip()

    if "HUMAN_ACTION:" in raw:
        h0           = raw.index("HUMAN_ACTION:") + len("HUMAN_ACTION:")
        human_action = raw[h0:].strip()

    logger.info("Q%d answered: %s", question_number, answer_str)
    return json.dumps({
        "question_number": question_number,
        "category":        q.category,
        "answer":          answer_str,
        "reasoning":       reasoning,
        "requires_human":  q.requires_human,
        "human_action":    human_action,
        "raw_response":    raw,
    })


# ── Report builder ────────────────────────────────────────────────────────────

def build_report(
    answers_json:  str,
    edr_data_json: str,
    output_path:   str,
    tool_context:  ToolContext,
) -> str:
    """
    Compute final verdict from all answers and write JSON result file.
    ADK injects tool_context automatically.
    """
    try:
        answers  = json.loads(answers_json)  if isinstance(answers_json,  str) else answers_json
        edr_data = json.loads(edr_data_json) if isinstance(edr_data_json, str) else edr_data_json
    except Exception as exc:
        return json.dumps({"error": f"JSON parse error: {exc}"})

    # Normalise keys: both "q1" and "1" accepted
    normalised: dict[int, dict] = {}
    for k, v in answers.items():
        num = int(str(k).replace("q", "").replace("Q", ""))
        normalised[num] = v

    yes_count  = sum(1 for v in normalised.values() if v.get("answer","").upper() in ("Y","YES"))
    no_count   = sum(1 for v in normalised.values() if v.get("answer","").upper() in ("N","NO"))
    has_human  = any(v.get("requires_human", False) for v in normalised.values())

    denom     = yes_count + no_count
    pass_rate = round(yes_count / denom * 100, 2) if denom > 0 else 0.0

    if no_count > 0:
        verdict = "FAIL"
    elif has_human:
        verdict = "REQUIRES_HUMAN_REVIEW"
    elif pass_rate == 100.0:
        verdict = "PASS"
    else:
        verdict = "PASS_WITH_EXCEPTIONS"

    failed_questions = [
        n for n, v in sorted(normalised.items())
        if v.get("answer","").upper() in ("N","NO")
    ]
    human_items = [
        {
            "question":        n,
            "category":        v.get("category",""),
            "action_required": v.get("human_action",""),
        }
        for n, v in sorted(normalised.items())
        if v.get("requires_human", False)
    ]

    from questions import CATEGORY_QUESTION_MAP
    breakdown: dict[str, Any] = {}
    for cat, q_nums in CATEGORY_QUESTION_MAP.items():
        cat_ans = [normalised.get(n, {}) for n in q_nums]
        breakdown[cat] = {
            "questions":   q_nums,
            "Y":           sum(1 for a in cat_ans if a.get("answer","").upper() in ("Y","YES")),
            "N":           sum(1 for a in cat_ans if a.get("answer","").upper() in ("N","NO")),
            "NA":          sum(1 for a in cat_ans if a.get("answer","").upper() in ("N/A","NA")),
            "NEEDS_HUMAN": sum(1 for a in cat_ans if a.get("answer","").upper() == "NEEDS_HUMAN"),
        }

    output: dict[str, Any] = {
        "ecn_id":                    edr_data.get("ecn_number","unknown"),
        "event_type":                edr_data.get("event_type",""),
        "brokerage_type":            edr_data.get("brokerage_type",""),
        "final_recommended_action":  edr_data.get("final_recommended_action",""),
        "verdict":                   verdict,
        "overall_pass_rate":         pass_rate,
        "passed":                    verdict in ("PASS","PASS_WITH_EXCEPTIONS"),
        "total_questions":           15,
        "answered_questions":        len(normalised),
        "failed_questions":          failed_questions,
        "human_review_required":     human_items,
        "category_breakdown":        breakdown,
        "answers": [
            {
                "number":         n,
                "category":       v.get("category",""),
                "answer":         v.get("answer",""),
                "reasoning":      v.get("reasoning",""),
                "requires_human": v.get("requires_human", False),
                "human_action":   v.get("human_action",""),
            }
            for n, v in sorted(normalised.items())
        ],
    }

    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as fh:
        json.dump(output, fh, indent=2)

    logger.info("Report written: %s | verdict=%s pass=%.1f%%", output_path, verdict, pass_rate)
    return json.dumps({
        "status":             "ok",
        "output_path":        output_path,
        "verdict":            verdict,
        "overall_pass_rate":  pass_rate,
        "failed_questions":   failed_questions,
        "human_review_count": len(human_items),
    })


# ── Tool registry — all FunctionTools ─────────────────────────────────────────

def make_all_tools() -> list:
    """
    Create ADK FunctionTool instances for all pipeline tools.
    Called once per agent build — ADK wraps each function and injects ToolContext.
    """
    from google.adk.tools import FunctionTool
    return [
        FunctionTool(fetch_edr_data),
        FunctionTool(store_edr_data),
        FunctionTool(get_edr_data),
        FunctionTool(get_prior_answers),
        FunctionTool(answer_question),
        FunctionTool(store_answer),
        FunctionTool(get_all_answers),
        FunctionTool(store_verdict),
        FunctionTool(build_report),
    ]
