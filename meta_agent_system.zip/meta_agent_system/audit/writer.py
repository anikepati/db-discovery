"""audit/writer.py — audit trail for the meta-agent pipeline run."""
import json, time
from datetime import datetime
from pathlib import Path


class AuditWriter:
    def __init__(self, run_id: str, output_dir: str):
        self.run_id     = run_id
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self._seq       = 0
        self._t0        = None
        self._agents    = []

    def start(self):
        self._t0 = time.time()
        self._write("00_run_start", {
            "run_id": self.run_id,
            "started_at": datetime.utcnow().isoformat(),
        })

    def record_agent(self, agent_name: str, output_preview: str):
        self._seq += 1
        self._agents.append(agent_name)
        self._write(f"{self._seq:02d}_{agent_name}", {
            "agent":          agent_name,
            "sequence":       self._seq,
            "output_preview": output_preview[:800],
            "timestamp":      datetime.utcnow().isoformat(),
        })

    def finish(self, final_output: str):
        duration = time.time() - (self._t0 or time.time())
        self._write("99_run_complete", {
            "run_id":          self.run_id,
            "agents_run":      self._agents,
            "duration_seconds": round(duration, 2),
            "completed_at":    datetime.utcnow().isoformat(),
            "final_preview":   final_output[:500],
        })

    def _write(self, name: str, data: dict):
        p = self.output_dir / f"{name}.json"
        p.write_text(json.dumps(data, indent=2, default=str))
