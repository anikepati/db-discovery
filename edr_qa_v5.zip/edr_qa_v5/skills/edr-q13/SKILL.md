---
name: edr-q13
description: >
  EDR QA Question 13 of 15 (Initiation of Decision Execution): Profile Refresh: Validate if profile refresh request was referred to the appropriate process for execution..
  Reads EDR data from context.state, reasons using Claude claude-sonnet-4-6, writes
  answer to context.state["answers"]["q13"]. Use only in EDR QA pipeline.
license: Proprietary
metadata:
  author: edr-qa-team
  version: "5.0"
  pipeline: edr-qa-v5
  question_number: "13"
  category: "Initiation of Decision Execution"
  requires_human: "true"
compatibility: Requires ADK ToolContext, Anthropic API, context.state with edr_data populated
allowed-tools: get_edr_data get_prior_answers answer_question store_answer
---

# EDR QA — Question 13: Initiation of Decision Execution

**Profile Refresh: Validate if profile refresh request was referred to the appropriate process for execution.**

## Dependencies

Depends on: Q10

Prior answers for dependent questions MUST be in `context.state["answers"]` before this agent runs.

## ⚠️ Human Review Required

If the condition applies, answer **NEEDS_HUMAN** and include a `HUMAN_ACTION:` line specifying the exact action required. Only answer N/A if the condition clearly does not apply.

## Steps

1. Call `get_edr_data()` — reads `context.state["edr_data"]` (populated by IngestAgent)
2. Call `get_prior_answers()` — reads `context.state["answers"]` for dependent Q answers
3. Call `answer_question(question_number=13, edr_data=<step1>, prior_answers=<step2>)`
   - This calls Claude claude-sonnet-4-6 with the check logic and EDR data
   - Returns: `answer`, `reasoning`, `requires_human`, `human_action`
4. Call `store_answer(question_number=13, answer=..., reasoning=..., ...)` 
   - Writes to `context.state["answers"]["q13"]`
5. Respond with exactly:

```
Q13 [Initiation of Decision Execution]: <answer>
REASONING: <1-2 sentence summary>
```

## Check Logic

```
If final_recommended_action changed to 'Profile Refresh' during risk review:   NEEDS_HUMAN — human must validate referral to appropriate process. Else: N/A.
```

## Validation

Human must validate if decision changed to Profile Refresh during review.

## Output Format

If decision changed to Profile Refresh: NEEDS_HUMAN. Else N/A.

Valid answers: `Y` | `N` | `N/A` | `NEEDS_HUMAN`

## DB Fields Used

| Column | Notes |
|--------|-------|
| `final_recommended_action` |
| `recommended_action` |
| `l2_action` |

## Gotchas

- Always call `get_edr_data()` first — never use stale data from a prior step.
- Always call `get_prior_answers()` before `answer_question` — dependency answers may affect the result.
- Never skip this question even if a dependency answered N or NEEDS_HUMAN.
- Do NOT write to `context.state` directly — use `store_answer` tool only.
- See [references/question.md](references/question.md) for full question text and validation grid.
