"""
yaml_runtime.py
---------------
Executes YAML-defined tools. Two types only:

  sql     — Parameterised MS SQL queries via SQLAlchemy + pyodbc
  python  — Sandboxed computation via RestrictedPython

edr_state is gone. SequentialAgent passes conversation history
automatically — no manual state management needed.

All tools go through in-memory MCP servers (mcp_factory.py).
No ToolContext. No FunctionTool wrapping. Clean and simple.
"""

import os
import yaml
import sqlalchemy
from typing import Any
from jinja2 import sandbox as jinja_sandbox
from dotenv import load_dotenv

load_dotenv()

# ── RestrictedPython ──────────────────────────────────────────────────────────
try:
    import RestrictedPython
    RESTRICTED_AVAILABLE = True
    SAFE_BUILTINS = RestrictedPython.safe_builtins.copy()
    SAFE_BUILTINS.update({
        "len": len, "range": range, "enumerate": enumerate,
        "zip": zip, "map": map, "filter": filter,
        "sum": sum, "min": min, "max": max, "round": round,
        "list": list, "dict": dict, "set": set, "tuple": tuple,
        "str": str, "int": int, "float": float, "bool": bool,
        "sorted": sorted, "reversed": reversed,
        "isinstance": isinstance, "type": type,
        "abs": abs, "any": any, "all": all,
        "print": print,
    })
except ImportError:
    RESTRICTED_AVAILABLE = False

ALLOWED_IMPORTS = {
    "json", "statistics", "math", "datetime",
    "re", "collections", "itertools", "functools",
}

MCP_TOOL_TYPES = {"sql", "python"}


class YAMLFunctionRuntime:
    """
    Loads a YAML tool definition file and executes sql/python tools.
    Called by mcp_factory.py to serve tools via in-memory MCP server.
    """

    def __init__(self, yaml_path: str) -> None:
        with open(yaml_path) as f:
            raw = yaml.safe_load(f)
        self.yaml_path = yaml_path
        self.registry: dict[str, dict] = {
            fn["id"]: fn
            for fn in raw.get("functions", [])
            if fn.get("type") in MCP_TOOL_TYPES
        }
        self.secrets: dict[str, str] = {k: v for k, v in os.environ.items() if v}
        self.jinja = jinja_sandbox.SandboxedEnvironment()

    # ── Input resolution ──────────────────────────────────────────────────────

    def _resolve(self, template: Any, ctx: dict) -> str:
        return self.jinja.from_string(str(template)).render(
            inputs=ctx.get("inputs", {}),
            secrets=self.secrets,
        )

    def _resolve_inputs(self, fn_def: dict, raw: dict) -> dict:
        resolved = {}
        for name, schema in fn_def.get("inputs", {}).items():
            if name in raw:
                resolved[name] = raw[name]
            elif "default" in schema:
                resolved[name] = schema["default"]
            elif schema.get("required", False):
                raise ValueError(
                    f"[{fn_def['id']}] Missing required input: '{name}'"
                )
        return resolved

    # ── Public execute ────────────────────────────────────────────────────────

    def execute(self, function_id: str, inputs: dict) -> Any:
        fn = self.registry.get(function_id)
        if not fn:
            raise ValueError(f"Unknown function: '{function_id}'")
        inputs  = self._resolve_inputs(fn, inputs)
        fn_type = fn.get("type")
        if fn_type == "sql":
            return self._run_sql(fn["config"], {"inputs": inputs})
        elif fn_type == "python":
            return self._run_python(fn["python"], inputs)
        else:
            raise ValueError(f"Unsupported tool type: '{fn_type}'")

    # ── SQL — MS SQL via pyodbc + SQLAlchemy ──────────────────────────────────

    def _run_sql(self, config: dict, ctx: dict) -> list[dict]:
        conn_str = self._resolve(config["connection"], ctx)
        query    = config["query"]
        bound    = {
            k: self._resolve(v, ctx)
            for k, v in config.get("params", {}).items()
        }
        engine = sqlalchemy.create_engine(conn_str, fast_executemany=True)
        with engine.connect() as conn:
            result = conn.execute(sqlalchemy.text(query), bound)
            return [dict(row._mapping) for row in result]

    # ── Python — sandboxed, ReportAgent only ─────────────────────────────────

    def _run_python(self, python_def: dict, inputs: dict) -> Any:
        if not RESTRICTED_AVAILABLE:
            raise RuntimeError("RestrictedPython not installed.")

        code     = python_def["code"]
        compiled = RestrictedPython.compile_restricted(code, "<yaml_tool>", "exec")

        def _safe_import(name, *args, **kwargs):
            if name not in ALLOWED_IMPORTS:
                raise ImportError(
                    f"'{name}' not allowed. Allowed: {sorted(ALLOWED_IMPORTS)}"
                )
            return __import__(name, *args, **kwargs)

        local_ns  = {"inputs": inputs, "result": None}
        global_ns = {
            "__builtins__": SAFE_BUILTINS,
            "__import__":   _safe_import,
            "_print_":      RestrictedPython.PrintCollector,
            "_getiter_":    iter,
            "_getattr_":    getattr,
            "_inplacevar_": RestrictedPython.Guards.guarded_inplacevar,
        }
        exec(compiled, global_ns, local_ns)  # noqa: S102
        if local_ns.get("result") is None:
            raise ValueError("Python tool did not assign to `result`.")
        return local_ns["result"]
