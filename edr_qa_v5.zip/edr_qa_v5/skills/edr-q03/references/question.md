# Q03 Full Reference — Event Creation

## Question

If EDR event type is not Priority FC Business Referral, validate the recommendation rationale aligns with the event description.

## Validation

Assess if Recommended Rationale came from authorized group per EDR type/brokerage grid.

## Check Logic (apply exactly)

If event_type = 'Priority FC Business Approval': answer N/A. Else check brokerage_type and recommending_group against the authorization grid. If recommending_group is authorized for this brokerage_type: Y. Else: N.

## Depends On

Q01, Q02

## Output Hint

State event_type, brokerage_type, recommending_group. Confirm authorization. Answer Y, N, or N/A.

## Requires Human Review

No — answer should be Y, N, or N/A only.

## DB Fields

- `event_type`
- `brokerage_type`
- `recommending_group`
- `recommended_rationale`
- `event_description`

## Authorization Grid (relevant for Q2, Q3, Q5, Q8)

See `skills/edr-ingest/references/schema.md` for the full authorization grid
mapping EDR type + brokerage type → authorized recommending groups.
