"""Configuration and logging for the EDR QA pipeline."""

import json
import logging
import logging.handlers
import os
import sys
from dataclasses import dataclass, field
from datetime import datetime, timezone

from dotenv import load_dotenv

load_dotenv()


@dataclass(frozen=True)
class Settings:
    google_api_key: str = field(default_factory=lambda: os.getenv("GOOGLE_API_KEY", ""))
    model: str = field(default_factory=lambda: os.getenv("AGENT_MODEL", "gemini-2.0-flash"))
    max_retries: int = field(default_factory=lambda: int(os.getenv("AGENT_MAX_RETRIES", "3")))
    retry_delay: float = field(default_factory=lambda: float(os.getenv("AGENT_RETRY_DELAY", "2.0")))
    app_name: str = field(default_factory=lambda: os.getenv("APP_NAME", "edr_qa_pipeline"))
    environment: str = field(default_factory=lambda: os.getenv("ENVIRONMENT", "development"))
    log_level: str = field(default_factory=lambda: os.getenv("LOG_LEVEL", "INFO"))
    log_dir: str = field(default_factory=lambda: os.getenv("LOG_DIR", "logs"))

    def validate(self) -> None:
        if not self.google_api_key:
            raise ValueError("GOOGLE_API_KEY is not set. Add it to your .env file.")

    @property
    def is_production(self) -> bool:
        return self.environment.lower() == "production"


settings = Settings()


# ── Logging ───────────────────────────────────────────────────────────────────

class _JSON(logging.Formatter):
    def format(self, r: logging.LogRecord) -> str:
        p = {"ts": datetime.now(timezone.utc).isoformat(), "level": r.levelname,
             "logger": r.name, "msg": r.getMessage()}
        for k in ("ecn_id", "agent", "question"):
            if hasattr(r, k):
                p[k] = getattr(r, k)
        if r.exc_info:
            p["exc"] = self.formatException(r.exc_info)
        return json.dumps(p)


class _Console(logging.Formatter):
    _C = {"DEBUG": "\033[36m", "INFO": "\033[32m", "WARNING": "\033[33m",
          "ERROR": "\033[31m", "CRITICAL": "\033[35m", "RESET": "\033[0m"}

    def format(self, r: logging.LogRecord) -> str:
        c, rst = self._C.get(r.levelname, ""), self._C["RESET"]
        ts = datetime.now().strftime("%H:%M:%S")
        extras = " ".join(f"{k}={getattr(r, k)}" for k in ("ecn_id", "agent", "question") if hasattr(r, k))
        suffix = f"  [{extras}]" if extras else ""
        return f"{c}{ts} {r.levelname:<8}{rst} {r.name:<30} {r.getMessage()}{suffix}"


def configure_logging() -> None:
    os.makedirs(settings.log_dir, exist_ok=True)
    level = getattr(logging, settings.log_level.upper(), logging.INFO)
    root = logging.getLogger()
    root.setLevel(logging.DEBUG)
    root.handlers.clear()

    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(level)
    ch.setFormatter(_JSON() if settings.is_production else _Console())
    root.addHandler(ch)

    fh = logging.handlers.RotatingFileHandler(
        os.path.join(settings.log_dir, f"{settings.app_name}.log"),
        maxBytes=50 * 1024 * 1024, backupCount=5, encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(_JSON())
    root.addHandler(fh)

    for name in ("httpx", "httpcore", "google"):
        logging.getLogger(name).setLevel(logging.WARNING)
