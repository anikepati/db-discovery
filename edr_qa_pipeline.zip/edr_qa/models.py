"""
Domain models for the EDR QA pipeline.
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any


class QAAnswer(str, Enum):
    YES = "Y"
    NO = "N"
    NA = "N/A"
    NEEDS_HUMAN = "NEEDS_HUMAN"   # questions that must not be auto-answered (e.g. Profile Refresh, Exit)

    @classmethod
    def from_string(cls, value: str) -> "QAAnswer":
        v = value.strip().upper()
        mapping = {"Y": cls.YES, "YES": cls.YES,
                   "N": cls.NO,  "NO": cls.NO,
                   "N/A": cls.NA, "NA": cls.NA,
                   "NEEDS_HUMAN": cls.NEEDS_HUMAN}
        return mapping.get(v, cls.NEEDS_HUMAN)


class EDRVerdict(str, Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    PASS_WITH_EXCEPTIONS = "PASS_WITH_EXCEPTIONS"
    REQUIRES_HUMAN_REVIEW = "REQUIRES_HUMAN_REVIEW"

    @property
    def passed(self) -> bool:
        return self in (EDRVerdict.PASS, EDRVerdict.PASS_WITH_EXCEPTIONS)


@dataclass
class QuestionResult:
    """Result for a single QA question."""
    number: int
    category: str
    question: str
    answer: QAAnswer
    reasoning: str
    raw_response: str
    requires_human: bool = False
    human_action: str = ""   # populated when requires_human is True


@dataclass
class CategorySummary:
    """Pass/fail summary for one category."""
    name: str
    total: int
    yes_count: int
    no_count: int
    na_count: int
    human_count: int

    @property
    def fail_count(self) -> int:
        return self.no_count

    @property
    def pass_rate(self) -> float:
        denominator = self.yes_count + self.no_count
        return (self.yes_count / denominator * 100) if denominator > 0 else 0.0


@dataclass
class EDRQAResult:
    """Complete result of one EDR QA pipeline run."""
    ecn_id: str
    session_id: str
    verdict: EDRVerdict
    overall_pass_rate: float
    summary: str
    category_summaries: list[CategorySummary]
    question_results: list[QuestionResult]
    failed_questions: list[int]
    human_review_required: list[int]
    started_at: datetime
    completed_at: datetime
    duration_seconds: float
    raw_edr_data: dict[str, Any] = field(default_factory=dict)

    def one_line(self) -> str:
        return (
            f"[{self.verdict.value}] ECN: {self.ecn_id} | "
            f"Pass rate: {self.overall_pass_rate:.1f}% | "
            f"Failed: {len(self.failed_questions)} | "
            f"Human review: {len(self.human_review_required)} | "
            f"{self.duration_seconds:.1f}s"
        )
