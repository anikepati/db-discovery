"""
Mode Detector — Standalone automation mode classification engine.

Classifies SOP content into BROWSER, THICK_CLIENT, SYSTEM, or HYBRID
using multi-signal analysis without requiring LLM calls.
"""

from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass, field
from typing import Any

from models.schemas import AutomationMode, ModeSignal, ModeClassification
from utils.config_loader import MAFConfig


@dataclass
class ModeDetector:
    """Rule-based automation mode detector using config-driven keywords."""

    config: MAFConfig = field(default_factory=lambda: MAFConfig())

    def classify(self, sop_text: str) -> ModeClassification:
        """
        Classify an SOP's automation mode using multi-signal analysis.

        Signals:
        1. Keyword frequency matching
        2. URL/path pattern detection
        3. Tool/command references
        4. UI element references
        5. Contextual phrases

        Args:
            sop_text: Raw SOP markdown text

        Returns:
            ModeClassification with primary mode, confidence, and signals
        """
        text_lower = sop_text.lower()
        signals: list[ModeSignal] = []

        # ── Signal 1: Keyword Matching ──
        for mode_name in ["browser", "thick_client", "system"]:
            keywords = self.config.get_mode_keywords(mode_name)
            mode_enum = self._str_to_mode(mode_name)
            for keyword in keywords:
                count = text_lower.count(keyword.lower())
                if count > 0:
                    confidence = min(0.3 + (count * 0.1), 0.9)
                    signals.append(ModeSignal(
                        signal_type="keyword",
                        signal_value=f"{keyword} (×{count})",
                        detected_mode=mode_enum,
                        confidence=confidence,
                    ))

        # ── Signal 2: URL Pattern Detection ──
        urls = re.findall(r'https?://[^\s\)]+', sop_text)
        if urls:
            signals.append(ModeSignal(
                signal_type="target",
                signal_value=f"URLs found: {len(urls)}",
                detected_mode=AutomationMode.BROWSER,
                confidence=0.8,
            ))

        # API endpoint patterns (versioned paths)
        api_patterns = re.findall(r'/v\d+/\w+', sop_text)
        if api_patterns:
            signals.append(ModeSignal(
                signal_type="target",
                signal_value=f"API endpoints: {len(api_patterns)}",
                detected_mode=AutomationMode.SYSTEM,
                confidence=0.7,
            ))

        # ── Signal 3: UI Element References ──
        ui_web = len(re.findall(
            r'(dropdown|checkbox|form|button|text field|input field|login page|dashboard)',
            text_lower
        ))
        if ui_web > 2:
            signals.append(ModeSignal(
                signal_type="context",
                signal_value=f"Web UI elements: {ui_web}",
                detected_mode=AutomationMode.BROWSER,
                confidence=0.7,
            ))

        ui_desktop = len(re.findall(
            r'(menu bar|toolbar|dialog|window|splash screen|system tray|right-click|double-click|desktop icon)',
            text_lower
        ))
        if ui_desktop > 2:
            signals.append(ModeSignal(
                signal_type="context",
                signal_value=f"Desktop UI elements: {ui_desktop}",
                detected_mode=AutomationMode.THICK_CLIENT,
                confidence=0.7,
            ))

        # ── Signal 4: Command/Script References ──
        cmd_patterns = len(re.findall(
            r'(curl|wget|SELECT|INSERT|UPDATE|COPY|subprocess|shell|bash|cron|CALL sp_)',
            sop_text
        ))
        if cmd_patterns > 0:
            signals.append(ModeSignal(
                signal_type="tool_hint",
                signal_value=f"CLI/SQL commands: {cmd_patterns}",
                detected_mode=AutomationMode.SYSTEM,
                confidence=0.75,
            ))

        # ── Signal 5: File operation patterns ──
        file_ops = len(re.findall(
            r'(\.json|\.csv|\.xml|staging/|s3://|upload|download|ETL)',
            text_lower
        ))
        if file_ops > 2:
            signals.append(ModeSignal(
                signal_type="context",
                signal_value=f"File operations: {file_ops}",
                detected_mode=AutomationMode.SYSTEM,
                confidence=0.6,
            ))

        # ── Aggregate Scores ──
        return self._aggregate_signals(signals)

    def _aggregate_signals(self, signals: list[ModeSignal]) -> ModeClassification:
        """Aggregate signals into a final classification."""
        if not signals:
            return ModeClassification(
                primary_mode=AutomationMode.SYSTEM,
                confidence=0.3,
                signals=[],
                reasoning="No clear signals detected, defaulting to SYSTEM mode",
            )

        mode_scores: dict[AutomationMode, float] = {
            AutomationMode.BROWSER: 0.0,
            AutomationMode.THICK_CLIENT: 0.0,
            AutomationMode.SYSTEM: 0.0,
        }

        for signal in signals:
            mode_scores[signal.detected_mode] += signal.confidence

        # Sort by score descending
        sorted_modes = sorted(mode_scores.items(), key=lambda x: x[1], reverse=True)
        primary_mode, primary_score = sorted_modes[0]
        total_score = sum(mode_scores.values())

        # Normalize confidence
        confidence = min(primary_score / max(total_score, 1.0), 1.0)

        # Check for HYBRID
        secondary_modes = []
        if len(sorted_modes) > 1:
            second_mode, second_score = sorted_modes[1]
            second_confidence = second_score / max(total_score, 1.0)
            if second_confidence > 0.25:  # Significant secondary mode
                secondary_modes.append((second_mode, second_confidence))

        # If secondary is strong enough relative to primary, it's HYBRID
        is_hybrid = (
            secondary_modes
            and secondary_modes[0][1] > 0.35
            and confidence < 0.65
        )

        if is_hybrid:
            return ModeClassification(
                primary_mode=AutomationMode.HYBRID,
                confidence=confidence,
                signals=signals,
                secondary_modes=[(primary_mode, confidence)] + secondary_modes,
                reasoning=(
                    f"Detected strong signals for both {primary_mode.value} "
                    f"({confidence:.0%}) and {secondary_modes[0][0].value} "
                    f"({secondary_modes[0][1]:.0%}). Classifying as HYBRID."
                ),
            )

        return ModeClassification(
            primary_mode=primary_mode,
            confidence=confidence,
            signals=signals,
            secondary_modes=secondary_modes,
            reasoning=(
                f"Strongest signals for {primary_mode.value} mode "
                f"(score: {primary_score:.1f}, confidence: {confidence:.0%}). "
                f"Based on {len(signals)} signals detected."
            ),
        )

    @staticmethod
    def _str_to_mode(mode_str: str) -> AutomationMode:
        mapping = {
            "browser": AutomationMode.BROWSER,
            "thick_client": AutomationMode.THICK_CLIENT,
            "system": AutomationMode.SYSTEM,
        }
        return mapping.get(mode_str, AutomationMode.SYSTEM)
