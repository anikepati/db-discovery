"""
Example Multi-Agent System — Compliance Review Team

A typical enterprise agent team for regulatory compliance review
using Google ADK. Import this into GEPA Forge to see evolution in action.
"""

import textwrap

from google.adk.agents import LlmAgent, SequentialAgent


# ---------------------------------------------------------------------------
# Custom Tools
# ---------------------------------------------------------------------------

def search_regulations(query: str) -> str:
    """Search the regulatory knowledge base for relevant rules and guidelines."""
    return f"[Regulation DB] Found 3 matching regulations for: {query}"


def check_sanctions_list(entity_name: str) -> str:
    """Check an entity against global sanctions lists (OFAC, EU, UN)."""
    return f"[Sanctions Check] Entity '{entity_name}' — No matches found in OFAC/EU/UN lists."


def generate_risk_score(transaction_data: str) -> str:
    """Calculate a risk score for a transaction based on multiple factors."""
    return f"[Risk Engine] Risk score calculated: 0.35 (Low Risk) for transaction data provided."


def create_compliance_report(findings: str) -> str:
    """Generate a structured compliance report from review findings."""
    return f"[Report Generator] Compliance report created with findings summary."


# ---------------------------------------------------------------------------
# Sub-Agents
# ---------------------------------------------------------------------------

data_collector = LlmAgent(
    name="data_collector",
    model="gemini-2.0-flash",
    description="Collects and validates input data for compliance review",
    instruction=textwrap.dedent("""
        You are a Data Collection Agent for compliance reviews.

        Your responsibilities:
        1. Extract relevant entities, transactions, and dates from the user query.
        2. Validate that all required fields are present.
        3. Flag any missing or ambiguous information.
        4. Structure the data for downstream analysis.

        Output a clear summary of extracted data points.
    """).strip(),
    tools=[search_regulations],
)

risk_analyst = LlmAgent(
    name="risk_analyst",
    model="gemini-2.0-flash",
    description="Analyzes risk factors and generates risk assessments",
    instruction=textwrap.dedent("""
        You are a Risk Analysis Agent specializing in financial compliance.

        Your responsibilities:
        1. Review the extracted data from the data collector.
        2. Check entities against sanctions lists.
        3. Calculate risk scores based on transaction patterns.
        4. Identify red flags and suspicious patterns.
        5. Provide a risk assessment with supporting evidence.

        Always provide a confidence level for your risk assessments.
    """).strip(),
    tools=[check_sanctions_list, generate_risk_score],
)

report_writer = LlmAgent(
    name="report_writer",
    model="gemini-2.0-flash",
    description="Generates structured compliance reports with findings and recommendations",
    instruction=textwrap.dedent("""
        You are a Compliance Report Writer Agent.

        Your responsibilities:
        1. Compile findings from data collection and risk analysis.
        2. Structure the report with: Executive Summary, Findings, Risk Assessment, Recommendations.
        3. Ensure all regulatory references are cited.
        4. Flag items requiring human review or escalation.
        5. Provide clear, actionable next steps.

        Output format: Professional compliance report suitable for regulatory submission.
    """).strip(),
    tools=[create_compliance_report],
)

# ---------------------------------------------------------------------------
# Root Agent (Sequential Pipeline)
# ---------------------------------------------------------------------------

root_agent = SequentialAgent(
    name="compliance_review_team",
    description="End-to-end compliance review pipeline: collect → analyze → report",
    sub_agents=[data_collector, risk_analyst, report_writer],
)
