"""
Database Action Handler — upserts validation results.
Uses SQLAlchemy for connection pooling and dialect abstraction.
Supports SQLite, PostgreSQL, MySQL — driven by connection string in YAML.
"""

import logging
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

# Connection cache to avoid repeated connections
_engines: Dict[str, Any] = {}


def _get_engine(connection_string: str):
    """Get or create a SQLAlchemy engine (cached)."""
    if connection_string not in _engines:
        try:
            from sqlalchemy import create_engine
            _engines[connection_string] = create_engine(
                connection_string,
                pool_pre_ping=True,
                echo=False,
            )
            logger.info(f"  [DB] Created engine for: {connection_string}")
        except ImportError:
            logger.warning("SQLAlchemy not installed — using sqlite3 fallback")
            _engines[connection_string] = None
    return _engines[connection_string]


def update_db(
    connection_string: str,
    table: str,
    row_id: str,
    row_id_column: str,
    values: Dict[str, Any],
) -> Dict[str, Any]:
    """
    Upsert a row in the database.
    If the row exists (by row_id), update it. Otherwise, insert.
    """
    try:
        engine = _get_engine(connection_string)

        if engine is None:
            return _fallback_sqlite(connection_string, table, row_id, row_id_column, values)

        from sqlalchemy import text

        # Build SET clause for upsert
        set_clause = ", ".join(f"{k} = :{k}" for k in values.keys())
        columns = ", ".join(values.keys())
        placeholders = ", ".join(f":{k}" for k in values.keys())

        with engine.begin() as conn:
            # Check if row exists
            check = conn.execute(
                text(f"SELECT 1 FROM {table} WHERE {row_id_column} = :rid"),
                {"rid": row_id},
            )

            if check.fetchone():
                # Update
                conn.execute(
                    text(f"UPDATE {table} SET {set_clause} WHERE {row_id_column} = :rid"),
                    {**values, "rid": row_id},
                )
                logger.info(f"  [DB] Updated row {row_id} in {table}")
            else:
                # Insert
                conn.execute(
                    text(f"INSERT INTO {table} ({columns}) VALUES ({placeholders})"),
                    values,
                )
                logger.info(f"  [DB] Inserted row {row_id} into {table}")

        return {"status": "success", "operation": "upsert", "row_id": row_id}

    except Exception as e:
        logger.error(f"  [DB] Error: {e}")
        return {"status": "error", "error": str(e), "row_id": row_id}


def _fallback_sqlite(connection_string, table, row_id, row_id_column, values):
    """Fallback using raw sqlite3 when SQLAlchemy is unavailable."""
    import sqlite3

    db_path = connection_string.replace("sqlite:///", "")
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # Auto-create table if it doesn't exist
    cols_def = ", ".join(f"{k} TEXT" for k in values.keys())
    cursor.execute(f"CREATE TABLE IF NOT EXISTS {table} ({cols_def})")

    columns = ", ".join(values.keys())
    placeholders = ", ".join("?" for _ in values)
    vals = list(values.values())

    # Simple insert (for fallback simplicity)
    cursor.execute(f"INSERT INTO {table} ({columns}) VALUES ({placeholders})", vals)
    conn.commit()
    conn.close()

    logger.info(f"  [DB/sqlite3] Inserted row {row_id} into {table}")
    return {"status": "success", "operation": "insert", "row_id": row_id}


def ensure_table_exists(
    connection_string: str,
    table: str,
    columns: Dict[str, str],
):
    """Create the results table if it doesn't exist."""
    engine = _get_engine(connection_string)
    if engine is None:
        return

    from sqlalchemy import text

    cols_sql = ", ".join(f"{name} {dtype}" for name, dtype in columns.items())
    with engine.begin() as conn:
        conn.execute(text(
            f"CREATE TABLE IF NOT EXISTS {table} ({cols_sql})"
        ))
    logger.info(f"  [DB] Ensured table exists: {table}")
