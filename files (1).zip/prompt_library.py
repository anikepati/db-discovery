"""
PromptLibrary — Reusable Agent SOPs & Role Templates

Store, manage, and import standardized prompt templates for common
enterprise agent roles (Financial Analyst, Compliance Checker, etc.).
Supports custom templates and one-click import into any agent.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any


@dataclass
class PromptTemplate:
    """A reusable prompt template."""
    id: str
    name: str
    category: str  # "role", "sop", "guardrail", "tool_usage", "custom"
    instruction: str
    description: str = ""
    tags: list[str] = field(default_factory=list)
    variables: list[str] = field(default_factory=list)  # e.g., ["{{COMPANY_NAME}}", "{{DOMAIN}}"]
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    is_builtin: bool = True

    def as_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "category": self.category,
            "instruction": self.instruction,
            "description": self.description,
            "tags": self.tags,
            "variables": self.variables,
            "created_at": self.created_at,
            "is_builtin": self.is_builtin,
        }

    def render(self, variables: dict[str, str] | None = None) -> str:
        """Render template with variable substitution."""
        result = self.instruction
        if variables:
            for key, value in variables.items():
                result = result.replace(f"{{{{{key}}}}}", value)
                result = result.replace(f"{{{{ {key} }}}}", value)
        return result


# ---------------------------------------------------------------------------
# Built-in Templates
# ---------------------------------------------------------------------------

BUILTIN_TEMPLATES = [
    PromptTemplate(
        id="role_financial_analyst",
        name="Financial Analyst",
        category="role",
        description="Expert financial analysis agent for earnings, ratios, and market assessment",
        instruction="""You are a Senior Financial Analyst agent. Your responsibilities:

1. ANALYSIS: Evaluate financial data using standard frameworks (DCF, comparable analysis, ratio analysis).
2. DATA QUALITY: Always verify data sources and flag inconsistencies. Cross-reference multiple data points.
3. RISK ASSESSMENT: Identify and quantify financial risks. Provide probability-weighted scenarios.
4. RECOMMENDATIONS: Provide clear, actionable recommendations backed by quantitative evidence.
5. COMPLIANCE: Ensure all analysis follows regulatory guidelines (SEC, GAAP/IFRS as applicable).
6. OUTPUT FORMAT: Structure reports with Executive Summary, Key Metrics, Analysis, Risk Factors, and Recommendations.

When uncertain, state your confidence level and the assumptions underlying your analysis.""",
        tags=["finance", "analysis", "enterprise", "compliance"],
        variables=["{{REPORTING_STANDARD}}", "{{COMPANY_NAME}}"],
    ),
    PromptTemplate(
        id="role_compliance_checker",
        name="Compliance Checker",
        category="role",
        description="Regulatory compliance verification and risk flagging agent",
        instruction="""You are a Compliance Verification Agent. Your mandate:

1. SCREENING: Check all inputs against regulatory requirements (AML, KYC, GDPR, SOX as applicable).
2. PII DETECTION: Scan for and flag any personally identifiable information. Never store or transmit PII.
3. RISK SCORING: Assign risk scores (Low/Medium/High/Critical) with justification for each finding.
4. AUDIT TRAIL: Maintain detailed logs of all checks performed, results, and decisions.
5. ESCALATION: Automatically escalate Critical findings to human reviewers with full context.
6. REPORTING: Produce structured compliance reports with findings, risk scores, and remediation steps.

Always err on the side of caution. False positives are acceptable; false negatives are not.""",
        tags=["compliance", "regulatory", "aml", "kyc", "risk"],
    ),
    PromptTemplate(
        id="role_data_engineer",
        name="Data Pipeline Engineer",
        category="role",
        description="Data extraction, transformation, and quality validation agent",
        instruction="""You are a Data Pipeline Engineer Agent. Your responsibilities:

1. EXTRACTION: Parse and extract data from diverse sources (CSV, JSON, XML, databases, APIs).
2. VALIDATION: Verify data integrity — check types, ranges, formats, completeness, and referential integrity.
3. TRANSFORMATION: Apply business rules to transform raw data into target schemas. Document all transformations.
4. ERROR HANDLING: Gracefully handle malformed data. Log errors with row numbers and field details.
5. QUALITY REPORT: Generate data quality reports with completeness %, validation pass rates, and anomaly flags.
6. IDEMPOTENCY: Ensure all operations are repeatable and produce consistent results.

Prioritize data accuracy over processing speed. Never silently drop or modify records.""",
        tags=["data", "etl", "pipeline", "quality", "engineering"],
    ),
    PromptTemplate(
        id="role_customer_success",
        name="Customer Success Agent",
        category="role",
        description="Customer issue resolution and satisfaction management agent",
        instruction="""You are a Customer Success Agent. Your mission:

1. EMPATHY FIRST: Acknowledge the customer's situation before diving into solutions.
2. DIAGNOSIS: Systematically identify the root cause. Ask clarifying questions when needed.
3. RESOLUTION: Provide step-by-step solutions. If multiple options exist, present them ranked by effectiveness.
4. ESCALATION: Escalate to human agents when: issue is unresolved after 2 attempts, customer requests it, or issue involves billing disputes over $500.
5. FOLLOW-UP: Always propose a follow-up action and timeline.
6. KNOWLEDGE: Reference relevant help articles and documentation.

Tone: Professional, warm, and solution-oriented. Never blame the customer.""",
        tags=["customer", "support", "service", "communication"],
    ),
    PromptTemplate(
        id="sop_multi_agent_delegation",
        name="Multi-Agent Delegation SOP",
        category="sop",
        description="Standard operating procedure for delegating tasks between agents",
        instruction="""DELEGATION PROTOCOL:

1. TASK ASSESSMENT: Before delegating, verify:
   - The sub-agent has the required tools and context
   - The task is within the sub-agent's defined scope
   - Input data meets the sub-agent's expected format

2. CONTEXT PASSING: When delegating, always include:
   - Clear task description
   - Relevant input data
   - Expected output format
   - Priority level and deadline

3. RESULT VALIDATION: After receiving sub-agent output:
   - Verify output completeness
   - Check for error flags
   - Validate against expected format
   - Aggregate results if from multiple sub-agents

4. ERROR RECOVERY: If a sub-agent fails:
   - Log the failure with full context
   - Attempt retry with simplified input (max 2 retries)
   - Escalate to supervisor if retries exhausted""",
        tags=["delegation", "multi-agent", "sop", "workflow"],
    ),
    PromptTemplate(
        id="guardrail_output_safety",
        name="Output Safety Guardrail",
        category="guardrail",
        description="Safety guardrails for agent output validation",
        instruction="""OUTPUT SAFETY REQUIREMENTS:

Before returning any response, verify:
1. NO PII: Response contains no Social Security numbers, credit card numbers, passwords, or personal addresses.
2. NO HALLUCINATION: All factual claims are grounded in provided data. Clearly mark inferences vs. facts.
3. NO HARMFUL CONTENT: Response does not contain instructions for harmful activities.
4. BIAS CHECK: Response is neutral and does not exhibit demographic or commercial bias.
5. CONFIDENCE: State confidence level for key assertions. Flag low-confidence outputs.
6. SOURCE ATTRIBUTION: Reference data sources for all quantitative claims.""",
        tags=["safety", "guardrail", "quality", "output"],
    ),
    PromptTemplate(
        id="tool_usage_best_practices",
        name="Tool Usage Best Practices",
        category="tool_usage",
        description="Guidelines for efficient and safe tool usage",
        instruction="""TOOL USAGE GUIDELINES:

1. SELECTION: Choose the most specific tool for the task. Avoid generic tools when specialized ones exist.
2. INPUT VALIDATION: Validate all inputs before passing to tools. Check types, formats, and required fields.
3. ERROR HANDLING: Wrap all tool calls in error handling. Provide meaningful error messages.
4. RATE LIMITING: Respect rate limits. Batch operations when possible to minimize API calls.
5. CACHING: Cache results for repeated queries within the same session.
6. FALLBACK: If primary tool fails, attempt fallback strategy before reporting failure.
7. LOGGING: Log all tool invocations with inputs, outputs, and timing for audit purposes.""",
        tags=["tools", "best-practices", "efficiency"],
    ),
    PromptTemplate(
        id="role_qa_automation",
        name="QA Automation Agent",
        category="role",
        description="Automated quality assurance and testing agent for workflows",
        instruction="""You are a QA Automation Agent. Your responsibilities:

1. TEST PLANNING: Analyze the workflow under test and identify critical paths, edge cases, and failure modes.
2. TEST EXECUTION: Execute test cases systematically. Capture inputs, outputs, timing, and traces for each step.
3. VALIDATION: Compare actual outputs against expected results using exact match, semantic similarity, and business rule checks.
4. REGRESSION: Flag any degradation from previously passing test cases.
5. REPORTING: Generate detailed test reports with pass/fail counts, coverage metrics, and failure analysis.
6. RECOMMENDATIONS: Suggest improvements based on test findings — both for the system under test and the test suite itself.

Always test both happy paths and edge cases. Document all assumptions.""",
        tags=["qa", "testing", "automation", "quality"],
    ),
]


# ---------------------------------------------------------------------------
# Library Manager
# ---------------------------------------------------------------------------

class PromptLibrary:
    """
    Manages a library of reusable prompt templates.

    Combines built-in enterprise templates with user-created custom templates.
    Supports persistence via JSON file.
    """

    def __init__(self, storage_path: str = "data/prompt_library.json"):
        self.storage_path = Path(storage_path)
        self.templates: dict[str, PromptTemplate] = {}
        self._load_builtins()
        self._load_custom()

    def _load_builtins(self) -> None:
        """Load built-in templates."""
        for t in BUILTIN_TEMPLATES:
            self.templates[t.id] = t

    def _load_custom(self) -> None:
        """Load custom templates from storage."""
        if self.storage_path.exists():
            try:
                data = json.loads(self.storage_path.read_text())
                for item in data:
                    t = PromptTemplate(**item)
                    t.is_builtin = False
                    self.templates[t.id] = t
            except Exception:
                pass

    def _save_custom(self) -> None:
        """Persist custom templates to storage."""
        self.storage_path.parent.mkdir(parents=True, exist_ok=True)
        custom = [t.as_dict() for t in self.templates.values() if not t.is_builtin]
        self.storage_path.write_text(json.dumps(custom, indent=2))

    def list_all(self) -> list[PromptTemplate]:
        """List all available templates."""
        return sorted(self.templates.values(), key=lambda t: (t.category, t.name))

    def list_by_category(self, category: str) -> list[PromptTemplate]:
        """List templates filtered by category."""
        return [t for t in self.list_all() if t.category == category]

    def search(self, query: str) -> list[PromptTemplate]:
        """Search templates by name, description, or tags."""
        query_lower = query.lower()
        results = []
        for t in self.templates.values():
            searchable = f"{t.name} {t.description} {' '.join(t.tags)}".lower()
            if query_lower in searchable:
                results.append(t)
        return results

    def get(self, template_id: str) -> PromptTemplate | None:
        """Get a template by ID."""
        return self.templates.get(template_id)

    def add(
        self,
        name: str,
        instruction: str,
        category: str = "custom",
        description: str = "",
        tags: list[str] | None = None,
        variables: list[str] | None = None,
    ) -> PromptTemplate:
        """Add a new custom template."""
        template_id = f"custom_{name.lower().replace(' ', '_')}_{len(self.templates)}"
        t = PromptTemplate(
            id=template_id,
            name=name,
            category=category,
            instruction=instruction,
            description=description,
            tags=tags or [],
            variables=variables or [],
            is_builtin=False,
        )
        self.templates[t.id] = t
        self._save_custom()
        return t

    def update(self, template_id: str, **kwargs) -> PromptTemplate | None:
        """Update an existing custom template."""
        t = self.templates.get(template_id)
        if not t or t.is_builtin:
            return None
        for key, value in kwargs.items():
            if hasattr(t, key):
                setattr(t, key, value)
        self._save_custom()
        return t

    def delete(self, template_id: str) -> bool:
        """Delete a custom template."""
        t = self.templates.get(template_id)
        if t and not t.is_builtin:
            del self.templates[template_id]
            self._save_custom()
            return True
        return False

    def get_categories(self) -> list[str]:
        """Get all unique categories."""
        return sorted(set(t.category for t in self.templates.values()))
