"""
VerdictSynthesizerAgent — final step of the QA pipeline.

Reads all 10 answers from session state and produces a single structured
JSON verdict consumed by the pipeline runner to build QAResult.
"""

import logging

from google.adk.agents import LlmAgent

from config import settings

logger = logging.getLogger(__name__)

# List all 10 state keys so the LLM knows exactly what to read.
_ANSWER_KEYS = "\n".join(f"  - answer_q{i}" for i in range(1, 11))

_INSTRUCTION = f"""
You are the QA Verdict Synthesizer. You read all 10 QA answers and produce
a final structured JSON verdict.

## Inputs (session state keys)
{_ANSWER_KEYS}

## Output
Respond with ONLY a valid JSON object — no markdown fences, no explanation.

{{
  "verdict": "PASS" | "CONDITIONAL_PASS" | "FAIL" | "REQUIRES_ESCALATION",
  "overall_score": <float 0–100>,
  "executive_summary": "<3–5 sentence summary for a non-technical executive>",
  "dimension_scores": {{
    "compliance": <0–100>,
    "risk":        <0–100>,
    "security":    <0–100>,
    "performance": <0–100>,
    "audit":       <0–100>
  }},
  "blocking_issues": [
    {{"issue": "<description>", "severity": "critical|high", "from_question": <int>}}
  ],
  "non_blocking_issues": [
    {{"issue": "<description>", "severity": "medium|low", "from_question": <int>}}
  ],
  "remediation_actions": [
    {{
      "priority": "P1|P2|P3",
      "action": "<specific action>",
      "owner_role": "<role>",
      "deadline_days": <int>
    }}
  ],
  "next_steps": ["<step>", "<step>", "<step>"]
}}

## Scoring
- overall_score = weighted average: compliance 30%, risk 25%, security 25%, performance 10%, audit 10%
- PASS:                 score ≥ 80,  zero blocking issues
- CONDITIONAL_PASS:     score 60–79, OR blocking issues with an accepted remediation plan
- FAIL:                 score < 60,  OR unresolved critical blocking issues
- REQUIRES_ESCALATION:  score < 40,  OR systemic failures, OR regulatory risk present

Derive all values from the answers — do not invent data.
"""


def create_verdict_synthesizer_agent() -> LlmAgent:
    return LlmAgent(
        name="VerdictSynthesizerAgent",
        model=settings.model,
        instruction=_INSTRUCTION,
        tools=[],
        output_key="verdict_json",
        description="Synthesises all 10 QA answers into a structured JSON verdict.",
    )
