"""
RRO QA Pipeline v1 — CLI

Usage:
  python main.py --ecn-id 584827531833118
  python main.py --ecn-id 584827531833118 --work-item-id 109112741
  python main.py --ecn-id 584827531833118 --output result.json --quiet
  python main.py --concurrent
  python main.py --generate-only

Architecture:
  SequentialAgent. 15 agents. Conversation history. No state tools.
  1 ingest + 13 Q agents + 1 report.
  Tools defined in YAML. Reasoning by agent model. Zero SDK calls.
"""

import argparse
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from config import settings, configure_logging
from pipeline_runner import PipelineRunner
from tool_generator import generate_all_question_yamls

DEMO_ECNS = ["584827531833118", "109112741", "780780000014979"]


def _args():
    p = argparse.ArgumentParser(
        description="RRO QA v1 — 15 ADK agents, SequentialAgent, YAML tools"
    )
    p.add_argument("--ecn-id",        default=None)
    p.add_argument("--work-item-id",  default="")
    p.add_argument("--output",        default=None)
    p.add_argument("--quiet",         action="store_true")
    p.add_argument("--concurrent",    action="store_true",
                   help="Run 3 demo ECNs concurrently (each isolated session)")
    p.add_argument("--generate-only", action="store_true",
                   help="Pre-generate Q01..Q13 YAML files and exit")
    return p.parse_args()


async def run_single(ecn_id, work_item_id, output, quiet) -> int:
    try:
        result = await PipelineRunner().run(
            ecn_id=ecn_id, output_path=output,
            work_item_id=work_item_id, verbose=not quiet
        )
        verdict = result.get("verdict","")
        return 0 if verdict in ("PASS","PASS_WITH_EXCEPTIONS") else 2
    except RuntimeError as e:
        print(f"\n❌  {e}\n", file=sys.stderr)
        return 1


async def run_concurrent(quiet) -> int:
    print("\n🚀  Launching 3 concurrent RRO QA runs (isolated sessions)…\n")
    runner  = PipelineRunner()
    results = await asyncio.gather(*[
        runner.run(ecn_id=ecn, verbose=not quiet)
        for ecn in DEMO_ECNS
    ], return_exceptions=True)

    print(f"\n{'═' * 64}\n  CONCURRENT RESULTS\n{'═' * 64}")
    code = 0
    _ICONS = {"PASS":"✅","PASS_WITH_EXCEPTIONS":"⚠️ ","FAIL":"❌","REQUIRES_HUMAN_REVIEW":"👤"}
    for ecn, res in zip(DEMO_ECNS, results):
        if isinstance(res, Exception):
            print(f"  ❌  {ecn}: FAILED — {res}")
            code = 1
        else:
            v    = res.get("verdict","UNKNOWN")
            icon = _ICONS.get(v,"❓")
            rate = res.get("overall_pass_rate",0)
            print(f"  {icon}  {ecn}: {v} ({rate:.1f}%)")
            if v not in ("PASS","PASS_WITH_EXCEPTIONS"):
                code = max(code, 2)
    print()
    return code


async def main() -> int:
    args = _args()

    if args.generate_only:
        configure_logging()
        paths = generate_all_question_yamls(force=True)
        print(f"✅  Generated {len(paths)} Q YAML files in tools/")
        return 0

    try:
        settings.validate()
    except ValueError as e:
        print(f"\n❌  Config error: {e}\n", file=sys.stderr)
        return 1

    configure_logging()

    try:
        if args.concurrent:
            return await run_concurrent(args.quiet)
        elif args.ecn_id:
            return await run_single(args.ecn_id, args.work_item_id, args.output, args.quiet)
        else:
            print("❌  Provide --ecn-id <ECN> or --concurrent\n", file=sys.stderr)
            return 1
    except KeyboardInterrupt:
        print("\n⏹  Interrupted.\n")
        return 130


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
