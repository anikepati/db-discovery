# Q10 Full Reference — Initiation of Decision Execution

## Question

Is the profile refresh referred to the appropriate group and evidence provided to QA.

## Validation

Human must validate referral and evidence for Profile Refresh actions.

## Check Logic (apply exactly)

If final_recommended_action = 'Profile Refresh':   NEEDS_HUMAN — human must validate referral to appropriate group and confirm evidence. Else: N/A.

## Depends On

Q06, Q07

## Output Hint

If Profile Refresh: NEEDS_HUMAN + specify which group to email. Else N/A.

## Requires Human Review

Yes — if condition applies, answer must be NEEDS_HUMAN with HUMAN_ACTION specified.

## DB Fields

- `final_recommended_action`
- `recommended_action`

## Authorization Grid (relevant for Q2, Q3, Q5, Q8)

See `skills/edr-ingest/references/schema.md` for the full authorization grid
mapping EDR type + brokerage type → authorized recommending groups.
