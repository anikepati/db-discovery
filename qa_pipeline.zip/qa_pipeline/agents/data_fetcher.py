"""
QA Pipeline - Data Fetcher Agent
Step 0: Fetches and validates all QA process data before the reasoning chain begins.
"""

import logging

from google.adk.agents import LlmAgent

from config.settings import agent_config
from tools.fetch_tools import fetch_qa_process_data_tool, validate_process_exists_tool
from tools.state_tools import QA_DATA_KEY

logger = logging.getLogger(__name__)

DATA_FETCHER_INSTRUCTION = """
You are the QA Pipeline Data Fetcher Agent. Your sole responsibility is to retrieve 
complete QA process data for a given Process ID and make it available for downstream analysis.

## Your Task

1. Extract the process_id from the user's message or session state key 'process_id'
2. First call validate_process_exists to confirm the process ID is valid
3. If valid, call fetch_qa_process_data to retrieve the full dataset
4. Report what was fetched in a brief structured summary

## On Success

Confirm the fetch was successful and provide a brief data summary:
- Process Name and Business Unit
- Current Status and Environment  
- Key risk indicators (compliance score, risk level, open findings)

## On Failure

If the process ID is not found or data fetch fails:
- Report the error clearly
- Do NOT proceed — state that the QA pipeline cannot continue
- Suggest valid Process IDs if available from the validation error

## Output Format

Start your response with either:
  ✅ DATA FETCH SUCCESS: [Process Name] ([Process ID])
or:
  ❌ DATA FETCH FAILED: [reason]

Then provide the brief summary.

## Important

- You MUST call the tools — do not fabricate or assume data
- Store results in session state via output_key (handled automatically)
- Be concise — downstream agents will do the deep analysis
"""


def create_data_fetcher_agent() -> LlmAgent:
    """Create and return the data fetcher agent."""
    return LlmAgent(
        name="DataFetcherAgent",
        model=agent_config.model,
        instruction=DATA_FETCHER_INSTRUCTION,
        tools=[validate_process_exists_tool, fetch_qa_process_data_tool],
        output_key=QA_DATA_KEY,
        description=(
            "Fetches and validates QA process data by Process ID. "
            "Must run before any question agents."
        ),
    )
