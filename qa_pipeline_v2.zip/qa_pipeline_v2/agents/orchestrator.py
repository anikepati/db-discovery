"""
Pipeline orchestrator.

Assembles all agents into a single SequentialAgent that ADK runs in order:
  DataFetcherAgent → QuestionAgent_01 … QuestionAgent_10 → VerdictSynthesizerAgent
"""

import logging

from google.adk.agents import SequentialAgent

from agents.data_fetcher import create_data_fetcher_agent
from agents.question_agents import create_all_question_agents
from agents.verdict_synthesizer import create_verdict_synthesizer_agent

logger = logging.getLogger(__name__)


def create_pipeline() -> SequentialAgent:
    """Build and return the complete QA pipeline."""
    sub_agents = [
        create_data_fetcher_agent(),
        *create_all_question_agents(),
        create_verdict_synthesizer_agent(),
    ]

    pipeline = SequentialAgent(
        name="QAPipeline",
        sub_agents=sub_agents,
        description=(
            "End-to-end QA evaluation pipeline: fetches process data, "
            "runs 10 sequential reasoning questions, produces a structured verdict."
        ),
    )

    logger.info(
        "Pipeline assembled with %d agents: %s",
        len(sub_agents),
        [a.name for a in sub_agents],
    )
    return pipeline
