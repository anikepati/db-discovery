"""
Excel Reader — loads Excel into row-by-row dicts for the evaluator.
"""

import logging
from pathlib import Path
from typing import Dict, Generator, List, Any

import pandas as pd

logger = logging.getLogger(__name__)


def read_excel(
    file_path: str,
    sheet_name: str = "Sheet1",
    chunk_size: int = 1000,
) -> Generator[List[Dict[str, Any]], None, None]:
    """Read Excel file and yield chunks of row dicts."""
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(f"Excel file not found: {file_path}")

    logger.info(f"Reading Excel: {file_path} | Sheet: {sheet_name}")
    df = pd.read_excel(file_path, sheet_name=sheet_name)
    logger.info(f"Loaded {len(df)} rows, {len(df.columns)} columns")

    for start in range(0, len(df), chunk_size):
        chunk = df.iloc[start : start + chunk_size]
        rows = chunk.to_dict(orient="records")
        yield rows


def validate_columns(
    file_path: str,
    sheet_name: str,
    required_columns: List[str],
) -> List[str]:
    """Check that all required columns exist. Return missing ones."""
    df = pd.read_excel(file_path, sheet_name=sheet_name, nrows=0)
    actual = set(df.columns)
    return [c for c in required_columns if c not in actual]
