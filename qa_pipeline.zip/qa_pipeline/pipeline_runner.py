"""
QA Pipeline - Pipeline Runner
Core execution engine with retry logic, event streaming, and result collection.
"""

import asyncio
import json
import logging
import time
from datetime import datetime
from typing import AsyncIterator, Optional
from uuid import uuid4

from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types

from agents.orchestrator import create_qa_pipeline
from agents.questions import QUESTION_MAP
from config.settings import app_config, agent_config
from models import (
    QAPipelineResult,
    QAVerdict,
    QuestionAnswer,
    Severity,
)
from tools.state_tools import (
    QA_DATA_KEY,
    make_answer_key,
    extract_answer_section,
)

logger = logging.getLogger(__name__)


class QAPipelineRunner:
    """
    Production-grade runner for the QA pipeline.

    Handles session management, execution, retry logic,
    event streaming, and result extraction.
    """

    def __init__(self) -> None:
        self.app_name = app_config.app_name
        self.session_service = InMemorySessionService()
        self.pipeline = create_qa_pipeline()
        self._runner: Optional[Runner] = None

    def _get_runner(self) -> Runner:
        if self._runner is None:
            self._runner = Runner(
                agent=self.pipeline,
                app_name=self.app_name,
                session_service=self.session_service,
            )
        return self._runner

    async def _create_session(
        self,
        user_id: str,
        process_id: str,
    ) -> object:
        """Create a new session pre-seeded with the process ID."""
        session = await self.session_service.create_session(
            app_name=self.app_name,
            user_id=user_id,
            state={
                "process_id": process_id,
                "pipeline_started_at": datetime.utcnow().isoformat(),
                "pipeline_version": "1.0.0",
            },
        )
        logger.info(
            f"Session created",
            extra={"process_id": process_id, "session_id": session.id},
        )
        return session

    async def run(
        self,
        process_id: str,
        user_id: Optional[str] = None,
        verbose: bool = True,
    ) -> QAPipelineResult:
        """
        Run the full QA pipeline for a given Process ID.

        Args:
            process_id: The business process ID to evaluate.
            user_id: Optional user identifier (defaults to generated UUID).
            verbose: If True, print progress to stdout.

        Returns:
            QAPipelineResult with all answers and final verdict.

        Raises:
            RuntimeError: If the pipeline fails after all retries.
        """
        user_id = user_id or f"user_{uuid4().hex[:8]}"
        started_at = datetime.utcnow()
        start_time = time.time()

        if verbose:
            print(f"\n{'='*65}")
            print(f"  QA PIPELINE STARTING")
            print(f"  Process ID : {process_id}")
            print(f"  User ID    : {user_id}")
            print(f"  Started At : {started_at.strftime('%Y-%m-%d %H:%M:%S UTC')}")
            print(f"{'='*65}\n")

        # Create session
        session = await self._create_session(user_id, process_id)
        runner = self._get_runner()

        # Build the trigger message
        trigger_message = types.Content(
            role="user",
            parts=[
                types.Part(
                    text=(
                        f"Run the complete QA evaluation pipeline for Process ID: {process_id}. "
                        f"Fetch all required data and answer all 10 QA questions in sequence. "
                        f"Provide thorough analysis for each question."
                    )
                )
            ],
        )

        # Execute pipeline with retry
        last_error: Optional[Exception] = None
        for attempt in range(1, agent_config.max_retries + 1):
            try:
                await self._execute_pipeline(
                    runner=runner,
                    user_id=user_id,
                    session_id=session.id,
                    message=trigger_message,
                    process_id=process_id,
                    verbose=verbose,
                    attempt=attempt,
                )
                break  # Success

            except Exception as e:
                last_error = e
                logger.error(
                    f"Pipeline attempt {attempt}/{agent_config.max_retries} failed: {e}",
                    extra={"process_id": process_id, "session_id": session.id},
                    exc_info=True,
                )
                if attempt < agent_config.max_retries:
                    wait = agent_config.retry_delay * attempt
                    logger.info(f"Retrying in {wait:.1f}s...")
                    await asyncio.sleep(wait)
                else:
                    raise RuntimeError(
                        f"QA Pipeline failed after {agent_config.max_retries} attempts: {last_error}"
                    ) from last_error

        # Collect results from session state
        final_session = await self.session_service.get_session(
            app_name=self.app_name,
            user_id=user_id,
            session_id=session.id,
        )

        result = self._build_result(
            process_id=process_id,
            session_id=session.id,
            state=final_session.state,
            started_at=started_at,
            elapsed=time.time() - start_time,
        )

        if verbose:
            self._print_result_summary(result)

        return result

    async def _execute_pipeline(
        self,
        runner: Runner,
        user_id: str,
        session_id: str,
        message: types.Content,
        process_id: str,
        verbose: bool,
        attempt: int,
    ) -> None:
        """Stream pipeline events and log progress."""
        if attempt > 1 and verbose:
            print(f"\n⟳ Retry attempt {attempt}/{agent_config.max_retries}\n")

        current_agent = None
        event_count = 0

        async for event in runner.run_async(
            user_id=user_id,
            session_id=session_id,
            new_message=message,
        ):
            event_count += 1

            # Track agent changes
            if event.author and event.author != current_agent:
                current_agent = event.author
                if verbose:
                    agent_label = self._format_agent_label(current_agent)
                    print(f"\n{'─'*65}")
                    print(f"  {agent_label}")
                    print(f"{'─'*65}")
                logger.info(
                    f"Agent started: {current_agent}",
                    extra={"process_id": process_id, "agent_name": current_agent},
                )

            # Log tool calls
            if event.get_function_calls():
                for call in event.get_function_calls():
                    if verbose:
                        args_preview = str(call.args)[:80]
                        print(f"  🔧 Tool: {call.name}({args_preview})")
                    logger.debug(
                        f"Tool call: {call.name}",
                        extra={"process_id": process_id, "agent_name": current_agent},
                    )

            # Print final agent responses
            if event.is_final_response() and event.content:
                for part in event.content.parts:
                    if hasattr(part, "text") and part.text:
                        if verbose:
                            # Truncate long outputs for readability
                            text = part.text.strip()
                            preview = text[:1200] + "..." if len(text) > 1200 else text
                            print(f"\n{preview}\n")
                        logger.info(
                            f"Agent completed: {current_agent}",
                            extra={"process_id": process_id, "agent_name": current_agent},
                        )

        logger.info(
            f"Pipeline execution complete. Total events: {event_count}",
            extra={"process_id": process_id},
        )

    def _format_agent_label(self, agent_name: str) -> str:
        """Format agent name for display."""
        labels = {
            "DataFetcherAgent": "📥  STEP 0: Data Fetcher",
            "VerdictSynthesizerAgent": "⚖️   FINAL: Verdict Synthesizer",
        }
        if agent_name in labels:
            return labels[agent_name]
        # Question agents
        if agent_name.startswith("QuestionAgent_"):
            try:
                num = int(agent_name.split("_")[1])
                q_def = QUESTION_MAP.get(num)
                title = q_def.title if q_def else f"Question {num}"
                return f"🔍  Q{num:02d}: {title}"
            except (IndexError, ValueError):
                pass
        return f"▶  {agent_name}"

    def _build_result(
        self,
        process_id: str,
        session_id: str,
        state: dict,
        started_at: datetime,
        elapsed: float,
    ) -> QAPipelineResult:
        """Extract all answers and verdict from session state."""

        # Collect all question answers
        answers: list[QuestionAnswer] = []
        for q_def in sorted(QUESTION_MAP.values(), key=lambda x: x.number):
            key = make_answer_key(q_def.number)
            raw_answer = state.get(key, "")
            parsed = extract_answer_section(raw_answer)
            answers.append(
                QuestionAnswer(
                    question_number=q_def.number,
                    question_text=q_def.question,
                    reasoning=parsed["reasoning"],
                    answer=parsed["answer"],
                    confidence=0.85,  # Could be extracted from LLM response
                    depends_on=q_def.depends_on,
                    agent_name=f"QuestionAgent_{q_def.number:02d}",
                )
            )

        # Parse the final verdict JSON
        verdict_json_str = state.get("final_verdict_json", "{}")
        verdict_data: dict = {}
        try:
            # Strip markdown code fences if present
            clean = verdict_json_str.strip()
            if clean.startswith("```"):
                clean = clean.split("```")[1]
                if clean.startswith("json"):
                    clean = clean[4:]
            verdict_data = json.loads(clean.strip())
        except (json.JSONDecodeError, AttributeError) as e:
            logger.warning(f"Could not parse verdict JSON: {e}. Raw: {verdict_json_str[:200]}")

        # Map verdict string to enum
        verdict_str = verdict_data.get("verdict", "INCONCLUSIVE").upper().replace(" ", "_")
        try:
            verdict = QAVerdict(verdict_str.lower())
        except ValueError:
            verdict = QAVerdict.INCONCLUSIVE

        blocking = [
            item.get("issue", str(item))
            for item in verdict_data.get("blocking_issues", [])
        ]
        recommendations = [
            f"[{item.get('priority', 'P2')}] {item.get('action', str(item))}"
            for item in verdict_data.get("remediation_actions", [])
        ]
        next_steps = verdict_data.get("next_steps", [])
        executive_summary = verdict_data.get("executive_summary", "See individual answers for details.")
        overall_score = float(verdict_data.get("overall_score", 0.0))

        result = QAPipelineResult(
            process_id=process_id,
            session_id=session_id,
            answers=answers,
            verdict=verdict,
            verdict_reasoning=executive_summary,
            overall_score=overall_score,
            critical_issues=blocking,
            recommendations=recommendations,
            next_steps=next_steps,
            started_at=started_at,
            total_duration_seconds=elapsed,
        )

        logger.info(
            f"Pipeline result built: {result.summary()}",
            extra={"process_id": process_id, "session_id": session_id},
        )

        return result

    def _print_result_summary(self, result: QAPipelineResult) -> None:
        """Print a final summary to stdout."""
        verdict_icons = {
            QAVerdict.PASS: "✅",
            QAVerdict.CONDITIONAL_PASS: "⚠️ ",
            QAVerdict.FAIL: "❌",
            QAVerdict.REQUIRES_ESCALATION: "🚨",
            QAVerdict.INCONCLUSIVE: "❓",
        }
        icon = verdict_icons.get(result.verdict, "❓")

        print(f"\n{'='*65}")
        print(f"  {icon}  FINAL QA VERDICT: {result.verdict.value.upper()}")
        print(f"  Score        : {result.overall_score:.1f} / 100")
        print(f"  Process ID   : {result.process_id}")
        print(f"  Session ID   : {result.session_id}")
        print(f"  Duration     : {result.total_duration_seconds:.1f}s")
        print(f"{'='*65}")

        print(f"\n📋 Executive Summary:")
        print(f"   {result.verdict_reasoning}\n")

        if result.critical_issues:
            print(f"🚫 Blocking Issues ({len(result.critical_issues)}):")
            for issue in result.critical_issues:
                print(f"   • {issue}")
            print()

        if result.recommendations:
            print(f"🔧 Top Remediation Actions:")
            for rec in result.recommendations[:5]:
                print(f"   • {rec}")
            print()

        if result.next_steps:
            print(f"➡️  Next Steps:")
            for i, step in enumerate(result.next_steps, 1):
                print(f"   {i}. {step}")
        print()
