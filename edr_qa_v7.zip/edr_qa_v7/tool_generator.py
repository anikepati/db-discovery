"""
tool_generator.py
-----------------
Generates tools/edr_q{N:02d}_tools.yaml for all 15 Q agents.

Default: empty functions list — Q agents reason from conversation history,
no tools needed. SequentialAgent passes all prior outputs automatically.

Per-question tools (optional):
  If a Q agent needs extra data (e.g. Q11 needs to verify RRO number
  exists in a separate table), add a sql or python tool to its section
  in Q_EXTRA_TOOLS below. It will be included in that agent's YAML.
  Zero code changes — only configuration.

Example of adding a tool to Q11:

  Q_EXTRA_TOOLS = {
      11: [
          {
              "id":          "verify_rro_number",
              "description": "Check if RRO number exists in rro_requests table",
              "type":        "sql",
              "inputs": {
                  "rro_number": {"type": "string", "required": True}
              },
              "config": {
                  "connection": "{{ secrets.MSSQL_CONN }}",
                  "query": "SELECT COUNT(*) as found FROM rro_requests WHERE rro_number = :rro",
                  "params": {"rro": "{{ inputs.rro_number }}"},
              },
          }
      ]
  }
"""

from pathlib import Path
import yaml

from questions import EDR_QUESTIONS

TOOLS_DIR = Path("tools")

# ── Per-question extra tools ──────────────────────────────────────────────────
# Add sql/python tool dicts here keyed by question number.
# Empty by default — Q agents use conversation history only.
Q_EXTRA_TOOLS: dict[int, list[dict]] = {
    # Example — uncomment and adapt as needed:
    # 11: [
    #     {
    #         "id":          "verify_rro",
    #         "description": "Verify RRO number exists in Actimize",
    #         "type":        "sql",
    #         "inputs": {"rro_number": {"type": "string", "required": True}},
    #         "config": {
    #             "connection": "{{ secrets.MSSQL_CONN }}",
    #             "query": "SELECT COUNT(*) as found FROM rro_requests WHERE rro_number = :rro",
    #             "params": {"rro": "{{ inputs.rro_number }}"},
    #         },
    #     }
    # ],
}


def _build_question_yaml(q_number: int) -> dict:
    """
    Build the YAML dict for one Q agent.
    Starts with empty functions list.
    Any extra tools from Q_EXTRA_TOOLS are appended.
    """
    extra = Q_EXTRA_TOOLS.get(q_number, [])
    return {"functions": list(extra)}  # copy so mutations don't affect source


def generate_all_question_yamls(
    tools_dir: str | Path = TOOLS_DIR,
    force:     bool = False,
) -> list[str]:
    """
    Generate tools/edr_q01_tools.yaml through tools/edr_q15_tools.yaml.

    Args:
        tools_dir: Target directory.
        force:     Overwrite existing files if True.

    Returns:
        List of file paths (generated or pre-existing).
    """
    tools_dir = Path(tools_dir)
    tools_dir.mkdir(parents=True, exist_ok=True)
    generated = []

    for q in EDR_QUESTIONS:
        filename = tools_dir / f"edr_q{q.number:02d}_tools.yaml"

        if filename.exists() and not force:
            generated.append(str(filename))
            continue

        doc = _build_question_yaml(q.number)
        extra_count = len(Q_EXTRA_TOOLS.get(q.number, []))

        with open(filename, "w", encoding="utf-8") as fh:
            fh.write(
                f"# AUTO-GENERATED — DO NOT EDIT MANUALLY\n"
                f"# Source    : questions.py Q{q.number}\n"
                f"# Category  : {q.category}\n"
                f"# Depends on: {list(q.depends_on)}\n"
                f"# Requires human: {q.requires_human}\n"
                f"# Extra tools: {extra_count} "
                f"(add to Q_EXTRA_TOOLS in tool_generator.py)\n"
                f"# Reasoning: native LlmAgent (Claude claude-sonnet-4-6) from conversation history\n\n"
            )
            yaml.dump(doc, fh, default_flow_style=False,
                      allow_unicode=True, sort_keys=False)

        generated.append(str(filename))

    return generated


if __name__ == "__main__":
    paths = generate_all_question_yamls(force=True)
    print(f"Generated {len(paths)} question YAML files:")
    for p in paths:
        n = int(Path(p).stem.split("_q")[1].split("_")[0])
        extra = len(Q_EXTRA_TOOLS.get(n, []))
        tag = f" [{extra} extra tools]" if extra else " [no tools — conversation only]"
        print(f"  {p}{tag}")
