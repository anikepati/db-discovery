"""
AgentForge Meta-Agent System
============================
Takes Excel or Markdown as input.
Runs 7 agents that plan, discover, generate, validate, and write
a complete ADK SequentialAgent pipeline.

Usage:
    python main.py --input process.xlsx --name edr_qa
    python main.py --input process.md   --name rro_qa --out ./pipelines/
    python main.py --input process.xlsx --name edr_qa --db-conn ${MSSQL_CONN}
    python main.py --input process.xlsx --name edr_qa --dry-run

What the 7 agents do:
    1. IntentAgent          → reads doc, produces IntentSpec
    2. DatabaseDiscovery    → probes DB or infers schema from question text
    3. PlannerAgent         → builds AgentPlan with full dependency graph
    4. GeneratorAgent       → writes ALL pipeline files as code strings
    5. ValidatorAgent       → validates syntax, structure, schema coverage
       [loop 4↔5 up to 3x on failure]
    6. MockDataAgent        → generates mock records that exercise check logic
    7. WriterAgent          → writes files to disk, runs mock test, reports

Output:
    <out>/<name>/
      questions.py, tool_registry.py, tool_generator.py
      tools/ingest_tools.yaml, tools/q01..qN_tools.yaml, tools/report_tools.yaml
      yaml_runtime.py, mcp_factory.py, agents/agent.py
      pipeline_runner.py, main.py, config.py, models.py
      audit/audit_writer.py
      mock/mock_data.json, mock/mock_runner.py
      tests/test_pipeline.py
      .env.example, requirements.txt, pytest.ini
"""

import argparse
import asyncio
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from agents.pipeline import run_meta_pipeline


def _load_document(path: str) -> str:
    """Load Excel or Markdown into text for the meta pipeline."""
    p = Path(path)
    if p.suffix.lower() in (".xlsx", ".xls"):
        return _load_excel(str(p))
    return p.read_text(encoding="utf-8", errors="replace")


def _load_excel(path: str) -> str:
    try:
        import openpyxl
    except ImportError:
        print("Install openpyxl: pip install openpyxl", file=sys.stderr)
        sys.exit(1)

    wb   = openpyxl.load_workbook(path, data_only=True)
    parts = []
    for sheet_name in wb.sheetnames:
        ws   = wb[sheet_name]
        rows = list(ws.iter_rows(values_only=True))
        if not rows:
            continue
        cleaned = []
        for row in rows:
            r = [str(c).strip() if c is not None else "" for c in row]
            if any(r):
                cleaned.append(r)
        if not cleaned:
            continue
        parts.append(f"\n=== SHEET: {sheet_name} ===")
        parts.append("COLUMNS: " + " | ".join(c for c in cleaned[0] if c))
        for row in cleaned[1:]:
            pairs = [f"{cleaned[0][i]}: {v}" for i, v in enumerate(row)
                     if i < len(cleaned[0]) and cleaned[0][i] and v]
            if pairs:
                parts.append("ROW: " + " | ".join(pairs))
    return "\n".join(parts)


def _args():
    p = argparse.ArgumentParser(
        description="AgentForge — Excel/Markdown → ADK pipeline via 7-agent meta-system"
    )
    p.add_argument("--input",    required=True,  help="Excel (.xlsx) or Markdown (.md) process document")
    p.add_argument("--name",     required=True,  help="Pipeline name e.g. edr_qa, rro_qa, case_review")
    p.add_argument("--out",      default="./pipelines", help="Output base directory (default: ./pipelines)")
    p.add_argument("--db-conn",  default=None,   help="Optional DB connection string for live schema discovery")
    p.add_argument("--dry-run",  action="store_true", help="Show IntentSpec + AgentPlan only — don't write files")
    p.add_argument("--quiet",    action="store_true", help="Suppress per-agent output")
    p.add_argument("--run-id",   default=None,   help="Custom run ID for audit trail")
    return p.parse_args()


async def main():
    args = _args()

    # Validate API keys
    for key in ["ANTHROPIC_API_KEY", "GOOGLE_API_KEY"]:
        if not os.environ.get(key):
            print(f"ERROR: {key} not set in environment", file=sys.stderr)
            sys.exit(1)

    # Load the input document
    input_path = Path(args.input)
    if not input_path.exists():
        print(f"ERROR: Input file not found: {input_path}", file=sys.stderr)
        sys.exit(1)

    print(f"\nLoading {input_path}...")
    document_text = _load_document(str(input_path))
    print(f"Loaded: {len(document_text):,} characters")

    # Set DB connection for discovery if provided
    db_yaml = None
    if args.db_conn:
        os.environ["TARGET_DB_CONN"] = args.db_conn
        db_yaml = str(Path(__file__).parent / "tools" / "discovery_tools.yaml")
        print(f"DB discovery: enabled ({args.db_conn[:40]}...)")
    else:
        print("DB discovery: schema inference mode (no live DB)")

    if args.dry_run:
        document_text = "[DRY RUN — show plan only]\n\n" + document_text

    # Run the 7-agent meta pipeline
    manifest = await run_meta_pipeline(
        document_text=document_text,
        pipeline_name=args.name,
        output_dir=args.out,
        db_yaml_path=db_yaml,
        run_id=args.run_id,
        verbose=not args.quiet,
    )

    # Print results
    print(f"\n{'='*62}")
    print(f"  AgentForge Complete")
    print(f"{'='*62}")
    if isinstance(manifest, dict):
        print(f"  Pipeline : {manifest.get('pipeline_name', args.name)}")
        print(f"  Output   : {manifest.get('output_directory', args.out + '/' + args.name)}")
        print(f"  Files    : {manifest.get('total_files', '?')}")
        if manifest.get("mock_test_results"):
            print(f"\n  Mock test results:")
            for rec, verdict in manifest["mock_test_results"].items():
                icon = "✅" if "PASS" in verdict else ("👤" if "HUMAN" in verdict else "❌")
                print(f"    {icon}  {rec}: {verdict}")
        if manifest.get("next_steps"):
            print(f"\n  Next steps:")
            for step in manifest["next_steps"]:
                print(f"    {step}")
    print()


if __name__ == "__main__":
    asyncio.run(main())
