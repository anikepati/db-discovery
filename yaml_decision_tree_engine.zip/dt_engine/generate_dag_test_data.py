"""Generate test data for full LAM DAG validation (sections 2-10)."""
import pandas as pd
from pathlib import Path

def generate():
    rows = [
        {"LoanID": "LN-0001", "ChangeInPercentage": "Yes", "PercentageProvided": "Yes",
         "LogicalProgression": "Yes", "FromType": "SPEC", "ToType": "PRESOLD",
         "ConversionType": "SPEC_TO_PRESOLD",
         "ContractPriceProvided": "Yes", "WithinThreshold": "Yes",
         "PlanNameExistsInLAM": "Yes", "AppraisalValueMatched": "Yes",
         "AppraisalAvailable": "Yes", "CustomerBDRHasHardCost": "Yes",
         "CustomerBDRHasContractPrice": "Yes", "LAMCollateralValueBasis": "Standard",
         "HardCostChange": "No", "LotCostChange": "No", "ContractPriceChange": "No",
         "AppraisalValueChange": "No", "BorrowingBaseChange": "No", "AvailabilityAmountChange": "No"},

        {"LoanID": "LN-0002", "ChangeInPercentage": "No", "PercentageProvided": "No",
         "LogicalProgression": "Yes", "FromType": "LOT", "ToType": "SPEC",
         "ConversionType": "LOT_TO_SPEC",
         "ContractPriceProvided": "No", "WithinThreshold": "No",
         "PlanNameExistsInLAM": "Yes", "AppraisalValueMatched": "Yes",
         "AppraisalAvailable": "Yes", "CustomerBDRHasHardCost": "Yes",
         "CustomerBDRHasContractPrice": "No", "LAMCollateralValueBasis": "Standard",
         "HardCostChange": "Yes", "LotCostChange": "No", "ContractPriceChange": "No",
         "AppraisalValueChange": "No", "BorrowingBaseChange": "No", "AvailabilityAmountChange": "No"},

        {"LoanID": "LN-0003", "ChangeInPercentage": "No", "PercentageProvided": "No",
         "LogicalProgression": "No", "FromType": "PRESOLD", "ToType": "LAND",
         "ConversionType": "PRESOLD_TO_LAND",
         "ContractPriceProvided": "No", "WithinThreshold": "No",
         "PlanNameExistsInLAM": "No", "AppraisalValueMatched": "No",
         "AppraisalAvailable": "No", "CustomerBDRHasHardCost": "No",
         "CustomerBDRHasContractPrice": "No", "LAMCollateralValueBasis": "Standard",
         "HardCostChange": "Yes", "LotCostChange": "Yes", "ContractPriceChange": "Yes",
         "AppraisalValueChange": "Yes", "BorrowingBaseChange": "Yes", "AvailabilityAmountChange": "Yes"},

        {"LoanID": "LN-0004", "ChangeInPercentage": "No", "PercentageProvided": "No",
         "LogicalProgression": "Yes", "FromType": "PRESOLD", "ToType": "MODEL",
         "ConversionType": "PRESOLD_TO_MODEL",
         "ContractPriceProvided": "No", "WithinThreshold": "No",
         "PlanNameExistsInLAM": "Yes", "AppraisalValueMatched": "Yes",
         "AppraisalAvailable": "Yes", "CustomerBDRHasHardCost": "No",
         "CustomerBDRHasContractPrice": "No", "LAMCollateralValueBasis": "Custom",
         "HardCostChange": "No", "LotCostChange": "No", "ContractPriceChange": "No",
         "AppraisalValueChange": "No", "BorrowingBaseChange": "No", "AvailabilityAmountChange": "Yes"},

        {"LoanID": "LN-0005", "ChangeInPercentage": "No", "PercentageProvided": "No",
         "LogicalProgression": "Yes", "FromType": "LAND", "ToType": "LUD",
         "ConversionType": "LAND_TO_LUD",
         "ContractPriceProvided": "No", "WithinThreshold": "No",
         "PlanNameExistsInLAM": "Yes", "AppraisalValueMatched": "No",
         "AppraisalAvailable": "Yes", "CustomerBDRHasHardCost": "No",
         "CustomerBDRHasContractPrice": "No", "LAMCollateralValueBasis": "Standard",
         "HardCostChange": "No", "LotCostChange": "Yes", "ContractPriceChange": "No",
         "AppraisalValueChange": "No", "BorrowingBaseChange": "Yes", "AvailabilityAmountChange": "No"},
    ]

    df = pd.DataFrame(rows)
    Path("data").mkdir(exist_ok=True)
    df.to_excel("data/lam_data.xlsx", index=False, sheet_name="Sheet1")
    print(f"✓ Generated {len(df)} rows → data/lam_data.xlsx")
    for _, r in df.iterrows():
        print(f"  {r['LoanID']}: {r['FromType']}→{r['ToType']}")

if __name__ == "__main__":
    generate()
