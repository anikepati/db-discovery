# Customer Portal Onboarding -- Browser Automation

Automated onboarding workflow for the customer self-service portal.
Uses Playwright browser automation to complete the registration and KYC flow.
System: CustomerPortal (https://portal.example.com)

## Login

### Navigate to portal and authenticate
Check Logic: Click Login button at ${APP_BASE_URL}/login.
Fill #username with operator username from env.
Fill #password with operator password from env.
Click button[type=submit].
Wait for #dashboard to load (networkidle).
Take screenshot: screenshots/01_login_done.png

## Customer Registration

### Click New Customer and verify registration form loads
Check Logic: Click [data-testid=new-customer-btn].
Wait for #registration-form.
Assert text in h1: Register New Customer.
Take screenshot: screenshots/02_registration_form.png

### Fill customer basic information
Check Logic: Fill #customer-name with customer_name input.
Fill #email with customer_email input.
Fill #phone with customer_phone input.
Click [data-testid=continue-btn].
Wait for #document-upload section.

### Upload identity document
Check Logic: Click [data-testid=upload-doc-btn].
Wait for .upload-success within 10000ms.
Assert text in .upload-status: Document received.
Take screenshot: screenshots/03_document_uploaded.png

## KYC Verification

### Verify document appears in pending queue
Check Logic: Navigate to /qa/pending.
Assert text in .document-status: Pending Review.
Assert text in .applicant-name matches customer_name.
Take screenshot: screenshots/04_kyc_pending.png

### Submit application for KYC review
Check Logic: Click [data-testid=submit-kyc-btn].
Wait for .modal-confirm.
Click #modal-confirm-btn.
Wait for .confirmation-banner.
Assert text in .confirmation-banner: Application Submitted Successfully.
Take screenshot: screenshots/05_submitted.png
Requires Human: Yes

## Completion

### Capture application reference number
Check Logic: Get text from #application-ref.
Assert value is not empty.
Take screenshot: screenshots/06_reference_captured.png

### Record application in tracking system
Check Logic: Navigate to /tracking/new.
Fill #ref-input with the application reference number captured above.
Click #save-btn.
Assert text in .save-status: Saved.
Take screenshot: screenshots/07_tracking_complete.png
