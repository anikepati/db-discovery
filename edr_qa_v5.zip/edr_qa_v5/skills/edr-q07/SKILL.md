---
name: edr-q07
description: >
  EDR QA Question 7 of 15 (Level 2 Review): Validate the decision rationale is reasonable based on the details of the event description..
  Reads EDR data from context.state, reasons using Claude claude-sonnet-4-6, writes
  answer to context.state["answers"]["q7"]. Use only in EDR QA pipeline.
license: Proprietary
metadata:
  author: edr-qa-team
  version: "5.0"
  pipeline: edr-qa-v5
  question_number: "7"
  category: "Level 2 Review"
  requires_human: "false"
compatibility: Requires ADK ToolContext, Anthropic API, context.state with edr_data populated
allowed-tools: get_edr_data get_prior_answers answer_question store_answer
---

# EDR QA — Question 7: Level 2 Review

**Validate the decision rationale is reasonable based on the details of the event description.**

## Dependencies

Depends on: Q05, Q06

Prior answers for dependent questions MUST be in `context.state["answers"]` before this agent runs.

## Steps

1. Call `get_edr_data()` — reads `context.state["edr_data"]` (populated by IngestAgent)
2. Call `get_prior_answers()` — reads `context.state["answers"]` for dependent Q answers
3. Call `answer_question(question_number=7, edr_data=<step1>, prior_answers=<step2>)`
   - This calls Claude claude-sonnet-4-6 with the check logic and EDR data
   - Returns: `answer`, `reasoning`, `requires_human`, `human_action`
4. Call `store_answer(question_number=7, answer=..., reasoning=..., ...)` 
   - Writes to `context.state["answers"]["q7"]`
5. Respond with exactly:

```
Q07 [Level 2 Review]: <answer>
REASONING: <1-2 sentence summary>
```

## Check Logic

```
If l2_decision = 'Accept': l2_rationale should align to l1_recommended_action. If l2_decision = 'Amend': l2_rationale should explain the amendment reason. If aligned: Y. Else: N.
```

## Validation

Assess if L2 rationale aligns to recommended action and event description.

## Output Format

Confirm l2_rationale aligns with event_description and l1_recommended_action. Answer Y or N.

Valid answers: `Y` | `N` | `N/A` | `NEEDS_HUMAN`

## DB Fields Used

| Column | Notes |
|--------|-------|
| `l2_decision` |
| `l2_rationale` |
| `l1_recommended_action` |
| `event_description` |

## Gotchas

- Always call `get_edr_data()` first — never use stale data from a prior step.
- Always call `get_prior_answers()` before `answer_question` — dependency answers may affect the result.
- Never skip this question even if a dependency answered N or NEEDS_HUMAN.
- Do NOT write to `context.state` directly — use `store_answer` tool only.
- See [references/question.md](references/question.md) for full question text and validation grid.
