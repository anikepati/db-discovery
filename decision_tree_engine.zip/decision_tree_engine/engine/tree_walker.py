"""
Decision Tree Walker — the core orchestrator.

For each row × each tree:
  1. Evaluate the root condition
  2. Dispatch the matching branch action (on_true / on_false)
  3. If the branch has a next_decision, recurse deeper into the tree
  4. Collect full audit trail per row

This is where config meets execution — YAML drives, Python walks.
"""

import logging
from typing import Any, Dict, List

from models.schemas import DecisionNode, ActionBranch
from engine.evaluator import ConditionEvaluator
from engine.action_dispatcher import ActionDispatcher

logger = logging.getLogger(__name__)

RowData = Dict[str, Any]


class DecisionTreeWalker:
    """Walks decision trees against row data."""

    def __init__(
        self,
        evaluator: ConditionEvaluator,
        dispatcher: ActionDispatcher,
        context: dict,
    ):
        self.evaluator = evaluator
        self.dispatcher = dispatcher
        self.context = context

    def walk_all_trees(
        self,
        trees: List[DecisionNode],
        row: RowData,
        row_id: str,
    ) -> List[Dict[str, Any]]:
        """Run all decision trees against a single row."""
        results = []
        for tree in trees:
            result = self.walk_tree(tree, row, row_id)
            results.append(result)
        return results

    def walk_tree(
        self,
        node: DecisionNode,
        row: RowData,
        row_id: str,
        depth: int = 0,
    ) -> Dict[str, Any]:
        """
        Recursively walk a decision tree node.
        Returns a full audit record of the path taken.
        """
        indent = "  " * depth
        logger.info(f"{indent}├─ Evaluating [{node.id}] {node.name}")

        # 1. Evaluate condition
        condition_result = self.evaluator.evaluate(node.condition, row)
        branch_label = "on_true" if condition_result else "on_false"
        branch: ActionBranch = node.on_true if condition_result else node.on_false

        logger.info(f"{indent}│  Result: {condition_result} → {branch_label}")

        # 2. Dispatch action
        action_result = self.dispatcher.dispatch(branch, row, row_id, self.context)

        # 3. Build audit record
        audit = {
            "node_id": node.id,
            "node_name": node.name,
            "condition_result": condition_result,
            "branch_taken": branch_label,
            "action": action_result,
            "children": [],
        }

        # 4. Recurse if there's a next_decision
        if branch.next_decision:
            logger.info(f"{indent}│  → Following next_decision: {branch.next_decision.id}")
            child_result = self.walk_tree(
                node=branch.next_decision,
                row=row,
                row_id=row_id,
                depth=depth + 1,
            )
            audit["children"].append(child_result)

        return audit


def generate_row_report(
    row_id: str,
    tree_results: List[Dict[str, Any]],
) -> Dict[str, Any]:
    """Generate a summary report for a single row."""
    total_nodes = 0
    total_true = 0
    total_false = 0
    errors = []

    def _count(node_result):
        nonlocal total_nodes, total_true, total_false
        total_nodes += 1
        if node_result["condition_result"]:
            total_true += 1
        else:
            total_false += 1
        if node_result["action"].get("status") == "error":
            errors.append(node_result)
        for child in node_result.get("children", []):
            _count(child)

    for tr in tree_results:
        _count(tr)

    return {
        "row_id": row_id,
        "total_nodes_evaluated": total_nodes,
        "true_count": total_true,
        "false_count": total_false,
        "error_count": len(errors),
        "errors": errors,
        "tree_results": tree_results,
    }
