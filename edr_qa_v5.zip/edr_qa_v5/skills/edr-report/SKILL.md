---
name: edr-report
description: >
  Reads all 15 EDR QA answers from context.state, computes the final verdict
  (PASS/FAIL/PASS_WITH_EXCEPTIONS/REQUIRES_HUMAN_REVIEW), writes a structured
  JSON result file, and stores the verdict in context.state["verdict"].
  Use as the final step in the EDR QA pipeline after all 15 Q agents complete.
license: Proprietary
metadata:
  author: edr-qa-team
  version: "5.0"
  pipeline: edr-qa-v5
compatibility: Requires ADK ToolContext, context.state with edr_data and answers populated
allowed-tools: get_all_answers get_edr_data build_report store_verdict
---

# EDR Report Skill

Computes the final QA verdict and writes the structured JSON result.

## Inputs

- `output_path` — Absolute path to write the result JSON file

## Steps

1. Call `get_all_answers()` — reads `context.state["answers"]` (all 15 Q answers)
2. Call `get_edr_data()` — reads `context.state["edr_data"]`
3. Validate: if `answers` has fewer than 15 entries, respond `REPORT FAILED: only <N>/15 answers in state`
4. Call `build_report(answers=<step1>, edr_data=<step2>, output_path=<input>)`
5. Call `store_verdict(verdict=..., overall_pass_rate=..., failed_questions=..., human_review_count=...)`
6. Respond with exactly:

```
REPORT WRITTEN
Path:    <output_path>
Verdict: <verdict>
Pass:    <overall_pass_rate>%
Failed:  <failed_questions or NONE>
Human:   <human_review_count> items requiring action
```

## Verdict Logic

| Condition | Verdict |
|-----------|---------|
| Any answer = N | FAIL |
| Any requires_human = True (and no N) | REQUIRES_HUMAN_REVIEW |
| All Y or N/A, pass_rate = 100% | PASS |
| All Y or N/A, pass_rate < 100% | PASS_WITH_EXCEPTIONS |

FAIL takes priority over REQUIRES_HUMAN_REVIEW.

## Gotchas

- N/A answers are excluded from pass rate denominator (only Y and N count).
- FAIL takes strict priority — even if human review items exist.
- Do not summarise individual answers — the JSON file is the full output.
- See [references/output_template.md](references/output_template.md) for the exact JSON structure.
