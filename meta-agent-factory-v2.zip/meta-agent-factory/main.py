"""
Meta Agent Factory — Main Entry Point

CLI interface for running the factory pipeline.
Usage:
    python -m meta_agent_factory.main --sop ./sops/process.md --refs ./refs/mapping.json --output ./generated/
"""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import sys
from pathlib import Path

from core.pipeline import MetaAgentFactory

logger = logging.getLogger("MAF.Main")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Meta Agent Factory — SOP to ADK Pipeline Generator",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Browser automation SOP
  python main.py --sop ./sops/web_login.md --output ./generated/web_login/

  # Thick client SOP with reference data
  python main.py --sop ./sops/sap_entry.md --refs ./refs/field_map.json ./refs/codes.json --output ./generated/sap_entry/

  # System/API automation
  python main.py --sop ./sops/etl_pipeline.md --config ./configs/custom_config.yaml --output ./generated/etl/

  # Inspect pipeline without running
  python main.py --info
        """,
    )
    parser.add_argument(
        "--sop", type=str, help="Path to SOP markdown file",
    )
    parser.add_argument(
        "--refs", type=str, nargs="*", default=[], help="Paths to JSON reference files",
    )
    parser.add_argument(
        "--output", type=str, default="./generated", help="Output directory (default: ./generated)",
    )
    parser.add_argument(
        "--config", type=str, default="configs/maf_config.yaml", help="Path to config YAML",
    )
    parser.add_argument(
        "--info", action="store_true", help="Print pipeline info and exit",
    )
    parser.add_argument(
        "--dry-run", action="store_true", help="Parse and analyze SOP without generating code",
    )
    parser.add_argument(
        "--verbose", "-v", action="store_true", help="Enable verbose logging",
    )
    return parser.parse_args()


async def run_factory(args: argparse.Namespace) -> int:
    """Execute the factory pipeline."""
    if args.verbose:
        logging.basicConfig(level=logging.DEBUG)

    # ── Initialize Factory ──
    try:
        factory = MetaAgentFactory(config_path=args.config)
    except FileNotFoundError as e:
        logger.error("Config not found: %s", e)
        return 1

    # ── Info Mode ──
    if args.info:
        info = factory.get_pipeline_info()
        print(json.dumps(info, indent=2, default=str))
        return 0

    # ── Validate Inputs ──
    if not args.sop:
        logger.error("--sop is required. Use --help for usage.")
        return 1

    sop_path = Path(args.sop)
    if not sop_path.exists():
        logger.error("SOP file not found: %s", sop_path)
        return 1

    for ref_path in args.refs:
        if not Path(ref_path).exists():
            logger.error("Reference file not found: %s", ref_path)
            return 1

    # ── Run Pipeline ──
    print("=" * 70)
    print("  META AGENT FACTORY")
    print("  SOP → ADK Agent Pipeline Generator")
    print("=" * 70)
    print(f"  SOP:    {args.sop}")
    print(f"  Refs:   {args.refs or 'None'}")
    print(f"  Output: {args.output}")
    print(f"  Config: {args.config}")
    print("=" * 70)

    try:
        result = await factory.run(
            sop_path=args.sop,
            ref_paths=args.refs if args.refs else None,
            output_dir=args.output,
        )

        print("\n" + "=" * 70)
        print("  PIPELINE COMPLETE")
        print("=" * 70)
        print(f"  State Keys: {result.get('session_state_keys', [])}")

        manifest = result.get("manifest", {})
        if manifest:
            m = manifest.get("manifest", {})
            print(f"  Pipeline:   {m.get('pipeline_name', 'N/A')}")
            print(f"  Mode:       {m.get('automation_mode', 'N/A')}")
            print(f"  Files:      {m.get('total_files', 0)}")
            print(f"  Agents:     {m.get('total_agents', 0)}")
            print(f"  Tools:      {m.get('total_tools', 0)}")
            print(f"  Score:      {m.get('validation_score', 'N/A')}")

        print("=" * 70)
        return 0

    except Exception as e:
        logger.exception("Pipeline failed: %s", e)
        return 1


def main():
    args = parse_args()
    exit_code = asyncio.run(run_factory(args))
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
