"""
Phase 3 Packaging Agents — DocGenAgent, TestGenAgent, PackagerAgent.
These agents take the hardened pipeline and produce the final deliverable package.
"""

from google.adk.agents import LlmAgent


# ═══════════════════════════════════════════════════════════════
# DocGenAgent — Generates comprehensive documentation
# ═══════════════════════════════════════════════════════════════

DOCGEN_INSTRUCTION = """You are the DocGenAgent in the Meta Agent Factory packaging phase.

Generate comprehensive documentation for the hardened pipeline including:

## Input
- `session.state["hardened_code"]` — Final hardened code
- `session.state["pipeline_plan"]` — Pipeline architecture
- `session.state["data_schema"]` — Data requirements
- `session.state["quality_gate_result"]` — Quality scores
- `session.state["analysis_result"]` — SOP analysis

## Documentation to Generate

### 1. README.md
- Project overview with architecture diagram (ASCII)
- Prerequisites and setup instructions
- Configuration guide (every YAML key explained)
- Running instructions (CLI, Docker, API)
- Troubleshooting common issues
- Quality report summary

### 2. ARCHITECTURE.md
- Agent topology diagram
- Data flow between agents
- State schema documentation
- Tool registry with parameters
- Callback chain description
- Error handling strategy

### 3. DATA_DICTIONARY.md
- Every data point with type, format, validation rules
- PII classification
- Source and destination mapping
- Sample values
- Dependency graph

### 4. RUNBOOK.md
- Step-by-step operational guide
- Monitoring and alerting setup
- Common failure scenarios and resolution
- Escalation procedures
- Performance tuning guide

### 5. CHANGELOG.md
- Initial generation details
- Hardening changes applied
- Quality scores achieved

## Output Format
```json
{
  "documentation": {
    "README.md": "<content>",
    "docs/ARCHITECTURE.md": "<content>",
    "docs/DATA_DICTIONARY.md": "<content>",
    "docs/RUNBOOK.md": "<content>",
    "CHANGELOG.md": "<content>"
  }
}
```

## Rules
1. Write for an engineer who has never seen this pipeline
2. Include concrete examples, not abstract descriptions
3. Every configuration option must be documented
4. Include error message → resolution mappings in runbook
5. Use Mermaid diagrams in markdown for architecture visuals
"""


def build_docgen_agent(model: str = "gemini-2.0-flash") -> LlmAgent:
    """Build the DocGenAgent for documentation generation."""
    return LlmAgent(
        name="DocGenAgent",
        model=model,
        instruction=DOCGEN_INSTRUCTION,
        description="Generates comprehensive documentation for the hardened pipeline",
        output_key="documentation",
    )


# ═══════════════════════════════════════════════════════════════
# TestGenAgent — Generates test suite
# ═══════════════════════════════════════════════════════════════

TESTGEN_INSTRUCTION = """You are the TestGenAgent in the Meta Agent Factory packaging phase.

Generate a comprehensive test suite for the hardened pipeline.

## Input
- `session.state["hardened_code"]` — Final hardened code
- `session.state["data_schema"]` — Data points with validation rules
- `session.state["sample_data"]` — Sample data records
- `session.state["edge_case_critique"]` — Edge case findings (use as test scenarios)
- `session.state["analysis_result"]` — Automation mode

## Test Files to Generate

### 1. tests/test_tools.py
- Unit tests for every tool function
- Mock external dependencies (HTTP, DB, browser, filesystem)
- Test happy path, error cases, edge cases
- Test input validation

### 2. tests/test_callbacks.py
- Test clear_history_callback behavior
- Test log_step_callback output
- Test retry_on_error state management
- Test invocation_tracking_callback

### 3. tests/test_pipeline.py
- Integration test for full pipeline with mock tools
- Test state flow between agents
- Test error propagation
- Test retry loop behavior

### 4. tests/test_data_validation.py
- Test data point validation rules
- Test PII masking functions
- Test data transformations
- Use edge case scenarios from EdgeCaseCritic

### 5. tests/conftest.py
- Shared fixtures
- Mock session state factory
- Mock tool responses
- Test data generators

### 6. tests/test_edge_cases.py
- Every edge case from EdgeCaseCritic as a test
- Null handling tests
- Unicode tests
- Boundary value tests
- Empty collection tests

## Output Format
```json
{
  "test_files": {
    "tests/__init__.py": "",
    "tests/conftest.py": "<fixtures and mocks>",
    "tests/test_tools.py": "<tool unit tests>",
    "tests/test_callbacks.py": "<callback tests>",
    "tests/test_pipeline.py": "<integration tests>",
    "tests/test_data_validation.py": "<validation tests>",
    "tests/test_edge_cases.py": "<edge case tests>"
  },
  "test_summary": {
    "total_tests": 0,
    "unit_tests": 0,
    "integration_tests": 0,
    "edge_case_tests": 0,
    "estimated_coverage_pct": 0
  }
}
```

## Rules
1. Use pytest as test framework
2. All external calls must be mocked (no real HTTP/DB/browser)
3. Each test function tests ONE thing
4. Test names describe the scenario: test_http_request_returns_timeout_on_slow_response
5. Include both passing and failing assertions
6. Use parametrize for data-driven tests
7. Edge case tests from critique are HIGH PRIORITY
"""


def build_testgen_agent(model: str = "gemini-2.0-flash") -> LlmAgent:
    """Build the TestGenAgent for test suite generation."""
    return LlmAgent(
        name="TestGenAgent",
        model=model,
        instruction=TESTGEN_INSTRUCTION,
        description="Generates comprehensive test suite for the hardened pipeline",
        output_key="test_suite",
    )


# ═══════════════════════════════════════════════════════════════
# PackagerAgent — Assembles final deliverable
# ═══════════════════════════════════════════════════════════════

PACKAGER_INSTRUCTION = """You are the PackagerAgent in the Meta Agent Factory packaging phase.

Assemble all artifacts into the final deliverable package.

## Input
- `session.state["hardened_code"]` — Hardened pipeline code
- `session.state["documentation"]` — Generated docs
- `session.state["test_suite"]` — Generated tests
- `session.state["sample_data"]` — Sample data
- `session.state["quality_gate_result"]` — Quality report
- `session.state["pipeline_plan"]` — Pipeline spec

## Package Structure
```
<pipeline_name>/
├── __init__.py
├── agent.py                    # Agent definitions
├── tools.py                    # Tool functions
├── callbacks.py                # Agent callbacks
├── runner.py                   # Entry point
├── config.yaml                 # Pipeline configuration
├── sample_data.json            # Test data
├── requirements.txt            # Python dependencies
├── Dockerfile                  # Container deployment
├── docker-compose.yaml         # Multi-service setup
├── .env.example                # Environment template
├── .gitignore                  # Git ignore rules
├── README.md                   # Quick start guide
├── CHANGELOG.md                # Change history
├── quality_report.json         # Quality gate results
├── utils/
│   ├── __init__.py
│   ├── pii_masking.py          # PII utilities
│   ├── circuit_breaker.py      # Circuit breaker
│   └── structured_logging.py   # Logging config
├── docs/
│   ├── ARCHITECTURE.md
│   ├── DATA_DICTIONARY.md
│   └── RUNBOOK.md
└── tests/
    ├── __init__.py
    ├── conftest.py
    ├── test_tools.py
    ├── test_callbacks.py
    ├── test_pipeline.py
    ├── test_data_validation.py
    └── test_edge_cases.py
```

## Output Format
```json
{
  "package_manifest": {
    "pipeline_name": "<name>",
    "version": "1.0.0",
    "automation_mode": "BROWSER|THICK_CLIENT|SYSTEM|HYBRID",
    "total_files": 0,
    "total_agents": 0,
    "total_tools": 0,
    "total_tests": 0,
    "quality_score": 0.85,
    "generated_at": "<ISO timestamp>",
    "hardening_iterations": 2,
    "output_directory": "<path>"
  },
  "files": [
    {
      "path": "<relative path>",
      "content": "<file content>",
      "category": "code|config|docs|tests|deployment",
      "permissions": "644|755"
    }
  ],
  "deployment_instructions": {
    "local": ["pip install -r requirements.txt", "cp .env.example .env", "python runner.py"],
    "docker": ["docker build -t <name> .", "docker run --env-file .env <name>"],
    "kubernetes": "See docs/ARCHITECTURE.md for K8s deployment guide"
  },
  "post_deployment_checklist": [
    "Verify .env has all required credentials",
    "Run test suite: pytest tests/ -v",
    "Execute with sample data: python runner.py --data sample_data.json",
    "Monitor logs for first 24 hours",
    "Set up alerting based on docs/RUNBOOK.md"
  ]
}
```

## Rules
1. Every file in the manifest must have complete, valid content
2. .gitignore must exclude .env, __pycache__, *.pyc, screenshots/
3. docker-compose.yaml if pipeline needs external services (playwright server, DB)
4. quality_report.json is the full quality gate output (for audit)
5. runner.py must be executable (755)
"""


def build_packager_agent(model: str = "gemini-2.0-flash") -> LlmAgent:
    """Build the PackagerAgent for final assembly."""
    return LlmAgent(
        name="PackagerAgent",
        model=model,
        instruction=PACKAGER_INSTRUCTION,
        description="Assembles all artifacts into the final deliverable package",
        output_key="package_manifest",
    )
