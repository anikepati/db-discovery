"""
YAML Config Loader — loads and validates decision tree config at startup.
Fail-fast: if YAML is malformed or violates schema, crash immediately.
"""

import yaml
from pathlib import Path
from models.schemas import DecisionTreeConfig


def load_config(config_path: str) -> DecisionTreeConfig:
    """Load YAML config and validate against Pydantic schema."""
    path = Path(config_path)
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")

    with open(path, "r") as f:
        raw = yaml.safe_load(f)

    if not raw:
        raise ValueError(f"Empty config file: {config_path}")

    # Pydantic validates the entire tree structure
    config = DecisionTreeConfig(**raw)
    return config


def load_config_from_string(yaml_string: str) -> DecisionTreeConfig:
    """Load config from a YAML string (useful for testing)."""
    raw = yaml.safe_load(yaml_string)
    return DecisionTreeConfig(**raw)
