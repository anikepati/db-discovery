"""
tool_generator.py
-----------------
Generates tools/rro_q{N:02d}_tools.yaml for all 13 Q agents.

Default: empty functions list — Q agents reason from conversation history.
SequentialAgent passes all prior outputs automatically.

Per-question tools (optional):
  If a Q agent needs extra data (e.g. Q5 needs to verify ECRM active override),
  add a sql or python tool entry to Q_EXTRA_TOOLS below.
  Zero code changes — only configuration.

Example:
  Q_EXTRA_TOOLS = {
      5: [
          {
              "id":          "check_ecrm_active_override",
              "description": "Check if ECN is under active overrides in ECRM",
              "type":        "sql",
              "inputs": {
                  "ecn_id": {"type": "string", "required": True}
              },
              "config": {
                  "connection": "{{ secrets.MSSQL_CONN }}",
                  "query": "SELECT active_flag FROM ecrm_overrides WHERE ecn = :ecn",
                  "params": {"ecn": "{{ inputs.ecn_id }}"},
              },
          }
      ]
  }
"""

from pathlib import Path
import yaml

from rro_questions import RRO_QUESTIONS

TOOLS_DIR = Path("tools")

# ── Per-question extra tools (add here, zero code changes) ────────────────────
Q_EXTRA_TOOLS: dict[int, list[dict]] = {
    # Example — uncomment and adapt:
    # 5: [
    #     {
    #         "id":          "check_ecrm_active_override",
    #         "description": "Verify ECN is active in ECRM RRO tab",
    #         "type":        "sql",
    #         "inputs": {"ecn_id": {"type": "string", "required": True}},
    #         "config": {
    #             "connection": "{{ secrets.MSSQL_CONN }}",
    #             "query": "SELECT active_flag FROM ecrm_overrides WHERE ecn = :ecn",
    #             "params": {"ecn": "{{ inputs.ecn_id }}"},
    #         },
    #     }
    # ],
}


def _build_question_yaml(q_number: int) -> dict:
    extra = Q_EXTRA_TOOLS.get(q_number, [])
    return {"functions": list(extra)}


def generate_all_question_yamls(
    tools_dir: str | Path = TOOLS_DIR,
    force:     bool = False,
) -> list[str]:
    tools_dir = Path(tools_dir)
    tools_dir.mkdir(parents=True, exist_ok=True)
    generated = []

    for q in RRO_QUESTIONS:
        filename = tools_dir / f"rro_q{q.number:02d}_tools.yaml"

        if filename.exists() and not force:
            generated.append(str(filename))
            continue

        doc         = _build_question_yaml(q.number)
        extra_count = len(Q_EXTRA_TOOLS.get(q.number, []))

        with open(filename, "w", encoding="utf-8") as fh:
            fh.write(
                f"# AUTO-GENERATED — DO NOT EDIT MANUALLY\n"
                f"# Source     : rro_questions.py Q{q.number}\n"
                f"# Category   : {q.category}\n"
                f"# RRO Type   : {q.rro_type or 'both'}\n"
                f"# Depends on : {list(q.depends_on)}\n"
                f"# Req. human : {q.requires_human}\n"
                f"# Extra tools: {extra_count} (add in Q_EXTRA_TOOLS)\n"
                f"# Reasoning  : native LlmAgent (Claude claude-sonnet-4-6) "
                f"from conversation history\n\n"
            )
            yaml.dump(doc, fh, default_flow_style=False,
                      allow_unicode=True, sort_keys=False)

        generated.append(str(filename))

    return generated


if __name__ == "__main__":
    paths = generate_all_question_yamls(force=True)
    print(f"Generated {len(paths)} RRO question YAML files:")
    for p in paths:
        n     = int(Path(p).stem.split("_q")[1].split("_")[0])
        extra = len(Q_EXTRA_TOOLS.get(n, []))
        tag   = f" [{extra} extra tools]" if extra else " [conversation only]"
        print(f"  {p}{tag}")
