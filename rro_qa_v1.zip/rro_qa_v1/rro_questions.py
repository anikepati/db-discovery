"""
rro_questions.py
----------------
Source of truth for all RRO QA questions.

Extracted from: RRO_12feb.xlsx (RRO tab)
Applications:   Actimize and ECRM
Applicable to:  CSBB, WIM, CB, CIB, CL

Process:
  1. Business inputs from Shared Drive / SP
  2. In Actimize: search ECN # and Work Item ID → select matching row

Two QA review types covered:
  RRO_ADDED   — RRO Processed Status (Override Addition)
  RRO_REMOVED — RRO Removed Status   (Override Removal)

Questions 1–6  : RRO Added   (Override Application, Review & Approval, Processing)
Questions 7–12 : RRO Removed (Override Removal, Review & Approval, Processing)
Question  13   : Business Exception — applies to both types

Dependency chains:
  Q1 → ()
  Q2 → (1,)
  Q3 → (1, 2)
  Q4 → (1, 2, 3)
  Q5 → (1, 4)
  Q6 → (5,)
  Q7 → ()            ← RRO Removed starts fresh
  Q8 → (7,)
  Q9 → (7, 8)
  Q10 → (7, 8, 9)
  Q11 → (10,)
  Q12 → (10,)
  Q13 → (1,2,3,4,5,6,7,8,9,10,11,12)  ← Business Exception, applies to all N answers
"""

from dataclasses import dataclass, field
from typing import Tuple

RRO_TYPE_ADDED   = "RRO_ADDED"
RRO_TYPE_REMOVED = "RRO_REMOVED"


@dataclass(frozen=True)
class RROQuestion:
    number:         int
    category:       str          # process category from spreadsheet
    question:       str          # question text
    validation:     str          # what to validate (column E)
    check:          str          # how to check (column F/G)
    notes:          str = ""     # notes / positive + negative scenarios
    depends_on:     Tuple[int, ...] = field(default_factory=tuple)
    requires_human: bool = False  # True = NEEDS_HUMAN if condition applies
    rro_type:       str = ""     # RRO_ADDED | RRO_REMOVED | "" (both)


# ─────────────────────────────────────────────────────────────────────────────
# RRO ADDED — Override Application, Review & Approval, Processing (Q1–Q6)
# ─────────────────────────────────────────────────────────────────────────────

RRO_QUESTIONS: list[RROQuestion] = [

    RROQuestion(
        number=1,
        category="Override Application - Addition",
        rro_type=RRO_TYPE_ADDED,
        question=(
            "Validate if the submitted record contains all the required fields."
        ),
        validation=(
            "Check if all the fields are populated in Actimize by clicking on "
            "QA View under Work Item ID for the given ECN / Sample Id."
        ),
        check=(
            "Are the below fields on Actimize populated:\n"
            "  1. Status\n"
            "  2. ECN\n"
            "  3. Submitting group\n"
            "  4. RRO type\n"
            "  5. RRO sub-type\n"
            "  6. Discretionary rationale\n"
            "  7. RR override value\n"
            "  8. Customer legal name\n"
            "  9. WCS id\n\n"
            "If all fields are populated → 'Y', otherwise → 'N'."
        ),
        depends_on=(),
    ),

    RROQuestion(
        number=2,
        category="Override Application - Addition",
        rro_type=RRO_TYPE_ADDED,
        question=(
            "Validate if discretionary rationale aligns with RRO sub-type selected."
        ),
        validation=(
            "Provided Discretionary rationale should be in line with the RRO sub-type."
        ),
        check=(
            "To check if the RRO type and RRO sub-type matches.\n"
            "If it matches → 'Y', otherwise → 'N'."
        ),
        depends_on=(1,),
    ),

    RROQuestion(
        number=3,
        category="Override Application - Addition",
        rro_type=RRO_TYPE_ADDED,
        question=(
            "Validate the rationale is reasonable and completed per defined "
            "parameters for all the discretionary overrides."
        ),
        validation=(
            "Discretionary rationale provided should explain the reason for "
            "Risk rating override."
        ),
        check=(
            "To read the content (entered as free text) and check if it makes "
            "sense → Discretionary Rationale.\n"
            "If it makes sense → 'Y', otherwise → 'N'.\n\n"
            "This is a reasoning question — apply judgment to assess whether "
            "the rationale is coherent, specific, and explains the risk rating override."
        ),
        notes=(
            "This is a reasoning agent question. Read the Discretionary Rationale "
            "free-text field and determine if it adequately explains the risk rating "
            "override. Vague or generic explanations should be flagged as 'N'."
        ),
        depends_on=(1, 2),
        requires_human=False,
    ),

    RROQuestion(
        number=4,
        category="Override Review and Approval",
        rro_type=RRO_TYPE_ADDED,
        question=(
            "If shared customer, validate all required DFCL approvals received "
            "before processing."
        ),
        validation=(
            "To check for the DFCL approval — look in the DFCL Details. "
            "Check for approvals for all LOBs."
        ),
        check=(
            "a. If DFCL Details is empty → add N/A to the test script against this ECN.\n"
            "b. If not empty → check the DFCL approval under the DFCL Details section.\n"
            "   The approval should be from primary business and shared business unit only.\n"
            "   These details are on the Actimize screen.\n"
            "c. If aligned → 'Y', otherwise → 'N'."
        ),
        depends_on=(1, 2, 3),
    ),

    RROQuestion(
        number=5,
        category="Override Processing",
        rro_type=RRO_TYPE_ADDED,
        question=(
            "Validate if override is appropriately reflected as Active."
        ),
        validation=(
            "Check if the ECN being reviewed is populated under the Risk Rating "
            "Override tab in the ECRM Tool. Check the event ID and ensure it "
            "aligns to the RRO activity being reviewed. If it shows a different "
            "RRO ID, search by RRO instead of ECN."
        ),
        check=(
            "a. Log into ECRM — search for customer with the ECN (search value — RRO tab).\n"
            "b. If many records, identify with the event ID (work item ID).\n"
            "c. If account ID is under active overrides on the same screen:\n"
            "   → Yes: mark test script as 'Y'\n"
            "   → No: mark as 'N'"
        ),
        notes=(
            "Positive Scenarios:\n"
            "  ECN: 584827531833118, 109112741, 780780000014979\n\n"
            "Negative Scenarios:\n"
            "  ECN: 10825602 — not found in Active overrides\n"
            "  ECN: 30468443 1810711 — No Data found\n"
            "  ECN: 204994411611214 — Different Event ID"
        ),
        depends_on=(1, 4),
    ),

    RROQuestion(
        number=6,
        category="Override Processing",
        rro_type=RRO_TYPE_ADDED,
        question=(
            "If override applied, validate the new risk rating."
        ),
        validation=(
            "Check that the Risk Rating Override aligns to the new risk rating "
            "in the RRO Actimize record."
        ),
        check=(
            "Get the risk rating override value from ECRM and update the test script.\n"
            "The max value is 15.\n"
            "Verify the value in ECRM matches the value in the Actimize RRO record."
        ),
        notes=(
            "Positive Scenarios:\n"
            "  ECN: 584827531833118 — RRO-0000104957\n"
            "  ECN: 109112741\n"
            "  ECN: 780780000014979\n"
            "  ECN: 584827531833118 — RRO-0000104544\n"
            "  ECN: 584827531833118 — RRO-0000104955\n\n"
            "Negative Scenarios:\n"
            "  RR Value in Excel can be altered to manipulate the scenario"
        ),
        depends_on=(5,),
    ),

    # ─────────────────────────────────────────────────────────────────────────
    # RRO REMOVED — Override Removal, Review & Approval, Processing (Q7–Q12)
    # ─────────────────────────────────────────────────────────────────────────

    RROQuestion(
        number=7,
        category="Override Removal",
        rro_type=RRO_TYPE_REMOVED,
        question=(
            "Validate the rationale is reasonable and completed per defined parameters."
        ),
        validation=(
            "Removal rationale provided should explain the reason for risk rating "
            "override removal."
        ),
        check=(
            "To check if the removal reason (entered as free text) is meaningful "
            "and aligns with the RRO sub-type.\n"
            "If it makes sense and aligns → 'Y', otherwise → 'N'."
        ),
        depends_on=(),
    ),

    RROQuestion(
        number=8,
        category="Override Review and Approval",
        rro_type=RRO_TYPE_REMOVED,
        question=(
            "Validate if supervisory review was received and reviewer was a "
            "different person than the submitter."
        ),
        validation=(
            "Check if the supervisory review was received and check if the "
            "reviewer and submitter were different people."
        ),
        check=(
            "1. If the RRO type is Discretionary, Non US Government, or "
            "Jurisdictional Elevated Risk, supervisory approval must be validated.\n"
            "2. Check if review was received.\n"
            "3. Go to View History in Actimize. Check owner change and reviewer name.\n"
            "   Ensure reviewer is NOT the same as submitter.\n"
            "4. Review supervisory comments (e.g. 'duplicate', 'did not process it') "
            "and add this comment to the test script.\n\n"
            "If supervisory review is present and reviewer ≠ submitter → 'Y', otherwise → 'N'."
        ),
        depends_on=(7,),
    ),

    RROQuestion(
        number=9,
        category="Override Review and Approval",
        rro_type=RRO_TYPE_REMOVED,
        question=(
            "If shared customer, validate all required DFCL approvals received "
            "before processing."
        ),
        validation=(
            "Check for DFCL approval — if SharedCustomerFlag is 'Yes' and the "
            "override type is Discretionary, Non-US Government, or Jurisdictional "
            "Elevated Risk, check for approvals from both Primary and Shared Businesses."
        ),
        check=(
            "1. If RRO type is Discretionary, Non-US Government, or Jurisdictional "
            "Elevated Risk → dfcl approval must be validated.\n"
            "2. Check the SharedCustomer field:\n"
            "   - If empty → mark N/A in the test script for that ECN.\n"
            "   - If populated → validate DFCL approvals:\n"
            "     a. Primary business approval\n"
            "     b. Shared / secondary business approval\n\n"
            "If approvals are present and aligned → 'Y'.\n"
            "If not required (SharedCustomerFlag empty or type not in scope) → 'N/A'.\n"
            "If required but missing → 'N'."
        ),
        depends_on=(7, 8),
    ),

    RROQuestion(
        number=10,
        category="Override Processing",
        rro_type=RRO_TYPE_REMOVED,
        question=(
            "Validate if override is appropriately reflected as Inactive on "
            "Customer risk rating."
        ),
        validation=(
            "Check that the RRO has a valid expiration date (i.e. not 12/31/9999) "
            "in the ECRM Tool."
        ),
        check=(
            "a. Log into ECRM — search for the customer using the ECN (RRO tab).\n"
            "b. If multiple records appear, use the Event ID / Work Item ID to "
            "identify the correct record.\n"
            "c. Under the History section, check the Expiry Date:\n"
            "   - If Inactive → mark test script as 'Y'\n"
            "   - If still Active → mark test script as 'N'"
        ),
        depends_on=(7, 8, 9),
    ),

    RROQuestion(
        number=11,
        category="Override Processing",
        rro_type=RRO_TYPE_REMOVED,
        question=(
            "Validate the risk rating has returned to pre-override level after removal."
        ),
        validation=(
            "After the RRO is removed, the customer risk rating in ECRM should "
            "revert to the original pre-override risk rating."
        ),
        check=(
            "Check the customer risk rating in ECRM after the RRO expiry:\n"
            "- If the risk rating has reverted to the pre-override value → 'Y'\n"
            "- If it has not reverted → 'N'\n"
            "- If pre-override value is not available for comparison → 'NEEDS_HUMAN'"
        ),
        depends_on=(10,),
        requires_human=True,
    ),

    RROQuestion(
        number=12,
        category="Override Processing",
        rro_type=RRO_TYPE_REMOVED,
        question=(
            "Validate the RRO record in Actimize reflects the removed/expired status."
        ),
        validation=(
            "The Actimize RRO record status should show as Removed or Expired "
            "once the override removal has been processed."
        ),
        check=(
            "Go to Actimize and locate the RRO record:\n"
            "- If the status shows Removed or Expired → 'Y'\n"
            "- If the status still shows Active → 'N'\n"
            "- If the record cannot be found → 'NEEDS_HUMAN'"
        ),
        depends_on=(10,),
        requires_human=True,
    ),

    # ─────────────────────────────────────────────────────────────────────────
    # BUSINESS EXCEPTION (Q13) — applies to both RRO Added and Removed
    # ─────────────────────────────────────────────────────────────────────────

    RROQuestion(
        number=13,
        category="Business Exception",
        rro_type="",   # applies to both
        question=(
            "Business Exception: If any questions are marked N, initiate "
            "LOB clarification process."
        ),
        validation=(
            "If any of the questions are marked N, send an email to the LOB "
            "for clarification."
        ),
        check=(
            "If any questions are marked 'N':\n"
            "  → Send an email to the LOB for clarification.\n"
            "  → If clarification resolves the issue: update test script to 'Y'.\n"
            "  → If clarification does not resolve the concern: keep as 'N'.\n"
            "  SLA for clarification response: 2 business days.\n\n"
            "Answer 'Y' if no questions are marked N (no exception needed).\n"
            "Answer 'NEEDS_HUMAN' if any questions are N (LOB email required)."
        ),
        depends_on=(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12),
        requires_human=True,
    ),
]

# ── Lookup helpers ────────────────────────────────────────────────────────────

RRO_QUESTION_MAP: dict[int, RROQuestion] = {q.number: q for q in RRO_QUESTIONS}

HUMAN_REVIEW_QUESTION_NUMBERS: set[int] = {
    q.number for q in RRO_QUESTIONS if q.requires_human
}

ADDED_QUESTIONS:   list[RROQuestion] = [q for q in RRO_QUESTIONS if q.rro_type in (RRO_TYPE_ADDED, "")]
REMOVED_QUESTIONS: list[RROQuestion] = [q for q in RRO_QUESTIONS if q.rro_type in (RRO_TYPE_REMOVED, "")]
