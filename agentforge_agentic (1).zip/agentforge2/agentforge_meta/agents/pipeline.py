"""
agentforge_meta/agents/pipeline.py
====================================
AgentForge Meta-Pipeline — a real ADK SequentialAgent where agents
read each other's outputs via conversation history and call real tools.

Pipeline:
  IntentAgent    → reads SOP, emits INTENT_SPEC JSON
  PlannerAgent   → reads INTENT_SPEC, emits AGENT_PLAN JSON
  GeneratorAgent → reads AGENT_PLAN, calls write_file for every pipeline file
  ValidatorAgent → reads files, calls check_python_syntax/check_yaml_syntax
  [Generator + Validator loop via LoopAgent, max 3 iterations]
  MockDataAgent  → reads AGENT_PLAN, writes mock_data.json + mock_runner.py + tests
  WriterAgent    → calls run_pytest + run_mock_test, emits DELIVERY_MANIFEST

All agents are LlmAgents. All communication is via conversation history.
Tools are served via in-memory MCP servers from meta_tools.yaml.
"""

import asyncio
import json
import logging
import re
from contextlib import AsyncExitStack
from pathlib import Path

import yaml as _yaml
from google.adk.agents import LlmAgent, LoopAgent, SequentialAgent
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.adk.tools.mcp_tool.mcp_toolset import MCPToolset
from google.genai import types
from mcp.shared.memory import create_connected_server_and_client_session as create_in_memory_pair

from agentforge_meta.agents.instructions import (
    INTENT_AGENT_INSTRUCTION,
    PLANNER_AGENT_INSTRUCTION,
    GENERATOR_AGENT_INSTRUCTION,
    VALIDATOR_AGENT_INSTRUCTION,
    MOCK_DATA_AGENT_INSTRUCTION,
    WRITER_AGENT_INSTRUCTION,
)
from agentforge_meta.core.mcp_factory import create_mcp_server
from agentforge_meta.core.runtime import MCP_TOOL_TYPES

logger = logging.getLogger(__name__)

FAST_MODEL   = "gemini-2.0-flash"
REASON_MODEL = "claude-sonnet-4-6"

_TOOLS_YAML = str(Path(__file__).parent.parent / "tools" / "meta_tools.yaml")
_APP_NAME   = "agentforge_meta"


async def _build_tool_agent(
    name: str,
    model: str,
    description: str,
    instruction: str,
    stack: AsyncExitStack,
) -> LlmAgent:
    """Build an LlmAgent with tools from meta_tools.yaml."""
    server        = create_mcp_server(_TOOLS_YAML)
    client_session = await stack.enter_async_context(create_in_memory_pair(server))
    mcp_tools      = await stack.enter_async_context(MCPToolset(client_session=client_session))
    return LlmAgent(
        name=name, model=model,
        description=description, instruction=instruction,
        tools=list(mcp_tools),
    )


def _pure_agent(name: str, model: str, description: str, instruction: str) -> LlmAgent:
    """Build an LlmAgent with no tools — reasons purely from conversation."""
    return LlmAgent(
        name=name, model=model,
        description=description, instruction=instruction,
        tools=[],
    )


async def run_agentforge(
    sop_text:     str,
    pipeline_name: str,
    mode:          str,  # "system" or "surface"
    output_dir:    str,
    surface:       str | None = None,
    run_id:        str | None = None,
    verbose:       bool = True,
) -> dict:
    """
    Run the AgentForge meta-pipeline.

    Agents communicate via conversation history (SequentialAgent pattern).
    Tools are called via in-memory MCP servers.
    Generator + Validator loop up to 3 times if validation fails.

    Returns: DELIVERY_MANIFEST dict
    """
    from datetime import datetime
    run_id  = run_id or f"forge_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}"
    out_dir = Path(output_dir) / pipeline_name
    out_dir.mkdir(parents=True, exist_ok=True)

    surface_hint = f"\nsurface: {surface}" if surface else ""
    user_message = (
        f"pipeline_name: {pipeline_name}\n"
        f"mode: {mode}{surface_hint}\n"
        f"output_dir: {out_dir}\n\n"
        f"SOP CONTENT:\n{sop_text}"
    )

    if verbose:
        print(f"\n{'━'*64}")
        print(f"  AgentForge Meta-Pipeline")
        print(f"  pipeline: {pipeline_name}  mode: {mode}  run: {run_id}")
        print(f"  output:   {out_dir}")
        print(f"  agents:   Intent → Planner → [Generator ↔ Validator] → Mock → Writer")
        print(f"{'━'*64}\n")

    async with AsyncExitStack() as stack:

        # ── Agent 1: IntentAgent ──────────────────────────────────────────
        intent_agent = _pure_agent(
            name="intent_agent",
            model=REASON_MODEL,
            description="Reads SOP content, extracts pipeline intent, steps, and metadata.",
            instruction=INTENT_AGENT_INSTRUCTION,
        )

        # ── Agent 2: PlannerAgent ─────────────────────────────────────────
        planner_agent = _pure_agent(
            name="planner_agent",
            model=REASON_MODEL,
            description="Reads IntentSpec, designs complete agent topology and instruction content.",
            instruction=PLANNER_AGENT_INSTRUCTION,
        )

        # ── Agent 3: GeneratorAgent ───────────────────────────────────────
        # Has write_file tool — actually writes files to disk
        generator_agent = await _build_tool_agent(
            name="generator_agent",
            model=REASON_MODEL,
            description="Reads AgentPlan, generates all pipeline files by calling write_file.",
            instruction=GENERATOR_AGENT_INSTRUCTION,
            stack=stack,
        )

        # ── Agent 4: ValidatorAgent ───────────────────────────────────────
        # Has check_python_syntax, check_yaml_syntax, read_file, list_output_files
        validator_agent = await _build_tool_agent(
            name="validator_agent",
            model=REASON_MODEL,
            description="Validates generated files for syntax errors and structural correctness.",
            instruction=VALIDATOR_AGENT_INSTRUCTION,
            stack=stack,
        )

        # Generator + Validator wrapped in LoopAgent
        # If validator emits NEEDS_REGENERATION: true, generator runs again
        # with the fix_request in conversation context. Max 3 iterations.
        gen_val_loop = LoopAgent(
            name="gen_val_loop",
            sub_agents=[generator_agent, validator_agent],
            max_iterations=3,
        )

        # ── Agent 5: MockDataAgent ────────────────────────────────────────
        mock_agent = await _build_tool_agent(
            name="mock_data_agent",
            model=REASON_MODEL,
            description="Generates mock records that exercise check logic, mock_runner.py, and test suite.",
            instruction=MOCK_DATA_AGENT_INSTRUCTION,
            stack=stack,
        )

        # ── Agent 6: WriterAgent ──────────────────────────────────────────
        writer_agent = await _build_tool_agent(
            name="writer_agent",
            model=REASON_MODEL,
            description="Runs pytest and mock tests, emits delivery manifest.",
            instruction=WRITER_AGENT_INSTRUCTION,
            stack=stack,
        )

        # ── Meta-pipeline ─────────────────────────────────────────────────
        meta_pipeline = SequentialAgent(
            name="agentforge_meta_pipeline",
            sub_agents=[
                intent_agent,
                planner_agent,
                gen_val_loop,
                mock_agent,
                writer_agent,
            ],
        )

        svc = InMemorySessionService()
        await svc.create_session(
            app_name=_APP_NAME,
            user_id=run_id,
            session_id=run_id,
        )
        runner = Runner(
            agent=meta_pipeline,
            app_name=_APP_NAME,
            session_service=svc,
        )
        message = types.Content(
            role="user",
            parts=[types.Part(text=user_message)],
        )

        # ── Stream and log ────────────────────────────────────────────────
        _ICONS = {
            "intent_agent":     "🧠",
            "planner_agent":    "📐",
            "generator_agent":  "⚙️ ",
            "validator_agent":  "✅",
            "mock_data_agent":  "🎭",
            "writer_agent":     "✍️ ",
        }

        final_text     = ""
        current_author = None
        all_outputs: dict[str, str] = {}

        async for event in runner.run_async(
            user_id=run_id, session_id=run_id, new_message=message
        ):
            author = getattr(event, "author", None)

            if author and author != current_author:
                if current_author:
                    all_outputs[current_author] = final_text
                current_author = author
                if verbose and author not in ("agentforge_meta_pipeline", "gen_val_loop"):
                    icon = _ICONS.get(author, "▶")
                    print(f"\n  {icon}  {author}")

            if event.get_function_calls() and verbose:
                for call in event.get_function_calls():
                    args_preview = str(call.args)[:100]
                    print(f"       🔧 {call.name}({args_preview})")

            if event.is_final_response() and event.content:
                for part in event.content.parts:
                    if hasattr(part, "text") and part.text:
                        final_text = part.text.strip()
                        if verbose:
                            preview = final_text[:400]
                            print(f"       → {preview}{'…' if len(final_text) > 400 else ''}")

        if current_author:
            all_outputs[current_author] = final_text

        # ── Extract DELIVERY_MANIFEST ─────────────────────────────────────
        manifest = _extract_json_tag(final_text, "DELIVERY_MANIFEST")
        if not manifest:
            # Search all outputs for the manifest
            for text in all_outputs.values():
                manifest = _extract_json_tag(text, "DELIVERY_MANIFEST")
                if manifest:
                    break

        return manifest or {
            "pipeline_name": pipeline_name,
            "output_directory": str(out_dir),
            "status": "completed",
            "note": "Delivery manifest not found in output. Check the output directory.",
        }


def _extract_json_tag(text: str, tag: str) -> dict | None:
    """Extract a tagged JSON block like DELIVERY_MANIFEST: {...}"""
    # Try code fence version first
    m = re.search(rf"{tag}:\s*```(?:json)?\s*(.*?)```", text, re.DOTALL)
    if m:
        try:
            return json.loads(m.group(1))
        except Exception:
            pass
    # Try raw JSON after tag
    idx = text.find(f"{tag}:")
    if idx != -1:
        rest = text[idx + len(tag) + 1:].strip()
        # Find the end of the JSON object
        depth = 0
        for i, ch in enumerate(rest):
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    try:
                        return json.loads(rest[: i + 1])
                    except Exception:
                        break
    return None
