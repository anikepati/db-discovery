# Case Management API Validation -- REST API Automation

Quality assurance pipeline for the Case Management REST API.
Validates case lifecycle: creation, assignment, status updates, and closure.
System: CaseManagement API (https://api.casemanagement.example.com)
Auth: Bearer token via ${CASE_API_TOKEN}

## Authentication

### Obtain API access token
Check Logic: POST to /auth/token with client_id and client_secret from env.
Verify HTTP 200 response.
Verify response contains access_token field.
Store token for subsequent calls.

## Case Retrieval

### Fetch case by case ID
Check Logic: GET /api/v1/cases/{case_id}.
Verify HTTP 200.
Verify response contains: case_id, status, assigned_to, created_at fields.
If HTTP 404: N/A -- case does not exist.
If HTTP 403: NEEDS_HUMAN -- permission denied, check API credentials.
Requires Human: No

### Verify case status is valid
Check Logic: Read status field from the GET /api/v1/cases/{case_id} response above.
Valid statuses are: OPEN, IN_PROGRESS, PENDING_REVIEW, CLOSED.
If status is one of the valid values: Y.
If status is any other value: N -- invalid status detected.
If case was not found (step 2 returned N/A): N/A.

### Check case assignee exists
Check Logic: Read assigned_to field from case response.
GET /api/v1/users/{assigned_to}.
If HTTP 200 and user active=true: Y.
If HTTP 404 or active=false: N -- case assigned to non-existent or inactive user.
If assigned_to is null: N/A -- unassigned case.

## Case Updates

### Validate case notes are retrievable
Check Logic: GET /api/v1/cases/{case_id}/notes.
Verify HTTP 200.
Verify response is a list (may be empty).
If HTTP 200: Y. If any error: N.

### Validate SLA deadline is set
Check Logic: Read sla_deadline field from case response.
If sla_deadline is a valid ISO 8601 datetime: Y.
If sla_deadline is null or invalid: N.
If case is CLOSED: N/A.

## Case History

### Validate audit trail is complete
Check Logic: GET /api/v1/cases/{case_id}/history.
Verify HTTP 200.
Verify first history entry has event_type = CREATED.
If case is IN_PROGRESS or beyond: verify ASSIGNED event exists in history.
If all checks pass: Y. Otherwise: N.
