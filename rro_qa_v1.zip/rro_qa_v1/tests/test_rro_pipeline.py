"""
RRO QA Pipeline v1 — test suite.
Run:   pytest tests/ -v
"""

import json
import sys
import yaml
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))


# ── tool_generator ────────────────────────────────────────────────────────────

class TestToolGenerator:

    def test_generates_13_yaml_files(self, tmp_path):
        from tool_generator import generate_all_question_yamls
        assert len(generate_all_question_yamls(tools_dir=tmp_path, force=True)) == 13

    def test_files_named_correctly(self, tmp_path):
        from tool_generator import generate_all_question_yamls
        generate_all_question_yamls(tools_dir=tmp_path, force=True)
        for n in range(1, 14):
            assert (tmp_path / f"rro_q{n:02d}_tools.yaml").exists()

    def test_default_yamls_have_empty_functions(self, tmp_path):
        from tool_generator import generate_all_question_yamls
        generate_all_question_yamls(tools_dir=tmp_path, force=True)
        for n in range(1, 14):
            with open(tmp_path / f"rro_q{n:02d}_tools.yaml") as f:
                data = yaml.safe_load(f)
            assert data["functions"] == []

    def test_no_edr_state_in_any_yaml(self, tmp_path):
        from tool_generator import generate_all_question_yamls
        generate_all_question_yamls(tools_dir=tmp_path, force=True)
        for n in range(1, 14):
            content = (tmp_path / f"rro_q{n:02d}_tools.yaml").read_text()
            assert "edr_state" not in content

    def test_extra_tools_included(self, tmp_path):
        import tool_generator as tg
        orig = tg.Q_EXTRA_TOOLS.copy()
        try:
            tg.Q_EXTRA_TOOLS[5] = [{
                "id": "check_ecrm", "description": "test", "type": "sql",
                "inputs": {}, "config": {"connection": "sqlite://", "query": "SELECT 1", "params": {}}
            }]
            tg.generate_all_question_yamls(tools_dir=tmp_path, force=True)
            with open(tmp_path / "rro_q05_tools.yaml") as f:
                data = yaml.safe_load(f)
            assert len(data["functions"]) == 1
        finally:
            tg.Q_EXTRA_TOOLS.clear()
            tg.Q_EXTRA_TOOLS.update(orig)


# ── Clean architecture ────────────────────────────────────────────────────────

class TestCleanArchitecture:

    _CORE = [
        "yaml_runtime.py", "mcp_factory.py", "tool_registry.py",
        "tool_generator.py", "agents/agent.py", "pipeline_runner.py", "main.py",
    ]

    def test_no_anthropic_sdk(self):
        for f in self._CORE:
            c = Path(f).read_text()
            assert "import anthropic" not in c
            assert "messages.create"  not in c

    def test_no_edr_state_in_core(self):
        for f in ["yaml_runtime.py", "tool_generator.py", "tool_registry.py"]:
            c = Path(f).read_text()
            # edr_state should not appear as actual code (comments ok)
            for line in c.splitlines():
                stripped = line.strip()
                if stripped.startswith("#"): continue
                assert "edr_state" not in stripped

    def test_sequential_agent_used(self):
        assert "SequentialAgent" in Path("agents/agent.py").read_text()

    def test_no_context_state_in_agent(self):
        c = Path("agents/agent.py").read_text()
        assert "context.state" not in c
        assert "ToolContext"   not in c


# ── rro_questions ─────────────────────────────────────────────────────────────

class TestRROQuestions:

    def test_exactly_13_questions(self):
        from rro_questions import RRO_QUESTIONS
        assert len(RRO_QUESTIONS) == 13

    def test_question_numbers_1_to_13(self):
        from rro_questions import RRO_QUESTIONS
        assert [q.number for q in RRO_QUESTIONS] == list(range(1, 14))

    def test_rro_added_questions(self):
        from rro_questions import RRO_QUESTIONS, RRO_TYPE_ADDED
        added = [q.number for q in RRO_QUESTIONS if q.rro_type == RRO_TYPE_ADDED]
        assert added == [1, 2, 3, 4, 5, 6]

    def test_rro_removed_questions(self):
        from rro_questions import RRO_QUESTIONS, RRO_TYPE_REMOVED
        removed = [q.number for q in RRO_QUESTIONS if q.rro_type == RRO_TYPE_REMOVED]
        assert removed == [7, 8, 9, 10, 11, 12]

    def test_business_exception_q13(self):
        from rro_questions import RRO_QUESTION_MAP
        q = RRO_QUESTION_MAP[13]
        assert q.category == "Business Exception"
        assert q.requires_human is True
        assert len(q.depends_on) == 12  # depends on all prior

    def test_human_review_questions(self):
        from rro_questions import HUMAN_REVIEW_QUESTION_NUMBERS
        assert HUMAN_REVIEW_QUESTION_NUMBERS == {11, 12, 13}

    def test_dependency_chains(self):
        from rro_questions import RRO_QUESTION_MAP
        assert RRO_QUESTION_MAP[1].depends_on  == ()
        assert RRO_QUESTION_MAP[2].depends_on  == (1,)
        assert RRO_QUESTION_MAP[3].depends_on  == (1, 2)
        assert RRO_QUESTION_MAP[4].depends_on  == (1, 2, 3)
        assert RRO_QUESTION_MAP[5].depends_on  == (1, 4)
        assert RRO_QUESTION_MAP[6].depends_on  == (5,)
        assert RRO_QUESTION_MAP[7].depends_on  == ()
        assert RRO_QUESTION_MAP[8].depends_on  == (7,)
        assert RRO_QUESTION_MAP[9].depends_on  == (7, 8)
        assert RRO_QUESTION_MAP[10].depends_on == (7, 8, 9)
        assert RRO_QUESTION_MAP[11].depends_on == (10,)
        assert RRO_QUESTION_MAP[12].depends_on == (10,)

    def test_categories_present(self):
        from rro_questions import RRO_QUESTIONS
        cats = {q.category for q in RRO_QUESTIONS}
        assert "Override Application - Addition" in cats
        assert "Override Review and Approval"    in cats
        assert "Override Processing"             in cats
        assert "Override Removal"                in cats
        assert "Business Exception"              in cats


# ── tool_registry ─────────────────────────────────────────────────────────────

class TestToolRegistry:

    def test_15_entries(self):
        from tool_registry import build_registry
        assert len(build_registry()) == 15

    def test_order(self):
        from tool_registry import build_registry
        reg = build_registry()
        assert reg[0].name  == "rro_ingest_agent"
        assert reg[1].name  == "q01_agent"
        assert reg[13].name == "q13_agent"
        assert reg[14].name == "rro_report_agent"

    def test_q_agents_use_claude(self):
        from tool_registry import build_registry, QA_MODEL
        for cfg in build_registry()[1:14]:
            assert cfg.model == QA_MODEL

    def test_ingest_uses_gemini(self):
        from tool_registry import build_registry, INGEST_MODEL
        assert build_registry()[0].model == INGEST_MODEL

    def test_instructions_contain_question_text(self):
        from tool_registry import build_registry
        from rro_questions import RRO_QUESTION_MAP
        for cfg in build_registry()[1:14]:
            n = int(cfg.name[1:3])
            assert RRO_QUESTION_MAP[n].question[:30] in cfg.instruction

    def test_instructions_mention_conversation(self):
        from tool_registry import build_registry
        for cfg in build_registry()[1:14]:
            assert "conversation" in cfg.instruction.lower()

    def test_human_review_agents_flagged(self):
        from tool_registry import build_registry
        from rro_questions import HUMAN_REVIEW_QUESTION_NUMBERS
        for cfg in build_registry()[1:14]:
            n = int(cfg.name[1:3])
            if n in HUMAN_REVIEW_QUESTION_NUMBERS:
                assert "NEEDS_HUMAN" in cfg.instruction

    def test_q13_depends_on_all_mentioned(self):
        from tool_registry import build_registry
        cfg = build_registry()[13]  # q13
        assert "1, 2, 3" in cfg.instruction or "all" in cfg.instruction.lower()

    def test_report_instruction_mentions_build_rro_report(self):
        from tool_registry import build_registry
        assert "build_rro_report" in build_registry()[-1].instruction


# ── build_rro_report ──────────────────────────────────────────────────────────

class TestBuildRROReport:

    def _run(self, answers, tmp_path):
        with open("tools/rro_report_tools.yaml") as f:
            fn = next(x for x in yaml.safe_load(f)["functions"]
                      if x["id"] == "build_rro_report")
        ns = {
            "inputs": {
                "answers":  answers,
                "rro_data": {"ecn_number": "584827531833118", "rro_number": "RRO-TEST"},
                "output_path": str(tmp_path / "result.json"),
            },
            "result": None,
        }
        exec(compile(fn["python"]["code"], "<t>", "exec"), {
            "__builtins__": __builtins__,
            "os": __import__("os"), "json": __import__("json"),
        }, ns)
        return ns["result"]

    def _a(self, mapping):
        return {
            f"q{n}": {"answer": v, "requires_human": v == "NEEDS_HUMAN",
                      "category": "", "rro_type": ""}
            for n, v in mapping.items()
        }

    def test_all_yes_pass(self, tmp_path):
        r = self._run(self._a({i: "Y" for i in range(1, 14)}), tmp_path)
        assert r["verdict"] == "PASS" and r["overall_pass_rate"] == 100.0

    def test_any_no_fail(self, tmp_path):
        a = self._a({i: "Y" for i in range(1, 14)})
        a["q4"]["answer"] = "N"
        r = self._run(a, tmp_path)
        assert r["verdict"] == "FAIL" and 4 in r["failed_questions"]

    def test_needs_human(self, tmp_path):
        a = self._a({i: "Y" for i in range(1, 14)})
        a["q13"].update({"answer": "NEEDS_HUMAN", "requires_human": True})
        assert self._run(a, tmp_path)["verdict"] == "REQUIRES_HUMAN_REVIEW"

    def test_fail_beats_human(self, tmp_path):
        a = self._a({i: "Y" for i in range(1, 14)})
        a["q3"]["answer"]  = "N"
        a["q13"].update({"answer": "NEEDS_HUMAN", "requires_human": True})
        assert self._run(a, tmp_path)["verdict"] == "FAIL"

    def test_na_excluded_from_rate(self, tmp_path):
        a = self._a({i: "Y" for i in range(1, 10)})
        for i in range(10, 14):
            a[f"q{i}"] = {"answer": "N/A", "requires_human": False}
        assert self._run(a, tmp_path)["overall_pass_rate"] == 100.0

    def test_output_json_written(self, tmp_path):
        self._run(self._a({i: "Y" for i in range(1, 14)}), tmp_path)
        data = json.loads((tmp_path / "result.json").read_text())
        assert len(data["answers"]) == 13
        assert "category_breakdown" in data
        assert data["ecn_number"] == "584827531833118"

    def test_total_questions_is_13(self, tmp_path):
        r = self._run(self._a({i: "Y" for i in range(1, 14)}), tmp_path)
        assert r["total_questions"] == 13


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
