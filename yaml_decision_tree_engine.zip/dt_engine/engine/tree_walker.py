"""
Decision Tree Walker — the core orchestrator.
For each row × each tree: evaluate → dispatch → recurse into children → audit.
"""

import logging
from typing import Any, Dict, List

from models.schemas import DecisionNode, ActionBranch
from engine.evaluator import ConditionEvaluator
from engine.action_dispatcher import ActionDispatcher

logger = logging.getLogger(__name__)

RowData = Dict[str, Any]


class DecisionTreeWalker:
    def __init__(self, evaluator: ConditionEvaluator, dispatcher: ActionDispatcher, context: dict):
        self.evaluator = evaluator
        self.dispatcher = dispatcher
        self.context = context

    def walk_all_trees(self, trees: List[DecisionNode], row: RowData, row_id: str) -> List[Dict]:
        return [self.walk_tree(tree, row, row_id) for tree in trees]

    def walk_tree(self, node: DecisionNode, row: RowData, row_id: str, depth: int = 0) -> Dict:
        indent = "  " * depth
        logger.info(f"{indent}├─ [{node.id}] {node.name}")

        condition_result = self.evaluator.evaluate(node.condition, row)
        branch_label = "on_true" if condition_result else "on_false"
        branch: ActionBranch = node.on_true if condition_result else node.on_false

        logger.info(f"{indent}│  → {condition_result} → {branch_label}")

        action_result = self.dispatcher.dispatch(branch, row, row_id, self.context)

        audit = {
            "node_id": node.id,
            "node_name": node.name,
            "condition_result": condition_result,
            "branch_taken": branch_label,
            "action": action_result,
            "children": [],
        }

        if branch.next_decision:
            logger.info(f"{indent}│  ↓ next: {branch.next_decision.id}")
            child_result = self.walk_tree(branch.next_decision, row, row_id, depth + 1)
            audit["children"].append(child_result)

        return audit


def generate_row_report(row_id: str, tree_results: List[Dict]) -> Dict:
    total_nodes = total_true = total_false = 0
    errors = []

    def _count(node_result):
        nonlocal total_nodes, total_true, total_false
        total_nodes += 1
        if node_result["condition_result"]:
            total_true += 1
        else:
            total_false += 1
        if node_result["action"].get("status") == "error":
            errors.append(node_result)
        for child in node_result.get("children", []):
            _count(child)

    for tr in tree_results:
        _count(tr)

    return {
        "row_id": row_id,
        "total_nodes_evaluated": total_nodes,
        "true_count": total_true,
        "false_count": total_false,
        "error_count": len(errors),
        "errors": errors,
        "tree_results": tree_results,
    }
