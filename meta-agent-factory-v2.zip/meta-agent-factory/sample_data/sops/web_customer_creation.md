# SOP: Customer Account Creation via Web Portal

## Version: 2.1
## Domain: Customer Onboarding
## Last Updated: 2025-06-15

## Prerequisites
- Access to CRM Web Portal (https://crm.company.com)
- Valid admin credentials
- Customer information form (completed)
- Approved credit check reference number

## Procedure

### Step 1: Login to CRM Portal
1. Open browser and navigate to https://crm.company.com/login
2. Enter username in the "Email" field
3. Enter password in the "Password" field
4. Click the "Sign In" button
5. Wait for dashboard to load
6. **Expected**: Dashboard displays with "Welcome, {username}" message

### Step 2: Navigate to Customer Creation
1. Click "Customers" in the left navigation menu
2. Click "New Customer" button in the top-right corner
3. **Expected**: Customer creation form opens

### Step 3: Enter Basic Information
1. Select "Customer Type" from dropdown (Individual / Corporate)
2. Enter "First Name" in the first name field
3. Enter "Last Name" in the last name field
4. Enter "Email Address" in the email field
5. Enter "Phone Number" in the phone field (format: +1-XXX-XXX-XXXX)
6. **Validation**: Email must be unique in the system

### Step 4: Enter Address Information
1. Enter "Street Address" in the address line 1 field
2. Enter "City" in the city field
3. Select "State" from the state dropdown
4. Enter "ZIP Code" in the zip field (format: XXXXX or XXXXX-XXXX)
5. Select "Country" from the country dropdown (default: United States)

### Step 5: Credit Check Reference
1. Enter "Credit Check Reference Number" in the reference field
2. Click "Verify" button next to the reference field
3. Wait for verification to complete (up to 10 seconds)
4. **Expected**: Green checkmark appears if valid
5. **Error Handling**: If verification fails, screenshot the error and escalate to supervisor

### Step 6: Account Settings
1. Select "Account Tier" from dropdown (Bronze / Silver / Gold / Platinum)
2. Enter "Credit Limit" amount (numeric, USD)
3. Select "Billing Cycle" (Monthly / Quarterly / Annual)
4. Check "Email Notifications" checkbox if customer opted in
5. Check "SMS Notifications" checkbox if customer opted in

### Step 7: Review and Submit
1. Click "Review" button at bottom of form
2. Verify all fields are correctly populated on the review screen
3. Click "Submit" button
4. Wait for confirmation page
5. **Expected**: "Customer Created Successfully" message with new Customer ID
6. Copy the Customer ID for records

### Step 8: Post-Creation Verification
1. Navigate to "Customers" > "Search"
2. Search for the newly created customer by email
3. Verify customer record appears with correct information
4. **Expected**: All fields match the input data

## Error Handling
- If login fails after 3 attempts, contact IT support
- If credit check verification times out, retry once then escalate
- If form submission fails, take a screenshot and save all entered data

## Output
- New Customer ID
- Confirmation screenshot
- Audit log entry
