"""
Meta Agent Factory v2 — Enterprise Pipeline Orchestrator

Three-phase architecture:
  Phase 1: Analysis + Generation (existing pipeline)
  Phase 2: Enterprise Hardening Loop (6 critics + refactor + quality gate)
  Phase 3: Packaging + Emission (docs, tests, packager, writer)

14 agents total. Config-first. Zero code changes after deployment.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Optional

from google.adk.agents import SequentialAgent, LoopAgent, ParallelAgent, LlmAgent
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService

# Phase 1 agents
from agents import (
    build_ingest_agent,
    build_analyzer_agent,
    build_datapoint_agent,
    build_planner_agent,
    build_generator_agent,
    build_mockdata_agent,
    build_validator_agent,
)
# Phase 2 agents
from agents.critics import (
    build_security_critic,
    build_resilience_critic,
    build_observability_critic,
    build_performance_critic,
    build_edge_case_critic,
    build_compliance_critic,
)
from agents.refactor_agent import build_refactor_agent
from agents.quality_gate_agent import build_quality_gate_agent
# Phase 3 agents
from agents.packaging_agents import (
    build_docgen_agent,
    build_testgen_agent,
    build_packager_agent,
)
from agents.writer_agent import build_writer_agent

from utils.config_loader import MAFConfig

logger = logging.getLogger("MAF.v2")


class MetaAgentFactoryV2:
    """
    Enterprise Meta-Agent Factory v2.

    Architecture:
    ┌─────────────────────────────────────────────────────────────┐
    │ Phase 1: Analysis + Generation                              │
    │  IngestAgent → AnalyzerAgent → DataPointAgent → PlannerAgent│
    │  → LoopAgent(GeneratorAgent → ValidatorAgent)               │
    │  → MockDataAgent                                            │
    ├─────────────────────────────────────────────────────────────┤
    │ Phase 2: Enterprise Hardening Loop (max 3 iterations)       │
    │  ParallelAgent(                                             │
    │    SecurityCritic, ResilienceCritic,                        │
    │    ObservabilityCritic, PerformanceCritic                   │
    │  )                                                          │
    │  → ParallelAgent(EdgeCaseCritic, ComplianceCritic)          │
    │  → RefactorAgent                                            │
    │  → QualityGateAgent                                         │
    │  ↻ iterate if score < threshold                             │
    ├─────────────────────────────────────────────────────────────┤
    │ Phase 3: Packaging + Emission                               │
    │  DocGenAgent → TestGenAgent → PackagerAgent → WriterAgent   │
    └─────────────────────────────────────────────────────────────┘
    """

    def __init__(self, config_path: str = "configs/maf_config.yaml"):
        self.config = MAFConfig(config_path)
        self._setup_logging()
        self.root_agent = self._build_full_pipeline()
        logger.info("MAF v2 initialized — 14 agents, 3 phases")

    def _setup_logging(self):
        log_level = self.config.factory.get("log_level", "INFO")
        logging.basicConfig(
            level=getattr(logging, log_level),
            format="[MAF %(levelname)s] %(name)s | %(message)s",
        )

    def _get_model(self, tier: str) -> str:
        model_config = self.config.get_model_config(tier)
        return model_config.get("model_id", "gemini-2.0-flash")

    def _build_full_pipeline(self) -> SequentialAgent:
        """Build the complete 3-phase enterprise pipeline."""
        fast = self._get_model("fast_io")
        reason = self._get_model("reasoning")
        retry_max = self.config.pipeline.get("retry", {}).get("max_attempts", 3)

        # ════════════════════════════════════════════
        # PHASE 1: Analysis + Generation
        # ════════════════════════════════════════════
        phase1_pipeline = SequentialAgent(
            name="Phase1_AnalysisGeneration",
            description="Parse SOP, analyze mode, extract data, plan and generate pipeline code",
            sub_agents=[
                build_ingest_agent(model=fast),
                build_analyzer_agent(model=reason),
                build_datapoint_agent(model=reason),
                build_planner_agent(model=reason),
                LoopAgent(
                    name="GenerateValidateLoop",
                    description="Generate code and validate, retry on failure",
                    sub_agents=[
                        build_generator_agent(model=reason),
                        build_validator_agent(model=reason),
                    ],
                    max_iterations=retry_max,
                ),
                build_mockdata_agent(model=fast),
            ],
        )

        # ════════════════════════════════════════════
        # PHASE 2: Enterprise Hardening Loop
        # ════════════════════════════════════════════

        # Tier 1 critics run in parallel (independent evaluations)
        tier1_critics = ParallelAgent(
            name="Tier1Critics",
            description="Security, resilience, observability, and performance evaluation in parallel",
            sub_agents=[
                build_security_critic(model=reason),
                build_resilience_critic(model=reason),
                build_observability_critic(model=reason),
                build_performance_critic(model=reason),
            ],
        )

        # Tier 2 critics run in parallel (depend on Tier 1 context but not each other)
        tier2_critics = ParallelAgent(
            name="Tier2Critics",
            description="Edge case and compliance evaluation in parallel",
            sub_agents=[
                build_edge_case_critic(model=reason),
                build_compliance_critic(model=reason),
            ],
        )

        # Hardening sequence: critique → refactor → quality gate
        hardening_sequence = SequentialAgent(
            name="HardeningSequence",
            description="Run critics, apply fixes, evaluate quality",
            sub_agents=[
                tier1_critics,
                tier2_critics,
                build_refactor_agent(model=reason),
                build_quality_gate_agent(model=reason),
            ],
        )

        # Wrap in LoopAgent for iterative hardening
        hardening_loop = LoopAgent(
            name="Phase2_HardeningLoop",
            description="Iteratively critique, refactor, and re-evaluate until quality threshold met",
            sub_agents=[hardening_sequence],
            max_iterations=retry_max,
        )

        # ════════════════════════════════════════════
        # PHASE 3: Packaging + Emission
        # ════════════════════════════════════════════
        phase3_pipeline = SequentialAgent(
            name="Phase3_Packaging",
            description="Generate docs, tests, and final package",
            sub_agents=[
                build_docgen_agent(model=fast),
                build_testgen_agent(model=fast),
                build_packager_agent(model=fast),
                build_writer_agent(model=fast),
            ],
        )

        # ════════════════════════════════════════════
        # ROOT: Wire all three phases
        # ════════════════════════════════════════════
        root = SequentialAgent(
            name="MetaAgentFactory_v2",
            description=(
                "Enterprise meta-agent factory: "
                "Phase 1 (analyze+generate) → "
                "Phase 2 (critic loop+harden) → "
                "Phase 3 (package+emit)"
            ),
            sub_agents=[
                phase1_pipeline,
                hardening_loop,
                phase3_pipeline,
            ],
        )

        agent_count = self._count_agents(root)
        logger.info(
            "Pipeline built: %d total agents, %d phases, models: %s / %s",
            agent_count, 3, fast, reason,
        )
        return root

    def _count_agents(self, agent, depth: int = 0) -> int:
        """Recursively count all agents in the pipeline tree."""
        count = 1
        if hasattr(agent, "sub_agents"):
            for sub in agent.sub_agents:
                count += self._count_agents(sub, depth + 1)
        return count

    async def run(
        self,
        sop_path: str,
        ref_paths: Optional[list[str]] = None,
        output_dir: str = "./generated",
    ) -> dict[str, Any]:
        """Execute the full 3-phase factory pipeline."""
        sop_markdown = Path(sop_path).read_text(encoding="utf-8")

        reference_files = {}
        if ref_paths:
            for ref_path in ref_paths:
                p = Path(ref_path)
                content = p.read_text(encoding="utf-8")
                reference_files[p.name] = (
                    json.loads(content) if p.suffix == ".json" else content
                )

        logger.info("SOP: %s (%d chars), refs: %d", sop_path, len(sop_markdown), len(reference_files))

        session_service = InMemorySessionService()
        runner = Runner(
            agent=self.root_agent,
            app_name="meta_agent_factory_v2",
            session_service=session_service,
        )

        session = await session_service.create_session(
            app_name="meta_agent_factory_v2",
            user_id="maf_operator",
            state={
                "raw_sop_markdown": sop_markdown,
                "reference_files": reference_files,
                "output_dir": output_dir,
                "config": self.config.to_dict(),
                "_hardening_iteration": 0,
            },
        )

        from google.adk.models import Content, Part
        user_message = Content(
            role="user",
            parts=[Part(text=(
                f"Process this SOP through the full enterprise pipeline.\n\n"
                f"SOP:\n{sop_markdown}\n\n"
                f"References:\n{json.dumps(reference_files, indent=2)}\n\n"
                f"Output: {output_dir}"
            ))],
        )

        results = []
        async for event in runner.run_async(
            session_id=session.id,
            user_id="maf_operator",
            new_message=user_message,
        ):
            if hasattr(event, "content") and event.content and event.content.parts:
                author = getattr(event, "author", "unknown")
                text = event.content.parts[0].text
                logger.info("[%s] %s...", author, text[:150])
                results.append({"author": author, "output": text})

        final_state = session.state
        quality = final_state.get("quality_gate_result", {})
        package = final_state.get("package_manifest", {})

        # Write output
        if package:
            await self._write_package(package, output_dir)

        return {
            "quality_gate": quality,
            "package_manifest": package,
            "pipeline_results": results,
            "hardening_iterations": final_state.get("_hardening_iteration", 0),
            "state_keys": list(final_state.keys()),
        }

    async def _write_package(self, manifest: dict, output_dir: str) -> None:
        """Write the final package to disk."""
        out = Path(output_dir)
        out.mkdir(parents=True, exist_ok=True)

        files = manifest.get("files", [])
        for entry in files:
            if isinstance(entry, dict):
                path = out / entry.get("path", "unknown.txt")
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(entry.get("content", ""), encoding="utf-8")
                logger.info("Written: %s", path)

    def get_pipeline_info(self) -> dict[str, Any]:
        """Return pipeline metadata."""
        return {
            "factory": "MetaAgentFactory v2",
            "version": "2.0.0",
            "total_agents": self._count_agents(self.root_agent),
            "phases": {
                "phase_1": {
                    "name": "Analysis + Generation",
                    "agents": 7,
                    "stages": [
                        "IngestAgent", "AnalyzerAgent", "DataPointAgent",
                        "PlannerAgent", "GenerateValidateLoop", "MockDataAgent",
                    ],
                },
                "phase_2": {
                    "name": "Enterprise Hardening Loop",
                    "agents": 8,
                    "stages": [
                        "Tier1Critics (Security, Resilience, Observability, Performance)",
                        "Tier2Critics (EdgeCase, Compliance)",
                        "RefactorAgent",
                        "QualityGateAgent",
                    ],
                    "max_iterations": 3,
                },
                "phase_3": {
                    "name": "Packaging + Emission",
                    "agents": 4,
                    "stages": [
                        "DocGenAgent", "TestGenAgent", "PackagerAgent", "WriterAgent",
                    ],
                },
            },
            "automation_modes": ["BROWSER", "THICK_CLIENT", "SYSTEM", "HYBRID"],
            "critic_dimensions": [
                "Security", "Resilience", "Observability",
                "Performance", "EdgeCases", "Compliance",
            ],
            "models": {
                "fast_io": self._get_model("fast_io"),
                "reasoning": self._get_model("reasoning"),
            },
        }
