"""
EDR QA Questions — 15 real Actimize EDR/RRO QA questions.

Each question carries:
  - number, category, question text
  - validation (what to assess)
  - check (exact logic to apply)
  - depends_on (prior question numbers that must be answered first)
  - requires_human (True → answer must be NEEDS_HUMAN if condition applies)
  - output_hint (how to format the reasoning response)
  - db_fields (which vw_get_qa_actimize_data columns this question uses)
"""

from dataclasses import dataclass, field


@dataclass(frozen=True)
class EDRQuestion:
    number:         int
    category:       str
    question:       str
    validation:     str
    check:          str
    depends_on:     tuple[int, ...]
    requires_human: bool
    output_hint:    str
    db_fields:      tuple[str, ...]   # columns from vw_get_qa_actimize_data


EDR_QUESTIONS: list[EDRQuestion] = [

    EDRQuestion(
        number=1,
        category="Event Creation",
        question="Validate the event description is complete for purposes of review.",
        validation="Match ECN #, Event Type & Subtype, and Workflow Status against Input File fields.",
        check=(
            "Compare ecn_number vs input_file_ecn, event_type vs input_file_event_type, "
            "workflow_status vs input_file_workflow_status. "
            "If ALL 3 match: Y. If any mismatch: N."
        ),
        depends_on=(),
        requires_human=False,
        output_hint="State each of the 3 field comparisons explicitly then give Y or N.",
        db_fields=(
            "ecn_number", "event_type", "event_subtype", "workflow_status",
            "input_file_ecn", "input_file_event_type", "input_file_workflow_status",
        ),
    ),

    EDRQuestion(
        number=2,
        category="Event Creation",
        question=(
            "If EDR event type is not Priority FC Business Referral, validate the "
            "recommendation rationale aligns with risk action recommendation type."
        ),
        validation="Assess Recommended Action vs Rationale alignment.",
        check=(
            "If event_type = 'Priority FC Business Approval': answer N/A. "
            "Else assess whether recommended_rationale aligns with recommended_action. "
            "If aligned: Y. Else: N."
        ),
        depends_on=(1,),
        requires_human=False,
        output_hint="State event_type, recommended_action, recommended_rationale, and alignment conclusion. Answer Y, N, or N/A.",
        db_fields=(
            "event_type", "recommended_action", "recommended_rationale", "recommending_group",
        ),
    ),

    EDRQuestion(
        number=3,
        category="Event Creation",
        question=(
            "If EDR event type is not Priority FC Business Referral, validate the "
            "recommendation rationale aligns with the event description."
        ),
        validation="Assess if Recommended Rationale came from authorized group per EDR type/brokerage grid.",
        check=(
            "If event_type = 'Priority FC Business Approval': answer N/A. "
            "Else check brokerage_type and recommending_group against the authorization grid. "
            "If recommending_group is authorized for this brokerage_type: Y. Else: N."
        ),
        depends_on=(1, 2),
        requires_human=False,
        output_hint="State event_type, brokerage_type, recommending_group. Confirm authorization. Answer Y, N, or N/A.",
        db_fields=(
            "event_type", "brokerage_type", "recommending_group",
            "recommended_rationale", "event_description",
        ),
    ),

    EDRQuestion(
        number=4,
        category="Level 1 Review (Priority FC Business)",
        question="Validate the recommendation rationale aligns with risk action recommendation type.",
        validation="Assess L1 Recommended Action vs L1 Rationale alignment.",
        check=(
            "If event_type != 'Priority FC Business Approval': answer N/A. "
            "Else assess whether l1_rationale aligns with l1_recommended_action. "
            "If aligned: Y. Else: N."
        ),
        depends_on=(1, 2),
        requires_human=False,
        output_hint="State event_type, l1_recommended_action, l1_rationale, alignment. Answer Y, N, or N/A.",
        db_fields=(
            "event_type", "l1_recommended_action", "l1_rationale",
        ),
    ),

    EDRQuestion(
        number=5,
        category="Level 1 Review (Priority FC Business)",
        question=(
            "Validate the recommendation rationale is reasonable based on the "
            "details of the event description."
        ),
        validation="Assess if L1 rationale is reasonable given event description and brokerage/group authorization.",
        check=(
            "If event_type != 'Priority FC Business Approval': answer N/A. "
            "Else check brokerage_type and recommending_group against authorization grid. "
            "If authorized and rationale aligns to event_description: Y. Else: N."
        ),
        depends_on=(1, 4),
        requires_human=False,
        output_hint="State event_type, brokerage_type, recommending_group, l1_rationale alignment. Answer Y, N, or N/A.",
        db_fields=(
            "event_type", "brokerage_type", "recommending_group",
            "l1_recommended_action", "l1_rationale", "event_description",
        ),
    ),

    EDRQuestion(
        number=6,
        category="Level 2 Review",
        question="Validate the decision rationale aligns with the risk decision type.",
        validation="Assess L2 decision, action, rationale alignment.",
        check=(
            "If l2_decision = 'Accept': l2_action should be blank, l2_rationale aligns to L1. "
            "If l2_decision = 'Amend': l2_action should be populated. "
            "If l2_multiple_rows = True: check l2_lob value. "
            "If all conditions met: Y. Else: N."
        ),
        depends_on=(4, 5),
        requires_human=False,
        output_hint="State l2_decision, l2_action (blank or populated), l2_rationale alignment to L1. Note l2_lob if multiple rows. Answer Y or N.",
        db_fields=(
            "l2_decision", "l2_action", "l2_rationale", "l2_lob", "l2_multiple_rows",
            "l1_recommended_action", "l1_rationale",
        ),
    ),

    EDRQuestion(
        number=7,
        category="Level 2 Review",
        question=(
            "Validate the decision rationale is reasonable based on the "
            "details of the event description."
        ),
        validation="Assess if L2 rationale aligns to recommended action and event description.",
        check=(
            "If l2_decision = 'Accept': l2_rationale should align to l1_recommended_action. "
            "If l2_decision = 'Amend': l2_rationale should explain the amendment reason. "
            "If aligned: Y. Else: N."
        ),
        depends_on=(5, 6),
        requires_human=False,
        output_hint="Confirm l2_rationale aligns with event_description and l1_recommended_action. Answer Y or N.",
        db_fields=(
            "l2_decision", "l2_rationale", "l1_recommended_action", "event_description",
        ),
    ),

    EDRQuestion(
        number=8,
        category="Level 2 Review",
        question=(
            "Validate Level 2 Rationale does not list incorrect group "
            "that made recommendation."
        ),
        validation="Confirm L2 rationale references the correct L1 recommending group.",
        check=(
            "l2_rationale should reference l1_recommended_action or the authorized "
            "recommending_group for this event_type/brokerage_type. "
            "If correct group referenced: Y. Else: N."
        ),
        depends_on=(6, 7),
        requires_human=False,
        output_hint="Identify group mentioned in l2_rationale. Confirm it matches authorized group per EDR type/brokerage. Answer Y or N.",
        db_fields=(
            "l2_rationale", "recommending_group", "event_type", "brokerage_type",
            "l1_recommended_action",
        ),
    ),

    EDRQuestion(
        number=9,
        category="Level 2 Review",
        question=(
            "Confirm if approver decision and rationale were obtained "
            "for elevated approvals."
        ),
        validation="Assess elevated approval decision and rationale alignment.",
        check=(
            "If elevated_approval_required = False or blank: answer N/A. "
            "If elevated_approval_required = True: "
            "  check elevated_approval_decision is populated AND "
            "  elevated_approval_rationale aligns to the decision. "
            "If aligned: Y. Else: N."
        ),
        depends_on=(6, 7, 8),
        requires_human=False,
        output_hint="State elevated_approval_required, elevated_approval_decision, elevated_approval_rationale alignment. Answer Y, N, or N/A.",
        db_fields=(
            "elevated_approval_required", "elevated_approval_decision",
            "elevated_approval_rationale",
        ),
    ),

    EDRQuestion(
        number=10,
        category="Initiation of Decision Execution",
        question=(
            "Is the profile refresh referred to the appropriate group "
            "and evidence provided to QA."
        ),
        validation="Human must validate referral and evidence for Profile Refresh actions.",
        check=(
            "If final_recommended_action = 'Profile Refresh': "
            "  NEEDS_HUMAN — human must validate referral to appropriate group and confirm evidence. "
            "Else: N/A."
        ),
        depends_on=(6, 7),
        requires_human=True,
        output_hint="If Profile Refresh: NEEDS_HUMAN + specify which group to email. Else N/A.",
        db_fields=("final_recommended_action", "recommended_action"),
    ),

    EDRQuestion(
        number=11,
        category="Initiation of Decision Execution",
        question=(
            "Is a risk rating override request present in the risk rating override "
            "Actimize workflow for this event."
        ),
        validation="Check rro_number presence for Increase Risk Rating actions.",
        check=(
            "If final_recommended_action = 'Increase Risk Rating': "
            "  If rro_number is populated: Y. "
            "  If rro_number is blank: NEEDS_HUMAN. "
            "If risk_rating_amended_in_l2 = True: confirm final_risk_rating is stated with rro_number. "
            "Else: N/A."
        ),
        depends_on=(6, 7),
        requires_human=False,
        output_hint="State final_recommended_action, rro_number (populated or blank), risk_rating_amended_in_l2. Answer Y, NEEDS_HUMAN, or N/A.",
        db_fields=(
            "final_recommended_action", "rro_number",
            "risk_rating_amended_in_l2", "final_risk_rating",
        ),
    ),

    EDRQuestion(
        number=12,
        category="Initiation of Decision Execution",
        question=(
            "Is the Exit referred to the appropriate group and evidence "
            "provided to QA."
        ),
        validation="Human must validate referral and evidence for Exit Decision actions.",
        check=(
            "If final_recommended_action = 'Exit Decision': "
            "  NEEDS_HUMAN — human must validate referral to appropriate group and confirm evidence. "
            "Else: N/A."
        ),
        depends_on=(6, 7),
        requires_human=True,
        output_hint="If Exit Decision: NEEDS_HUMAN + specify which group to email. Else N/A.",
        db_fields=("final_recommended_action", "recommended_action"),
    ),

    EDRQuestion(
        number=13,
        category="Initiation of Decision Execution",
        question=(
            "Profile Refresh: Validate if profile refresh request was referred "
            "to the appropriate process for execution."
        ),
        validation="Human must validate if decision changed to Profile Refresh during review.",
        check=(
            "If final_recommended_action changed to 'Profile Refresh' during risk review: "
            "  NEEDS_HUMAN — human must validate referral to appropriate process. "
            "Else: N/A."
        ),
        depends_on=(10,),
        requires_human=True,
        output_hint="If decision changed to Profile Refresh: NEEDS_HUMAN. Else N/A.",
        db_fields=("final_recommended_action", "recommended_action", "l2_action"),
    ),

    EDRQuestion(
        number=14,
        category="Initiation of Decision Execution",
        question=(
            "Increase Risk Rating: Validate if the Risk Rating Override request was "
            "referred to the appropriate process for execution."
        ),
        validation="Check rro_number for decisions changed to Increase Risk Rating.",
        check=(
            "If final_recommended_action changed to 'Increase Risk Rating' during review: "
            "  If rro_number populated: Y. "
            "  If rro_number blank: NEEDS_HUMAN. "
            "Else: N/A."
        ),
        depends_on=(11,),
        requires_human=False,
        output_hint="State whether decision changed to Increase Risk Rating, rro_number status. Answer Y, NEEDS_HUMAN, or N/A.",
        db_fields=("final_recommended_action", "recommended_action", "rro_number", "l2_action"),
    ),

    EDRQuestion(
        number=15,
        category="Initiation of Decision Execution",
        question=(
            "Exit Decision: Validate if customer exit request was referred "
            "to the appropriate process for execution."
        ),
        validation="Human must validate if decision changed to Exit Decision during review.",
        check=(
            "If final_recommended_action changed to 'Exit Decision' during risk review: "
            "  NEEDS_HUMAN — human must validate referral to appropriate process. "
            "Else: N/A."
        ),
        depends_on=(12,),
        requires_human=True,
        output_hint="If decision changed to Exit Decision: NEEDS_HUMAN. Else N/A.",
        db_fields=("final_recommended_action", "recommended_action", "l2_action"),
    ),
]

# Fast lookup
EDR_QUESTION_MAP: dict[int, EDRQuestion] = {q.number: q for q in EDR_QUESTIONS}

CATEGORIES: list[str] = [
    "Event Creation",
    "Level 1 Review (Priority FC Business)",
    "Level 2 Review",
    "Initiation of Decision Execution",
]

HUMAN_REVIEW_QUESTION_NUMBERS: set[int] = {
    q.number for q in EDR_QUESTIONS if q.requires_human
}

CATEGORY_QUESTION_MAP: dict[str, list[int]] = {
    "Event Creation":                        [1, 2, 3],
    "Level 1 Review (Priority FC Business)": [4, 5],
    "Level 2 Review":                        [6, 7, 8, 9],
    "Initiation of Decision Execution":      [10, 11, 12, 13, 14, 15],
}
