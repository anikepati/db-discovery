"""
EDR QA v5 — Test suite.
Run: pytest tests/ -v
All tests run without API calls or DB connections.
"""

import json
import sys
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from models import QAAnswer, Verdict
from questions import (
    EDR_QUESTIONS, EDR_QUESTION_MAP,
    HUMAN_REVIEW_QUESTION_NUMBERS, CATEGORY_QUESTION_MAP,
)


# ── Helpers ───────────────────────────────────────────────────────────────────

def _mock_tool_context(initial_state: dict | None = None) -> MagicMock:
    """Create a mock ADK ToolContext with a real dict as state."""
    ctx = MagicMock()
    ctx.state = initial_state or {}
    return ctx


# ── context.state tools ───────────────────────────────────────────────────────

class TestStateTools:

    def test_store_and_get_edr_data(self):
        from agents.tools import store_edr_data, get_edr_data
        ctx  = _mock_tool_context()
        data = {"ecn_number": "ECN-001", "event_type": "Standard Referral"}
        r    = store_edr_data(json.dumps(data), tool_context=ctx)
        assert json.loads(r)["stored"] is True
        assert ctx.state["edr_data"]["ecn_number"] == "ECN-001"

        r2 = get_edr_data(tool_context=ctx)
        out = json.loads(r2)
        assert out["found"] is True
        assert out["edr_data"]["event_type"] == "Standard Referral"

    def test_get_edr_data_empty(self):
        from agents.tools import get_edr_data
        ctx = _mock_tool_context()
        r   = get_edr_data(tool_context=ctx)
        assert json.loads(r)["found"] is False

    def test_store_edr_data_error_payload(self):
        from agents.tools import store_edr_data
        ctx = _mock_tool_context()
        r   = store_edr_data(json.dumps({"error": "ECN not found"}), tool_context=ctx)
        assert json.loads(r)["stored"] is False

    def test_store_and_get_answer(self):
        from agents.tools import store_answer, get_prior_answers
        ctx = _mock_tool_context()
        r   = store_answer(
            question_number=3,
            answer="N/A",
            reasoning="Event type is Priority FC Business Approval.",
            category="Event Creation",
            requires_human=False,
            human_action="",
            tool_context=ctx,
        )
        assert json.loads(r)["stored"] is True
        assert ctx.state["answers"]["q3"]["answer"] == "N/A"

        r2 = get_prior_answers(tool_context=ctx)
        out = json.loads(r2)
        assert out["count"] == 1
        assert "q3" in out["answers"]

    def test_store_multiple_answers(self):
        from agents.tools import store_answer, get_all_answers
        ctx = _mock_tool_context()
        for n in range(1, 6):
            store_answer(n, "Y", f"Reasoning for Q{n}", "Event Creation", False, "", tool_context=ctx)

        r = get_all_answers(tool_context=ctx)
        assert json.loads(r)["count"] == 5

    def test_store_answer_preserves_existing(self):
        """Storing Q5 should not delete Q1."""
        from agents.tools import store_answer
        ctx = _mock_tool_context()
        store_answer(1, "Y", "Q1 reasoning", "Event Creation", False, "", tool_context=ctx)
        store_answer(5, "N/A", "Q5 reasoning", "L1 Review", False, "", tool_context=ctx)
        assert "q1" in ctx.state["answers"]
        assert "q5" in ctx.state["answers"]

    def test_store_verdict(self):
        from agents.tools import store_verdict
        ctx = _mock_tool_context()
        r   = store_verdict("PASS", 100.0, "[]", 0, tool_context=ctx)
        assert json.loads(r)["stored"] is True
        assert ctx.state["verdict"]["verdict"] == "PASS"

    def test_store_verdict_with_failed_questions(self):
        from agents.tools import store_verdict
        ctx = _mock_tool_context()
        store_verdict("FAIL", 80.0, "[3, 7]", 0, tool_context=ctx)
        assert ctx.state["verdict"]["failed_questions"] == [3, 7]


# ── Mock fetch ────────────────────────────────────────────────────────────────

class TestMockFetch:

    def test_mock_ecn_001_returns_record(self):
        from agents.tools import fetch_edr_data
        ctx = _mock_tool_context()
        with patch.dict("os.environ", {}, clear=False):
            # MSSQL_CONN not set → mock path
            import os
            os.environ.pop("MSSQL_CONN", None)
            r = fetch_edr_data("ECN-2024-001", tool_context=ctx)
        data = json.loads(r)
        assert data["ecn_number"] == "ECN-2024-001"
        assert data["event_type"] == "Priority FC Business Approval"

    def test_mock_ecn_002_no_rro(self):
        from agents.tools import fetch_edr_data
        import os; os.environ.pop("MSSQL_CONN", None)
        ctx = _mock_tool_context()
        r   = fetch_edr_data("ECN-2024-002", tool_context=ctx)
        data = json.loads(r)
        assert data["rro_number"] is None
        assert data["final_recommended_action"] == "Increase Risk Rating"

    def test_mock_unknown_ecn_returns_error(self):
        from agents.tools import fetch_edr_data
        import os; os.environ.pop("MSSQL_CONN", None)
        ctx = _mock_tool_context()
        r   = fetch_edr_data("ECN-UNKNOWN-999", tool_context=ctx)
        assert "error" in json.loads(r)


# ── build_report ──────────────────────────────────────────────────────────────

class TestBuildReport:

    def _answers(self, mapping: dict[int, str]) -> dict:
        return {
            f"q{n}": {
                "answer":         v,
                "reasoning":      f"Reasoning for Q{n}",
                "category":       "Event Creation",
                "requires_human": v == "NEEDS_HUMAN",
                "human_action":   f"Action for Q{n}" if v == "NEEDS_HUMAN" else "",
            }
            for n, v in mapping.items()
        }

    def _run(self, answers: dict, tmp_path) -> dict:
        from agents.tools import build_report
        ctx  = _mock_tool_context()
        path = str(tmp_path / "result.json")
        r = build_report(
            answers_json=json.dumps(answers),
            edr_data_json=json.dumps({"ecn_number": "ECN-TEST", "event_type": "Standard Referral"}),
            output_path=path,
            tool_context=ctx,
        )
        return json.loads(r)

    def test_all_yes_pass(self, tmp_path):
        r = self._run(self._answers({i: "Y" for i in range(1, 16)}), tmp_path)
        assert r["verdict"] == "PASS"
        assert r["overall_pass_rate"] == 100.0

    def test_any_no_fail(self, tmp_path):
        a = self._answers({i: "Y" for i in range(1, 16)})
        a["q3"]["answer"] = "N"
        r = self._run(a, tmp_path)
        assert r["verdict"] == "FAIL"
        assert 3 in r["failed_questions"]

    def test_needs_human_requires_human_review(self, tmp_path):
        a = self._answers({i: "Y" for i in range(1, 16)})
        a["q10"]["answer"] = "NEEDS_HUMAN"
        a["q10"]["requires_human"] = True
        r = self._run(a, tmp_path)
        assert r["verdict"] == "REQUIRES_HUMAN_REVIEW"

    def test_fail_beats_needs_human(self, tmp_path):
        a = self._answers({i: "Y" for i in range(1, 16)})
        a["q3"]["answer"]  = "N"
        a["q10"]["answer"] = "NEEDS_HUMAN"
        a["q10"]["requires_human"] = True
        r = self._run(a, tmp_path)
        assert r["verdict"] == "FAIL"

    def test_na_excluded_from_pass_rate(self, tmp_path):
        a = {f"q{n}": {"answer": "Y", "reasoning": "", "category": "", "requires_human": False, "human_action": ""} for n in range(1, 11)}
        for n in range(11, 16):
            a[f"q{n}"] = {"answer": "N/A", "reasoning": "", "category": "", "requires_human": False, "human_action": ""}
        r = self._run(a, tmp_path)
        assert r["overall_pass_rate"] == 100.0
        assert r["verdict"] == "PASS"

    def test_output_json_written(self, tmp_path):
        self._run(self._answers({i: "Y" for i in range(1, 16)}), tmp_path)
        f = tmp_path / "result.json"
        assert f.exists()
        data = json.loads(f.read_text())
        assert data["verdict"] == "PASS"
        assert len(data["answers"]) == 15


# ── Questions ─────────────────────────────────────────────────────────────────

class TestQuestions:

    def test_exactly_15(self):
        assert len(EDR_QUESTIONS) == 15

    def test_numbered_1_to_15(self):
        assert [q.number for q in EDR_QUESTIONS] == list(range(1, 16))

    def test_no_forward_dependencies(self):
        for q in EDR_QUESTIONS:
            for dep in q.depends_on:
                assert dep < q.number, f"Q{q.number} has forward dep Q{dep}"

    def test_exact_dependency_chains(self):
        expected = {
            1: (), 2: (1,), 3: (1, 2), 4: (1, 2), 5: (1, 4),
            6: (4, 5), 7: (5, 6), 8: (6, 7), 9: (6, 7, 8),
            10: (6, 7), 11: (6, 7), 12: (6, 7),
            13: (10,), 14: (11,), 15: (12,),
        }
        for num, deps in expected.items():
            assert EDR_QUESTION_MAP[num].depends_on == deps, f"Q{num} deps mismatch"

    def test_human_review_questions(self):
        assert HUMAN_REVIEW_QUESTION_NUMBERS == {10, 12, 13, 15}

    def test_all_have_db_fields(self):
        for q in EDR_QUESTIONS:
            assert len(q.db_fields) > 0, f"Q{q.number} has no db_fields"

    def test_all_have_check_logic(self):
        for q in EDR_QUESTIONS:
            assert q.check.strip(), f"Q{q.number} has empty check"


# ── Agent Skills ──────────────────────────────────────────────────────────────

class TestAgentSkills:

    def test_all_skill_dirs_exist(self):
        skills_dir = Path(__file__).parent.parent / "skills"
        expected = (
            ["edr-ingest", "edr-report"] +
            [f"edr-q{n:02d}" for n in range(1, 16)]
        )
        for name in expected:
            assert (skills_dir / name).is_dir(), f"Skill dir missing: {name}"

    def test_all_skill_md_files_exist(self):
        skills_dir = Path(__file__).parent.parent / "skills"
        for d in skills_dir.iterdir():
            if d.is_dir():
                assert (d / "SKILL.md").exists(), f"SKILL.md missing in {d.name}"

    def test_skill_md_has_valid_frontmatter(self):
        import yaml
        skills_dir = Path(__file__).parent.parent / "skills"
        for d in skills_dir.iterdir():
            if not d.is_dir():
                continue
            content = (d / "SKILL.md").read_text()
            assert content.startswith("---"), f"{d.name}/SKILL.md missing frontmatter"
            end = content.find("---", 3)
            assert end != -1, f"{d.name}/SKILL.md frontmatter not closed"
            fm = yaml.safe_load(content[3:end])
            assert "name" in fm,        f"{d.name}/SKILL.md missing 'name'"
            assert "description" in fm, f"{d.name}/SKILL.md missing 'description'"

    def test_question_skill_names_match_convention(self):
        skills_dir = Path(__file__).parent.parent / "skills"
        import yaml
        for n in range(1, 16):
            slug    = f"edr-q{n:02d}"
            content = (skills_dir / slug / "SKILL.md").read_text()
            end     = content.find("---", 3)
            fm      = yaml.safe_load(content[3:end])
            assert fm["name"] == slug, f"name mismatch in {slug}/SKILL.md"

    def test_question_reference_files_exist(self):
        skills_dir = Path(__file__).parent.parent / "skills"
        for n in range(1, 16):
            ref = skills_dir / f"edr-q{n:02d}" / "references" / "question.md"
            assert ref.exists(), f"Missing: {ref}"

    def test_ingest_schema_reference_exists(self):
        skills_dir = Path(__file__).parent.parent / "skills"
        schema = skills_dir / "edr-ingest" / "references" / "schema.md"
        assert schema.exists()
        content = schema.read_text()
        assert "vw_get_qa_actimize_data" in content
        assert "ecn_number" in content


# ── Agent Registry ────────────────────────────────────────────────────────────

class TestAgentRegistry:

    def test_registry_has_17_entries(self):
        from agents.registry import AGENT_REGISTRY
        assert len(AGENT_REGISTRY) == 17

    def test_first_is_ingest_last_is_report(self):
        from agents.registry import AGENT_REGISTRY
        assert AGENT_REGISTRY[0].name  == "ingest_agent"
        assert AGENT_REGISTRY[-1].name == "report_agent"

    def test_q_agents_in_order(self):
        from agents.registry import Q_AGENT_CONFIGS
        assert len(Q_AGENT_CONFIGS) == 15
        for i, cfg in enumerate(Q_AGENT_CONFIGS, 1):
            assert cfg.name == f"q{i:02d}_agent"

    def test_all_skill_dirs_resolvable(self):
        from agents.registry import AGENT_REGISTRY
        for cfg in AGENT_REGISTRY:
            assert cfg.skill_dir.is_dir(), f"Skill dir not found: {cfg.skill_dir}"

    def test_load_instruction_strips_frontmatter(self):
        from agents.registry import AGENT_MAP
        instr = AGENT_MAP["ingest_agent"].load_instruction()
        assert not instr.startswith("---")
        assert "Steps" in instr or "step" in instr.lower()

    def test_q_agent_depends_on_from_questions(self):
        from agents.registry import AGENT_MAP
        from questions import EDR_QUESTION_MAP
        for n in range(1, 16):
            cfg = AGENT_MAP[f"q{n:02d}_agent"]
            assert cfg.depends_on == EDR_QUESTION_MAP[n].depends_on


# ── Models ────────────────────────────────────────────────────────────────────

class TestModels:

    def test_qa_answer_from_string(self):
        assert QAAnswer.from_string("Y")           == QAAnswer.YES
        assert QAAnswer.from_string("yes")         == QAAnswer.YES
        assert QAAnswer.from_string("N")           == QAAnswer.NO
        assert QAAnswer.from_string("n/a")         == QAAnswer.NA
        assert QAAnswer.from_string("NEEDS_HUMAN") == QAAnswer.NEEDS_HUMAN
        assert QAAnswer.from_string("garbage")     == QAAnswer.NEEDS_HUMAN

    def test_verdict_passed(self):
        assert Verdict.PASS.passed is True
        assert Verdict.PASS_WITH_EXCEPTIONS.passed is True
        assert Verdict.FAIL.passed is False
        assert Verdict.REQUIRES_HUMAN_REVIEW.passed is False

    def test_verdict_from_string(self):
        assert Verdict.from_string("PASS")                   == Verdict.PASS
        assert Verdict.from_string("FAIL")                   == Verdict.FAIL
        assert Verdict.from_string("REQUIRES_HUMAN_REVIEW")  == Verdict.REQUIRES_HUMAN_REVIEW
        assert Verdict.from_string("unknown")                == Verdict.REQUIRES_HUMAN_REVIEW


# ── AuditWriter ───────────────────────────────────────────────────────────────

class TestAuditWriter:

    def test_manifest_written(self, tmp_path):
        from audit.audit_writer import AuditWriter
        w = AuditWriter("run_001", "ECN-001", audit_dir=str(tmp_path))
        w.write_manifest("ECN-001")
        data = json.loads((tmp_path / "run_001" / "00_run_manifest.json").read_text())
        assert data["run_id"]           == "run_001"
        assert data["pipeline_version"] == "v5"
        assert data["db_view"]          == "vw_get_qa_actimize_data"

    def test_agent_record_written(self, tmp_path):
        from audit.audit_writer import AuditWriter
        w = AuditWriter("run_001", "ECN-001", audit_dir=str(tmp_path))
        w.agent_started("ingest_agent")
        w.write_agent_record("ingest_agent", "success", "INGEST OK")
        f = tmp_path / "run_001" / "01_ingest_agent.json"
        assert f.exists()
        data = json.loads(f.read_text())
        assert data["status"] == "success"

    def test_q_agent_prefix(self, tmp_path):
        from audit.audit_writer import AuditWriter
        w = AuditWriter("run_001", "ECN-001", audit_dir=str(tmp_path))
        w.agent_started("q07_agent")
        w.write_agent_record("q07_agent", "success", "Q07: Y")
        f = tmp_path / "run_001" / "08_q07_agent.json"
        assert f.exists()

    def test_summary_written(self, tmp_path):
        from audit.audit_writer import AuditWriter
        w = AuditWriter("run_001", "ECN-001", audit_dir=str(tmp_path))
        w.write_run_summary("PASS", 100.0, [], [], 15.3)
        f = tmp_path / "run_001" / "18_run_summary.json"
        assert f.exists()
        data = json.loads(f.read_text())
        assert data["verdict"] == "PASS"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
