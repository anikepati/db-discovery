"""
EDR QA Pipeline v4 — CLI entry point.

Usage:
    python main.py --ecn-id ECN-2024-001
    python main.py --ecn-id ECN-2024-002 --output result.json --quiet

    # Concurrent simulation (multiple ECNs — each fully isolated)
    python main.py --concurrent

Exit codes:
    0   PASS or PASS_WITH_EXCEPTIONS
    1   Config error or pipeline failure
    2   FAIL or REQUIRES_HUMAN_REVIEW
  130   Interrupted
"""

import argparse
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from config import settings, configure_logging
from pipeline_runner import PipelineRunner

DEMO_ECNS = ["ECN-2024-001", "ECN-2024-002", "ECN-2024-003"]


def _args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="EDR QA Pipeline v4 — YAML MCP + Shared State",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Demo ECNs:\n"
            "  ECN-2024-001  Priority FC Business Approval  → expected PASS\n"
            "  ECN-2024-002  Increase Risk Rating            → expected REQUIRES_HUMAN_REVIEW\n"
            "  ECN-2024-003  Exit Decision                   → expected REQUIRES_HUMAN_REVIEW\n"
        ),
    )
    p.add_argument("--ecn-id",     default=None,         help="ECN identifier to evaluate")
    p.add_argument("--output",     default=None,         help="Output path for result JSON")
    p.add_argument("--quiet",      action="store_true",  help="Suppress per-agent output")
    p.add_argument("--concurrent", action="store_true",  help="Run all 3 demo ECNs concurrently")
    return p.parse_args()


async def run_single(ecn_id: str, output: str | None, quiet: bool) -> int:
    runner = PipelineRunner()
    try:
        result = await runner.run(
            ecn_id=ecn_id,
            output_path=output,
            verbose=not quiet,
        )
        return 0 if result.passed else 2
    except RuntimeError as e:
        print(f"\n❌  Pipeline failed: {e}\n", file=sys.stderr)
        return 1


async def run_concurrent(quiet: bool) -> int:
    """
    Run all 3 demo ECNs concurrently.
    Each run has its own RunState — zero shared state between them.
    """
    print("\n🚀 Launching concurrent EDR QA runs...\n")
    runner = PipelineRunner()
    results = await asyncio.gather(*[
        runner.run(ecn_id=ecn, verbose=not quiet)
        for ecn in DEMO_ECNS
    ], return_exceptions=True)

    print(f"\n{'═' * 60}")
    print("  CONCURRENT RESULTS")
    print(f"{'═' * 60}")
    exit_code = 0
    for ecn, res in zip(DEMO_ECNS, results):
        if isinstance(res, Exception):
            print(f"  ❌  {ecn}: FAILED — {res}")
            exit_code = 1
        else:
            icon = "✅" if res.passed else "❌"
            print(f"  {icon}  {ecn}: {res.verdict.value} ({res.overall_pass_rate:.1f}%)")
            if not res.passed:
                exit_code = 2
    print()
    return exit_code


async def main() -> int:
    args = _args()

    try:
        settings.validate()
    except ValueError as e:
        print(f"\n❌  Config error: {e}\n", file=sys.stderr)
        return 1

    configure_logging()

    try:
        if args.concurrent:
            return await run_concurrent(args.quiet)
        elif args.ecn_id:
            return await run_single(args.ecn_id, args.output, args.quiet)
        else:
            print("❌  Provide --ecn-id <ECN> or --concurrent\n", file=sys.stderr)
            return 1
    except KeyboardInterrupt:
        print("\n⏹  Interrupted.\n")
        return 130


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
