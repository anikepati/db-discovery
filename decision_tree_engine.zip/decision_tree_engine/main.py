"""
Main Orchestrator — entry point for the YAML Decision Tree Engine.

Flow:
  1. Load & validate YAML config (fail fast)
  2. Extract required columns from config
  3. Validate Excel has those columns (fail fast)
  4. For each row: walk all trees, collect audit trail
  5. Generate summary report

Usage:
  python main.py --config config/validations.yaml
  python main.py --config config/validations.yaml --dry-run
"""

import argparse
import json
import logging
import sys
import time
from pathlib import Path
from typing import List, Dict, Any

from engine.loader import load_config
from engine.evaluator import ConditionEvaluator, OperatorRegistry
from engine.action_dispatcher import ActionDispatcher
from engine.tree_walker import DecisionTreeWalker, generate_row_report
from engine.excel_reader import read_excel, validate_columns
from engine.column_extractor import extract_columns


def setup_logging(level: str = "INFO"):
    """Configure structured logging."""
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format="%(asctime)s │ %(levelname)-7s │ %(name)s │ %(message)s",
        datefmt="%H:%M:%S",
    )


def run_engine(config_path: str, dry_run_override: bool = None):
    """
    Main engine execution.
    Returns summary dict with all row reports.
    """
    start_time = time.time()

    # ── Step 1: Load & Validate Config ───────────────────────────────────
    logger = logging.getLogger("engine")
    logger.info("=" * 60)
    logger.info("YAML DECISION TREE ENGINE")
    logger.info("=" * 60)

    logger.info(f"Loading config: {config_path}")
    config = load_config(config_path)
    logger.info(
        f"Config loaded: {len(config.decision_trees)} decision trees"
    )

    settings = config.settings
    dry_run = dry_run_override if dry_run_override is not None else settings.dry_run

    if dry_run:
        logger.info("*** DRY RUN MODE — no side effects ***")

    setup_logging(settings.log_level)

    # ── Step 2: Extract & Validate Columns ───────────────────────────────
    required_columns = extract_columns(config)
    logger.info(f"Required columns from YAML: {sorted(required_columns)}")

    missing = validate_columns(
        settings.excel_file,
        settings.sheet_name,
        list(required_columns),
    )
    if missing:
        logger.error(f"MISSING COLUMNS in Excel: {missing}")
        logger.error("These columns are referenced in YAML but not found in the Excel file.")
        logger.error("Fix the YAML config or the Excel file and retry.")
        sys.exit(1)

    logger.info("All required columns found in Excel ✓")

    # ── Step 3: Initialize Engine Components ─────────────────────────────
    registry = OperatorRegistry()
    evaluator = ConditionEvaluator(registry)
    dispatcher = ActionDispatcher(dry_run=dry_run)

    context = {
        "api_base_url": settings.api_base_url,
        "db_connection_string": settings.db_connection_string,
        "db_table": settings.db_table,
        "row_id_column": settings.row_id_column,
    }

    walker = DecisionTreeWalker(evaluator, dispatcher, context)

    # ── Step 4: Process Rows ─────────────────────────────────────────────
    all_reports: List[Dict[str, Any]] = []
    row_count = 0
    error_count = 0

    logger.info("-" * 60)
    logger.info("PROCESSING ROWS")
    logger.info("-" * 60)

    for chunk in read_excel(
        settings.excel_file,
        settings.sheet_name,
        chunk_size=settings.batch_size,
    ):
        for row in chunk:
            row_count += 1
            row_id = str(row.get(settings.row_id_column, f"row_{row_count}"))

            logger.info(f"\n{'─' * 40}")
            logger.info(f"Row {row_count} | ID: {row_id}")
            logger.info(f"{'─' * 40}")

            # Walk all decision trees for this row
            tree_results = walker.walk_all_trees(
                config.decision_trees, row, row_id
            )

            # Generate per-row report
            report = generate_row_report(row_id, tree_results)
            all_reports.append(report)

            if report["error_count"] > 0:
                error_count += report["error_count"]

    # ── Step 5: Summary ──────────────────────────────────────────────────
    elapsed = time.time() - start_time

    summary = {
        "total_rows": row_count,
        "total_trees": len(config.decision_trees),
        "total_evaluations": sum(r["total_nodes_evaluated"] for r in all_reports),
        "total_errors": error_count,
        "elapsed_seconds": round(elapsed, 2),
        "dry_run": dry_run,
        "row_reports": all_reports,
    }

    logger.info("\n" + "=" * 60)
    logger.info("EXECUTION SUMMARY")
    logger.info("=" * 60)
    logger.info(f"Rows processed:    {summary['total_rows']}")
    logger.info(f"Trees per row:     {summary['total_trees']}")
    logger.info(f"Total evaluations: {summary['total_evaluations']}")
    logger.info(f"Errors:            {summary['total_errors']}")
    logger.info(f"Elapsed:           {summary['elapsed_seconds']}s")
    logger.info(f"Dry run:           {summary['dry_run']}")
    logger.info("=" * 60)

    return summary


def main():
    parser = argparse.ArgumentParser(
        description="YAML Decision Tree Engine",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python main.py --config config/validations.yaml
  python main.py --config config/validations.yaml --dry-run
  python main.py --config config/validations.yaml --output results.json
        """,
    )
    parser.add_argument(
        "--config", "-c",
        required=True,
        help="Path to YAML decision tree config",
    )
    parser.add_argument(
        "--dry-run", "-d",
        action="store_true",
        help="Run without executing actions (log only)",
    )
    parser.add_argument(
        "--output", "-o",
        help="Save results to JSON file",
    )

    args = parser.parse_args()

    setup_logging()
    summary = run_engine(args.config, dry_run_override=args.dry_run or None)

    if args.output:
        output_path = Path(args.output)
        # Remove full row_reports from file output to keep it manageable
        file_summary = {k: v for k, v in summary.items() if k != "row_reports"}
        file_summary["row_count_with_errors"] = sum(
            1 for r in summary["row_reports"] if r["error_count"] > 0
        )
        with open(output_path, "w") as f:
            json.dump(file_summary, f, indent=2, default=str)
        logging.getLogger("engine").info(f"Results saved to: {output_path}")


if __name__ == "__main__":
    main()
