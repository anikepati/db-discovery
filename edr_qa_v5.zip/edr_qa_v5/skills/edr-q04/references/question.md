# Q04 Full Reference — Level 1 Review (Priority FC Business)

## Question

Validate the recommendation rationale aligns with risk action recommendation type.

## Validation

Assess L1 Recommended Action vs L1 Rationale alignment.

## Check Logic (apply exactly)

If event_type != 'Priority FC Business Approval': answer N/A. Else assess whether l1_rationale aligns with l1_recommended_action. If aligned: Y. Else: N.

## Depends On

Q01, Q02

## Output Hint

State event_type, l1_recommended_action, l1_rationale, alignment. Answer Y, N, or N/A.

## Requires Human Review

No — answer should be Y, N, or N/A only.

## DB Fields

- `event_type`
- `l1_recommended_action`
- `l1_rationale`

## Authorization Grid (relevant for Q2, Q3, Q5, Q8)

See `skills/edr-ingest/references/schema.md` for the full authorization grid
mapping EDR type + brokerage type → authorized recommending groups.
