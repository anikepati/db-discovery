"""
EDR QA Question Registry
Transcribed from the EDR QA spreadsheet (images provided).

Structure per question:
  - number       : execution order
  - category     : Event Creation | Level 1 Review | Level 2 Review | Initiation of Decision Execution
  - question     : the QA question text (column E)
  - validation   : what to perform / how to validate (column F)
  - check        : specific check logic and Y/N/N/A rules (column G)
  - notes        : examples and extra guidance (column H, where present)
  - depends_on   : prior question numbers whose answers inform this one
"""

from dataclasses import dataclass, field


@dataclass(frozen=True)
class EDRQuestion:
    number: int
    category: str
    question: str
    validation: str
    check: str
    notes: str
    depends_on: tuple[int, ...] = field(default=())
    output_hint: str = "Answer 'Y', 'N', or 'N/A' with a clear justification."


EDR_QUESTIONS: tuple[EDRQuestion, ...] = (

    # ── Image 2 · Row 2 ──────────────────────────────────────────────────────
    EDRQuestion(
        number=1,
        category="Event Creation",
        question=(
            "Validate the event description is complete for purposes of review."
        ),
        validation=(
            "Check if the Event Description provided is complete in Actimize by "
            "selecting the reviewing ECN/Sample ID on EDR Script under Event Closed Status tab."
        ),
        check=(
            "Match the below fields on Actimize with the Input File:\n"
            "1. ECN #\n"
            "2. Event Type & Subtype\n"
            "3. Workflow Status\n"
            "If all the above match: 'Yes', otherwise 'No'."
        ),
        notes="",
        depends_on=(),
        output_hint="Answer 'Yes' or 'No'. List each of the 3 fields checked and whether they matched.",
    ),

    # ── Image 2 · Row 3 ──────────────────────────────────────────────────────
    EDRQuestion(
        number=2,
        category="Event Creation",
        question=(
            "If EDR event type is not Priority FC Business Referral, validate the "
            "recommendation rationale aligns with risk action recommendation type."
        ),
        validation=(
            "If the Event Type is anything apart from Priority FC Business Referral, "
            "ensure that the recommended action and the rationale aligns with each other."
        ),
        check=(
            "If EDR Type = 'Priority FC Business Approval', then 'N/A'.\n"
            "If EDR Type = anything other than Priority FC Business Approval, "
            "then assess the 'Recommended Action' and 'Rationale' on Actimize. "
            "Both should be aligned.\n"
            "If aligned then 'Y', otherwise 'N'."
        ),
        notes=(
            "Example:\n"
            "Recommended Action - No further Action Required.\n"
            "In this case the rationale must also state the same thing."
        ),
        depends_on=(1,),
        output_hint="Answer 'Y', 'N', or 'N/A'. State the EDR type, recommended action, rationale, and whether they align.",
    ),

    # ── Image 2 · Row 4 ──────────────────────────────────────────────────────
    EDRQuestion(
        number=3,
        category="Event Creation",
        question=(
            "If EDR event type is not Priority FC Business Referral, validate the "
            "recommendation rationale aligns with the event description."
        ),
        validation=(
            "If the Event Type is anything apart from Priority FC Business Referral, "
            "ensure that the rationale and the event description aligns with each other."
        ),
        check=(
            "If EDR Type = 'Priority FC Business Approval', then 'N/A'.\n"
            "If EDR Type = anything other than Priority FC Business Approval, "
            "then assess if the 'Recommended Rationale' has come from an authorized group "
            "(as per the grid below).\n"
            "If aligned then 'Y', otherwise 'N'."
        ),
        notes=(
            "Example:\n"
            "If the EDR is 'Priority FC Business Referral' and the Brokerage type is "
            "'Non-brokerage', then the group making recommendation should be 'TRIG'.\n"
            "The rationale will be - TRIG recommends no further action."
        ),
        depends_on=(1, 2),
        output_hint="Answer 'Y', 'N', or 'N/A'. Identify EDR type, brokerage type, recommending group, and alignment.",
    ),

    # ── Image 2 · Row 5 ──────────────────────────────────────────────────────
    EDRQuestion(
        number=4,
        category="Level 1 Review (Priority FC Business)",
        question=(
            "Validate the recommendation rationale aligns with risk action recommendation type."
        ),
        validation=(
            "Ensure that the recommended action and the rationale aligns with each other."
        ),
        check=(
            "If EDR Type = anything other than Priority FC Business Approval, then 'N/A'.\n"
            "If EDR Type = Priority FC Business Approval, then assess the "
            "'Recommended Action' and 'Rationale' on Actimize. Both should be aligned.\n"
            "If aligned then 'Y' otherwise 'N'."
        ),
        notes=(
            "Example:\n"
            "Recommended Action - No further Action Required.\n"
            "In this case the rationale must also state the same thing."
        ),
        depends_on=(1, 2),
        output_hint="Answer 'Y', 'N', or 'N/A'. Confirm EDR type, recommended action, rationale, and alignment.",
    ),

    # ── Image 2 · Row 6 ──────────────────────────────────────────────────────
    EDRQuestion(
        number=5,
        category="Level 1 Review (Priority FC Business)",
        question=(
            "Validate the recommendation rationale is reasonable based on the details "
            "of the event description."
        ),
        validation=(
            "Ensure that the provided rationale and the event description aligns with each other."
        ),
        check=(
            "If EDR Type = anything other than Priority FC Business Approval, then 'N/A'.\n"
            "If EDR Type = Priority FC Business Approval, then assess if the "
            "'Recommended Rationale' has come from an authorized group (as per the grid below).\n"
            "If aligned then 'Y' otherwise 'N'."
        ),
        notes=(
            "Example:\n"
            "If the EDR is 'Priority FC Business Referral' and the Brokerage type is "
            "'Non-brokerage', then the group making recommendation should be 'TRIG'.\n"
            "The rationale will be - TRIG recommends no further action."
        ),
        depends_on=(1, 4),
        output_hint="Answer 'Y', 'N', or 'N/A'. State EDR type, brokerage type, recommending group, and rationale alignment.",
    ),

    # ── Image 2 · Row 7 ──────────────────────────────────────────────────────
    EDRQuestion(
        number=6,
        category="Level 2 Review",
        question=(
            "Validate the decision rationale aligns with the risk decision type."
        ),
        validation=(
            "Decision rationale provided by the business should align with the decision type."
        ),
        check=(
            "Assess if L2 approval rationale should align to recommended Action.\n\n"
            "If the L2 Decision is 'Accept', then L2 action would be blank and the rationale "
            "will align to the L1 rationale/recommended action.\n\n"
            "If the L2 Decision is 'Amend', then the L2 action will have the action mentioned "
            "in this field.\n\n"
            "In case there are multiple rows for L2 review in Actimize, then check for the LOB "
            "value and then select the row with the required LOB value.\n"
            "If aligned then 'Y' otherwise 'N'."
        ),
        notes=(
            "Example:\n"
            "Recommended Action - No further Action Required.\n"
            "In this case the L2 rationale must also state the same thing and align with L1 rationale."
        ),
        depends_on=(4, 5),
        output_hint=(
            "Answer 'Y' or 'N'. State L2 decision type (Accept/Amend), L2 action, "
            "L1 rationale, and whether they align. Note LOB row selected if multiple rows exist."
        ),
    ),

    # ── Image 2 · Row 8 (partially visible, continued) ───────────────────────
    EDRQuestion(
        number=7,
        category="Level 2 Review",
        question=(
            "Validate the decision rationale is reasonable based on the details of the "
            "event description."
        ),
        validation=(
            "Decision rationale provided by business in Level 2 should align with the event description."
        ),
        check=(
            "Assess if L2 approval rationale should align to recommended Action.\n\n"
            "If the L2 Decision is 'Accept', then L2 action would be blank and the rationale "
            "will align to the L1 recommended action."
        ),
        notes="",
        depends_on=(5, 6),
        output_hint=(
            "Answer 'Y' or 'N'. Confirm L2 rationale aligns with event description and L1 recommended action."
        ),
    ),

    # ── Image 1 · Row 9 ──────────────────────────────────────────────────────
    EDRQuestion(
        number=8,
        category="Level 2 Review",
        question=(
            "Validate Level 2 Rationale does not list incorrect group that made recommendation."
        ),
        validation=(
            "Based on the above grid, either ensure no reference is made to recommending group, "
            "or the correct group is referenced in rationale, based on Event Type and Brokerage fields."
        ),
        check=(
            "The rationale should either state the L1 recommending group or L1 action recommended "
            "and the reason to amend the action.\n"
            "If aligned then 'Y', otherwise 'N'."
        ),
        notes="",
        depends_on=(6, 7),
        output_hint=(
            "Answer 'Y' or 'N'. Identify the group referenced in the L2 rationale and confirm "
            "it matches the authorized L1 recommending group per the EDR type/brokerage grid."
        ),
    ),

    # ── Image 1 · Row 10 ─────────────────────────────────────────────────────
    EDRQuestion(
        number=9,
        category="Level 2 Review",
        question=(
            "Confirm if approver decision and rationale were obtained for elevated approvals."
        ),
        validation=(
            "Check for elevated approval decision is Accept."
        ),
        check=(
            "In case elevated approvals were required (if it mentions in Actimize), then assess "
            "if the elevated approval rationale is aligned.\n"
            "If the elevated approvals not updated/blank then 'N/A'.\n"
            "If aligned then 'Y', otherwise 'N'."
        ),
        notes="",
        depends_on=(6, 7, 8),
        output_hint=(
            "Answer 'Y', 'N', or 'N/A'. State whether elevated approval was required, "
            "the decision recorded, and whether the rationale is aligned."
        ),
    ),

    # ── Image 1 · Row 11 ─────────────────────────────────────────────────────
    EDRQuestion(
        number=10,
        category="Initiation of Decision Execution",
        question=(
            "Is the profile refresh referred to the appropriate group and evidence provided to QA."
        ),
        validation=(
            "Profile Refresh: Validate if profile refresh request was referred to the "
            "appropriate process for execution (see below grid)."
        ),
        check=(
            "If the recommended action is 'Profile Refresh', then leave this validation blank "
            "for the human to validate / send an email to the appropriate group for the profile "
            "refresh report.\n"
            "If it is not 'Profile Refresh' then 'N/A'."
        ),
        notes="",
        depends_on=(6, 7),
        output_hint=(
            "Answer 'N/A' if recommended action is not Profile Refresh. "
            "If it is Profile Refresh, flag for human validation — do not auto-answer."
        ),
    ),

    # ── Image 1 · Row 12 ─────────────────────────────────────────────────────
    EDRQuestion(
        number=11,
        category="Initiation of Decision Execution",
        question=(
            "Is a risk rating override request present in the risk rating override "
            "Actimize workflow for this event (Actimize only)."
        ),
        validation=(
            "Increase Risk Rating: Validate if the Risk Rating Override request was referred "
            "to the appropriate process for execution (see below grid)."
        ),
        check=(
            "If the recommended action is 'Increase Risk Rating', then navigate to the History "
            "tab in Actimize and identify the activity where the RRO # is generated. "
            "If that's done then mark this question as 'Y', otherwise send email to the "
            "appropriate group for confirmation.\n\n"
            "In case the risk rating is amended in L2 review, then the final rating should be "
            "mentioned with the RRO #.\n"
            "If it is not 'Increase Risk Rating' then 'N/A'."
        ),
        notes="",
        depends_on=(6, 7),
        output_hint=(
            "Answer 'Y', 'N/A', or flag for human confirmation. "
            "If 'Increase Risk Rating': check History tab for RRO #. "
            "If found: 'Y'. If not found: flag for human. If not applicable: 'N/A'."
        ),
    ),

    # ── Image 1 · Row 13 ─────────────────────────────────────────────────────
    EDRQuestion(
        number=12,
        category="Initiation of Decision Execution",
        question=(
            "Is the Exit referred to the appropriate group and evidence provided to QA."
        ),
        validation=(
            "Exit Decision: Validate if customer exit request was referred to the appropriate "
            "process for execution (see below grid)."
        ),
        check=(
            "If the recommended action is 'Exit Decision', then leave this validation blank "
            "for the human to validate / send an email to the appropriate group for the exit report.\n"
            "If it is not 'Exit Decision' then 'N/A'."
        ),
        notes="",
        depends_on=(6, 7),
        output_hint=(
            "Answer 'N/A' if recommended action is not Exit Decision. "
            "If it is Exit Decision, flag for human validation — do not auto-answer."
        ),
    ),

    # ── Image 1 · Row 14 ─────────────────────────────────────────────────────
    EDRQuestion(
        number=13,
        category="Initiation of Decision Execution",
        question=(
            "Profile Refresh: Validate if profile refresh request was referred to the "
            "appropriate process for execution."
        ),
        validation=(
            "If the decision changed during risk review, is the profile refresh referred "
            "to the appropriate group and evidence provided to QA."
        ),
        check=(
            "If the recommended action is 'Profile Refresh', then leave this validation blank "
            "for the human to validate / send an email to the appropriate group for the profile "
            "refresh report."
        ),
        notes="",
        depends_on=(10,),
        output_hint=(
            "Answer 'N/A' if decision did not change to Profile Refresh during risk review. "
            "If it did change: flag for human validation."
        ),
    ),

    # ── Image 1 · Row 15 ─────────────────────────────────────────────────────
    EDRQuestion(
        number=14,
        category="Initiation of Decision Execution",
        question=(
            "Increase Risk Rating: Validate if the Risk Rating Override request was referred "
            "to the appropriate process for execution."
        ),
        validation=(
            "If the decision changed during risk review, a risk rating override request present "
            "in the risk rating override Actimize workflow for this event."
        ),
        check=(
            "If the recommended action is 'Increase Risk Rating', then navigate to the History "
            "tab in Actimize and identify the activity where the RRO # is generated. "
            "If that's done then mark this question as 'Y', otherwise send email to the "
            "appropriate group for confirmation.\n\n"
            "In case the risk rating is amended in L2 review, then the final rating should be "
            "mentioned with the RRO #.\n"
            "If it is not 'Increase Risk Rating' then 'N/A'."
        ),
        notes="",
        depends_on=(11,),
        output_hint=(
            "Answer 'Y', 'N/A', or flag for human confirmation. "
            "Check History tab for RRO # if Increase Risk Rating applies after decision change."
        ),
    ),

    # ── Image 1 · Row 16 ─────────────────────────────────────────────────────
    EDRQuestion(
        number=15,
        category="Initiation of Decision Execution",
        question=(
            "Exit Decision: Validate if customer exit request was referred to the "
            "appropriate process for execution."
        ),
        validation=(
            "If the decision changed during risk review, the Exit referred to the appropriate "
            "group and evidence provided to QA."
        ),
        check=(
            "If the recommended action is 'Exit Decision', then leave this validation blank "
            "for the human to validate / send an email to the appropriate group for the exit report.\n"
            "If it is not 'Exit Decision' then 'N/A'."
        ),
        notes="",
        depends_on=(12,),
        output_hint=(
            "Answer 'N/A' if decision did not change to Exit Decision during risk review. "
            "If it did change: flag for human validation."
        ),
    ),
)

# Fast lookup
EDR_QUESTION_MAP: dict[int, EDRQuestion] = {q.number: q for q in EDR_QUESTIONS}

# Category groupings for reporting
CATEGORIES: tuple[str, ...] = (
    "Event Creation",
    "Level 1 Review (Priority FC Business)",
    "Level 2 Review",
    "Initiation of Decision Execution",
)
