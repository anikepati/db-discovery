# Q11 Full Reference — Initiation of Decision Execution

## Question

Is a risk rating override request present in the risk rating override Actimize workflow for this event.

## Validation

Check rro_number presence for Increase Risk Rating actions.

## Check Logic (apply exactly)

If final_recommended_action = 'Increase Risk Rating':   If rro_number is populated: Y.   If rro_number is blank: NEEDS_HUMAN. If risk_rating_amended_in_l2 = True: confirm final_risk_rating is stated with rro_number. Else: N/A.

## Depends On

Q06, Q07

## Output Hint

State final_recommended_action, rro_number (populated or blank), risk_rating_amended_in_l2. Answer Y, NEEDS_HUMAN, or N/A.

## Requires Human Review

No — answer should be Y, N, or N/A only.

## DB Fields

- `final_recommended_action`
- `rro_number`
- `risk_rating_amended_in_l2`
- `final_risk_rating`

## Authorization Grid (relevant for Q2, Q3, Q5, Q8)

See `skills/edr-ingest/references/schema.md` for the full authorization grid
mapping EDR type + brokerage type → authorized recommending groups.
