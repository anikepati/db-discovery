---
name: edr-q04
description: >
  EDR QA Question 4 of 15 (Level 1 Review (Priority FC Business)): Validate the recommendation rationale aligns with risk action recommendation type..
  Reads EDR data from context.state, reasons using Claude claude-sonnet-4-6, writes
  answer to context.state["answers"]["q4"]. Use only in EDR QA pipeline.
license: Proprietary
metadata:
  author: edr-qa-team
  version: "5.0"
  pipeline: edr-qa-v5
  question_number: "4"
  category: "Level 1 Review (Priority FC Business)"
  requires_human: "false"
compatibility: Requires ADK ToolContext, Anthropic API, context.state with edr_data populated
allowed-tools: get_edr_data get_prior_answers answer_question store_answer
---

# EDR QA — Question 4: Level 1 Review (Priority FC Business)

**Validate the recommendation rationale aligns with risk action recommendation type.**

## Dependencies

Depends on: Q01, Q02

Prior answers for dependent questions MUST be in `context.state["answers"]` before this agent runs.

## Steps

1. Call `get_edr_data()` — reads `context.state["edr_data"]` (populated by IngestAgent)
2. Call `get_prior_answers()` — reads `context.state["answers"]` for dependent Q answers
3. Call `answer_question(question_number=4, edr_data=<step1>, prior_answers=<step2>)`
   - This calls Claude claude-sonnet-4-6 with the check logic and EDR data
   - Returns: `answer`, `reasoning`, `requires_human`, `human_action`
4. Call `store_answer(question_number=4, answer=..., reasoning=..., ...)` 
   - Writes to `context.state["answers"]["q4"]`
5. Respond with exactly:

```
Q04 [Level 1 Review (Priority FC Business)]: <answer>
REASONING: <1-2 sentence summary>
```

## Check Logic

```
If event_type != 'Priority FC Business Approval': answer N/A. Else assess whether l1_rationale aligns with l1_recommended_action. If aligned: Y. Else: N.
```

## Validation

Assess L1 Recommended Action vs L1 Rationale alignment.

## Output Format

State event_type, l1_recommended_action, l1_rationale, alignment. Answer Y, N, or N/A.

Valid answers: `Y` | `N` | `N/A` | `NEEDS_HUMAN`

## DB Fields Used

| Column | Notes |
|--------|-------|
| `event_type` |
| `l1_recommended_action` |
| `l1_rationale` |

## Gotchas

- Always call `get_edr_data()` first — never use stale data from a prior step.
- Always call `get_prior_answers()` before `answer_question` — dependency answers may affect the result.
- Never skip this question even if a dependency answered N or NEEDS_HUMAN.
- Do NOT write to `context.state` directly — use `store_answer` tool only.
- See [references/question.md](references/question.md) for full question text and validation grid.
