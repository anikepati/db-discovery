# Q15 Full Reference — Initiation of Decision Execution

## Question

Exit Decision: Validate if customer exit request was referred to the appropriate process for execution.

## Validation

Human must validate if decision changed to Exit Decision during review.

## Check Logic (apply exactly)

If final_recommended_action changed to 'Exit Decision' during risk review:   NEEDS_HUMAN — human must validate referral to appropriate process. Else: N/A.

## Depends On

Q12

## Output Hint

If decision changed to Exit Decision: NEEDS_HUMAN. Else N/A.

## Requires Human Review

Yes — if condition applies, answer must be NEEDS_HUMAN with HUMAN_ACTION specified.

## DB Fields

- `final_recommended_action`
- `recommended_action`
- `l2_action`

## Authorization Grid (relevant for Q2, Q3, Q5, Q8)

See `skills/edr-ingest/references/schema.md` for the full authorization grid
mapping EDR type + brokerage type → authorized recommending groups.
