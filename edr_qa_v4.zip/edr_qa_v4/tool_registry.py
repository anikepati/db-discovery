"""
tool_registry.py
----------------
Single source of truth for all YAML-backed EDR tool sets.

Mirrors the AgentMCP pattern exactly — one ToolConfig per agent,
each pointing to a YAML file.

EDR-specific addition:
  Each ToolConfig carries the yaml_path so the agent builder can
  pass the shared RunState into YAMLFunctionRuntime at construction
  time. This wires all edr_state tools to the same per-run dict.

To add a new EDR stage:
  1. Create tools/<stage>_tools.yaml
  2. Add a ToolConfig entry below
  3. Nothing else changes.
"""

from dataclasses import dataclass


@dataclass
class ToolConfig:
    name:        str   # agent name
    yaml_path:   str   # path to yaml tool definition
    description: str   # shown to orchestrator for routing decisions
    instruction: str   # system prompt for this specialist agent


EDR_TOOL_REGISTRY: list[ToolConfig] = [

    ToolConfig(
        name="ingest_agent",
        yaml_path="tools/edr_ingest_tools.yaml",
        description=(
            "Fetches the EDR record for a given ECN from Actimize "
            "(REST API or database) and stores it in shared run state "
            "for all QA agents to access."
        ),
        instruction=(
            "You are the EDR Ingest Agent. Your job is to fetch the EDR "
            "data for the given ECN and store it in shared state.\n\n"
            "Steps:\n"
            "1. Call fetch_edr_data_api with the ecn_id from your input.\n"
            "   If that fails, fall back to fetch_edr_data_db.\n"
            "2. Call store_edr_data with the fetched data.\n"
            "3. Call get_edr_data to confirm it was stored.\n"
            "4. Respond with a brief structured summary:\n"
            "   INGEST OK\n"
            "   ECN: <ecn_id>\n"
            "   Event Type: <event_type>\n"
            "   Brokerage Type: <brokerage_type>\n"
            "   Recommended Action: <recommended_action>\n"
            "   L2 Decision: <l2_decision>\n"
            "   Elevated Approval: <elevated_approval_required>\n"
            "   RRO Number: <rro_number or none>\n\n"
            "Do not analyse or evaluate the data. QA agents do that."
        ),
    ),

    ToolConfig(
        name="qa_reasoning_agent",
        yaml_path="tools/edr_qa_tools.yaml",
        description=(
            "Answers all 15 EDR QA questions in order (Q1→Q15) by reading "
            "EDR data and prior answers from shared run state, calling "
            "Claude claude-sonnet-4-6 for each question, and storing answers back into state."
        ),
        instruction=(
            "You are the EDR QA Reasoning Agent. Answer all 15 EDR QA "
            "questions in order from 1 to 15. Do not skip any question.\n\n"
            "For each question N (1 → 15):\n"
            "1. Call get_edr_data to read the EDR record.\n"
            "2. Call get_prior_answers to read all answers stored so far.\n"
            "3. Call answer_question with:\n"
            "   - question_number: N\n"
            "   - edr_data: the EDR record from step 1\n"
            "   - prior_answers: the answers dict from step 2\n"
            "4. Call store_answer with the result from step 3.\n"
            "5. Print one line: Q<N> [<category>]: <answer>\n"
            "6. Move to N+1 regardless of the answer.\n\n"
            "When all 15 are done, respond:\n"
            "  REASONING COMPLETE — 15/15\n"
            "  Q01: <answer> ... Q15: <answer>\n\n"
            "Rules:\n"
            "- Always call in order 1 → 15. Never skip or reorder.\n"
            "- Never stop early due to FAIL or NEEDS_HUMAN.\n"
            "- Do not interpret or summarise — ReportAgent does that."
        ),
    ),

    ToolConfig(
        name="report_agent",
        yaml_path="tools/edr_report_tools.yaml",
        description=(
            "Reads all 15 answers from shared run state, computes the "
            "final QA verdict and pass rate, and writes the structured "
            "JSON result file."
        ),
        instruction=(
            "You are the EDR QA Report Agent. Build the final QA report.\n\n"
            "Steps:\n"
            "1. Call get_all_answers to read all stored QA answers.\n"
            "2. Call get_edr_data to read the EDR record.\n"
            "3. Call build_report with:\n"
            "   - answers: the answers dict from step 1\n"
            "   - edr_data: the EDR record from step 2\n"
            "   - output_path: from your input\n"
            "4. Call store_verdict with the verdict and pass rate.\n"
            "5. Respond:\n"
            "   REPORT WRITTEN\n"
            "   Path:    <output_path>\n"
            "   Verdict: <verdict>\n"
            "   Pass:    <overall_pass_rate>%\n"
            "   Failed:  <failed_questions or none>\n"
            "   Human:   <human_review_count> items\n\n"
            "Do not summarise individual answers — the JSON is the full output."
        ),
    ),
]
