"""Domain models for EDR QA v5."""

from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime
from enum import Enum


class QAAnswer(str, Enum):
    YES         = "Y"
    NO          = "N"
    NA          = "N/A"
    NEEDS_HUMAN = "NEEDS_HUMAN"

    @classmethod
    def from_string(cls, raw: str) -> "QAAnswer":
        v = raw.strip().upper()
        return {
            "Y": cls.YES, "YES": cls.YES,
            "N": cls.NO,  "NO":  cls.NO,
            "N/A": cls.NA, "NA": cls.NA,
            "NEEDS_HUMAN": cls.NEEDS_HUMAN,
        }.get(v, cls.NEEDS_HUMAN)


class Verdict(str, Enum):
    PASS                  = "PASS"
    FAIL                  = "FAIL"
    PASS_WITH_EXCEPTIONS  = "PASS_WITH_EXCEPTIONS"
    REQUIRES_HUMAN_REVIEW = "REQUIRES_HUMAN_REVIEW"

    @property
    def passed(self) -> bool:
        return self in (Verdict.PASS, Verdict.PASS_WITH_EXCEPTIONS)

    @classmethod
    def from_string(cls, raw: str) -> "Verdict":
        try:
            return cls(raw.strip().upper().replace(" ", "_"))
        except ValueError:
            return cls.REQUIRES_HUMAN_REVIEW


@dataclass
class QuestionResult:
    number:         int
    category:       str
    answer:         QAAnswer
    reasoning:      str
    requires_human: bool = False
    human_action:   str  = ""


@dataclass
class EDRQAResult:
    run_id:             str
    ecn_id:             str
    verdict:            Verdict
    overall_pass_rate:  float
    question_results:   list[QuestionResult]
    failed_questions:   list[int]
    human_review_items: list[dict]
    output_path:        str
    audit_path:         str
    started_at:         datetime
    completed_at:       datetime
    duration_seconds:   float

    @property
    def passed(self) -> bool:
        return self.verdict.passed

    def one_line(self) -> str:
        return (
            f"[{self.verdict.value}] {self.ecn_id} | "
            f"pass:{self.overall_pass_rate:.1f}% | "
            f"failed:Q{self.failed_questions} | "
            f"human:{len(self.human_review_items)} | "
            f"{self.duration_seconds:.1f}s"
        )
