# Q08 Full Reference — Level 2 Review

## Question

Validate Level 2 Rationale does not list incorrect group that made recommendation.

## Validation

Confirm L2 rationale references the correct L1 recommending group.

## Check Logic (apply exactly)

l2_rationale should reference l1_recommended_action or the authorized recommending_group for this event_type/brokerage_type. If correct group referenced: Y. Else: N.

## Depends On

Q06, Q07

## Output Hint

Identify group mentioned in l2_rationale. Confirm it matches authorized group per EDR type/brokerage. Answer Y or N.

## Requires Human Review

No — answer should be Y, N, or N/A only.

## DB Fields

- `l2_rationale`
- `recommending_group`
- `event_type`
- `brokerage_type`
- `l1_recommended_action`

## Authorization Grid (relevant for Q2, Q3, Q5, Q8)

See `skills/edr-ingest/references/schema.md` for the full authorization grid
mapping EDR type + brokerage type → authorized recommending groups.
