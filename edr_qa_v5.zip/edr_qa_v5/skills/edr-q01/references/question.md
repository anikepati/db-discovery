# Q01 Full Reference — Event Creation

## Question

Validate the event description is complete for purposes of review.

## Validation

Match ECN #, Event Type & Subtype, and Workflow Status against Input File fields.

## Check Logic (apply exactly)

Compare ecn_number vs input_file_ecn, event_type vs input_file_event_type, workflow_status vs input_file_workflow_status. If ALL 3 match: Y. If any mismatch: N.

## Depends On

None (first question in chain)

## Output Hint

State each of the 3 field comparisons explicitly then give Y or N.

## Requires Human Review

No — answer should be Y, N, or N/A only.

## DB Fields

- `ecn_number`
- `event_type`
- `event_subtype`
- `workflow_status`
- `input_file_ecn`
- `input_file_event_type`
- `input_file_workflow_status`

## Authorization Grid (relevant for Q2, Q3, Q5, Q8)

See `skills/edr-ingest/references/schema.md` for the full authorization grid
mapping EDR type + brokerage type → authorized recommending groups.
