"""
VerdictSynthesizerAgent — reads all 15 answers and produces the final QA report JSON.
"""

import logging

from google.adk.agents import LlmAgent

from config import settings

logger = logging.getLogger(__name__)

_ANSWER_KEYS = "\n".join(f"  - answer_q{i}" for i in range(1, 16))

_INSTRUCTION = f"""
You are the EDR QA Verdict Synthesizer.

Read all 15 QA answers from session state and produce a final structured JSON report.

## Session State Keys
{_ANSWER_KEYS}

## Output
Respond with ONLY a valid JSON object. No markdown fences, no preamble.

{{
  "verdict": "PASS" | "FAIL" | "PASS_WITH_EXCEPTIONS" | "REQUIRES_HUMAN_REVIEW",
  "overall_pass_rate": <float 0–100, counting Y as pass, N as fail, N/A and NEEDS_HUMAN excluded from denominator>,
  "summary": "<3–4 sentence plain-English summary for a QA supervisor>",
  "category_results": {{
    "Event Creation": {{
      "questions": [1, 2, 3],
      "pass": <int>,
      "fail": <int>,
      "na": <int>,
      "needs_human": <int>
    }},
    "Level 1 Review": {{
      "questions": [4, 5],
      "pass": <int>, "fail": <int>, "na": <int>, "needs_human": <int>
    }},
    "Level 2 Review": {{
      "questions": [6, 7, 8, 9],
      "pass": <int>, "fail": <int>, "na": <int>, "needs_human": <int>
    }},
    "Initiation of Decision Execution": {{
      "questions": [10, 11, 12, 13, 14, 15],
      "pass": <int>, "fail": <int>, "na": <int>, "needs_human": <int>
    }}
  }},
  "failed_questions": [<list of question numbers that answered N>],
  "human_review_required": [
    {{
      "question": <int>,
      "action_required": "<what the human must do>"
    }}
  ],
  "qa_findings": [
    {{
      "question": <int>,
      "category": "<category name>",
      "answer": "Y|N|N/A|NEEDS_HUMAN",
      "key_finding": "<one sentence>"
    }}
  ]
}}

## Verdict Rules
- PASS:                   pass_rate = 100%, zero NEEDS_HUMAN items
- PASS_WITH_EXCEPTIONS:   pass_rate >= 80%, zero N answers, only N/A or NEEDS_HUMAN exceptions
- REQUIRES_HUMAN_REVIEW:  any NEEDS_HUMAN answer present (regardless of pass rate)
- FAIL:                   any N answer present

Derive all values strictly from the answers provided. Do not invent data.
"""


def create_verdict_synthesizer_agent() -> LlmAgent:
    return LlmAgent(
        name="VerdictSynthesizerAgent",
        model=settings.model,
        instruction=_INSTRUCTION,
        tools=[],
        output_key="verdict_json",
        description="Synthesises all 15 EDR QA answers into a structured JSON verdict.",
    )
