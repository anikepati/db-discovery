"""
tool_registry.py
----------------
17 ToolConfig entries — one per sub-agent in the SequentialAgent pipeline.

Execution order = registry order:
  [0]     ingest_agent       — Gemini Flash, sql tool
  [1-15]  q01..q15_agent     — Claude claude-sonnet-4-6, tools from YAML (empty by default)
  [16]    report_agent       — Claude claude-sonnet-4-6, python build_report tool

Instructions for Q agents are auto-generated from questions.py so the
full question definition (text, check logic, validation, depends_on,
requires_human) is always in sync with the source of truth.

To change anything:
  - Question logic      → edit questions.py → python tool_generator.py
  - Agent behaviour     → edit instruction builders below
  - Add a tool to Q{N}  → add to Q_EXTRA_TOOLS in tool_generator.py
  - Swap model          → change QA_MODEL / INGEST_MODEL constants
  Zero Python code changes needed for any of the above.
"""

from dataclasses import dataclass, field
from pathlib import Path

from questions import EDR_QUESTIONS, EDRQuestion

ORCHESTRATOR_MODEL = "gemini-2.0-flash"
INGEST_MODEL       = "gemini-2.0-flash"
QA_MODEL           = "claude-sonnet-4-6"


@dataclass
class ToolConfig:
    name:        str
    yaml_path:   str
    description: str
    instruction: str
    model:       str = field(default=ORCHESTRATOR_MODEL)


# ── IngestAgent ───────────────────────────────────────────────────────────────

def _ingest_config() -> ToolConfig:
    return ToolConfig(
        name="ingest_agent",
        yaml_path="tools/edr_ingest_tools.yaml",
        model=INGEST_MODEL,
        description=(
            "Fetches the complete EDR record for a given ECN from the "
            "Actimize MS SQL view vw_get_qa_actimize_data. Outputs the full "
            "record as structured text into the conversation for all Q agents."
        ),
        instruction="""You are the EDR Ingest Agent.

Your job: fetch the EDR record for the given ECN and output it clearly
so all downstream Q agents can read it from the conversation history.

Steps:
1. Call fetch_edr_data with the ecn_id from your input.
2. If the result is empty or contains an error — respond:
   INGEST FAILED: <reason>
   Then stop.
3. Format and output the full EDR record as structured text:

   INGEST OK
   ══════════════════════════════════════════
   ECN RECORD: <ecn_number>
   ══════════════════════════════════════════
   Event Type:                  <event_type>
   Event Subtype:               <event_subtype>
   Workflow Status:             <workflow_status>
   Brokerage Type:              <brokerage_type>
   Event Description:           <event_description>

   Recommended Action:          <recommended_action>
   Recommended Rationale:       <recommended_rationale>
   Recommending Group:          <recommending_group>

   Input File ECN:              <input_file_ecn>
   Input File Event Type:       <input_file_event_type>
   Input File Workflow Status:  <input_file_workflow_status>

   L1 Recommended Action:       <l1_recommended_action>
   L1 Rationale:                <l1_rationale>
   L1 Reviewer Group:           <l1_reviewer_group>

   L2 Decision:                 <l2_decision>
   L2 Action:                   <l2_action>
   L2 Rationale:                <l2_rationale>
   L2 LOB:                      <l2_lob>
   L2 Multiple Rows:            <l2_multiple_rows>

   Elevated Approval Required:  <elevated_approval_required>
   Elevated Approval Decision:  <elevated_approval_decision>
   Elevated Approval Rationale: <elevated_approval_rationale>

   Final Recommended Action:    <final_recommended_action>
   RRO Number:                  <rro_number>
   Risk Rating Amended in L2:   <risk_rating_amended_in_l2>
   Final Risk Rating:           <final_risk_rating>
   ══════════════════════════════════════════

Rules:
- Output every field, even if blank (write "none" for empty values).
- Do not analyse or evaluate the data. Q agents do that.
- This output is the only source of EDR data for all 15 Q agents.
""",
    )


# ── Q Agent instruction builder ───────────────────────────────────────────────

def _build_q_instruction(q: EDRQuestion) -> str:
    dep_str = ", ".join(f"Q{d}" for d in q.depends_on) if q.depends_on else "none"

    dep_note = (
        f"\nThis question depends on: {dep_str}.\n"
        f"The answers for those questions are already in the conversation history above.\n"
        f"Review them before applying the check logic.\n"
        if q.depends_on else
        "\nThis is the first question — no prior answers needed.\n"
    )

    human_block = ""
    if q.requires_human:
        human_block = """
⚠️  HUMAN REVIEW REQUIRED:
If the condition in the Check Logic applies:
  answer:         NEEDS_HUMAN
  requires_human: true
  human_action:   the exact action (which team to email, which report to request)
Only answer N/A if the condition clearly does NOT apply to this EDR record.
"""

    notes_block = f"\nNotes / Examples:\n{q.notes}\n" if q.notes else ""

    return f"""You are the EDR QA Agent for Question {q.number} of 15.
Category: {q.category}
Depends on: {dep_str}
{dep_note}
══════════════════════════════════════════════
QUESTION {q.number}: {q.question}
══════════════════════════════════════════════

What to Validate:
{q.validation}

Check Logic (apply precisely — do not deviate):
{q.check}
{notes_block}{human_block}
══════════════════════════════════════════════
STEPS — follow in exact order:
══════════════════════════════════════════════

1. READ the EDR record from the conversation history above (output by IngestAgent).
   If the EDR record is not in the conversation: respond
   Q{q.number:02d} [ERROR]: EDR data not found in conversation history.

2. READ prior answers from the conversation history if depends_on is not none.
   Locate the outputs of {dep_str if q.depends_on else "no prior agents"}.

3. REASON about Question {q.number}:
   - Apply the Check Logic above to the actual field values from the EDR record.
   - Reference specific field values by name.
     e.g. "event_type = Priority FC Business Approval, therefore..."
   - Work step by step — minimum 3 sentences.
   - Arrive at exactly one of: Y | N | N/A | NEEDS_HUMAN

4. RESPOND in exactly this format:
   Q{q.number:02d} [{q.category}]
   ANSWER: <Y | N | N/A | NEEDS_HUMAN>
   REASONING: <full step-by-step reasoning referencing field values>{"" if not q.requires_human else chr(10) + "   HUMAN_ACTION: <exact action for reviewer>"}
   REQUIRES_HUMAN: <true | false>
   CATEGORY: {q.category}

══════════════════════════════════════════════
RULES:
- Only answer Question {q.number}. Never answer any other question number.
- Never fabricate field values. Only use what is in the EDR record above.
- Always output the full structured response format — downstream agents parse it.
- If EDR record is missing a field, note it in reasoning and answer NEEDS_HUMAN.
"""


# ── Q Agent ToolConfig ────────────────────────────────────────────────────────

def _question_config(q: EDRQuestion) -> ToolConfig:
    dep_str = f"Q{list(q.depends_on)}" if q.depends_on else "none"
    return ToolConfig(
        name=f"q{q.number:02d}_agent",
        yaml_path=f"tools/edr_q{q.number:02d}_tools.yaml",
        model=QA_MODEL,
        description=(
            f"Answers EDR QA Question {q.number} ({q.category}). "
            f"Reads EDR data and prior answers from conversation history. "
            f"Depends on: {dep_str}."
        ),
        instruction=_build_q_instruction(q),
    )


# ── ReportAgent ───────────────────────────────────────────────────────────────

def _report_config() -> ToolConfig:
    return ToolConfig(
        name="report_agent",
        yaml_path="tools/edr_report_tools.yaml",
        model=QA_MODEL,
        description=(
            "Reads all 15 QA answers from conversation history, calls "
            "build_report to compute the final verdict and write the JSON report."
        ),
        instruction="""You are the EDR QA Report Agent.

Your job: collect all 15 answers from the conversation history above
and call build_report to write the final JSON verdict file.

Steps:
1. READ the conversation history. Find the output of every Q agent (Q01..Q15).
   Each Q agent responded in the format:
     Q{N} [Category]
     ANSWER: Y | N | N/A | NEEDS_HUMAN
     REASONING: ...
     REQUIRES_HUMAN: true | false
     CATEGORY: ...

2. READ the ECN RECORD section from IngestAgent's output to get edr_data.

3. CONSTRUCT the answers dict exactly:
   {
     "q1":  {"answer": "Y",  "reasoning": "...", "requires_human": false, "human_action": "", "category": "Event Creation"},
     "q2":  {"answer": "N/A","reasoning": "...", "requires_human": false, "human_action": "", "category": "Event Creation"},
     ...
     "q15": {"answer": "...", ...}
   }
   If any Q agent is missing from the conversation, include it as:
     {"answer": "NEEDS_HUMAN", "reasoning": "Agent did not respond", "requires_human": true,
      "human_action": "Q{N} not answered — manual review required", "category": ""}

4. CONSTRUCT the edr_data dict from the ECN RECORD in the conversation:
   {"ecn_number": "...", "event_type": "...", "brokerage_type": "...",
    "final_recommended_action": "..."}

5. Call build_report with:
   - answers:     the answers dict from step 3
   - edr_data:    the edr_data dict from step 4
   - output_path: from your input

6. Respond:
   REPORT WRITTEN
   Path:    <output_path>
   Verdict: <verdict>
   Pass:    <overall_pass_rate>%
   Failed:  <failed_questions or none>
   Human:   <human_review_count> items requiring action

Rules:
- Collect ALL 15 answers before calling build_report.
- Never fabricate answers — only use what Q agents actually output.
- If build_report returns an error: respond "REPORT FAILED: <error>".
""",
    )


# ── Public API ────────────────────────────────────────────────────────────────

def build_registry() -> list[ToolConfig]:
    """17-entry registry in SequentialAgent execution order."""
    registry: list[ToolConfig] = [_ingest_config()]
    for q in EDR_QUESTIONS:
        registry.append(_question_config(q))
    registry.append(_report_config())
    return registry


def validate_yaml_files(registry: list[ToolConfig]) -> None:
    missing = [c.yaml_path for c in registry if not Path(c.yaml_path).exists()]
    if missing:
        raise FileNotFoundError(
            "Missing YAML files (run: python tool_generator.py):\n"
            + "\n".join(f"  {p}" for p in missing)
        )
