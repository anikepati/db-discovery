"""
EDR QA Question Registry
========================
Single source of truth for all 15 questions, transcribed verbatim from
the EDR QA spreadsheet (columns E–H of your images).

Each EDRQuestion carries:
  number         — 1-based execution order
  category       — the 4 process stages from the spreadsheet
  question       — column E  (the QA question text)
  validation     — column F  (what to check / how to validate)
  check          — column G  (exact Y / N / N/A decision rules)
  notes          — column H  (examples and extra guidance)
  depends_on     — tuple of prior question numbers whose answers must
                   be in context before this question is answered
  requires_human — True when the check logic explicitly says
                   "leave blank for the human to validate"

To add, remove, or change a question: edit ONLY this file.
The 3-agent pipeline (IngestAgent → QAReasoningAgent → ReportAgent)
reads from EDR_QUESTIONS and adapts automatically.
"""

from dataclasses import dataclass, field


@dataclass(frozen=True)
class EDRQuestion:
    number:         int
    category:       str
    question:       str
    validation:     str
    check:          str
    notes:          str
    depends_on:     tuple[int, ...]
    requires_human: bool = False
    output_hint:    str  = "Answer Y, N, or N/A with clear justification."


# ─────────────────────────────────────────────────────────────────────────────
# ALL 15 QUESTIONS — verbatim from your spreadsheet images
# ─────────────────────────────────────────────────────────────────────────────

EDR_QUESTIONS: tuple[EDRQuestion, ...] = (

    # ── Category 1: Event Creation ────────────────────────────────────────────

    EDRQuestion(
        number=1,
        category="Event Creation",
        question=(
            "Validate the event description is complete for purposes of review."
        ),
        validation=(
            "Check if the Event Description provided is complete in Actimize by "
            "selecting the reviewing ECN/Sample ID on EDR Script under Event "
            "Closed Status tab."
        ),
        check=(
            "Match the below fields on Actimize with the Input File:\n"
            "1. ECN #\n"
            "2. Event Type & Subtype\n"
            "3. Workflow Status\n"
            "If all the above match: 'Yes', otherwise 'No'."
        ),
        notes="",
        depends_on=(),
        output_hint=(
            "Answer Yes or No. List each of the 3 fields (ECN #, Event Type & "
            "Subtype, Workflow Status) and state whether each one matched."
        ),
    ),

    EDRQuestion(
        number=2,
        category="Event Creation",
        question=(
            "If EDR event type is not Priority FC Business Referral, validate the "
            "recommendation rationale aligns with risk action recommendation type."
        ),
        validation=(
            "If the Event Type is anything apart from Priority FC Business Referral, "
            "ensure that the recommended action and the rationale aligns with each other."
        ),
        check=(
            "If EDR Type = 'Priority FC Business Approval', then 'N/A'.\n"
            "If EDR Type = anything other than Priority FC Business Approval, "
            "then assess the 'Recommended Action' and 'Rationale' on Actimize. "
            "Both should be aligned.\n"
            "If aligned then 'Y', otherwise 'N'."
        ),
        notes=(
            "Example:\n"
            "Recommended Action - No further Action Required.\n"
            "In this case the rationale must also state the same thing."
        ),
        depends_on=(1,),
        output_hint=(
            "Answer Y, N, or N/A. State the EDR type, the recommended action, "
            "the rationale text, and whether they align."
        ),
    ),

    EDRQuestion(
        number=3,
        category="Event Creation",
        question=(
            "If EDR event type is not Priority FC Business Referral, validate the "
            "recommendation rationale aligns with the event description."
        ),
        validation=(
            "If the Event Type is anything apart from Priority FC Business Referral, "
            "ensure that the rationale and the event description aligns with each other."
        ),
        check=(
            "If EDR Type = 'Priority FC Business Approval', then 'N/A'.\n"
            "If EDR Type = anything other than Priority FC Business Approval, "
            "then assess if the 'Recommended Rationale' has come from an authorized "
            "group (as per the grid below).\n"
            "If aligned then 'Y', otherwise 'N'."
        ),
        notes=(
            "Example:\n"
            "If the EDR is 'Priority FC Business Referral' and the Brokerage type "
            "is 'Non-brokerage', then the group making recommendation should be 'TRIG'.\n"
            "The rationale will be - TRIG recommends no further action."
        ),
        depends_on=(1, 2),
        output_hint=(
            "Answer Y, N, or N/A. Identify EDR type, brokerage type, recommending "
            "group, and whether the rationale aligns with the event description."
        ),
    ),

    # ── Category 2: Level 1 Review (Priority FC Business) ────────────────────

    EDRQuestion(
        number=4,
        category="Level 1 Review (Priority FC Business)",
        question=(
            "Validate the recommendation rationale aligns with risk action "
            "recommendation type."
        ),
        validation=(
            "Ensure that the recommended action and the rationale aligns with each other."
        ),
        check=(
            "If EDR Type = anything other than Priority FC Business Approval, then 'N/A'.\n"
            "If EDR Type = Priority FC Business Approval, then assess the "
            "'Recommended Action' and 'Rationale' on Actimize. Both should be aligned.\n"
            "If aligned then 'Y' otherwise 'N'."
        ),
        notes=(
            "Example:\n"
            "Recommended Action - No further Action Required.\n"
            "In this case the rationale must also state the same thing."
        ),
        depends_on=(1, 2),
        output_hint=(
            "Answer Y, N, or N/A. Confirm EDR type, L1 recommended action, "
            "L1 rationale, and their alignment."
        ),
    ),

    EDRQuestion(
        number=5,
        category="Level 1 Review (Priority FC Business)",
        question=(
            "Validate the recommendation rationale is reasonable based on the "
            "details of the event description."
        ),
        validation=(
            "Ensure that the provided rationale and the event description aligns "
            "with each other."
        ),
        check=(
            "If EDR Type = anything other than Priority FC Business Approval, then 'N/A'.\n"
            "If EDR Type = Priority FC Business Approval, then assess if the "
            "'Recommended Rationale' has come from an authorized group "
            "(as per the grid below).\n"
            "If aligned then 'Y' otherwise 'N'."
        ),
        notes=(
            "Example:\n"
            "If the EDR is 'Priority FC Business Referral' and the Brokerage type "
            "is 'Non-brokerage', then the group making recommendation should be 'TRIG'.\n"
            "The rationale will be - TRIG recommends no further action."
        ),
        depends_on=(1, 4),
        output_hint=(
            "Answer Y, N, or N/A. State EDR type, brokerage type, recommending "
            "group, and rationale alignment with the event description."
        ),
    ),

    # ── Category 3: Level 2 Review ────────────────────────────────────────────

    EDRQuestion(
        number=6,
        category="Level 2 Review",
        question=(
            "Validate the decision rationale aligns with the risk decision type."
        ),
        validation=(
            "Decision rationale provided by the business should align with the "
            "decision type."
        ),
        check=(
            "Assess if L2 approval rationale should align to recommended Action.\n\n"
            "If the L2 Decision is 'Accept', then L2 action would be blank and the "
            "rationale will align to the L1 rationale/recommended action.\n\n"
            "If the L2 Decision is 'Amend', then the L2 action will have the action "
            "mentioned in this field.\n\n"
            "In case there are multiple rows for L2 review in Actimize, then check "
            "for the LOB value and then select the row with the required LOB value.\n"
            "If aligned then 'Y' otherwise 'N'."
        ),
        notes=(
            "Example:\n"
            "Recommended Action - No further Action Required.\n"
            "In this case the L2 rationale must also state the same thing and "
            "align with L1 rationale."
        ),
        depends_on=(4, 5),
        output_hint=(
            "Answer Y or N. State L2 decision type (Accept/Amend), L2 action field "
            "value, L1 rationale, and whether they align. If multiple L2 rows exist, "
            "note which LOB row was selected."
        ),
    ),

    EDRQuestion(
        number=7,
        category="Level 2 Review",
        question=(
            "Validate the decision rationale is reasonable based on the details of "
            "the event description."
        ),
        validation=(
            "Decision rationale provided by business in Level 2 should align with "
            "the event description."
        ),
        check=(
            "Assess if L2 approval rationale should align to recommended Action.\n\n"
            "If the L2 Decision is 'Accept', then L2 action would be blank and the "
            "rationale will align to the L1 recommended action."
        ),
        notes="",
        depends_on=(5, 6),
        output_hint=(
            "Answer Y or N. Confirm L2 rationale aligns with the event description "
            "and L1 recommended action."
        ),
    ),

    EDRQuestion(
        number=8,
        category="Level 2 Review",
        question=(
            "Validate Level 2 Rationale does not list incorrect group that made "
            "recommendation."
        ),
        validation=(
            "Based on the above grid, either ensure no reference is made to "
            "recommending group, or the correct group is referenced in rationale, "
            "based on Event Type and Brokerage fields."
        ),
        check=(
            "The rationale should either state the L1 recommending group or L1 action "
            "recommended and the reason to amend the action.\n"
            "If aligned then 'Y', otherwise 'N'."
        ),
        notes="",
        depends_on=(6, 7),
        output_hint=(
            "Answer Y or N. Identify the group referenced in the L2 rationale and "
            "confirm it matches the authorized L1 recommending group per the "
            "EDR type / brokerage grid."
        ),
    ),

    EDRQuestion(
        number=9,
        category="Level 2 Review",
        question=(
            "Confirm if approver decision and rationale were obtained for elevated "
            "approvals."
        ),
        validation=(
            "Check for elevated approval decision is Accept."
        ),
        check=(
            "In case elevated approvals were required (if it mentions in Actimize), "
            "then assess if the elevated approval rationale is aligned.\n"
            "If the elevated approvals not updated/blank then 'N/A'.\n"
            "If aligned then 'Y', otherwise 'N'."
        ),
        notes="",
        depends_on=(6, 7, 8),
        output_hint=(
            "Answer Y, N, or N/A. State whether elevated approval was required, "
            "the decision recorded, and whether the rationale is aligned."
        ),
    ),

    # ── Category 4: Initiation of Decision Execution ──────────────────────────

    EDRQuestion(
        number=10,
        category="Initiation of Decision Execution",
        question=(
            "Is the profile refresh referred to the appropriate group and evidence "
            "provided to QA."
        ),
        validation=(
            "Profile Refresh: Validate if profile refresh request was referred to "
            "the appropriate process for execution (see below grid)."
        ),
        check=(
            "If the recommended action is 'Profile Refresh', then leave this "
            "validation blank for the human to validate / send an email to the "
            "appropriate group for the profile refresh report.\n"
            "If it is not 'Profile Refresh' then 'N/A'."
        ),
        notes="",
        depends_on=(6, 7),
        requires_human=True,
        output_hint=(
            "If final_recommended_action = 'Profile Refresh': answer NEEDS_HUMAN. "
            "State exactly which group the human must email and for which report.\n"
            "If not 'Profile Refresh': answer N/A."
        ),
    ),

    EDRQuestion(
        number=11,
        category="Initiation of Decision Execution",
        question=(
            "Is a risk rating override request present in the risk rating override "
            "Actimize workflow for this event (Actimize only)."
        ),
        validation=(
            "Increase Risk Rating: Validate if the Risk Rating Override request was "
            "referred to the appropriate process for execution (see below grid)."
        ),
        check=(
            "If the recommended action is 'Increase Risk Rating', then navigate to "
            "the History tab in Actimize and identify the activity where the RRO # "
            "is generated. If that's done then mark this question as 'Y', otherwise "
            "send email to the appropriate group for confirmation.\n\n"
            "In case the risk rating is amended in L2 review, then the final rating "
            "should be mentioned with the RRO #.\n"
            "If it is not 'Increase Risk Rating' then 'N/A'."
        ),
        notes="",
        depends_on=(6, 7),
        output_hint=(
            "If final_recommended_action = 'Increase Risk Rating':\n"
            "  - If rro_number is present in EDR data: answer Y and state the RRO #.\n"
            "  - If rro_number is blank: answer NEEDS_HUMAN — human must check "
            "    Actimize History tab.\n"
            "  - If risk_rating_amended_in_l2 = True: confirm final_risk_rating "
            "    is stated alongside the RRO #.\n"
            "If not 'Increase Risk Rating': answer N/A."
        ),
    ),

    EDRQuestion(
        number=12,
        category="Initiation of Decision Execution",
        question=(
            "Is the Exit referred to the appropriate group and evidence provided to QA."
        ),
        validation=(
            "Exit Decision: Validate if customer exit request was referred to the "
            "appropriate process for execution (see below grid)."
        ),
        check=(
            "If the recommended action is 'Exit Decision', then leave this validation "
            "blank for the human to validate / send an email to the appropriate group "
            "for the exit report.\n"
            "If it is not 'Exit Decision' then 'N/A'."
        ),
        notes="",
        depends_on=(6, 7),
        requires_human=True,
        output_hint=(
            "If final_recommended_action = 'Exit Decision': answer NEEDS_HUMAN. "
            "State exactly which group the human must email and for which report.\n"
            "If not 'Exit Decision': answer N/A."
        ),
    ),

    EDRQuestion(
        number=13,
        category="Initiation of Decision Execution",
        question=(
            "Profile Refresh: Validate if profile refresh request was referred to "
            "the appropriate process for execution."
        ),
        validation=(
            "If the decision changed during risk review, is the profile refresh "
            "referred to the appropriate group and evidence provided to QA."
        ),
        check=(
            "If the recommended action is 'Profile Refresh', then leave this "
            "validation blank for the human to validate / send an email to the "
            "appropriate group for the profile refresh report."
        ),
        notes="",
        depends_on=(10,),
        requires_human=True,
        output_hint=(
            "If the decision changed to 'Profile Refresh' during risk review: "
            "answer NEEDS_HUMAN and state the email action required.\n"
            "If the decision did not change to Profile Refresh: answer N/A."
        ),
    ),

    EDRQuestion(
        number=14,
        category="Initiation of Decision Execution",
        question=(
            "Increase Risk Rating: Validate if the Risk Rating Override request "
            "was referred to the appropriate process for execution."
        ),
        validation=(
            "If the decision changed during risk review, a risk rating override "
            "request present in the risk rating override Actimize workflow for "
            "this event."
        ),
        check=(
            "If the recommended action is 'Increase Risk Rating', then navigate "
            "to the History tab in Actimize and identify the activity where the "
            "RRO # is generated. If that's done then mark this question as 'Y', "
            "otherwise send email to the appropriate group for confirmation.\n\n"
            "In case the risk rating is amended in L2 review, then the final "
            "rating should be mentioned with the RRO #.\n"
            "If it is not 'Increase Risk Rating' then 'N/A'."
        ),
        notes="",
        depends_on=(11,),
        output_hint=(
            "If the decision changed to 'Increase Risk Rating' during risk review:\n"
            "  - Check rro_number. If present: Y.\n"
            "  - If blank: NEEDS_HUMAN — human must verify Actimize History tab.\n"
            "If not applicable: answer N/A."
        ),
    ),

    EDRQuestion(
        number=15,
        category="Initiation of Decision Execution",
        question=(
            "Exit Decision: Validate if customer exit request was referred to the "
            "appropriate process for execution."
        ),
        validation=(
            "If the decision changed during risk review, the Exit referred to the "
            "appropriate group and evidence provided to QA."
        ),
        check=(
            "If the recommended action is 'Exit Decision', then leave this validation "
            "blank for the human to validate / send an email to the appropriate group "
            "for the exit report.\n"
            "If it is not 'Exit Decision' then 'N/A'."
        ),
        notes="",
        depends_on=(12,),
        requires_human=True,
        output_hint=(
            "If the decision changed to 'Exit Decision' during risk review: "
            "answer NEEDS_HUMAN and state the email action required.\n"
            "If not applicable: answer N/A."
        ),
    ),
)

# ── Lookups ───────────────────────────────────────────────────────────────────

EDR_QUESTION_MAP: dict[int, EDRQuestion] = {q.number: q for q in EDR_QUESTIONS}

CATEGORIES: tuple[str, ...] = (
    "Event Creation",
    "Level 1 Review (Priority FC Business)",
    "Level 2 Review",
    "Initiation of Decision Execution",
)

HUMAN_REVIEW_QUESTION_NUMBERS: frozenset[int] = frozenset(
    q.number for q in EDR_QUESTIONS if q.requires_human
)
# → {10, 12, 13, 15}
