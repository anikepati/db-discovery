"""
QA Pipeline test suite.

Run:   pytest tests/ -v
Cover: pytest tests/ -v --cov=. --cov-report=term-missing
"""

import json
import sys
from datetime import datetime
from pathlib import Path
from unittest.mock import patch

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from agents.questions import QUESTIONS, QUESTION_MAP
from models import QAResult, QAVerdict, QuestionAnswer
from pipeline_runner import _parse_answer, _parse_verdict_json, _build_result
from tools import fetch_process_data


# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture
def valid_id():
    return "PROC-2024-001"

@pytest.fixture
def invalid_id():
    return "PROC-DOES-NOT-EXIST"

@pytest.fixture
def raw_process_data(valid_id):
    return json.loads(fetch_process_data(valid_id))


# ── fetch_process_data ────────────────────────────────────────────────────────

class TestFetchTool:

    def test_returns_ok_for_known_id(self, valid_id, raw_process_data):
        assert raw_process_data["status"] == "ok"
        assert raw_process_data["process_id"] == valid_id

    def test_returns_error_for_unknown_id(self, invalid_id):
        result = json.loads(fetch_process_data(invalid_id))
        assert result["status"] == "error"
        assert invalid_id in result["error"]
        assert "available_ids" in result

    def test_ok_response_contains_required_fields(self, raw_process_data):
        required = [
            "process_name", "business_unit", "status", "environment",
            "compliance_score", "risk_score", "encryption_at_rest",
            "encryption_in_transit", "mfa_enabled", "error_rate_pct",
            "availability_pct", "open_vulnerabilities", "critical_vulnerabilities",
        ]
        for field in required:
            assert field in raw_process_data, f"Missing field: {field}"

    def test_returns_valid_json(self, valid_id):
        raw = fetch_process_data(valid_id)
        parsed = json.loads(raw)   # must not raise
        assert isinstance(parsed, dict)


# ── Question definitions ───────────────────────────────────────────────────────

class TestQuestions:

    def test_exactly_10_questions(self):
        assert len(QUESTIONS) == 10

    def test_numbered_1_to_10_in_order(self):
        assert [q.number for q in QUESTIONS] == list(range(1, 11))

    def test_question_map_matches_list(self):
        for q in QUESTIONS:
            assert QUESTION_MAP[q.number] is q

    def test_q1_has_no_dependencies(self):
        assert QUESTION_MAP[1].depends_on == ()

    def test_q2_depends_on_q1(self):
        assert 1 in QUESTION_MAP[2].depends_on

    def test_q10_depends_on_all_prior(self):
        deps = QUESTION_MAP[10].depends_on
        for i in range(1, 10):
            assert i in deps

    def test_all_dependencies_reference_earlier_questions(self):
        """No forward or self references allowed."""
        for q in QUESTIONS:
            for dep in q.depends_on:
                assert dep < q.number, (
                    f"Q{q.number} depends on Q{dep} which comes after it — invalid DAG"
                )

    def test_no_empty_fields(self):
        for q in QUESTIONS:
            assert q.title.strip(), f"Q{q.number} has empty title"
            assert len(q.prompt) > 30, f"Q{q.number} prompt is too short"
            assert q.output_hint.strip(), f"Q{q.number} has empty output_hint"


# ── Pipeline helpers ───────────────────────────────────────────────────────────

class TestParseAnswer:

    def test_splits_structured_response(self):
        raw = "REASONING:\nThe process is active.\n\nANSWER:\nELIGIBLE — active in production."
        reasoning, answer = _parse_answer(raw)
        assert "active" in reasoning
        assert "ELIGIBLE" in answer

    def test_falls_back_to_full_text_when_unstructured(self):
        raw = "The process looks fine."
        reasoning, answer = _parse_answer(raw)
        assert reasoning == ""
        assert answer == raw.strip()

    def test_does_not_include_answer_label_in_reasoning(self):
        raw = "REASONING:\nStep one.\nStep two.\n\nANSWER:\nFinal verdict."
        reasoning, _ = _parse_answer(raw)
        assert "ANSWER:" not in reasoning


class TestParseVerdictJson:

    def test_parses_clean_json(self):
        data = {"verdict": "PASS", "overall_score": 85.0}
        assert _parse_verdict_json(json.dumps(data)) == data

    def test_strips_markdown_fences(self):
        raw = "```json\n{\"verdict\": \"FAIL\", \"overall_score\": 45.0}\n```"
        result = _parse_verdict_json(raw)
        assert result["verdict"] == "FAIL"

    def test_returns_empty_dict_on_invalid_json(self):
        assert _parse_verdict_json("not json at all") == {}

    def test_returns_empty_dict_on_empty_string(self):
        assert _parse_verdict_json("") == {}


# ── QAVerdict model ────────────────────────────────────────────────────────────

class TestQAVerdict:

    def test_pass_and_conditional_pass_are_passing(self):
        assert QAVerdict.PASS.passed is True
        assert QAVerdict.CONDITIONAL_PASS.passed is True

    def test_fail_and_escalation_are_not_passing(self):
        assert QAVerdict.FAIL.passed is False
        assert QAVerdict.REQUIRES_ESCALATION.passed is False

    def test_from_string_case_insensitive(self):
        assert QAVerdict.from_string("pass") == QAVerdict.PASS
        assert QAVerdict.from_string("CONDITIONAL PASS") == QAVerdict.CONDITIONAL_PASS
        assert QAVerdict.from_string("FAIL") == QAVerdict.FAIL

    def test_from_string_unknown_returns_inconclusive(self):
        assert QAVerdict.from_string("garbage") == QAVerdict.INCONCLUSIVE


# ── build_result ───────────────────────────────────────────────────────────────

class TestBuildResult:

    def _base_state(self) -> dict:
        return {}

    def test_builds_result_from_empty_state(self):
        result = _build_result("P-001", "s-001", {}, datetime.utcnow(), 5.0)
        assert result.process_id == "P-001"
        assert result.verdict == QAVerdict.INCONCLUSIVE
        assert len(result.answers) == 10   # one per question, even if empty

    def test_builds_result_with_verdict_json(self):
        vdata = {
            "verdict": "PASS",
            "overall_score": 88.5,
            "executive_summary": "All checks passed.",
            "blocking_issues": [],
            "remediation_actions": [],
            "next_steps": ["Schedule next review"],
        }
        state = {"verdict_json": json.dumps(vdata)}
        result = _build_result("P-002", "s-002", state, datetime.utcnow(), 10.0)
        assert result.verdict == QAVerdict.PASS
        assert result.overall_score == 88.5
        assert result.passed is True
        assert result.next_steps == ["Schedule next review"]

    def test_answers_are_sorted_by_question_number(self):
        result = _build_result("P-003", "s-003", {}, datetime.utcnow(), 2.0)
        numbers = [a.number for a in result.answers]
        assert numbers == sorted(numbers)

    def test_one_line_summary_contains_key_info(self):
        result = _build_result("P-004", "s-004", {}, datetime.utcnow(), 7.3)
        summary = result.one_line_summary()
        assert "P-004" in summary
        assert "/" in summary   # score format X/100


# ── Agent creation (structural only, no API calls) ────────────────────────────

class TestAgentCreation:

    def test_data_fetcher_agent(self):
        from agents.data_fetcher import create_data_fetcher_agent
        agent = create_data_fetcher_agent()
        assert agent.name == "DataFetcherAgent"
        assert agent.output_key == "process_data"
        assert len(agent.tools) == 1

    def test_question_agents_count_and_keys(self):
        from agents.question_agents import create_all_question_agents
        agents = create_all_question_agents()
        assert len(agents) == 10
        for i, agent in enumerate(agents, 1):
            assert agent.name == f"QuestionAgent_{i:02d}"
            assert agent.output_key == f"answer_q{i}"
            assert len(agent.tools) == 0

    def test_verdict_agent(self):
        from agents.verdict_synthesizer import create_verdict_synthesizer_agent
        agent = create_verdict_synthesizer_agent()
        assert agent.name == "VerdictSynthesizerAgent"
        assert agent.output_key == "verdict_json"
        assert len(agent.tools) == 0

    def test_pipeline_has_12_sub_agents(self):
        from agents.orchestrator import create_pipeline
        pipeline = create_pipeline()
        # DataFetcher + 10 questions + VerdictSynthesizer = 12
        assert len(pipeline.sub_agents) == 12
        assert pipeline.sub_agents[0].name == "DataFetcherAgent"
        assert pipeline.sub_agents[-1].name == "VerdictSynthesizerAgent"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
