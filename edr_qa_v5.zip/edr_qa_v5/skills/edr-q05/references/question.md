# Q05 Full Reference — Level 1 Review (Priority FC Business)

## Question

Validate the recommendation rationale is reasonable based on the details of the event description.

## Validation

Assess if L1 rationale is reasonable given event description and brokerage/group authorization.

## Check Logic (apply exactly)

If event_type != 'Priority FC Business Approval': answer N/A. Else check brokerage_type and recommending_group against authorization grid. If authorized and rationale aligns to event_description: Y. Else: N.

## Depends On

Q01, Q04

## Output Hint

State event_type, brokerage_type, recommending_group, l1_rationale alignment. Answer Y, N, or N/A.

## Requires Human Review

No — answer should be Y, N, or N/A only.

## DB Fields

- `event_type`
- `brokerage_type`
- `recommending_group`
- `l1_recommended_action`
- `l1_rationale`
- `event_description`

## Authorization Grid (relevant for Q2, Q3, Q5, Q8)

See `skills/edr-ingest/references/schema.md` for the full authorization grid
mapping EDR type + brokerage type → authorized recommending groups.
