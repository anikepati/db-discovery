"""
QA question registry.

Each QuestionDef declares:
  - number      : execution order (1–10)
  - title       : short label used in logs and display
  - prompt      : the actual question text given to the LLM
  - depends_on  : question numbers whose answers must be in context before this runs
  - output_hint : format the LLM must follow (used in the agent instruction)

To add or change questions, edit this file only — everything else adapts automatically.
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class QuestionDef:
    number: int
    title: str
    prompt: str
    depends_on: tuple[int, ...]
    output_hint: str


QUESTIONS: tuple[QuestionDef, ...] = (

    QuestionDef(
        number=1,
        title="Process Status & Eligibility",
        prompt=(
            "What is the current status of this process, and is it eligible for a full QA review? "
            "Consider: operational status, environment (production vs staging), version stability, "
            "and whether an owner is assigned."
        ),
        depends_on=(),
        output_hint="Declare ELIGIBLE or DEFERRED. State the status, environment, and version clearly.",
    ),

    QuestionDef(
        number=2,
        title="Compliance Framework & Obligations",
        prompt=(
            "Which compliance framework governs this process, and what are the minimum thresholds "
            "that must be met? Note any active exceptions or certifications."
        ),
        depends_on=(1,),
        output_hint="Name the framework, state the minimum compliance score threshold, list certifications and exceptions.",
    ),

    QuestionDef(
        number=3,
        title="Compliance Score Evaluation",
        prompt=(
            "Does the current compliance score meet the threshold identified in Q2? "
            "List all open findings by severity and flag any critical ones individually."
        ),
        depends_on=(1, 2),
        output_hint="Declare COMPLIANT or NON-COMPLIANT. Provide score vs threshold. List critical and high findings.",
    ),

    QuestionDef(
        number=4,
        title="Risk Assessment",
        prompt=(
            "Given the process context (Q1) and compliance status (Q3), assess the risk profile. "
            "Are the mitigating controls adequate for the inherent and residual risk levels? "
            "Identify any unmitigated risk vectors."
        ),
        depends_on=(1, 3),
        output_hint="Rate risk: ACCEPTABLE / ELEVATED / CRITICAL. List inadequate or missing controls.",
    ),

    QuestionDef(
        number=5,
        title="Security Controls",
        prompt=(
            "Given the data classification and risk level (Q4), evaluate the security posture. "
            "Assess: encryption at rest and in transit, MFA enforcement, open vulnerabilities "
            "(especially critical ones), pen test recency, and privileged user count."
        ),
        depends_on=(4,),
        output_hint="Rate security: STRONG / ADEQUATE / INADEQUATE / CRITICAL. List specific deficiencies.",
    ),

    QuestionDef(
        number=6,
        title="Performance & SLA",
        prompt=(
            "Is the process meeting its SLA commitments? Compare average completion time against "
            "the SLA threshold, evaluate the SLA breach count, error rate, and availability. "
            "Apply stricter thresholds for high-risk processes (error rate <1%, availability >99.5%)."
        ),
        depends_on=(1, 4),
        output_hint="Declare MEETING SLA / AT RISK / FAILING. Show actual vs target for each metric.",
    ),

    QuestionDef(
        number=7,
        title="Audit Trail & Policy Violations",
        prompt=(
            "Analyze the audit trail for unauthorized access attempts, policy violations, and "
            "change volume. Using the compliance gaps (Q3) and security posture (Q5) as context, "
            "determine whether issues are systemic or isolated."
        ),
        depends_on=(3, 5),
        output_hint="Declare CLEAN / MINOR CONCERNS / SIGNIFICANT CONCERNS / SYSTEMIC FAILURE. Distinguish systemic from isolated.",
    ),

    QuestionDef(
        number=8,
        title="Consolidated Violation Summary",
        prompt=(
            "Synthesize findings from Q3 (compliance), Q4 (risk), Q5 (security), Q6 (performance), "
            "and Q7 (audit) into a single violation summary. Classify each issue as BLOCKING "
            "(must resolve before approval) or NON-BLOCKING (track but doesn't prevent approval)."
        ),
        depends_on=(3, 4, 5, 6, 7),
        output_hint="List BLOCKING issues. List NON-BLOCKING issues. State aggregate impact: LOW / MEDIUM / HIGH / CRITICAL.",
    ),

    QuestionDef(
        number=9,
        title="Remediation Plan",
        prompt=(
            "Based on the blocking and non-blocking violations from Q8, propose a prioritized "
            "remediation plan. Each action must be specific, assigned to a role, and time-bound. "
            "P1 (critical security): ≤7 days. P2 (compliance gaps): ≤30 days. P3 (improvements): ≤90 days."
        ),
        depends_on=(8,),
        output_hint="List P1 / P2 / P3 actions, each with: action description, owner role, deadline in days.",
    ),

    QuestionDef(
        number=10,
        title="Final QA Verdict",
        prompt=(
            "Based on all prior analysis (Q1–Q9), deliver the final QA verdict. "
            "PASS: no blocking issues. "
            "CONDITIONAL PASS: blocking issues present but remediation plan accepted. "
            "FAIL: critical unresolved blocking issues. "
            "REQUIRES ESCALATION: systemic failures or regulatory risk detected."
        ),
        depends_on=(1, 2, 3, 4, 5, 6, 7, 8, 9),
        output_hint=(
            "VERDICT: [PASS | CONDITIONAL PASS | FAIL | REQUIRES ESCALATION]\n"
            "Score: X/100\n"
            "Summary: 3–5 sentences for a non-technical executive audience."
        ),
    ),
)

# Fast lookup by question number
QUESTION_MAP: dict[int, QuestionDef] = {q.number: q for q in QUESTIONS}
