# Q14 Full Reference — Initiation of Decision Execution

## Question

Increase Risk Rating: Validate if the Risk Rating Override request was referred to the appropriate process for execution.

## Validation

Check rro_number for decisions changed to Increase Risk Rating.

## Check Logic (apply exactly)

If final_recommended_action changed to 'Increase Risk Rating' during review:   If rro_number populated: Y.   If rro_number blank: NEEDS_HUMAN. Else: N/A.

## Depends On

Q11

## Output Hint

State whether decision changed to Increase Risk Rating, rro_number status. Answer Y, NEEDS_HUMAN, or N/A.

## Requires Human Review

No — answer should be Y, N, or N/A only.

## DB Fields

- `final_recommended_action`
- `recommended_action`
- `rro_number`
- `l2_action`

## Authorization Grid (relevant for Q2, Q3, Q5, Q8)

See `skills/edr-ingest/references/schema.md` for the full authorization grid
mapping EDR type + brokerage type → authorized recommending groups.
