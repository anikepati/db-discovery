"""
GEPA Forge — Enterprise Google ADK Playground (Full Feature Edition)

Streamlit UI with 4 main tabs:
1. Agent Studio — Visual agent builder & editor
2. Evaluation Lab — Test case management & synthetic generation
3. Evolution Dashboard — Genetic-Pareto evolution with live charts
4. Enterprise Tools — Safety checker, benchmark reports, history, prompt library
"""

from __future__ import annotations

import json
import os
import tempfile
import time
from datetime import datetime
from pathlib import Path

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
from dotenv import load_dotenv

# Local imports
from core.gepa_adapter import (
    AgentGenome,
    EnterpriseGEPAAdapter,
    EvolutionConfig,
    EvolutionHistory,
    EvolutionTrace,
    FitnessResult,
    SystemGenome,
)
from core.synthetic_generator import SyntheticTestGenerator
from core.safety_checker import SafetyChecker, format_safety_report
from core.benchmark_report import BenchmarkReportGenerator
from core.prompt_library import PromptLibrary

load_dotenv()


# ═══════════════════════════════════════════════════════════════════════════
# Page Config & Session State
# ═══════════════════════════════════════════════════════════════════════════

st.set_page_config(
    page_title="GEPA Forge — Enterprise ADK Playground",
    page_icon="🧬",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Initialize session state defaults
DEFAULTS = {
    "genome": None,
    "test_cases": [],
    "adapter": None,
    "evolution_traces": [],
    "best_genome": None,
    "best_fitness": None,
    "original_fitness": None,
    "evolving": False,
    "raw_source": "",
    "source_file_name": "",
    "chat_messages": [],
    "prompt_library": None,
    "safety_report": None,
}
for key, val in DEFAULTS.items():
    if key not in st.session_state:
        st.session_state[key] = val

# Initialize shared objects
if st.session_state.prompt_library is None:
    st.session_state.prompt_library = PromptLibrary()


# ═══════════════════════════════════════════════════════════════════════════
# Sidebar — Global Config
# ═══════════════════════════════════════════════════════════════════════════

with st.sidebar:
    st.image("https://img.icons8.com/fluency/96/dna-helix.png", width=48)
    st.title("GEPA Forge")
    st.caption("Enterprise Google ADK Playground")
    st.divider()

    st.subheader("⚙️ Evolution Config")
    pop_size = st.slider("Population Size", 4, 20, 6, key="cfg_pop")
    generations = st.slider("Generations", 2, 30, 10, key="cfg_gen")
    mutation_rate = st.slider("Mutation Rate", 0.05, 0.8, 0.3, key="cfg_mut")
    crossover_rate = st.slider("Crossover Rate", 0.3, 1.0, 0.7, key="cfg_cross")
    elite_count = st.slider("Elite Count", 1, 5, 2, key="cfg_elite")
    model_id = st.selectbox("Model", [
        "gemini-2.0-flash", "gemini-2.5-flash", "gemini-2.5-pro",
    ], key="cfg_model")
    safety_gate = st.checkbox("Enable Safety Gate", True, key="cfg_safety")

    st.divider()
    st.subheader("📊 Status")
    if st.session_state.genome:
        st.success(f"Agents loaded: {len(st.session_state.genome.agents)}")
    else:
        st.info("No agents loaded")
    st.metric("Test Cases", len(st.session_state.test_cases))
    if st.session_state.best_fitness:
        st.metric("Best Score", f"{st.session_state.best_fitness.weighted_score():.4f}")


# ═══════════════════════════════════════════════════════════════════════════
# Helper Functions
# ═══════════════════════════════════════════════════════════════════════════

def build_config() -> EvolutionConfig:
    return EvolutionConfig(
        population_size=st.session_state.cfg_pop,
        generations=st.session_state.cfg_gen,
        mutation_rate=st.session_state.cfg_mut,
        crossover_rate=st.session_state.cfg_cross,
        elite_count=st.session_state.cfg_elite,
        model_id=st.session_state.cfg_model,
        eval_model_id=st.session_state.cfg_model,
        safety_gate_enabled=st.session_state.cfg_safety,
    )


def render_agent_graph(genome: SystemGenome):
    """Render the agent graph using Plotly."""
    if not genome or not genome.agents:
        st.info("No agents to display.")
        return

    import networkx as nx

    G = nx.DiGraph()
    agent_map = {a.agent_name: a for a in genome.agents}

    for agent in genome.agents:
        node_color = {
            "SequentialAgent": "#4CAF50",
            "ParallelAgent": "#2196F3",
            "SupervisorAgent": "#FF9800",
            "LoopAgent": "#9C27B0",
            "LlmAgent": "#607D8B",
            "Agent": "#607D8B",
        }.get(agent.agent_type, "#9E9E9E")
        G.add_node(agent.agent_name, agent_type=agent.agent_type, color=node_color)

        for sub in agent.sub_agent_names:
            G.add_edge(agent.agent_name, sub)

    if len(G.nodes) == 0:
        st.info("No agent graph to display.")
        return

    pos = nx.spring_layout(G, seed=42, k=2)
    edge_x, edge_y = [], []
    for e in G.edges():
        x0, y0 = pos[e[0]]
        x1, y1 = pos[e[1]]
        edge_x.extend([x0, x1, None])
        edge_y.extend([y0, y1, None])

    edge_trace = go.Scatter(
        x=edge_x, y=edge_y, mode="lines",
        line=dict(width=2, color="#888"),
        hoverinfo="none",
    )

    node_x, node_y, node_text, node_colors = [], [], [], []
    for node in G.nodes():
        x, y = pos[node]
        node_x.append(x)
        node_y.append(y)
        data = G.nodes[node]
        agent = agent_map.get(node)
        tools_str = ", ".join(agent.tool_names) if agent and agent.tool_names else "none"
        node_text.append(f"{node}<br>Type: {data['agent_type']}<br>Tools: {tools_str}")
        node_colors.append(data["color"])

    node_trace = go.Scatter(
        x=node_x, y=node_y, mode="markers+text",
        hoverinfo="text", text=[n for n in G.nodes()],
        textposition="top center",
        hovertext=node_text,
        marker=dict(size=30, color=node_colors, line=dict(width=2, color="white")),
    )

    fig = go.Figure(
        data=[edge_trace, node_trace],
        layout=go.Layout(
            showlegend=False, hovermode="closest",
            margin=dict(b=20, l=20, r=20, t=20),
            xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
            yaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
            height=350,
            plot_bgcolor="rgba(0,0,0,0)",
            paper_bgcolor="rgba(0,0,0,0)",
        ),
    )
    st.plotly_chart(fig, use_container_width=True)


# ═══════════════════════════════════════════════════════════════════════════
# Tab 1 — Agent Studio
# ═══════════════════════════════════════════════════════════════════════════

def tab_agent_studio():
    st.header("🏗️ Agent Studio")
    st.caption("Import, visualize, and edit your ADK multi-agent system")

    col_import, col_paste = st.columns(2)

    with col_import:
        st.subheader("Import Python File")
        uploaded = st.file_uploader(
            "Upload your ADK agent file (.py)",
            type=["py"],
            key="agent_upload",
        )
        if uploaded:
            source = uploaded.read().decode("utf-8")
            tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".py", mode="w")
            tmp.write(source)
            tmp.close()
            try:
                config = build_config()
                adapter = EnterpriseGEPAAdapter(config)
                genome = adapter.load_agents(tmp.name)
                st.session_state.genome = genome
                st.session_state.adapter = adapter
                st.session_state.raw_source = source
                st.session_state.source_file_name = uploaded.name
                st.success(f"Loaded {len(genome.agents)} agents from **{uploaded.name}**")
            except Exception as e:
                st.error(f"Parse error: {e}")
            finally:
                os.unlink(tmp.name)

    with col_paste:
        st.subheader("Paste Agent Code")
        pasted = st.text_area(
            "Paste your ADK agent Python code:",
            height=200,
            key="paste_code",
            placeholder="from google.adk.agents import LlmAgent...",
        )
        if st.button("📥 Parse Pasted Code", key="btn_parse_paste"):
            if pasted.strip():
                try:
                    config = build_config()
                    adapter = EnterpriseGEPAAdapter(config)
                    genome = adapter.load_agents_from_source(pasted)
                    st.session_state.genome = genome
                    st.session_state.adapter = adapter
                    st.session_state.raw_source = pasted
                    st.session_state.source_file_name = "pasted_code.py"
                    st.success(f"Parsed {len(genome.agents)} agents")
                except Exception as e:
                    st.error(f"Parse error: {e}")

    # Load example
    if st.button("📂 Load Example (Compliance Team)", key="btn_example"):
        example_path = Path("agents/example_multi_agent.py")
        if example_path.exists():
            config = build_config()
            adapter = EnterpriseGEPAAdapter(config)
            genome = adapter.load_agents(str(example_path))
            st.session_state.genome = genome
            st.session_state.adapter = adapter
            st.session_state.raw_source = example_path.read_text()
            st.session_state.source_file_name = "example_multi_agent.py"
            st.success(f"Loaded example with {len(genome.agents)} agents")

    st.divider()

    # Agent Graph Visualization
    genome = st.session_state.genome
    if genome and genome.agents:
        st.subheader("🔗 Agent Graph")
        render_agent_graph(genome)

        st.divider()

        # Agent Editor
        st.subheader("✏️ Agent Editor")
        for i, agent in enumerate(genome.agents):
            with st.expander(
                f"{'🤖' if agent.agent_type in ('LlmAgent', 'Agent') else '🔄'} "
                f"{agent.agent_name} ({agent.agent_type})",
                expanded=(i == 0),
            ):
                col_meta, col_edit = st.columns([1, 2])
                with col_meta:
                    st.text_input(
                        "Name", value=agent.agent_name,
                        key=f"name_{i}", disabled=True,
                    )
                    st.text_input(
                        "Type", value=agent.agent_type,
                        key=f"type_{i}", disabled=True,
                    )
                    st.text_input(
                        "Model", value=agent.model_id or "(inherited)",
                        key=f"model_{i}", disabled=True,
                    )
                    if agent.tool_names:
                        st.markdown(f"**Tools:** {', '.join(agent.tool_names)}")
                    if agent.sub_agent_names:
                        st.markdown(f"**Sub-agents:** {', '.join(agent.sub_agent_names)}")

                with col_edit:
                    new_desc = st.text_area(
                        "Description",
                        value=agent.description,
                        key=f"desc_{i}",
                        height=60,
                    )
                    agent.description = new_desc

                    new_instruction = st.text_area(
                        "Instruction",
                        value=agent.instruction,
                        key=f"instr_{i}",
                        height=200,
                    )
                    agent.instruction = new_instruction

                    # Import from prompt library
                    library = st.session_state.prompt_library
                    templates = library.list_all()
                    template_names = ["(none)"] + [f"{t.name} [{t.category}]" for t in templates]
                    selected = st.selectbox(
                        "📚 Import from Prompt Library",
                        template_names,
                        key=f"lib_import_{i}",
                    )
                    if selected != "(none)":
                        idx = template_names.index(selected) - 1
                        if st.button(f"Apply '{templates[idx].name}'", key=f"apply_lib_{i}"):
                            agent.instruction = templates[idx].instruction
                            st.rerun()

        # Source code viewer
        if st.session_state.raw_source:
            with st.expander("📄 Raw Source Code"):
                st.code(st.session_state.raw_source, language="python")


# ═══════════════════════════════════════════════════════════════════════════
# Tab 2 — Evaluation Lab
# ═══════════════════════════════════════════════════════════════════════════

def tab_evaluation_lab():
    st.header("🧪 Evaluation Lab")
    st.caption("Manage test cases — generate, import, record, and review")

    col_gen, col_upload = st.columns(2)

    with col_gen:
        st.subheader("🤖 Synthetic Test Generator")
        gen_count = st.slider("Number of test cases", 5, 100, 30, key="gen_count")
        use_ai = st.checkbox("Use AI-enhanced generation", True, key="gen_ai")
        domains = st.multiselect(
            "Target domains",
            ["compliance", "financial_analysis", "customer_service", "data_processing", "general"],
            default=["compliance", "general"],
            key="gen_domains",
        )

        if st.button("🚀 Generate Test Cases", key="btn_generate", type="primary"):
            with st.spinner(f"Generating {gen_count} test cases..."):
                generator = SyntheticTestGenerator(model_id=st.session_state.cfg_model)
                cases = generator.generate(
                    genome=st.session_state.genome,
                    count=gen_count,
                    domains=domains if domains else None,
                    use_ai=use_ai,
                )
                st.session_state.test_cases = cases
                st.success(f"Generated {len(cases)} test cases")

    with col_upload:
        st.subheader("📁 Import Test Cases")
        uploaded_tc = st.file_uploader(
            "Upload JSON or CSV test cases",
            type=["json", "csv"],
            key="tc_upload",
        )
        if uploaded_tc:
            try:
                tmp = tempfile.NamedTemporaryFile(
                    delete=False, suffix=f".{uploaded_tc.name.split('.')[-1]}",
                )
                tmp.write(uploaded_tc.read())
                tmp.close()
                cases = SyntheticTestGenerator.load_from_file(tmp.name)
                st.session_state.test_cases.extend(cases)
                st.success(f"Imported {len(cases)} test cases (total: {len(st.session_state.test_cases)})")
                os.unlink(tmp.name)
            except Exception as e:
                st.error(f"Import error: {e}")

        # Load default test cases
        if st.button("📂 Load Example Test Cases", key="btn_load_tc"):
            tc_path = Path("data/test_cases.json")
            if tc_path.exists():
                cases = json.loads(tc_path.read_text())
                st.session_state.test_cases = cases
                st.success(f"Loaded {len(cases)} example test cases")

    st.divider()

    # Record from conversation
    st.subheader("🎙️ Record from Conversation")
    col_chat_in, col_chat_out = st.columns(2)
    with col_chat_in:
        user_msg = st.text_area("User Input", key="conv_user", height=80,
                                placeholder="Enter a sample user query...")
    with col_chat_out:
        expected_msg = st.text_area("Expected Output", key="conv_expected", height=80,
                                    placeholder="Enter the expected agent response...")
    if st.button("💾 Save as Test Case", key="btn_save_conv"):
        if user_msg and expected_msg:
            tc = {
                "id": f"tc_conv_{len(st.session_state.test_cases)+1:03d}",
                "input": user_msg,
                "expected_output": expected_msg,
                "business_kpis": {},
                "domain": "conversation_recorded",
                "difficulty": "real_world",
                "generated_by": "manual",
            }
            st.session_state.test_cases.append(tc)
            st.success("Test case saved!")

    st.divider()

    # Test Case Browser
    st.subheader(f"📋 Test Cases ({len(st.session_state.test_cases)} total)")
    if st.session_state.test_cases:
        df = pd.DataFrame(st.session_state.test_cases)
        display_cols = [c for c in ["id", "input", "expected_output", "domain", "difficulty", "generated_by"] if c in df.columns]
        st.dataframe(df[display_cols], use_container_width=True, height=400)

        # Export
        col_exp_json, col_exp_csv, col_clear = st.columns(3)
        with col_exp_json:
            st.download_button(
                "📥 Export JSON",
                data=json.dumps(st.session_state.test_cases, indent=2),
                file_name="test_cases.json",
                mime="application/json",
            )
        with col_exp_csv:
            csv_data = df[display_cols].to_csv(index=False) if display_cols else ""
            st.download_button(
                "📥 Export CSV",
                data=csv_data,
                file_name="test_cases.csv",
                mime="text/csv",
            )
        with col_clear:
            if st.button("🗑️ Clear All", key="btn_clear_tc"):
                st.session_state.test_cases = []
                st.rerun()
    else:
        st.info("No test cases loaded. Generate or import test cases above.")


# ═══════════════════════════════════════════════════════════════════════════
# Tab 3 — Evolution Dashboard
# ═══════════════════════════════════════════════════════════════════════════

def tab_evolution_dashboard():
    st.header("🧬 Evolution Dashboard")
    st.caption("Genetic-Pareto optimization for your multi-agent system")

    # Pre-flight checks
    genome = st.session_state.genome
    test_cases = st.session_state.test_cases

    col_status, col_action = st.columns([2, 1])
    with col_status:
        c1, c2, c3 = st.columns(3)
        c1.metric("Agents", len(genome.agents) if genome else 0)
        c2.metric("Test Cases", len(test_cases))
        c3.metric("Generations", st.session_state.cfg_gen)

    can_evolve = genome is not None and len(test_cases) > 0

    with col_action:
        if can_evolve:
            evolve_btn = st.button(
                "🚀 Evolve Multi-Agent System",
                type="primary",
                key="btn_evolve",
                disabled=st.session_state.evolving,
            )
        else:
            st.warning("Load agents and test cases first")
            evolve_btn = False

    if evolve_btn and can_evolve:
        st.session_state.evolving = True
        config = build_config()
        adapter = EnterpriseGEPAAdapter(config)

        # Load agents
        if st.session_state.raw_source:
            adapter.load_agents_from_source(st.session_state.raw_source)
        adapter.load_test_cases(test_cases)

        # Safety pre-flight
        if config.safety_gate_enabled:
            checker = SafetyChecker()
            preflight = checker.check_genome(adapter.original_genome)
            if not preflight.passed:
                st.warning("⚠️ Safety pre-flight found critical issues — evolution will use safety gate")
                with st.expander("Pre-flight Safety Report"):
                    st.text(format_safety_report(preflight))
        else:
            checker = None

        # Evolution loop with live progress
        st.divider()
        progress_bar = st.progress(0, text="Initializing evolution...")
        chart_placeholder = st.empty()
        metrics_placeholder = st.empty()
        traces_collected: list[EvolutionTrace] = []

        def on_progress(trace: EvolutionTrace):
            traces_collected.append(trace)
            pct = (trace.generation + 1) / config.generations
            progress_bar.progress(
                pct,
                text=f"Generation {trace.generation + 1}/{config.generations} — "
                     f"Best: {trace.best_fitness:.4f} | Avg: {trace.avg_fitness:.4f}",
            )

            # Live chart
            df_trace = pd.DataFrame([{
                "Generation": t.generation,
                "Best Fitness": t.best_fitness,
                "Avg Fitness": t.avg_fitness,
                "Pareto Front": t.pareto_front_size,
            } for t in traces_collected])

            fig = go.Figure()
            fig.add_trace(go.Scatter(
                x=df_trace["Generation"], y=df_trace["Best Fitness"],
                mode="lines+markers", name="Best Fitness",
                line=dict(color="#4CAF50", width=3),
            ))
            fig.add_trace(go.Scatter(
                x=df_trace["Generation"], y=df_trace["Avg Fitness"],
                mode="lines+markers", name="Avg Fitness",
                line=dict(color="#2196F3", width=2, dash="dash"),
            ))
            fig.update_layout(
                title="Evolution Progress",
                xaxis_title="Generation",
                yaxis_title="Weighted Fitness Score",
                height=350,
                template="plotly_white",
            )
            chart_placeholder.plotly_chart(fig, use_container_width=True)

            # Live metrics
            with metrics_placeholder.container():
                mc1, mc2, mc3, mc4 = st.columns(4)
                mc1.metric("Best Fitness", f"{trace.best_fitness:.4f}")
                mc2.metric("Avg Fitness", f"{trace.avg_fitness:.4f}")
                mc3.metric("Pareto Front", trace.pareto_front_size)
                fb = trace.fitness_breakdown or {}
                top = max(fb, key=fb.get) if fb else "N/A"
                mc4.metric("Top KPI", f"{top}")

        # Run evolution
        try:
            best_genome, best_fitness = adapter.evolve(
                progress_callback=on_progress,
                safety_checker=checker if config.safety_gate_enabled else None,
            )
            st.session_state.best_genome = best_genome
            st.session_state.best_fitness = best_fitness
            st.session_state.evolution_traces = traces_collected
            st.session_state.adapter = adapter

            # Evaluate original for comparison
            orig_fitness = adapter.evaluator.evaluate(
                adapter.original_genome, test_cases, adapter.raw_source
            )
            st.session_state.original_fitness = orig_fitness

            progress_bar.progress(1.0, text="✅ Evolution complete!")
            st.balloons()
        except Exception as e:
            st.error(f"Evolution error: {e}")
            import traceback
            st.code(traceback.format_exc())
        finally:
            st.session_state.evolving = False

    # Show results if available
    if st.session_state.best_genome and st.session_state.best_fitness:
        st.divider()
        st.subheader("🏆 Results")

        best_fitness = st.session_state.best_fitness
        orig_fitness = st.session_state.original_fitness

        # Improvement metrics
        orig_score = orig_fitness.weighted_score() if orig_fitness else 0
        evolved_score = best_fitness.weighted_score()
        improvement = ((evolved_score - orig_score) / max(orig_score, 0.001)) * 100

        r1, r2, r3 = st.columns(3)
        r1.metric("Original Score", f"{orig_score:.4f}")
        r2.metric("Evolved Score", f"{evolved_score:.4f}", delta=f"{improvement:+.1f}%")
        r3.metric("Pareto Rank", st.session_state.best_genome.pareto_rank)

        # KPI radar chart
        if orig_fitness:
            categories = list(best_fitness.as_dict().keys())
            orig_vals = [orig_fitness.as_dict().get(c, 0) for c in categories]
            evolved_vals = [best_fitness.as_dict().get(c, 0) for c in categories]

            fig_radar = go.Figure()
            fig_radar.add_trace(go.Scatterpolar(
                r=orig_vals + [orig_vals[0]],
                theta=[c.replace("_", " ").title() for c in categories] + [categories[0].replace("_", " ").title()],
                fill="toself", name="Original", opacity=0.5,
                line=dict(color="#FF5722"),
            ))
            fig_radar.add_trace(go.Scatterpolar(
                r=evolved_vals + [evolved_vals[0]],
                theta=[c.replace("_", " ").title() for c in categories] + [categories[0].replace("_", " ").title()],
                fill="toself", name="Evolved", opacity=0.5,
                line=dict(color="#4CAF50"),
            ))
            fig_radar.update_layout(
                polar=dict(radialaxis=dict(visible=True, range=[0, 1])),
                title="Business KPI Comparison",
                height=400,
                template="plotly_white",
            )
            st.plotly_chart(fig_radar, use_container_width=True)

        # Pareto frontier chart
        if st.session_state.evolution_traces:
            traces = st.session_state.evolution_traces
            df_pareto = pd.DataFrame([{
                "Generation": t.generation,
                "Pareto Front Size": t.pareto_front_size,
                "Accuracy": t.fitness_breakdown.get("accuracy", 0),
                "Compliance": t.fitness_breakdown.get("compliance", 0),
            } for t in traces])

            fig_pareto = px.scatter(
                df_pareto, x="Accuracy", y="Compliance",
                size="Pareto Front Size", color="Generation",
                title="Pareto Frontier (Accuracy vs Compliance)",
                color_continuous_scale="Viridis",
                height=350,
            )
            st.plotly_chart(fig_pareto, use_container_width=True)

        # Before/After comparison
        adapter = st.session_state.adapter
        if adapter:
            adapter.best_genome = st.session_state.best_genome
            adapter.best_fitness = st.session_state.best_fitness
            comparison = adapter.get_before_after_comparison()

            if comparison and comparison.get("agents"):
                st.subheader("📝 Before vs After — Prompt Changes")
                for agent_info in comparison["agents"]:
                    changed = agent_info.get("changed", False)
                    icon = "🔄" if changed else "✅"
                    with st.expander(f"{icon} {agent_info['name']} {'(CHANGED)' if changed else '(unchanged)'}"):
                        if changed:
                            col_before, col_after = st.columns(2)
                            with col_before:
                                st.markdown("**Original Instruction:**")
                                st.text_area(
                                    "Original", agent_info["original_instruction"],
                                    height=200, disabled=True,
                                    key=f"orig_{agent_info['name']}",
                                )
                            with col_after:
                                st.markdown(f"**Evolved Instruction** (mutation: `{agent_info.get('mutation_applied', 'N/A')}`):")
                                st.text_area(
                                    "Evolved", agent_info["evolved_instruction"],
                                    height=200, disabled=True,
                                    key=f"evol_{agent_info['name']}",
                                )
                        else:
                            st.info("No changes made to this agent.")

        # Apply & Export
        st.divider()
        col_apply, col_export = st.columns(2)
        with col_apply:
            if st.button("✅ Apply Evolved Version", key="btn_apply", type="primary"):
                st.session_state.genome = st.session_state.best_genome
                if adapter:
                    st.session_state.raw_source = adapter.export_evolved_source()
                st.success("Evolved version applied as current agent system!")

        with col_export:
            if adapter:
                evolved_source = adapter.export_evolved_source()
                if evolved_source:
                    st.download_button(
                        "📥 Download Evolved Source (.py)",
                        data=evolved_source,
                        file_name=f"evolved_{st.session_state.source_file_name or 'agents.py'}",
                        mime="text/x-python",
                    )


# ═══════════════════════════════════════════════════════════════════════════
# Tab 4 — Enterprise Tools
# ═══════════════════════════════════════════════════════════════════════════

def tab_enterprise_tools():
    st.header("🛠️ Enterprise Tools")

    tool_tabs = st.tabs([
        "🛡️ Safety Checker",
        "📊 Benchmark Reports",
        "📜 Evolution History",
        "📚 Prompt Library",
    ])

    # --- Safety Checker ---
    with tool_tabs[0]:
        st.subheader("🛡️ Pre-flight Safety Checker")
        st.caption("PII detection, hallucination risk, compliance scan, injection check")

        genome = st.session_state.best_genome or st.session_state.genome
        if genome:
            if st.button("🔍 Run Safety Scan", key="btn_safety"):
                checker = SafetyChecker()
                report = checker.check_genome(genome)
                st.session_state.safety_report = report

            report = st.session_state.safety_report
            if report:
                status = "✅ PASSED" if report.passed else "❌ FAILED — Critical Issues Found"
                if report.passed:
                    st.success(status)
                else:
                    st.error(status)

                s1, s2, s3, s4 = st.columns(4)
                s1.metric("🔴 Critical", len(report.critical_issues))
                s2.metric("🟡 Warnings", len(report.warnings))
                s3.metric("🔵 Info", len(report.info_items))
                s4.metric("Total", len(report.issues))

                if report.issues:
                    for issue in report.issues:
                        icon = {"critical": "🔴", "warning": "🟡", "info": "🔵"}.get(issue.severity, "⚪")
                        with st.expander(f"{icon} [{issue.severity.upper()}] {issue.category} — {issue.agent_name}"):
                            st.markdown(f"**Issue:** {issue.description}")
                            st.markdown(f"**Recommendation:** {issue.recommendation}")
                            if issue.line_preview:
                                st.code(issue.line_preview)

                st.download_button(
                    "📥 Download Safety Report",
                    data=format_safety_report(report),
                    file_name="safety_report.txt",
                    mime="text/plain",
                )
        else:
            st.info("Load agents first to run safety checks.")

    # --- Benchmark Reports ---
    with tool_tabs[1]:
        st.subheader("📊 Benchmark Reports")
        st.caption("Auto-generated PDF + CSV reports")

        if st.session_state.best_fitness and st.session_state.evolution_traces:
            reporter = BenchmarkReportGenerator()
            adapter = st.session_state.adapter

            col_pdf, col_csv = st.columns(2)
            with col_pdf:
                if st.button("📄 Generate PDF Report", key="btn_pdf"):
                    comparison = adapter.get_before_after_comparison() if adapter else None
                    path = reporter.generate_pdf_report(
                        original_genome=adapter.original_genome if adapter else SystemGenome(),
                        evolved_genome=st.session_state.best_genome,
                        original_fitness=st.session_state.original_fitness,
                        evolved_fitness=st.session_state.best_fitness,
                        traces=st.session_state.evolution_traces,
                        run_id=datetime.utcnow().strftime("%Y%m%d_%H%M%S"),
                        comparison=comparison,
                    )
                    with open(path, "rb") as f:
                        st.download_button(
                            "📥 Download PDF Report",
                            data=f.read(),
                            file_name=Path(path).name,
                            mime="application/pdf",
                            key="dl_pdf",
                        )
                    st.success(f"Report generated: {path}")

            with col_csv:
                if st.button("📊 Generate CSV Export", key="btn_csv"):
                    path = reporter.generate_csv_export(
                        traces=st.session_state.evolution_traces,
                        evolved_fitness=st.session_state.best_fitness,
                        run_id=datetime.utcnow().strftime("%Y%m%d_%H%M%S"),
                    )
                    with open(path, "rb") as f:
                        st.download_button(
                            "📥 Download CSV Data",
                            data=f.read(),
                            file_name=Path(path).name,
                            mime="text/csv",
                            key="dl_csv",
                        )
                    st.success(f"CSV exported: {path}")

            # Show evolution summary
            st.subheader("Evolution Summary")
            traces = st.session_state.evolution_traces
            df = pd.DataFrame([{
                "Generation": t.generation,
                "Best": f"{t.best_fitness:.4f}",
                "Avg": f"{t.avg_fitness:.4f}",
                "Pareto Front": t.pareto_front_size,
                **{k.replace("_", " ").title(): f"{v:.3f}" for k, v in (t.fitness_breakdown or {}).items()},
            } for t in traces])
            st.dataframe(df, use_container_width=True)
        else:
            st.info("Run an evolution first to generate benchmark reports.")

    # --- Evolution History ---
    with tool_tabs[2]:
        st.subheader("📜 Evolution History")
        st.caption("All past evolution runs saved in SQLite")

        history = EvolutionHistory()
        runs = history.list_runs()

        if runs:
            df_runs = pd.DataFrame(runs)
            display_cols = [c for c in ["run_id", "started_at", "completed_at", "status", "source_file"] if c in df_runs.columns]
            st.dataframe(df_runs[display_cols], use_container_width=True)

            selected_run = st.selectbox(
                "Select a run to view details",
                [r["run_id"] for r in runs],
                key="history_run",
            )

            if selected_run:
                traces = history.get_run_traces(selected_run)
                if traces:
                    df_traces = pd.DataFrame(traces)
                    trace_cols = [c for c in ["generation", "best_fitness", "avg_fitness", "pareto_front_size", "timestamp"]
                                  if c in df_traces.columns]
                    st.dataframe(df_traces[trace_cols], use_container_width=True)

                    # Chart
                    if "best_fitness" in df_traces.columns:
                        fig = px.line(
                            df_traces, x="generation", y=["best_fitness", "avg_fitness"],
                            title=f"Evolution Trace — {selected_run}",
                        )
                        st.plotly_chart(fig, use_container_width=True)

                best = history.get_best_genome(selected_run)
                if best:
                    with st.expander("Best Genome Details"):
                        st.json(json.loads(best.get("genome_json", "[]")))
                        st.json(json.loads(best.get("fitness_json", "{}")))
        else:
            st.info("No evolution history yet. Run an evolution to start recording.")

    # --- Prompt Library ---
    with tool_tabs[3]:
        st.subheader("📚 Prompt Library")
        st.caption("Reusable SOPs, roles, and guardrails")

        library = st.session_state.prompt_library

        # Category filter
        categories = library.get_categories()
        selected_cat = st.selectbox(
            "Filter by category",
            ["all"] + categories,
            key="lib_filter",
        )

        # Search
        search_query = st.text_input("🔍 Search templates", key="lib_search")

        # List templates
        if search_query:
            templates = library.search(search_query)
        elif selected_cat == "all":
            templates = library.list_all()
        else:
            templates = library.list_by_category(selected_cat)

        for t in templates:
            builtin_badge = "📦 Built-in" if t.is_builtin else "👤 Custom"
            with st.expander(f"{t.name} — {builtin_badge} [{t.category}]"):
                st.markdown(f"**Description:** {t.description}")
                st.markdown(f"**Tags:** {', '.join(t.tags)}")
                if t.variables:
                    st.markdown(f"**Variables:** {', '.join(t.variables)}")
                st.text_area(
                    "Instruction",
                    value=t.instruction,
                    height=200,
                    disabled=True,
                    key=f"lib_view_{t.id}",
                )
                col_copy, col_del = st.columns([3, 1])
                with col_copy:
                    st.code(t.instruction, language=None)
                with col_del:
                    if not t.is_builtin:
                        if st.button("🗑️ Delete", key=f"lib_del_{t.id}"):
                            library.delete(t.id)
                            st.rerun()

        # Add new template
        st.divider()
        st.subheader("➕ Add Custom Template")
        with st.form("add_template_form"):
            new_name = st.text_input("Name")
            new_cat = st.selectbox("Category", ["custom", "role", "sop", "guardrail", "tool_usage"])
            new_desc = st.text_input("Description")
            new_instr = st.text_area("Instruction", height=200)
            new_tags = st.text_input("Tags (comma-separated)")

            if st.form_submit_button("💾 Save Template"):
                if new_name and new_instr:
                    library.add(
                        name=new_name,
                        instruction=new_instr,
                        category=new_cat,
                        description=new_desc,
                        tags=[t.strip() for t in new_tags.split(",") if t.strip()],
                    )
                    st.success(f"Template '{new_name}' saved!")
                    st.rerun()
                else:
                    st.warning("Name and instruction are required.")


# ═══════════════════════════════════════════════════════════════════════════
# Main Layout
# ═══════════════════════════════════════════════════════════════════════════

tab1, tab2, tab3, tab4 = st.tabs([
    "🏗️ Agent Studio",
    "🧪 Evaluation Lab",
    "🧬 Evolution Dashboard",
    "🛠️ Enterprise Tools",
])

with tab1:
    tab_agent_studio()

with tab2:
    tab_evaluation_lab()

with tab3:
    tab_evolution_dashboard()

with tab4:
    tab_enterprise_tools()
