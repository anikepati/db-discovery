"""
EDR QA Pipeline v4 — test suite.

Run:   pytest tests/ -v
Cover: pytest tests/ --cov=.. --cov-report=term-missing

All tests run without any API calls.
"""

import json
import sys
import tempfile
from datetime import datetime
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from models import QAAnswer, QuestionResult, RunState, Verdict
from questions import (
    EDR_QUESTIONS, EDR_QUESTION_MAP,
    CATEGORIES, HUMAN_REVIEW_QUESTION_NUMBERS,
)
from tool_registry import EDR_TOOL_REGISTRY


# ── RunState ──────────────────────────────────────────────────────────────────

class TestRunState:

    def test_basic_set_get(self):
        s = RunState("run_001", "ECN-001")
        s.set("edr_data", {"ecn_id": "ECN-001", "event_type": "Standard Referral"})
        assert s.get("edr_data")["ecn_id"] == "ECN-001"

    def test_dotted_key_set_get(self):
        s = RunState("run_001", "ECN-001")
        s.set("answers.q3.answer", "Y")
        assert s.get("answers.q3.answer") == "Y"

    def test_dotted_key_creates_intermediate_dicts(self):
        s = RunState("run_001", "ECN-001")
        s.set("answers.q5.reasoning", "Rationale aligns.")
        assert s.get("answers.q5.reasoning") == "Rationale aligns."

    def test_get_missing_key_returns_default(self):
        s = RunState("run_001", "ECN-001")
        assert s.get("answers.q99") is None
        assert s.get("answers.q99", "default") == "default"

    def test_merge_updates_existing_dict(self):
        s = RunState("run_001", "ECN-001")
        s.set("answers.q1", {"answer": "Y"})
        s.merge("answers.q1", {"reasoning": "ECN # matches."})
        assert s.get("answers.q1.answer") == "Y"
        assert s.get("answers.q1.reasoning") == "ECN # matches."

    def test_snapshot_is_deep_copy(self):
        s = RunState("run_001", "ECN-001")
        s.set("edr_data", {"ecn_id": "ECN-001"})
        snap = s.snapshot()
        snap["edr_data"]["ecn_id"] = "MUTATED"
        # Original should be unchanged
        assert s.get("edr_data")["ecn_id"] == "ECN-001"

    def test_thread_safety(self):
        """Concurrent writes to different keys should not corrupt state."""
        import threading
        s = RunState("run_001", "ECN-001")
        errors = []

        def write(n):
            try:
                for _ in range(100):
                    s.set(f"answers.q{n}.answer", "Y")
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=write, args=(i,)) for i in range(1, 6)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert not errors
        for i in range(1, 6):
            assert s.get(f"answers.q{i}.answer") == "Y"

    def test_initial_state_structure(self):
        s = RunState("run_001", "ECN-001")
        snap = s.snapshot()
        assert snap["run_id"]   == "run_001"
        assert snap["ecn_id"]   == "ECN-001"
        assert snap["edr_data"] == {}
        assert snap["answers"]  == {}
        assert snap["verdict"]  is None
        assert "started_at" in snap["metadata"]


# ── yaml_runtime edr_state executor ──────────────────────────────────────────

class TestEdrStateRuntime:

    def _runtime(self, yaml_path: str, run_state: RunState):
        from yaml_runtime import YAMLFunctionRuntime
        return YAMLFunctionRuntime(yaml_path, run_state=run_state)

    def test_get_edr_data_returns_stored(self, tmp_path):
        yaml_path = tmp_path / "test_tools.yaml"
        yaml_path.write_text("""
functions:
  - id: get_edr_data
    description: "Get EDR data"
    type: edr_state
    inputs: {}
    state:
      operation: get_edr_data
""")
        s = RunState("run_001", "ECN-001")
        s.set("edr_data", {"ecn_id": "ECN-001", "event_type": "Standard Referral"})
        rt = self._runtime(str(yaml_path), s)
        result = rt.execute("get_edr_data", {})
        assert result["found"] is True
        assert result["edr_data"]["ecn_id"] == "ECN-001"

    def test_set_edr_data_stores(self, tmp_path):
        yaml_path = tmp_path / "test_tools.yaml"
        yaml_path.write_text("""
functions:
  - id: store_edr_data
    description: "Store EDR data"
    type: edr_state
    inputs:
      edr_data:
        type: object
        required: true
    state:
      operation: set_edr_data
      value_field: edr_data
""")
        s = RunState("run_001", "ECN-001")
        rt = self._runtime(str(yaml_path), s)
        rt.execute("store_edr_data", {"edr_data": {"ecn_id": "ECN-001"}})
        assert s.get("edr_data")["ecn_id"] == "ECN-001"

    def test_set_answer_stores_structured_record(self, tmp_path):
        yaml_path = tmp_path / "test_tools.yaml"
        yaml_path.write_text("""
functions:
  - id: store_answer
    description: "Store answer"
    type: edr_state
    inputs:
      question_number:
        type: integer
        required: true
      answer:
        type: string
        required: true
      reasoning:
        type: string
        required: false
        default: ""
      requires_human:
        type: boolean
        required: false
        default: false
      human_action:
        type: string
        required: false
        default: ""
      category:
        type: string
        required: false
        default: ""
    state:
      operation: set_answer
""")
        s = RunState("run_001", "ECN-001")
        rt = self._runtime(str(yaml_path), s)
        result = rt.execute("store_answer", {
            "question_number": 3,
            "answer":          "N/A",
            "reasoning":       "EDR Type is Priority FC Business Approval.",
            "requires_human":  False,
            "category":        "Event Creation",
        })
        assert result["stored"] is True
        assert result["answer"] == "N/A"
        stored = s.get("answers.q3")
        assert stored["answer"]   == "N/A"
        assert stored["category"] == "Event Creation"

    def test_get_answers_returns_all(self, tmp_path):
        yaml_path = tmp_path / "test_tools.yaml"
        yaml_path.write_text("""
functions:
  - id: get_answers
    description: "Get all answers"
    type: edr_state
    inputs: {}
    state:
      operation: get_answers
""")
        s = RunState("run_001", "ECN-001")
        s.set("answers.q1", {"answer": "Y"})
        s.set("answers.q2", {"answer": "N/A"})
        rt = self._runtime(str(yaml_path), s)
        result = rt.execute("get_answers", {})
        assert result["count"] == 2

    def test_edr_state_without_run_state_raises(self, tmp_path):
        yaml_path = tmp_path / "test_tools.yaml"
        yaml_path.write_text("""
functions:
  - id: get_edr_data
    description: "test"
    type: edr_state
    inputs: {}
    state:
      operation: get_edr_data
""")
        from yaml_runtime import YAMLFunctionRuntime
        rt = YAMLFunctionRuntime(str(yaml_path), run_state=None)
        with pytest.raises(RuntimeError, match="no RunState was injected"):
            rt.execute("get_edr_data", {})

    def test_unknown_operation_raises(self, tmp_path):
        yaml_path = tmp_path / "test_tools.yaml"
        yaml_path.write_text("""
functions:
  - id: bad_op
    description: "test"
    type: edr_state
    inputs: {}
    state:
      operation: totally_unknown_op
""")
        s = RunState("run_001", "ECN-001")
        from yaml_runtime import YAMLFunctionRuntime
        rt = YAMLFunctionRuntime(str(yaml_path), s)
        with pytest.raises(ValueError, match="Unknown edr_state operation"):
            rt.execute("bad_op", {})


# ── Questions ─────────────────────────────────────────────────────────────────

class TestQuestions:

    def test_exactly_15_questions(self):
        assert len(EDR_QUESTIONS) == 15

    def test_numbered_1_to_15(self):
        assert [q.number for q in EDR_QUESTIONS] == list(range(1, 16))

    def test_no_forward_or_self_dependencies(self):
        for q in EDR_QUESTIONS:
            for dep in q.depends_on:
                assert dep < q.number, (
                    f"Q{q.number} has forward dep on Q{dep}"
                )

    def test_exact_dependency_chains(self):
        expected = {
            1: (), 2: (1,), 3: (1, 2), 4: (1, 2), 5: (1, 4),
            6: (4, 5), 7: (5, 6), 8: (6, 7), 9: (6, 7, 8),
            10: (6, 7), 11: (6, 7), 12: (6, 7),
            13: (10,), 14: (11,), 15: (12,),
        }
        for num, deps in expected.items():
            assert EDR_QUESTION_MAP[num].depends_on == deps

    def test_human_review_questions_are_10_12_13_15(self):
        assert HUMAN_REVIEW_QUESTION_NUMBERS == {10, 12, 13, 15}

    def test_all_questions_have_required_fields(self):
        for q in EDR_QUESTIONS:
            assert q.question.strip(),   f"Q{q.number} empty question"
            assert q.validation.strip(), f"Q{q.number} empty validation"
            assert q.check.strip(),      f"Q{q.number} empty check"


# ── Tool registry ─────────────────────────────────────────────────────────────

class TestToolRegistry:

    def test_exactly_3_tool_configs(self):
        assert len(EDR_TOOL_REGISTRY) == 3

    def test_agent_names_in_order(self):
        names = [c.name for c in EDR_TOOL_REGISTRY]
        assert names == ["ingest_agent", "qa_reasoning_agent", "report_agent"]

    def test_yaml_files_exist(self):
        for cfg in EDR_TOOL_REGISTRY:
            assert Path(cfg.yaml_path).exists(), (
                f"YAML file not found: {cfg.yaml_path}"
            )

    def test_all_yaml_files_have_functions_key(self):
        import yaml
        for cfg in EDR_TOOL_REGISTRY:
            with open(cfg.yaml_path) as f:
                data = yaml.safe_load(f)
            assert "functions" in data, f"Missing 'functions' key in {cfg.yaml_path}"
            assert len(data["functions"]) > 0


# ── YAML tool schemas ─────────────────────────────────────────────────────────

class TestYAMLToolSchemas:

    def test_edr_ingest_tools_has_expected_tools(self):
        import yaml
        with open("tools/edr_ingest_tools.yaml") as f:
            data = yaml.safe_load(f)
        tool_ids = {fn["id"] for fn in data["functions"]}
        assert "fetch_edr_data_api"  in tool_ids
        assert "fetch_edr_data_db"   in tool_ids
        assert "store_edr_data"      in tool_ids
        assert "get_edr_data"        in tool_ids

    def test_edr_qa_tools_has_expected_tools(self):
        import yaml
        with open("tools/edr_qa_tools.yaml") as f:
            data = yaml.safe_load(f)
        tool_ids = {fn["id"] for fn in data["functions"]}
        assert "get_edr_data"     in tool_ids
        assert "get_prior_answers" in tool_ids
        assert "answer_question"  in tool_ids
        assert "store_answer"     in tool_ids

    def test_edr_report_tools_has_expected_tools(self):
        import yaml
        with open("tools/edr_report_tools.yaml") as f:
            data = yaml.safe_load(f)
        tool_ids = {fn["id"] for fn in data["functions"]}
        assert "get_all_answers"  in tool_ids
        assert "get_edr_data"     in tool_ids
        assert "build_report"     in tool_ids
        assert "store_verdict"    in tool_ids

    def test_all_edr_state_tools_have_state_block(self):
        import yaml
        for path in [
            "tools/edr_ingest_tools.yaml",
            "tools/edr_qa_tools.yaml",
            "tools/edr_report_tools.yaml",
        ]:
            with open(path) as f:
                data = yaml.safe_load(f)
            for fn in data["functions"]:
                if fn["type"] == "edr_state":
                    assert "state" in fn, (
                        f"edr_state tool '{fn['id']}' in {path} missing 'state' block"
                    )
                    assert "operation" in fn["state"], (
                        f"edr_state tool '{fn['id']}' missing 'operation'"
                    )

    def test_python_tools_have_code_block(self):
        import yaml
        for path in [
            "tools/edr_qa_tools.yaml",
            "tools/edr_report_tools.yaml",
        ]:
            with open(path) as f:
                data = yaml.safe_load(f)
            for fn in data["functions"]:
                if fn["type"] == "python":
                    assert "python" in fn, (
                        f"python tool '{fn['id']}' missing 'python' block"
                    )
                    assert "code" in fn["python"], (
                        f"python tool '{fn['id']}' missing 'python.code'"
                    )


# ── Verdict logic ─────────────────────────────────────────────────────────────

class TestVerdictLogic:

    def _answers(self, mapping: dict[int, str]) -> dict:
        """Build an answers dict from {q_num: answer_str}."""
        return {
            f"q{n}": {"answer": v, "requires_human": v == "NEEDS_HUMAN"}
            for n, v in mapping.items()
        }

    def _run_build_report(self, answers: dict, tmp_path) -> dict:
        """Exercise the build_report python code directly."""
        import yaml, types as pytypes
        with open("tools/edr_report_tools.yaml") as f:
            data = yaml.safe_load(f)
        fn = next(fn for fn in data["functions"] if fn["id"] == "build_report")
        code = fn["python"]["code"]

        output_file = str(tmp_path / "result.json")
        inputs = {
            "answers":     answers,
            "edr_data":    {"ecn_id": "ECN-TEST"},
            "output_path": output_file,
        }
        local_ns = {"inputs": inputs, "result": None}
        exec(compile(code, "<test>", "exec"), {
            "__builtins__": __builtins__,
            "os": __import__("os"),
            "json": __import__("json"),
        }, local_ns)
        return local_ns["result"]

    def test_all_yes_returns_pass(self, tmp_path):
        answers = self._answers({i: "Y" for i in range(1, 16)})
        result  = self._run_build_report(answers, tmp_path)
        assert result["verdict"] == "PASS"
        assert result["overall_pass_rate"] == 100.0

    def test_any_no_returns_fail(self, tmp_path):
        answers = self._answers({i: "Y" for i in range(1, 16)})
        answers["q3"]["answer"] = "N"
        result = self._run_build_report(answers, tmp_path)
        assert result["verdict"] == "FAIL"
        assert 3 in result["failed_questions"]

    def test_needs_human_returns_requires_human_review(self, tmp_path):
        answers = self._answers({i: "Y" for i in range(1, 16)})
        answers["q10"]["answer"]          = "NEEDS_HUMAN"
        answers["q10"]["requires_human"]  = True
        result = self._run_build_report(answers, tmp_path)
        assert result["verdict"] == "REQUIRES_HUMAN_REVIEW"

    def test_fail_takes_priority_over_needs_human(self, tmp_path):
        answers = self._answers({i: "Y" for i in range(1, 16)})
        answers["q3"]["answer"]           = "N"
        answers["q10"]["answer"]          = "NEEDS_HUMAN"
        answers["q10"]["requires_human"]  = True
        result = self._run_build_report(answers, tmp_path)
        assert result["verdict"] == "FAIL"

    def test_na_excluded_from_pass_rate(self, tmp_path):
        answers = self._answers({i: "Y" for i in range(1, 11)})
        for i in range(11, 16):
            answers[f"q{i}"] = {"answer": "N/A", "requires_human": False}
        result = self._run_build_report(answers, tmp_path)
        assert result["overall_pass_rate"] == 100.0
        assert result["verdict"] == "PASS"

    def test_output_json_written(self, tmp_path):
        answers = self._answers({i: "Y" for i in range(1, 16)})
        self._run_build_report(answers, tmp_path)
        output_file = tmp_path / "result.json"
        assert output_file.exists()
        data = json.loads(output_file.read_text())
        assert data["verdict"] == "PASS"


# ── QAAnswer ──────────────────────────────────────────────────────────────────

class TestQAAnswer:

    def test_from_string(self):
        assert QAAnswer.from_string("Y")           == QAAnswer.YES
        assert QAAnswer.from_string("yes")         == QAAnswer.YES
        assert QAAnswer.from_string("N")           == QAAnswer.NO
        assert QAAnswer.from_string("n/a")         == QAAnswer.NA
        assert QAAnswer.from_string("NEEDS_HUMAN") == QAAnswer.NEEDS_HUMAN
        assert QAAnswer.from_string("garbage")     == QAAnswer.NEEDS_HUMAN


# ── AuditWriter ───────────────────────────────────────────────────────────────

class TestAuditWriter:

    def test_manifest_written(self, tmp_path):
        from audit.audit_writer import AuditWriter
        writer = AuditWriter("run_001", "ECN-001", audit_dir=str(tmp_path))
        writer.write_manifest("ECN-001", questions_count=15)
        manifest = json.loads((tmp_path / "run_001" / "00_run_manifest.json").read_text())
        assert manifest["run_id"]          == "run_001"
        assert manifest["questions_count"] == 15

    def test_agent_record_written(self, tmp_path):
        from audit.audit_writer import AuditWriter
        writer = AuditWriter("run_001", "ECN-001", audit_dir=str(tmp_path))
        writer.agent_started("ingest_agent")
        writer.write_agent_record(
            agent_name="ingest_agent",
            status="success",
            response_text="INGEST OK",
        )
        record = json.loads(
            (tmp_path / "run_001" / "01_ingest_agent.json").read_text()
        )
        assert record["agent_name"] == "ingest_agent"
        assert record["status"]     == "success"
        assert record["attempt"]    == 1

    def test_run_summary_written(self, tmp_path):
        from audit.audit_writer import AuditWriter
        writer = AuditWriter("run_001", "ECN-001", audit_dir=str(tmp_path))
        writer.write_run_summary(
            verdict="PASS",
            pass_rate=100.0,
            failed_questions=[],
            human_items=[],
            duration_seconds=12.3,
            state_snapshot={},
        )
        summary = json.loads(
            (tmp_path / "run_001" / "04_run_summary.json").read_text()
        )
        assert summary["verdict"]          == "PASS"
        assert summary["duration_seconds"] == 12.3


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
