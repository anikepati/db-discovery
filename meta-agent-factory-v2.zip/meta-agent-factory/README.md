# Meta Agent Factory (MAF) v2

## Enterprise Meta-Agent System for Automated Agent Pipeline Generation

---

## Overview

**Meta Agent Factory** is an enterprise-grade system that ingests Standard Operating Procedure (SOP)
Markdown documents and JSON reference files, analyzes them to determine the automation mode,
identifies all required data points, and generates complete, runnable Google ADK multi-agent
pipelines — hardened through a 6-dimension critic loop to meet enterprise production standards.

### What It Does

```
SOP.md + refs.json  →  [19-Agent Pipeline]  →  Production-Ready ADK Agent System
                                                  ├── agent.py (hardened)
                                                  ├── tools.py (mode-specific)
                                                  ├── callbacks.py (observability)
                                                  ├── config.yaml (zero-code tuning)
                                                  ├── runner.py (entry point)
                                                  ├── tests/ (auto-generated)
                                                  ├── docs/ (architecture, runbook)
                                                  ├── sample_data.json
                                                  ├── quality_report.json
                                                  ├── Dockerfile
                                                  └── requirements.txt
```

### Key Design Principles

- **Config-First**: All behavior driven by YAML. Zero code changes after deployment.
- **Three Automation Modes**: Browser (Playwright), Thick Client (PyAutoGUI), System (API/CLI).
- **Enterprise Hardening**: 6 critic agents evaluate security, resilience, observability,
  performance, edge cases, and compliance — iterating until quality threshold is met.
- **Dual-Model Strategy**: gemini-2.0-flash for fast I/O agents, claude-sonnet for reasoning agents.

---

## Architecture

### Three-Phase Pipeline (19 Agent Instances, 14 Unique Definitions)

```
┌──────────────────────────────────────────────────────────────────┐
│ PHASE 1: Analysis + Generation                                   │
│                                                                   │
│  SOP.md ──→ IngestAgent ──→ AnalyzerAgent ──→ DataPointAgent     │
│     +           (flash)       (sonnet)          (sonnet)         │
│  refs.json                                                        │
│                  ──→ PlannerAgent ──→ ┌──────────────────────┐   │
│                       (sonnet)       │ LoopAgent (max 3)     │   │
│                                      │  GeneratorAgent       │   │
│                                      │  ValidatorAgent       │   │
│                                      └──────────────────────┘   │
│                  ──→ MockDataAgent                                │
│                       (flash)                                     │
├──────────────────────────────────────────────────────────────────┤
│ PHASE 2: Enterprise Hardening Loop (max 3 iterations)            │
│                                                                   │
│  ┌─ ParallelAgent (Tier 1) ─────────────────────────────────┐   │
│  │  SecurityCritic   ResilienceCritic                        │   │
│  │  ObservCritic     PerformanceCritic                       │   │
│  └───────────────────────────────────────────────────────────┘   │
│  ┌─ ParallelAgent (Tier 2) ─────────────────────────────────┐   │
│  │  EdgeCaseCritic   ComplianceCritic                        │   │
│  └───────────────────────────────────────────────────────────┘   │
│       ──→ RefactorAgent ──→ QualityGateAgent                     │
│            (sonnet)          (sonnet)                             │
│                                 │                                 │
│                    PASS ────────┼──────── ITERATE (loop back)    │
│                    │            └──────── FAIL (escalate)         │
├──────────────────────────────────────────────────────────────────┤
│ PHASE 3: Packaging + Emission                                    │
│                                                                   │
│  DocGenAgent ──→ TestGenAgent ──→ PackagerAgent ──→ WriterAgent  │
│   (flash)         (flash)          (flash)          (flash)      │
└──────────────────────────────────────────────────────────────────┘
```

### Agent Inventory

| # | Agent | Model | Phase | Role |
|---|-------|-------|-------|------|
| 1 | IngestAgent | gemini-flash | 1 | Parse SOP markdown + JSON refs |
| 2 | AnalyzerAgent | claude-sonnet | 1 | Classify automation mode, analyze steps |
| 3 | DataPointAgent | claude-sonnet | 1 | Extract all data requirements |
| 4 | PlannerAgent | claude-sonnet | 1 | Design agent topology + tool mappings |
| 5 | GeneratorAgent | claude-sonnet | 1 | Generate ADK pipeline code |
| 6 | ValidatorAgent | claude-sonnet | 1 | AST validation, state flow checks |
| 7 | MockDataAgent | gemini-flash | 1 | Generate realistic sample data |
| 8 | SecurityCritic | claude-sonnet | 2 | Auth, secrets, injection, RBAC |
| 9 | ResilienceCritic | claude-sonnet | 2 | Retry, circuit breaker, fallback |
| 10 | ObservabilityCritic | claude-sonnet | 2 | Logging, metrics, tracing, audit |
| 11 | PerformanceCritic | claude-sonnet | 2 | Context bloat, cost, model selection |
| 12 | EdgeCaseCritic | claude-sonnet | 2 | Null, unicode, boundary, race conditions |
| 13 | ComplianceCritic | claude-sonnet | 2 | PII flow, data retention, regulatory |
| 14 | RefactorAgent | claude-sonnet | 2 | Apply all critic remediations |
| 15 | QualityGateAgent | claude-sonnet | 2 | Weighted scoring, pass/fail decision |
| 16 | DocGenAgent | gemini-flash | 3 | README, architecture, runbook |
| 17 | TestGenAgent | gemini-flash | 3 | pytest suite from edge case findings |
| 18 | PackagerAgent | gemini-flash | 3 | Final deliverable assembly |
| 19 | WriterAgent | gemini-flash | 3 | Write files to disk |

---

## Automation Mode Detection

The system classifies each SOP into one of three modes using multi-signal analysis:

| Mode | Tool Stack | Detected By |
|------|-----------|-------------|
| **BROWSER** | Playwright MCP | URLs, web forms, login pages, dropdowns, dashboards |
| **THICK_CLIENT** | PyAutoGUI | Desktop apps, dialogs, menus, toolbars, right-click |
| **SYSTEM** | httpx + subprocess | API endpoints, SQL, CLI commands, file transforms |
| **HYBRID** | Mixed | Multiple modes detected with high confidence |

---

## Project Structure

```
meta-agent-factory/
├── __init__.py
├── main.py                              # CLI entry point
├── README.md
├── core/                                # Pipeline orchestrators
│   ├── pipeline.py                      # v1 pipeline (8 agents)
│   ├── pipeline_v2.py                   # v2 enterprise pipeline (19 agents)
│   ├── mode_detector.py                 # Rule-based mode classification
│   └── data_extractor.py               # Rule-based data point extraction
├── agents/                              # All agent definitions
│   ├── ingest_agent.py                 # Phase 1: SOP parser
│   ├── analyzer_agent.py              # Phase 1: Mode + step classifier
│   ├── datapoint_agent.py             # Phase 1: Data requirement extractor
│   ├── planner_agent.py               # Phase 1: Architecture designer
│   ├── generator_agent.py             # Phase 1: Code generator
│   ├── validator_agent.py             # Phase 1: AST + state validator
│   ├── mockdata_agent.py              # Phase 1: Sample data generator
│   ├── refactor_agent.py              # Phase 2: Applies critic fixes
│   ├── quality_gate_agent.py          # Phase 2: Pass/fail decision
│   ├── packaging_agents.py            # Phase 3: DocGen, TestGen, Packager
│   ├── writer_agent.py                # Phase 3: File writer
│   └── critics/                        # Enterprise critic agents
│       ├── security_critic.py
│       ├── resilience_critic.py
│       ├── observability_critic.py
│       ├── performance_critic.py
│       ├── edge_case_critic.py
│       └── compliance_critic.py
├── models/
│   └── schemas.py                      # All dataclasses and enums
├── templates/
│   └── code_templates.py              # Jinja2 templates per automation mode
├── configs/
│   └── maf_config.yaml                # Master YAML configuration
├── utils/
│   └── config_loader.py               # YAML config singleton with env interpolation
├── generators/                          # Template rendering (extensible)
└── sample_data/
    ├── sops/
    │   ├── web_customer_creation.md    # Browser mode example SOP
    │   ├── desktop_invoice_generation.md  # Thick client example SOP
    │   └── api_data_sync_etl.md        # System mode example SOP
    └── refs/
        ├── field_mapping.json          # CRM-to-DW field mapping reference
        └── status_codes.json           # Order status code lookup
```

---

## Quick Start

### Prerequisites

- Python 3.11+
- Google ADK (latest)
- Anthropic API key (for claude-sonnet agents)
- Google AI API key (for gemini-flash agents)

### Installation

```bash
cd meta-agent-factory

pip install google-adk anthropic pyyaml jinja2 httpx tenacity --break-system-packages

# For browser automation mode
pip install playwright --break-system-packages && playwright install chromium

# For thick client automation mode
pip install pyautogui Pillow pyperclip --break-system-packages

# Set environment variables
export GOOGLE_API_KEY="your-google-api-key"
export ANTHROPIC_API_KEY="your-anthropic-api-key"
```

### Running the Factory

```bash
# Browser automation SOP
python main.py \
  --sop ./sample_data/sops/web_customer_creation.md \
  --refs ./sample_data/refs/field_mapping.json \
  --output ./generated/web_customer/

# System/API SOP with multiple references
python main.py \
  --sop ./sample_data/sops/api_data_sync_etl.md \
  --refs ./sample_data/refs/field_mapping.json ./sample_data/refs/status_codes.json \
  --output ./generated/etl_pipeline/

# Thick client SOP
python main.py \
  --sop ./sample_data/sops/desktop_invoice_generation.md \
  --output ./generated/invoice_gen/

# Inspect pipeline
python main.py --info
```

### Programmatic Usage

```python
import asyncio
from core.pipeline_v2 import MetaAgentFactoryV2

async def main():
    factory = MetaAgentFactoryV2(config_path="configs/maf_config.yaml")

    result = await factory.run(
        sop_path="./sample_data/sops/web_customer_creation.md",
        ref_paths=["./sample_data/refs/field_mapping.json"],
        output_dir="./generated/web_customer/",
    )

    quality = result["quality_gate"]
    print(f"Decision: {quality.get('decision')}")
    print(f"Score: {quality.get('aggregate_score')}")
    print(f"Iterations: {result['hardening_iterations']}")

asyncio.run(main())
```

---

## Configuration Reference

All behavior is controlled via `configs/maf_config.yaml`.

### Models

```yaml
models:
  fast_io:
    provider: "google"
    model_id: "gemini-2.0-flash"
    temperature: 0.1
  reasoning:
    provider: "anthropic"
    model_id: "claude-sonnet-4-20250514"
    temperature: 0.2
```

### Pipeline Retry

```yaml
pipeline:
  retry:
    max_attempts: 3
    backoff: "exponential"
    base_delay_seconds: 2
```

### Mode Keywords (extensible)

```yaml
automation_modes:
  browser:
    keywords: ["browser", "web", "url", "login page", "dropdown", ...]
  thick_client:
    keywords: ["desktop", "application", "dialog", "menu bar", ...]
  system:
    keywords: ["api", "endpoint", "rest", "database", "script", ...]
```

### PII Detection

```yaml
data_detection:
  pii_keywords: ["ssn", "social security", "credit card", "date of birth", ...]
```

---

## Enterprise Hardening: Critic Details

### Quality Gate Scoring

| Critic | Weight | Min Threshold |
|--------|--------|---------------|
| Security | 0.25 | 0.70 |
| Resilience | 0.20 | 0.65 |
| Observability | 0.15 | 0.60 |
| Performance | 0.15 | 0.60 |
| Edge Cases | 0.15 | 0.55 |
| Compliance | 0.10 | 0.60 |

### Gate Decisions

| Decision | Condition |
|----------|-----------|
| **PASS** | Aggregate >= 0.75, all individual >= threshold, zero criticals |
| **ITERATE** | Aggregate 0.50-0.75, iteration < max (3) |
| **FAIL** | Aggregate <= 0.50 OR criticals remain after max iterations |

### What Each Critic Checks

- **SecurityCritic**: Hardcoded credentials, SQL/shell injection, disabled TLS, RBAC gaps, CWE references
- **ResilienceCritic**: Missing retries, no circuit breaker, unbounded timeouts, no fallback, state corruption
- **ObservabilityCritic**: No structured logging, missing metrics, no correlation ID, PII in logs
- **PerformanceCritic**: Context window bloat, wrong model tier, N+1 queries, missed parallelization
- **EdgeCaseCritic**: Null crashes, unicode failures, boundary overflow, race conditions, stale selectors
- **ComplianceCritic**: Untracked PII flow, incomplete audit trail, no data retention, regulatory gaps

---

## Generated Output Structure

```
<pipeline_name>/
├── agent.py                    # ADK agent definitions (hardened)
├── tools.py                    # Mode-specific tool functions
├── callbacks.py                # Observability + context management
├── config.yaml                 # Pipeline configuration
├── runner.py                   # Entry point
├── sample_data.json            # Test data (5+ records)
├── requirements.txt            # Dependencies
├── Dockerfile                  # Container deployment
├── .env.example                # Environment template
├── quality_report.json         # Critic scores + findings
├── README.md                   # Quick start
├── CHANGELOG.md                # Generation details
├── utils/
│   ├── pii_masking.py          # PII hash/mask utilities
│   ├── circuit_breaker.py      # Circuit breaker pattern
│   └── structured_logging.py   # JSON logging setup
├── docs/
│   ├── ARCHITECTURE.md         # Agent topology + data flow
│   ├── DATA_DICTIONARY.md      # Every data point documented
│   └── RUNBOOK.md              # Operational guide
└── tests/
    ├── conftest.py             # Shared fixtures
    ├── test_tools.py           # Tool unit tests
    ├── test_callbacks.py       # Callback tests
    ├── test_pipeline.py        # Integration tests
    ├── test_data_validation.py # Validation tests
    └── test_edge_cases.py      # Edge case tests
```

---

## Writing SOPs for MAF

### Format

```markdown
# SOP: <Title>
## Version: <X.Y>
## Domain: <Business Domain>

## Prerequisites
- <What must be true before starting>

## Procedure

### Step 1: <Step Title>
1. <Action description>
2. Enter "<Field Name>" in the <field> field
3. Click "<Button Name>" button
4. **Expected**: <What should happen>
5. **Error Handling**: <What to do on failure>

## Error Handling
- <Global error handling rules>

## Output
- <What the process produces>
```

### Tips

1. Use specific verbs: "Navigate to", "Click", "Enter", "Select from dropdown"
2. Include URLs for browser SOPs
3. Name every field explicitly in quotes
4. Specify expected results for validation steps
5. Include error handling per step
6. List all outputs at the end

---

## Sample SOPs Included

| SOP | Mode | Steps | Domain |
|-----|------|-------|--------|
| `web_customer_creation.md` | BROWSER | 8 | Customer Onboarding |
| `desktop_invoice_generation.md` | THICK_CLIENT | 10 | Finance/Billing |
| `api_data_sync_etl.md` | SYSTEM | 10 | Data Engineering |

---

## Stats

- **Total files**: 40
- **Python lines**: 5,300+
- **Total lines**: 6,100+
- **Agent definitions**: 14 unique (19 instances in pipeline)
- **Phases**: 3
- **Critic dimensions**: 6
- **Automation modes**: 3 + hybrid
- **Sample SOPs**: 3
- **Sample reference files**: 2

---

*Built with Google Agent Development Kit (ADK) and Anthropic Claude.*
