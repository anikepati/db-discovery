"""
Mode Validator — Validates user-specified automation mode against SOP content.

The user DECLARES the mode. This utility checks whether the SOP content is
consistent with that declaration and produces warnings if signals suggest
a different or hybrid mode.

This is a pre-LLM validation step — fast, rule-based, no API calls.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from models.schemas import AutomationMode, ModeSignal
from utils.config_loader import MAFConfig


@dataclass
class ModeValidationResult:
    """Result of validating user-specified mode against SOP content."""
    declared_mode: AutomationMode
    is_consistent: bool
    consistency_score: float
    signals_found: dict[str, int]
    warnings: list[str] = field(default_factory=list)
    suggestions: list[str] = field(default_factory=list)


class ModeValidator:
    """Validates user-declared automation mode against SOP signal analysis."""

    def __init__(self, config: MAFConfig = None):
        self.config = config or MAFConfig()

    def validate(self, declared_mode: str, sop_text: str) -> ModeValidationResult:
        """
        Validate that SOP content is consistent with the user-declared mode.

        Args:
            declared_mode: User-specified mode (browser, thick_client, system, hybrid)
            sop_text: Raw SOP markdown text

        Returns:
            ModeValidationResult with consistency assessment
        """
        mode = self._str_to_mode(declared_mode.lower())
        text_lower = sop_text.lower()

        # Count signals for each mode
        signal_counts = {}
        for mode_name in ["browser", "thick_client", "system"]:
            keywords = self.config.get_mode_keywords(mode_name)
            count = sum(text_lower.count(kw.lower()) for kw in keywords)
            signal_counts[mode_name] = count

        # URL detection as strong browser signal
        url_count = len(re.findall(r'https?://[^\s\)]+', sop_text))
        signal_counts["browser"] += url_count * 2

        # API pattern as strong system signal
        api_count = len(re.findall(r'/v\d+/\w+', sop_text))
        signal_counts["system"] += api_count * 2

        # Desktop UI elements as strong thick_client signal
        desktop_count = len(re.findall(
            r'(menu bar|toolbar|dialog|splash screen|system tray|double-click|desktop icon)',
            text_lower
        ))
        signal_counts["thick_client"] += desktop_count * 2

        # Determine consistency
        total = sum(signal_counts.values()) or 1
        declared_key = declared_mode.lower()
        warnings = []
        suggestions = []

        if mode == AutomationMode.HYBRID:
            # For HYBRID, check that at least 2 modes have signals
            modes_with_signals = sum(1 for v in signal_counts.values() if v > 0)
            is_consistent = modes_with_signals >= 2
            consistency_score = min(modes_with_signals / 2.0, 1.0)
            if not is_consistent:
                warnings.append(
                    "HYBRID mode declared but signals found for only one mode. "
                    "Consider using a single mode instead."
                )
        else:
            declared_score = signal_counts.get(declared_key, 0) / total
            is_consistent = declared_score >= 0.3
            consistency_score = min(declared_score * 1.5, 1.0)

            # Check if another mode has stronger signals
            for other_mode, count in signal_counts.items():
                if other_mode != declared_key and count > signal_counts.get(declared_key, 0) * 1.5:
                    warnings.append(
                        f"Declared mode is {declared_mode.upper()}, but SOP has stronger "
                        f"{other_mode.upper()} signals ({count} vs {signal_counts.get(declared_key, 0)}). "
                        f"Verify the mode is correct."
                    )

            # Check if SOP has significant signals for other modes (might need HYBRID)
            for other_mode, count in signal_counts.items():
                if other_mode != declared_key and count > 3:
                    suggestions.append(
                        f"SOP has {count} {other_mode.upper()} signals alongside the "
                        f"declared {declared_mode.upper()} mode. Consider HYBRID if "
                        f"the SOP spans both modes."
                    )

        return ModeValidationResult(
            declared_mode=mode,
            is_consistent=is_consistent,
            consistency_score=round(consistency_score, 2),
            signals_found={
                "browser": signal_counts["browser"],
                "thick_client": signal_counts["thick_client"],
                "system": signal_counts["system"],
            },
            warnings=warnings,
            suggestions=suggestions,
        )

    @staticmethod
    def _str_to_mode(mode_str: str) -> AutomationMode:
        mapping = {
            "browser": AutomationMode.BROWSER,
            "thick_client": AutomationMode.THICK_CLIENT,
            "system": AutomationMode.SYSTEM,
            "hybrid": AutomationMode.HYBRID,
        }
        return mapping.get(mode_str, AutomationMode.SYSTEM)
