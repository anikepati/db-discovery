"""
QA Pipeline — entry point.

Usage:
    python main.py --process-id PROC-2024-001
    python main.py --process-id PROC-2024-002 --output result.json --quiet

Exit codes:
    0  pipeline ran — verdict is PASS or CONDITIONAL PASS
    1  configuration error or unrecoverable pipeline failure
    2  pipeline ran — verdict is FAIL or REQUIRES ESCALATION
  130  interrupted (Ctrl-C)
"""

import argparse
import asyncio
import json
import sys
from datetime import datetime
from pathlib import Path

# Ensure project root is importable regardless of working directory
sys.path.insert(0, str(Path(__file__).parent))

from config import settings, configure_logging
from models import QAResult
from pipeline_runner import PipelineRunner


def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="Agentic QA Process Evaluator — Google ADK",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Demo process IDs:\n"
            "  PROC-2024-001  Customer Onboarding  (expected: CONDITIONAL PASS)\n"
            "  PROC-2024-002  Loan Approval         (expected: FAIL / ESCALATION)\n"
        ),
    )
    p.add_argument("--process-id", required=True, help="Process ID to evaluate")
    p.add_argument("--output", default=None, help="Save JSON result to this path")
    p.add_argument("--quiet", action="store_true", help="Suppress per-agent output")
    p.add_argument("--user-id", default=None, help="User ID for session tracking")
    return p.parse_args()


def _save(result: QAResult, path: str) -> None:
    output = {
        "run": {
            "process_id": result.process_id,
            "session_id": result.session_id,
            "started_at": result.started_at.isoformat(),
            "completed_at": result.completed_at.isoformat(),
            "duration_seconds": result.duration_seconds,
        },
        "verdict": {
            "verdict": result.verdict.value,
            "overall_score": result.overall_score,
            "passed": result.passed,
            "executive_summary": result.executive_summary,
            "blocking_issues": result.blocking_issues,
            "remediation_actions": result.remediation_actions,
            "next_steps": result.next_steps,
        },
        "answers": [
            {
                "number": a.number,
                "title": a.title,
                "depends_on": a.depends_on,
                "reasoning": a.reasoning,
                "answer": a.answer,
            }
            for a in result.answers
        ],
    }
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(f"\n💾  Saved to {path}")


async def main() -> int:
    args = _parse_args()

    try:
        settings.validate()
    except ValueError as exc:
        print(f"\n❌  Config error: {exc}\n", file=sys.stderr)
        return 1

    configure_logging(
        log_level=settings.log_level,
        log_dir=settings.log_dir,
        app_name=settings.app_name,
        is_production=settings.is_production,
    )

    try:
        runner = PipelineRunner()
        result = await runner.run(
            process_id=args.process_id,
            user_id=args.user_id,
            verbose=not args.quiet,
        )
    except RuntimeError as exc:
        print(f"\n❌  Pipeline failed: {exc}\n", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\n\n⏹  Interrupted.\n")
        return 130

    if args.output:
        _save(result, args.output)
    elif not args.quiet:
        ts = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        default = f"result_{args.process_id}_{ts}.json"
        if input(f"Save results to '{default}'? [y/N]: ").strip().lower() == "y":
            _save(result, default)

    return 0 if result.passed else 2


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
