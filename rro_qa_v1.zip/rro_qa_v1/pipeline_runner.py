"""
pipeline_runner.py — RRO QA v1
Startup: generates 13 Q YAMLs + 15-entry registry.
Per run: creates session, calls run_rro_qa, parses result, writes audit.
"""

import asyncio
import json
import logging
import os
import time
from datetime import datetime
from pathlib import Path

from config import settings
from models import EDRQAResult, QAAnswer, QuestionResult, Verdict
from audit.audit_writer import AuditWriter
from tool_generator import generate_all_question_yamls
from tool_registry import build_registry, validate_yaml_files, ToolConfig
from agents.agent import run_rro_qa

logger = logging.getLogger(__name__)

_ICONS = {
    "PASS":                  "✅",
    "PASS_WITH_EXCEPTIONS":  "⚠️ ",
    "FAIL":                  "❌",
    "REQUIRES_HUMAN_REVIEW": "👤",
}

_REGISTRY: list[ToolConfig] | None = None


def _get_registry() -> list[ToolConfig]:
    global _REGISTRY
    if _REGISTRY is None:
        generated = generate_all_question_yamls(tools_dir="tools", force=False)
        logger.info("Q YAMLs ready: %d", len(generated))
        _REGISTRY = build_registry()
        validate_yaml_files(_REGISTRY)
        logger.info("Registry ready: %d agents", len(_REGISTRY))
    return _REGISTRY


class PipelineRunner:

    async def run(
        self,
        ecn_id:       str,
        output_path:  str | None = None,
        work_item_id: str = "",
        verbose:      bool = True,
    ) -> dict:

        registry = _get_registry()
        ts       = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        run_id   = f"run_{ts}_{ecn_id}"
        t0       = time.time()

        if output_path is None:
            os.makedirs(settings.outputs_dir, exist_ok=True)
            output_path = os.path.join(
                settings.outputs_dir, f"rro_{ecn_id}_{ts}.json"
            )

        audit = AuditWriter(run_id=run_id, ecn_id=ecn_id,
                            audit_dir=settings.audit_dir)
        audit.write_manifest(ecn_id=ecn_id, questions_count=13)

        if verbose:
            print(f"\n{'═' * 64}")
            print(f"  RRO QA PIPELINE v1  |  ECN: {ecn_id}")
            print(f"  Run    : {run_id}")
            print(f"  Output : {output_path}")
            print(f"  Agents : 15 (1 ingest + 13 Q + 1 report)")
            print(f"  Models : Gemini Flash (ingest) + Claude claude-sonnet-4-6 (Q/report)")
            print(f"{'═' * 64}")

        last_exc = None
        for attempt in range(1, settings.max_retries + 1):
            try:
                await run_rro_qa(
                    ecn_id=ecn_id,
                    run_id=run_id,
                    output_path=output_path,
                    registry=registry,
                    audit=audit,
                    work_item_id=work_item_id,
                    verbose=verbose,
                )
                break
            except Exception as exc:
                last_exc = exc
                logger.error("Attempt %d/%d failed: %s", attempt, settings.max_retries, exc)
                if attempt < settings.max_retries:
                    await asyncio.sleep(settings.retry_delay * attempt)
                else:
                    raise RuntimeError(
                        f"Pipeline failed after {settings.max_retries} attempts."
                    ) from last_exc

        duration = time.time() - t0
        result   = self._load_result(output_path)

        audit.write_run_summary(
            verdict=result.get("verdict", "UNKNOWN"),
            pass_rate=result.get("overall_pass_rate", 0.0),
            failed_questions=result.get("failed_questions", []),
            human_items=result.get("human_review_required", []),
            duration_seconds=duration,
            state_snapshot={},
        )

        if verbose:
            self._print_result(result, output_path, audit.audit_path())

        return result

    def _load_result(self, output_path: str) -> dict:
        try:
            return json.loads(Path(output_path).read_text(encoding="utf-8"))
        except Exception:
            return {"verdict": "REQUIRES_HUMAN_REVIEW", "overall_pass_rate": 0.0}

    def _print_result(self, result: dict, output_path: str, audit_path: str):
        verdict = result.get("verdict", "UNKNOWN")
        icon    = _ICONS.get(verdict, "❓")
        print(f"\n{'═' * 64}")
        print(f"  {icon}  {verdict}")
        print(f"  ECN      : {result.get('ecn_number','')}")
        print(f"  RRO #    : {result.get('rro_number','')}")
        print(f"  Pass Rate: {result.get('overall_pass_rate', 0):.1f}%")
        print(f"{'═' * 64}")
        if result.get("failed_questions"):
            print(f"\n❌ Failed   : Q{result['failed_questions']}")
        if result.get("human_review_required"):
            print(f"\n👤 Human review ({len(result['human_review_required'])}):")
            for item in result["human_review_required"]:
                print(f"   Q{item['question']}: {item['action_required']}")
        print(f"\n💾 Report   : {output_path}")
        print(f"🗂  Audit    : {audit_path}/\n")
