"""
agents/agent.py
---------------
Core agent builder for the EDR QA pipeline.

Mirrors the AgentMCP handle_request() pattern exactly:

  ┌─────────────────────────────────────────────────────────┐
  │  run_edr_qa(ecn_id, run_id, run_state, ...)             │
  │                                                         │
  │  AsyncExitStack (owns all resources for this run)       │
  │  │                                                      │
  │  ├─ ingest_agent                                        │
  │  │    └─ InMemoryTransport → MCP Server                 │
  │  │         (edr_ingest_tools.yaml + run_state)          │
  │  │                                                      │
  │  ├─ qa_reasoning_agent                                  │
  │  │    └─ InMemoryTransport → MCP Server                 │
  │  │         (edr_qa_tools.yaml + run_state)              │
  │  │                                                      │
  │  ├─ report_agent                                        │
  │  │    └─ InMemoryTransport → MCP Server                 │
  │  │         (edr_report_tools.yaml + run_state)          │
  │  │                                                      │
  │  └─ orchestrator (routes via AgentTool — chat messages) │
  │                                                         │
  │  AsyncExitStack cleans up all transports on exit        │
  └─────────────────────────────────────────────────────────┘

Key EDR-specific differences from AgentMCP:
  - run_state injected into every MCP server so edr_state tools share one dict
  - audit_writer records per-agent timing and response
  - Orchestrator instruction is EDR-specific (ingest → qa → report pipeline)
  - Sequential delegation — not domain-routing like the CRM/Finance/HR example
"""

import logging
from contextlib import AsyncExitStack

from dotenv import load_dotenv
from google.adk.agents import LlmAgent
from google.adk.tools.agent_tool import AgentTool
from google.adk.tools.mcp_tool.mcp_toolset import MCPToolset
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types
from mcp.shared.memory import (
    create_connected_server_and_client_session as create_in_memory_pair,
)

from config import settings
from mcp_factory import create_mcp_server
from models import RunState
from tool_registry import EDR_TOOL_REGISTRY, ToolConfig
from audit.audit_writer import AuditWriter

load_dotenv()
logger = logging.getLogger(__name__)


# ── In-memory MCP session builder ─────────────────────────────────────────────

async def _build_in_memory_tools(
    config:     ToolConfig,
    run_state:  RunState,
    exit_stack: AsyncExitStack,
) -> list:
    """
    Creates an in-memory MCP server from a YAML file (with run_state injected)
    and connects an ADK MCPToolset to it via async memory transport.

    run_state is passed into the MCP server so edr_state tools can read
    and write the shared per-run dict directly — no external storage needed.
    """
    server = create_mcp_server(config.yaml_path, run_state=run_state)

    client_session = await exit_stack.enter_async_context(
        create_in_memory_pair(server)
    )
    mcp_toolset = MCPToolset(client_session=client_session)
    tools = await exit_stack.enter_async_context(mcp_toolset)
    return tools


# ── Sub-agent builder ──────────────────────────────────────────────────────────

async def _build_sub_agent(
    config:     ToolConfig,
    run_state:  RunState,
    exit_stack: AsyncExitStack,
) -> LlmAgent:
    """Build one EDR specialist LlmAgent backed by an in-memory MCP server."""
    tools = await _build_in_memory_tools(config, run_state, exit_stack)
    return LlmAgent(
        name=config.name,
        model=settings.adk_model,
        description=config.description,
        instruction=config.instruction,
        tools=tools,
    )


# ── Orchestrator builder ───────────────────────────────────────────────────────

async def _build_orchestrator(sub_agents: list[LlmAgent]) -> LlmAgent:
    """
    Build the orchestrator that delegates to the 3 EDR agents in sequence
    via AgentTool (chat messages — not tool calls).
    """
    agent_list = "\n".join(
        f"  - {cfg.name}: {cfg.description}"
        for cfg in EDR_TOOL_REGISTRY
    )

    return LlmAgent(
        name="edr_qa_orchestrator",
        model=settings.adk_model,
        description="Orchestrates the EDR QA pipeline: Ingest → QA Reasoning → Report",
        instruction=f"""
You are the EDR QA Pipeline Orchestrator.

Your job is to run the 3 EDR QA agents in strict sequence for a given ECN.
Do not skip any agent. Do not change the order.

Available agents:
{agent_list}

Pipeline execution order:
1. Delegate to ingest_agent — pass the ecn_id and wait for "INGEST OK".
   If you receive "INGEST FAILED" — stop and report the error.

2. Delegate to qa_reasoning_agent — pass the ecn_id and output_path and
   wait for "REASONING COMPLETE — 15/15".
   If fewer than 15 questions are answered — report the gap.

3. Delegate to report_agent — pass the output_path and wait for "REPORT WRITTEN".
   If you receive "REPORT FAILED" — stop and report the error.

When all 3 complete, respond with a final summary:
  EDR QA PIPELINE COMPLETE
  ECN:     <ecn_id>
  Verdict: <verdict>
  Pass:    <pass_rate>%
  Failed:  <failed_questions or none>
  Human:   <human_review_count> items requiring action
  Report:  <output_path>

Rules:
- Always run all 3 agents regardless of intermediate answers.
- Never fabricate results — only report what the agents return.
- If any agent fails after retries — mark that stage FAILED in the summary.
""",
        tools=[AgentTool(agent=a) for a in sub_agents],
    )


# ── Main run function ──────────────────────────────────────────────────────────

async def run_edr_qa(
    ecn_id:      str,
    run_id:      str,
    run_state:   RunState,
    output_path: str,
    audit:       AuditWriter,
    verbose:     bool = True,
) -> str:
    """
    Run the full EDR QA pipeline for one ECN.

    Fully isolated — each call creates its own:
      - RunState (shared across agents within this run, private to this run)
      - in-memory MCP servers (one per yaml file)
      - transport pairs
      - ADK session and runner

    Concurrent runs for different ECNs never share any state.

    Returns the orchestrator's final response text.
    """
    async with AsyncExitStack() as stack:

        # 1. Build all 3 sub-agents with shared run_state injected
        sub_agents = [
            await _build_sub_agent(cfg, run_state, stack)
            for cfg in EDR_TOOL_REGISTRY
        ]

        # 2. Build orchestrator on top of sub-agents
        orchestrator = await _build_orchestrator(sub_agents)

        # 3. Create ADK session and runner
        session_service = InMemorySessionService()
        session = await session_service.create_session(
            app_name=settings.app_name,
            user_id=run_id,
            session_id=run_id,
        )

        runner = Runner(
            agent=orchestrator,
            app_name=settings.app_name,
            session_service=session_service,
        )

        # 4. Build the initial user message
        message = types.Content(
            role="user",
            parts=[types.Part(text=(
                f"Run the full EDR QA pipeline for ECN: {ecn_id}. "
                f"Output path: {output_path}."
            ))],
        )

        if verbose:
            print(f"\n{'─' * 60}")
            print(f"  📋  EDR QA Pipeline  |  {ecn_id}  |  {run_id}")
            print(f"{'─' * 60}")

        # 5. Stream events
        response_text = ""
        current_agent = None

        async for event in runner.run_async(
            user_id=run_id,
            session_id=run_id,
            new_message=message,
        ):
            # Track agent transitions for audit
            if event.author and event.author != current_agent:
                if current_agent:
                    audit.write_agent_record(
                        agent_name=current_agent,
                        status="success",
                        response_text=response_text,
                        state_snapshot=run_state.snapshot(),
                    )
                current_agent = event.author
                audit.agent_started(current_agent)
                if verbose:
                    icons = {
                        "ingest_agent":       "📥",
                        "qa_reasoning_agent": "🔍",
                        "report_agent":       "📊",
                        "edr_qa_orchestrator": "🎯",
                    }
                    icon = icons.get(current_agent, "▶")
                    print(f"\n{'─' * 50}\n  {icon}  {current_agent}\n{'─' * 50}")
                logger.info(
                    "Agent started: %s", current_agent,
                    extra={"run_id": run_id, "ecn_id": ecn_id, "agent": current_agent},
                )

            # Show tool calls
            if event.get_function_calls() and verbose:
                for call in event.get_function_calls():
                    print(f"  🔧 {call.name}({str(call.args)[:80]})")

            # Capture final response
            if event.is_final_response() and event.content:
                for part in event.content.parts:
                    if hasattr(part, "text") and part.text:
                        response_text = part.text.strip()
                        if verbose:
                            print(f"\n{response_text[:3000]}"
                                  f"{'…' if len(response_text) > 3000 else ''}\n")

        # Write audit for last agent
        if current_agent:
            audit.write_agent_record(
                agent_name=current_agent,
                status="success",
                response_text=response_text,
                state_snapshot=run_state.snapshot(),
            )

        return response_text
