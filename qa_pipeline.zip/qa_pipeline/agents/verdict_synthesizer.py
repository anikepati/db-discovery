"""
QA Pipeline - Verdict Synthesizer Agent
Final agent that reads ALL 10 answers and produces a structured JSON verdict
suitable for downstream systems (dashboards, notifications, ticketing).
"""

import logging

from google.adk.agents import LlmAgent

from config.settings import agent_config
from tools.state_tools import make_answer_key

logger = logging.getLogger(__name__)

# Build the state key references for all 10 answers
_ALL_ANSWER_KEYS = "\n".join(
    [f"  - Q{i}: session state key '{make_answer_key(i)}'" for i in range(1, 11)]
)

VERDICT_SYNTHESIZER_INSTRUCTION = f"""
You are the QA Pipeline Verdict Synthesizer.

Your job is to read all 10 QA question answers from session state and produce a final 
structured JSON verdict that can be consumed by downstream systems.

## Input — All Answer Keys
{_ALL_ANSWER_KEYS}

## Your Task

1. Read and synthesize all 10 answers
2. Produce a final structured JSON verdict

## Required JSON Output Structure

You MUST respond with ONLY valid JSON — no preamble, no markdown, no explanation.

{{
  "verdict": "PASS" | "CONDITIONAL_PASS" | "FAIL" | "REQUIRES_ESCALATION",
  "overall_score": <float 0-100>,
  "executive_summary": "<3-5 sentence summary for leadership>",
  "dimension_scores": {{
    "compliance": <0-100>,
    "risk_management": <0-100>,
    "security": <0-100>,
    "performance": <0-100>,
    "audit_governance": <0-100>
  }},
  "blocking_issues": [
    {{"issue": "<description>", "severity": "critical|high", "source_question": <int>}}
  ],
  "non_blocking_issues": [
    {{"issue": "<description>", "severity": "medium|low", "source_question": <int>}}
  ],
  "remediation_actions": [
    {{
      "priority": "P1|P2|P3",
      "action": "<specific action>",
      "owner_role": "<role>",
      "deadline_days": <int>
    }}
  ],
  "next_steps": ["<step 1>", "<step 2>", "<step 3>"],
  "requires_escalation": <true|false>,
  "escalation_reason": "<reason or null>"
}}

## Scoring Guidelines

- overall_score: Weighted average (compliance 30%, risk 25%, security 25%, performance 10%, audit 10%)
- PASS: score >= 80, zero blocking issues
- CONDITIONAL_PASS: score 60-79, or blocking issues with accepted remediation plan
- FAIL: score < 60, or unresolved critical blocking issues
- REQUIRES_ESCALATION: regulatory risk, systemic failures, or score < 40

## Important

- Output ONLY the JSON object — nothing else
- All fields are required
- If a field is not applicable, use null or empty array []
- Base scores on actual findings from Q1-Q10, not assumptions
"""


def create_verdict_synthesizer_agent() -> LlmAgent:
    """Create the verdict synthesizer agent."""
    return LlmAgent(
        name="VerdictSynthesizerAgent",
        model=agent_config.model,
        instruction=VERDICT_SYNTHESIZER_INSTRUCTION,
        tools=[],
        output_key="final_verdict_json",
        description=(
            "Synthesizes all 10 QA answers into a final structured JSON verdict. "
            "Runs after all question agents complete."
        ),
    )
