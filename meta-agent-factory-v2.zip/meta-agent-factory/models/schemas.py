"""
Meta Agent Factory - Core Models
Enterprise data models for SOP analysis, agent generation, and automation mode detection.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional


# ─────────────────────────────────────────────
# Automation Mode Classification
# ─────────────────────────────────────────────

class AutomationMode(Enum):
    """Three-mode automation classification."""
    BROWSER = "browser"           # Playwright-based web automation
    THICK_CLIENT = "thick_client" # PyAutoGUI desktop automation
    SYSTEM = "system"             # API/CLI/script automation
    HYBRID = "hybrid"             # Mixed-mode (multiple detected)


class DataPointType(Enum):
    """Classification of data points extracted from SOPs."""
    INPUT = "input"               # User/external input required
    DERIVED = "derived"           # Computed from other data points
    REFERENCE = "reference"       # Lookup from reference data
    STATE = "state"               # Pipeline state variable
    OUTPUT = "output"             # Final output/result
    CREDENTIAL = "credential"     # Auth/secret data


class StepType(Enum):
    """SOP step classification."""
    NAVIGATION = "navigation"     # Go to URL/screen/location
    INPUT = "input"               # Fill form/field/dialog
    CLICK = "click"               # Button/link/element interaction
    VALIDATION = "validation"     # Check/verify/assert
    DECISION = "decision"         # If/else branch point
    WAIT = "wait"                 # Explicit wait/delay
    EXTRACTION = "extraction"     # Read/capture data
    API_CALL = "api_call"         # HTTP/REST/SOAP call
    FILE_OP = "file_operation"    # File read/write/transform
    SUBPROCESS = "subprocess"     # CLI/shell command


# ─────────────────────────────────────────────
# SOP Parsing Models
# ─────────────────────────────────────────────

@dataclass
class SOPStep:
    """Single step from an SOP document."""
    step_id: str
    step_number: int
    title: str
    description: str
    step_type: StepType
    automation_mode: AutomationMode
    target: Optional[str] = None          # URL, app name, API endpoint
    selector: Optional[str] = None        # CSS/XPath/image ref
    input_data: Optional[str] = None      # What to type/select
    expected_result: Optional[str] = None  # Validation criteria
    screenshot_ref: Optional[str] = None   # Reference screenshot
    preconditions: list[str] = field(default_factory=list)
    data_points_needed: list[str] = field(default_factory=list)
    data_points_produced: list[str] = field(default_factory=list)
    error_handling: Optional[str] = None
    retry_strategy: Optional[str] = None
    timeout_seconds: int = 30
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class SOPDocument:
    """Parsed SOP document with full metadata."""
    sop_id: str
    title: str
    version: str
    domain: str
    description: str
    declared_mode: AutomationMode          # User-specified, not auto-detected
    steps: list[SOPStep] = field(default_factory=list)
    preconditions: list[str] = field(default_factory=list)
    postconditions: list[str] = field(default_factory=list)
    data_points: list[DataPoint] = field(default_factory=list)
    reference_files: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)
    raw_markdown: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)


# ─────────────────────────────────────────────
# Data Point Models
# ─────────────────────────────────────────────

@dataclass
class DataPoint:
    """A data element required or produced by the SOP pipeline."""
    dp_id: str
    name: str
    dp_type: DataPointType
    data_format: str                       # string, int, float, date, email, etc.
    description: str
    required: bool = True
    default_value: Optional[Any] = None
    validation_rule: Optional[str] = None  # regex, range, enum values
    source: Optional[str] = None           # Where this comes from
    depends_on: list[str] = field(default_factory=list)
    sample_values: list[Any] = field(default_factory=list)
    pii_flag: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class DataSchema:
    """Complete data schema for a generated agent pipeline."""
    schema_id: str
    sop_id: str
    data_points: list[DataPoint]
    relationships: list[DataRelationship] = field(default_factory=list)
    reference_mappings: dict[str, str] = field(default_factory=dict)


@dataclass
class DataRelationship:
    """Dependency relationship between data points."""
    source_dp_id: str
    target_dp_id: str
    relationship_type: str  # derives_from, validates_against, populates
    transform: Optional[str] = None


# ─────────────────────────────────────────────
# Agent Generation Models
# ─────────────────────────────────────────────

@dataclass
class ToolSpec:
    """Specification for a tool needed by a generated agent."""
    tool_id: str
    tool_name: str
    tool_type: str               # mcp, function, api
    provider: str                # playwright_mcp, pyautogui, native
    description: str
    parameters: dict[str, Any] = field(default_factory=dict)
    returns: Optional[str] = None
    requires_auth: bool = False
    timeout_seconds: int = 30


@dataclass
class AgentSpec:
    """Specification for a single agent in the generated pipeline."""
    agent_id: str
    agent_name: str
    agent_type: str              # SequentialAgent, LoopAgent, LlmAgent, CustomAgent
    model: str
    description: str
    instruction: str
    tools: list[ToolSpec] = field(default_factory=list)
    sub_agents: list[str] = field(default_factory=list)
    input_keys: list[str] = field(default_factory=list)
    output_key: Optional[str] = None
    state_keys: list[str] = field(default_factory=list)
    before_agent_callback: Optional[str] = None
    after_agent_callback: Optional[str] = None
    error_handler: Optional[str] = None
    config: dict[str, Any] = field(default_factory=dict)


@dataclass
class PipelineSpec:
    """Complete pipeline specification for code generation."""
    pipeline_id: str
    sop_id: str
    pipeline_name: str
    automation_mode: AutomationMode
    agents: list[AgentSpec]
    state_schema: dict[str, str]
    tool_registry: list[ToolSpec]
    entry_point: str
    config_yaml: dict[str, Any] = field(default_factory=dict)
    callbacks: dict[str, str] = field(default_factory=dict)
    error_strategy: str = "retry_with_backoff"
    max_retries: int = 3


# ─────────────────────────────────────────────
# Mode Validation Models (mode is user-specified)
# ─────────────────────────────────────────────

@dataclass
class ModeSignal:
    """Evidence signal found in SOP content for mode validation."""
    signal_type: str             # keyword, context, target, tool_hint
    signal_value: str
    indicated_mode: AutomationMode
    strength: float              # 0.0 - 1.0
    source_step: Optional[str] = None


@dataclass 
class ModeValidation:
    """Result of validating user-specified mode against SOP content."""
    declared_mode: AutomationMode
    is_consistent: bool
    consistency_score: float
    signals: list[ModeSignal] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    suggestions: list[str] = field(default_factory=list)


# ─────────────────────────────────────────────
# Validation Models
# ─────────────────────────────────────────────

@dataclass
class ValidationResult:
    """Result from the ValidatorAgent."""
    is_valid: bool
    errors: list[ValidationError] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    ast_check_passed: bool = False
    tool_refs_valid: bool = False
    state_flow_valid: bool = False
    score: float = 0.0


@dataclass
class ValidationError:
    """Specific validation error."""
    error_type: str              # syntax, tool_ref, state_flow, missing_import
    message: str
    file_path: Optional[str] = None
    line_number: Optional[int] = None
    severity: str = "error"      # error, warning, info
    suggestion: Optional[str] = None


# ─────────────────────────────────────────────
# Factory Output Models
# ─────────────────────────────────────────────

@dataclass
class FactoryOutput:
    """Complete output from the Meta Agent Factory."""
    sop_document: SOPDocument
    mode_validation: ModeValidation
    data_schema: DataSchema
    pipeline_spec: PipelineSpec
    generated_files: dict[str, str]        # filename -> content
    sample_data: dict[str, Any]
    validation_result: ValidationResult
    config_yaml: str
    execution_instructions: str
