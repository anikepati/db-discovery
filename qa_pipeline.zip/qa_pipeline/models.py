"""
QA Pipeline - Domain Models
Strongly-typed data models for QA process data and results.
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Optional


class ProcessStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING_REVIEW = "pending_review"
    APPROVED = "approved"
    REJECTED = "rejected"
    ESCALATED = "escalated"


class QAVerdict(str, Enum):
    PASS = "pass"
    FAIL = "fail"
    CONDITIONAL_PASS = "conditional_pass"
    REQUIRES_ESCALATION = "requires_escalation"
    INCONCLUSIVE = "inconclusive"


class Severity(str, Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"
    NONE = "none"


@dataclass
class ProcessMetadata:
    """Core metadata about the business process under QA review."""
    process_id: str
    process_name: str
    business_unit: str
    owner: str
    created_date: datetime
    last_modified: datetime
    status: ProcessStatus
    version: str
    environment: str
    tags: list[str] = field(default_factory=list)


@dataclass
class ComplianceRecord:
    """Compliance and regulatory information."""
    framework: str           # e.g., SOX, GDPR, ISO27001
    last_audit_date: Optional[datetime]
    next_audit_due: Optional[datetime]
    compliance_score: float  # 0.0 - 100.0
    open_findings: int
    critical_findings: int
    certifications: list[str] = field(default_factory=list)
    exceptions: list[str] = field(default_factory=list)


@dataclass
class RiskProfile:
    """Risk assessment for the process."""
    inherent_risk: Severity
    residual_risk: Severity
    risk_score: float         # 0.0 - 10.0
    risk_categories: list[str] = field(default_factory=list)
    mitigating_controls: list[str] = field(default_factory=list)
    risk_owner: str = ""
    last_assessed: Optional[datetime] = None


@dataclass
class PerformanceMetrics:
    """Process performance data."""
    avg_completion_time_minutes: float
    sla_threshold_minutes: float
    sla_breach_count_30d: int
    error_rate_percent: float
    throughput_per_day: float
    availability_percent: float
    last_incident_date: Optional[datetime] = None
    kpis: dict[str, float] = field(default_factory=dict)


@dataclass
class SecurityAssessment:
    """Security controls and vulnerabilities."""
    access_control_level: str
    encryption_at_rest: bool
    encryption_in_transit: bool
    mfa_enabled: bool
    last_pen_test_date: Optional[datetime]
    open_vulnerabilities: int
    critical_vulnerabilities: int
    data_classification: str  # public, internal, confidential, restricted
    privileged_access_users: int = 0


@dataclass
class AuditTrail:
    """Recent audit history."""
    total_changes_30d: int
    unauthorized_access_attempts: int
    policy_violations_90d: int
    last_reviewed_by: str
    last_review_date: Optional[datetime]
    review_outcome: str
    findings: list[dict[str, str]] = field(default_factory=list)


@dataclass
class QAProcessData:
    """
    Complete dataset for QA process evaluation.
    This is the primary data structure passed through the pipeline.
    """
    metadata: ProcessMetadata
    compliance: ComplianceRecord
    risk_profile: RiskProfile
    performance: PerformanceMetrics
    security: SecurityAssessment
    audit_trail: AuditTrail
    raw_data: dict[str, Any] = field(default_factory=dict)
    fetched_at: datetime = field(default_factory=datetime.utcnow)

    def to_summary_dict(self) -> dict[str, Any]:
        """Return a flattened summary for agent prompt injection."""
        return {
            "process_id": self.metadata.process_id,
            "process_name": self.metadata.process_name,
            "business_unit": self.metadata.business_unit,
            "status": self.metadata.status.value,
            "version": self.metadata.version,
            "environment": self.metadata.environment,
            "compliance_score": self.compliance.compliance_score,
            "compliance_framework": self.compliance.framework,
            "open_findings": self.compliance.open_findings,
            "critical_findings": self.compliance.critical_findings,
            "inherent_risk": self.risk_profile.inherent_risk.value,
            "residual_risk": self.risk_profile.residual_risk.value,
            "risk_score": self.risk_profile.risk_score,
            "mitigating_controls": self.risk_profile.mitigating_controls,
            "avg_completion_time_min": self.performance.avg_completion_time_minutes,
            "sla_threshold_min": self.performance.sla_threshold_minutes,
            "sla_breaches_30d": self.performance.sla_breach_count_30d,
            "error_rate_pct": self.performance.error_rate_percent,
            "availability_pct": self.performance.availability_percent,
            "encryption_at_rest": self.security.encryption_at_rest,
            "encryption_in_transit": self.security.encryption_in_transit,
            "mfa_enabled": self.security.mfa_enabled,
            "open_vulnerabilities": self.security.open_vulnerabilities,
            "critical_vulnerabilities": self.security.critical_vulnerabilities,
            "data_classification": self.security.data_classification,
            "policy_violations_90d": self.audit_trail.policy_violations_90d,
            "unauthorized_access_attempts": self.audit_trail.unauthorized_access_attempts,
        }


@dataclass
class QuestionAnswer:
    """Single QA question with its answer and metadata."""
    question_number: int
    question_text: str
    reasoning: str
    answer: str
    confidence: float          # 0.0 - 1.0
    depends_on: list[int]
    answered_at: datetime = field(default_factory=datetime.utcnow)
    agent_name: str = ""


@dataclass
class QAPipelineResult:
    """Final output of the complete QA pipeline."""
    process_id: str
    session_id: str
    answers: list[QuestionAnswer]
    verdict: QAVerdict
    verdict_reasoning: str
    overall_score: float        # 0.0 - 100.0
    critical_issues: list[str]
    recommendations: list[str]
    next_steps: list[str]
    started_at: datetime
    completed_at: datetime = field(default_factory=datetime.utcnow)
    total_duration_seconds: float = 0.0

    @property
    def passed(self) -> bool:
        return self.verdict in (QAVerdict.PASS, QAVerdict.CONDITIONAL_PASS)

    def summary(self) -> str:
        duration = self.total_duration_seconds
        return (
            f"Process {self.process_id} | Verdict: {self.verdict.value.upper()} | "
            f"Score: {self.overall_score:.1f}/100 | "
            f"Critical Issues: {len(self.critical_issues)} | "
            f"Duration: {duration:.1f}s"
        )
