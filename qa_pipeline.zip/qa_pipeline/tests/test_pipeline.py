"""
QA Pipeline - Test Suite
Unit and integration tests for pipeline components.

Run: pytest tests/ -v
Run with coverage: pytest tests/ -v --cov=. --cov-report=term-missing
"""

import json
import pytest
import asyncio
from datetime import datetime
from unittest.mock import AsyncMock, MagicMock, patch

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from models import (
    QAPipelineResult,
    QAVerdict,
    QuestionAnswer,
    ProcessStatus,
    Severity,
)
from tools.state_tools import (
    extract_answer_section,
    build_context_for_agent,
    make_answer_key,
    make_reasoning_key,
)
from tools.fetch_tools import fetch_qa_process_data, validate_process_exists
from agents.questions import QA_QUESTIONS, QUESTION_MAP


# ─────────────────────────────────────────────
# Fixtures
# ─────────────────────────────────────────────

@pytest.fixture
def valid_process_id():
    return "PROC-2024-001"


@pytest.fixture
def invalid_process_id():
    return "PROC-DOES-NOT-EXIST"


@pytest.fixture
def sample_qa_data_json(valid_process_id):
    return fetch_qa_process_data(valid_process_id)


# ─────────────────────────────────────────────
# Tool Tests
# ─────────────────────────────────────────────

class TestFetchTools:

    def test_fetch_valid_process(self, valid_process_id):
        result_json = fetch_qa_process_data(valid_process_id)
        result = json.loads(result_json)

        assert result["status"] == "success"
        assert result["process_id"] == valid_process_id
        assert "compliance_score" in result
        assert "risk_score" in result
        assert "encryption_at_rest" in result

    def test_fetch_invalid_process(self, invalid_process_id):
        result_json = fetch_qa_process_data(invalid_process_id)
        result = json.loads(result_json)

        assert result["status"] == "error"
        assert invalid_process_id in result["message"]

    def test_validate_existing_process(self, valid_process_id):
        result_json = validate_process_exists(valid_process_id)
        result = json.loads(result_json)

        assert result["exists"] is True
        assert result["process_id"] == valid_process_id
        assert "process_name" in result

    def test_validate_nonexistent_process(self, invalid_process_id):
        result_json = validate_process_exists(invalid_process_id)
        result = json.loads(result_json)

        assert result["exists"] is False

    def test_fetch_returns_all_required_fields(self, valid_process_id):
        result = json.loads(fetch_qa_process_data(valid_process_id))
        required_fields = [
            "process_id", "process_name", "business_unit", "status",
            "compliance_score", "risk_score", "encryption_at_rest",
            "encryption_in_transit", "mfa_enabled", "error_rate_pct",
            "availability_pct", "open_vulnerabilities",
        ]
        for field in required_fields:
            assert field in result, f"Missing required field: {field}"


# ─────────────────────────────────────────────
# State Tool Tests
# ─────────────────────────────────────────────

class TestStateTools:

    def test_make_answer_key(self):
        assert make_answer_key(1) == "answer_q1"
        assert make_answer_key(10) == "answer_q10"

    def test_make_reasoning_key(self):
        assert make_reasoning_key(1) == "reasoning_q1"

    def test_extract_answer_section_structured(self):
        raw = """REASONING:
The process has active status and is in production.
It meets basic eligibility criteria.

ANSWER:
ELIGIBLE — Process is active in production with version 3.2.1."""

        parsed = extract_answer_section(raw)
        assert "active" in parsed["reasoning"].lower()
        assert "ELIGIBLE" in parsed["answer"]
        assert parsed["reasoning"] != ""
        assert parsed["answer"] != ""

    def test_extract_answer_section_unstructured(self):
        raw = "The process appears eligible based on available data."
        parsed = extract_answer_section(raw)
        assert parsed["answer"] == raw.strip()
        assert parsed["reasoning"] == ""

    def test_build_context_includes_qa_data(self, sample_qa_data_json):
        context = build_context_for_agent(
            qa_data_json=sample_qa_data_json,
            prior_answers={},
            depends_on=[],
        )
        assert "QA PROCESS DATA" in context
        assert "compliance_score" in context

    def test_build_context_includes_prior_answers(self, sample_qa_data_json):
        prior = {1: "ELIGIBLE — process is active", 2: "SOX framework applies"}
        context = build_context_for_agent(
            qa_data_json=sample_qa_data_json,
            prior_answers=prior,
            depends_on=[1, 2],
        )
        assert "Q1 Answer" in context
        assert "ELIGIBLE" in context
        assert "SOX" in context

    def test_build_context_missing_dependency_handled(self, sample_qa_data_json):
        # Q3 depends on Q1 and Q2, but only Q1 is available
        context = build_context_for_agent(
            qa_data_json=sample_qa_data_json,
            prior_answers={1: "ELIGIBLE"},
            depends_on=[1, 2],
        )
        assert "NOT YET AVAILABLE" in context


# ─────────────────────────────────────────────
# Question Definition Tests
# ─────────────────────────────────────────────

class TestQuestionDefinitions:

    def test_all_10_questions_defined(self):
        assert len(QA_QUESTIONS) == 10

    def test_questions_numbered_1_to_10(self):
        numbers = sorted([q.number for q in QA_QUESTIONS])
        assert numbers == list(range(1, 11))

    def test_question_map_matches_list(self):
        assert len(QUESTION_MAP) == 10
        for q in QA_QUESTIONS:
            assert q.number in QUESTION_MAP
            assert QUESTION_MAP[q.number] == q

    def test_q1_has_no_dependencies(self):
        assert QUESTION_MAP[1].depends_on == []

    def test_q2_depends_on_q1(self):
        assert 1 in QUESTION_MAP[2].depends_on

    def test_q10_depends_on_all_prior(self):
        deps = QUESTION_MAP[10].depends_on
        for i in range(1, 10):
            assert i in deps, f"Q10 should depend on Q{i}"

    def test_all_questions_have_required_fields(self):
        for q in QA_QUESTIONS:
            assert q.number > 0
            assert len(q.title) > 0, f"Q{q.number} missing title"
            assert len(q.question) > 20, f"Q{q.number} question too short"
            assert len(q.evaluation_criteria) > 0, f"Q{q.number} missing evaluation criteria"
            assert len(q.expected_output_format) > 0, f"Q{q.number} missing output format"

    def test_dependency_chain_is_acyclic(self):
        """Verify no circular dependencies."""
        for q in QA_QUESTIONS:
            assert q.number not in q.depends_on, f"Q{q.number} depends on itself"
            for dep in q.depends_on:
                assert dep < q.number, (
                    f"Q{q.number} depends on Q{dep} which comes AFTER it — invalid!"
                )


# ─────────────────────────────────────────────
# Model Tests
# ─────────────────────────────────────────────

class TestModels:

    def test_qa_pipeline_result_passed_verdicts(self):
        def make_result(verdict):
            return QAPipelineResult(
                process_id="TEST-001",
                session_id="session-1",
                answers=[],
                verdict=verdict,
                verdict_reasoning="test",
                overall_score=75.0,
                critical_issues=[],
                recommendations=[],
                next_steps=[],
                started_at=datetime.utcnow(),
            )

        assert make_result(QAVerdict.PASS).passed is True
        assert make_result(QAVerdict.CONDITIONAL_PASS).passed is True
        assert make_result(QAVerdict.FAIL).passed is False
        assert make_result(QAVerdict.REQUIRES_ESCALATION).passed is False
        assert make_result(QAVerdict.INCONCLUSIVE).passed is False

    def test_qa_pipeline_result_summary(self):
        result = QAPipelineResult(
            process_id="PROC-001",
            session_id="sess-abc",
            answers=[],
            verdict=QAVerdict.PASS,
            verdict_reasoning="All checks passed.",
            overall_score=88.5,
            critical_issues=[],
            recommendations=["Update documentation"],
            next_steps=["Schedule next review"],
            started_at=datetime.utcnow(),
            total_duration_seconds=42.3,
        )
        summary = result.summary()
        assert "PROC-001" in summary
        assert "pass" in summary.lower()
        assert "88.5" in summary

    def test_process_status_enum_values(self):
        assert ProcessStatus.ACTIVE.value == "active"
        assert ProcessStatus.REJECTED.value == "rejected"

    def test_severity_ordering(self):
        severities = [Severity.INFO, Severity.LOW, Severity.MEDIUM, Severity.HIGH, Severity.CRITICAL]
        assert len(severities) == 5


# ─────────────────────────────────────────────
# Agent Creation Tests
# ─────────────────────────────────────────────

class TestAgentCreation:

    def test_data_fetcher_agent_created(self):
        from agents.data_fetcher import create_data_fetcher_agent
        agent = create_data_fetcher_agent()
        assert agent.name == "DataFetcherAgent"
        assert agent.output_key == "qa_raw_data"
        assert len(agent.tools) == 2

    def test_question_agents_created(self):
        from agents.question_agents import create_all_question_agents
        agents = create_all_question_agents()
        assert len(agents) == 10
        for i, agent in enumerate(agents, 1):
            assert agent.name == f"QuestionAgent_{i:02d}"
            assert agent.output_key == make_answer_key(i)

    def test_verdict_agent_created(self):
        from agents.verdict_synthesizer import create_verdict_synthesizer_agent
        agent = create_verdict_synthesizer_agent()
        assert agent.name == "VerdictSynthesizerAgent"
        assert agent.output_key == "final_verdict_json"

    def test_pipeline_assembled(self):
        from agents.orchestrator import create_qa_pipeline
        pipeline = create_qa_pipeline()
        assert pipeline.name == "QAPipelineOrchestrator"
        # DataFetcher + 10 Questions + VerdictSynthesizer = 12 agents
        assert len(pipeline.sub_agents) == 12


# ─────────────────────────────────────────────
# Runner tests (with mocked ADK calls)
# ─────────────────────────────────────────────

class TestPipelineRunner:

    @pytest.mark.asyncio
    async def test_runner_initializes(self):
        with patch.dict("os.environ", {"GOOGLE_API_KEY": "test-key-mock"}):
            from pipeline_runner import QAPipelineRunner
            runner = QAPipelineRunner()
            assert runner.app_name is not None
            assert runner.session_service is not None

    def test_result_build_with_empty_state(self):
        with patch.dict("os.environ", {"GOOGLE_API_KEY": "test-key-mock"}):
            from pipeline_runner import QAPipelineRunner
            runner = QAPipelineRunner()
            result = runner._build_result(
                process_id="TEST-001",
                session_id="sess-test",
                state={},
                started_at=datetime.utcnow(),
                elapsed=5.0,
            )
            assert result.process_id == "TEST-001"
            assert result.verdict == QAVerdict.INCONCLUSIVE
            assert len(result.answers) == 10  # All 10 questions, even if empty

    def test_result_build_with_verdict_json(self):
        with patch.dict("os.environ", {"GOOGLE_API_KEY": "test-key-mock"}):
            from pipeline_runner import QAPipelineRunner
            runner = QAPipelineRunner()

            verdict_json = json.dumps({
                "verdict": "PASS",
                "overall_score": 85.0,
                "executive_summary": "All checks passed successfully.",
                "blocking_issues": [],
                "remediation_actions": [
                    {"priority": "P3", "action": "Update docs", "owner_role": "QA Lead", "deadline_days": 90}
                ],
                "next_steps": ["Schedule next review"],
                "requires_escalation": False,
                "escalation_reason": None,
            })

            state = {"final_verdict_json": verdict_json}
            result = runner._build_result(
                process_id="TEST-001",
                session_id="sess-test",
                state=state,
                started_at=datetime.utcnow(),
                elapsed=10.0,
            )
            assert result.verdict == QAVerdict.PASS
            assert result.overall_score == 85.0
            assert result.passed is True


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
