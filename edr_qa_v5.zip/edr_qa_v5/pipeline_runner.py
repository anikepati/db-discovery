"""
pipeline_runner.py
------------------
Creates run_id, seeds context.state, calls run_edr_qa(), returns EDRQAResult.
"""

import asyncio
import json
import logging
import os
import time
from datetime import datetime
from pathlib import Path

from config import settings, configure_logging
from models import EDRQAResult, QAAnswer, QuestionResult, Verdict
from audit.audit_writer import AuditWriter
from agents.agent import run_edr_qa

logger = logging.getLogger(__name__)

_VERDICT_ICONS = {
    "PASS":                  "✅",
    "PASS_WITH_EXCEPTIONS":  "⚠️ ",
    "FAIL":                  "❌",
    "REQUIRES_HUMAN_REVIEW": "👤",
}


class PipelineRunner:

    async def run(
        self,
        ecn_id:      str,
        output_path: str | None = None,
        verbose:     bool = True,
    ) -> EDRQAResult:
        ts      = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        run_id  = f"run_{ts}_{ecn_id}"
        started = datetime.utcnow()
        t0      = time.time()

        os.makedirs(settings.outputs_dir, exist_ok=True)
        if output_path is None:
            output_path = os.path.join(settings.outputs_dir, f"edr_{ecn_id}_{ts}.json")

        audit = AuditWriter(run_id=run_id, ecn_id=ecn_id, audit_dir=settings.audit_dir)
        audit.write_manifest(ecn_id=ecn_id)

        if verbose:
            print(f"\n{'═' * 62}")
            print(f"  EDR QA PIPELINE  v5  (17 agents + ADK context.state)")
            print(f"  ECN      : {ecn_id}")
            print(f"  Run ID   : {run_id}")
            print(f"  DB View  : vw_get_qa_actimize_data")
            print(f"  Output   : {output_path}")
            print(f"{'═' * 62}")

        last_exc: Exception | None = None
        for attempt in range(1, settings.max_retries + 1):
            try:
                await run_edr_qa(
                    ecn_id=ecn_id,
                    run_id=run_id,
                    output_path=output_path,
                    audit=audit,
                    verbose=verbose,
                )
                break
            except Exception as exc:
                last_exc = exc
                logger.error("Attempt %d/%d failed: %s", attempt, settings.max_retries, exc, exc_info=True)
                if attempt < settings.max_retries:
                    delay = settings.retry_delay * attempt
                    if verbose:
                        print(f"\n⟳  Retry {attempt}/{settings.max_retries} in {delay:.0f}s…")
                    await asyncio.sleep(delay)
                else:
                    raise RuntimeError(
                        f"Pipeline failed after {settings.max_retries} attempts: {exc}"
                    ) from last_exc

        duration = time.time() - t0
        result   = self._load_result(ecn_id, run_id, output_path, started, duration, audit.audit_path())

        audit.write_run_summary(
            verdict=result.verdict.value,
            pass_rate=result.overall_pass_rate,
            failed_questions=result.failed_questions,
            human_items=result.human_review_items,
            duration_seconds=duration,
        )

        if verbose:
            self._print_result(result)

        return result

    def _load_result(
        self,
        ecn_id: str, run_id: str, output_path: str,
        started_at: datetime, duration: float, audit_path: str,
    ) -> EDRQAResult:
        try:
            data = json.loads(Path(output_path).read_text(encoding="utf-8"))
        except Exception:
            data = {}

        verdict = Verdict.from_string(data.get("verdict", "REQUIRES_HUMAN_REVIEW"))
        qresults = [
            QuestionResult(
                number=a["number"],
                category=a.get("category", ""),
                answer=QAAnswer.from_string(a.get("answer", "NEEDS_HUMAN")),
                reasoning=a.get("reasoning", ""),
                requires_human=a.get("requires_human", False),
                human_action=a.get("human_action", ""),
            )
            for a in data.get("answers", [])
        ]
        return EDRQAResult(
            run_id=run_id,
            ecn_id=ecn_id,
            verdict=verdict,
            overall_pass_rate=float(data.get("overall_pass_rate", 0.0)),
            question_results=qresults,
            failed_questions=data.get("failed_questions", []),
            human_review_items=data.get("human_review_required", []),
            output_path=output_path,
            audit_path=audit_path,
            started_at=started_at,
            completed_at=datetime.utcnow(),
            duration_seconds=duration,
        )

    def _print_result(self, r: EDRQAResult) -> None:
        icon = _VERDICT_ICONS.get(r.verdict.value, "❓")
        print(f"\n{'═' * 62}")
        print(f"  {icon}  {r.verdict.value}")
        print(f"  ECN:      {r.ecn_id}")
        print(f"  Pass:     {r.overall_pass_rate:.1f}%")
        print(f"  Duration: {r.duration_seconds:.1f}s")
        if r.failed_questions:
            print(f"  Failed:   Q{r.failed_questions}")
        if r.human_review_items:
            print(f"\n  👤 Human review ({len(r.human_review_items)}):")
            for item in r.human_review_items:
                print(f"     Q{item['question']}: {item['action_required']}")
        print(f"\n  💾 Report : {r.output_path}")
        print(f"  🗂  Audit  : {r.audit_path}/")
        print(f"{'═' * 62}\n")
