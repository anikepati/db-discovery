---
name: edr-q06
description: >
  EDR QA Question 6 of 15 (Level 2 Review): Validate the decision rationale aligns with the risk decision type..
  Reads EDR data from context.state, reasons using Claude claude-sonnet-4-6, writes
  answer to context.state["answers"]["q6"]. Use only in EDR QA pipeline.
license: Proprietary
metadata:
  author: edr-qa-team
  version: "5.0"
  pipeline: edr-qa-v5
  question_number: "6"
  category: "Level 2 Review"
  requires_human: "false"
compatibility: Requires ADK ToolContext, Anthropic API, context.state with edr_data populated
allowed-tools: get_edr_data get_prior_answers answer_question store_answer
---

# EDR QA — Question 6: Level 2 Review

**Validate the decision rationale aligns with the risk decision type.**

## Dependencies

Depends on: Q04, Q05

Prior answers for dependent questions MUST be in `context.state["answers"]` before this agent runs.

## Steps

1. Call `get_edr_data()` — reads `context.state["edr_data"]` (populated by IngestAgent)
2. Call `get_prior_answers()` — reads `context.state["answers"]` for dependent Q answers
3. Call `answer_question(question_number=6, edr_data=<step1>, prior_answers=<step2>)`
   - This calls Claude claude-sonnet-4-6 with the check logic and EDR data
   - Returns: `answer`, `reasoning`, `requires_human`, `human_action`
4. Call `store_answer(question_number=6, answer=..., reasoning=..., ...)` 
   - Writes to `context.state["answers"]["q6"]`
5. Respond with exactly:

```
Q06 [Level 2 Review]: <answer>
REASONING: <1-2 sentence summary>
```

## Check Logic

```
If l2_decision = 'Accept': l2_action should be blank, l2_rationale aligns to L1. If l2_decision = 'Amend': l2_action should be populated. If l2_multiple_rows = True: check l2_lob value. If all conditions met: Y. Else: N.
```

## Validation

Assess L2 decision, action, rationale alignment.

## Output Format

State l2_decision, l2_action (blank or populated), l2_rationale alignment to L1. Note l2_lob if multiple rows. Answer Y or N.

Valid answers: `Y` | `N` | `N/A` | `NEEDS_HUMAN`

## DB Fields Used

| Column | Notes |
|--------|-------|
| `l2_decision` |
| `l2_action` |
| `l2_rationale` |
| `l2_lob` |
| `l2_multiple_rows` |
| `l1_recommended_action` |
| `l1_rationale` |

## Gotchas

- Always call `get_edr_data()` first — never use stale data from a prior step.
- Always call `get_prior_answers()` before `answer_question` — dependency answers may affect the result.
- Never skip this question even if a dependency answered N or NEEDS_HUMAN.
- Do NOT write to `context.state` directly — use `store_answer` tool only.
- See [references/question.md](references/question.md) for full question text and validation grid.
