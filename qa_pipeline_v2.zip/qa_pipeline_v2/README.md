# QA Pipeline

Agentic QA process evaluator built with **Google Agent Development Kit (ADK)**.  
Evaluates business processes through a 10-question sequential reasoning chain where each answer builds on prior ones.

---

## Architecture

```
QAPipeline (SequentialAgent)
│
├── DataFetcherAgent
│     Calls fetch_process_data(process_id) → stores result in session state as 'process_data'
│
├── QuestionAgent_01  Process Status & Eligibility
│     Reads: process_data                        Writes: answer_q1
│
├── QuestionAgent_02  Compliance Framework & Obligations
│     Reads: process_data, answer_q1             Writes: answer_q2
│
├── QuestionAgent_03  Compliance Score Evaluation
│     Reads: process_data, answer_q1, answer_q2  Writes: answer_q3
│
├── QuestionAgent_04  Risk Assessment             (depends on Q1, Q3)
├── QuestionAgent_05  Security Controls           (depends on Q4)
├── QuestionAgent_06  Performance & SLA           (depends on Q1, Q4)
├── QuestionAgent_07  Audit Trail                 (depends on Q3, Q5)
├── QuestionAgent_08  Consolidated Violations     (depends on Q3–Q7)
├── QuestionAgent_09  Remediation Plan            (depends on Q8)
├── QuestionAgent_10  Final QA Verdict            (depends on Q1–Q9)
│
└── VerdictSynthesizerAgent
      Reads: answer_q1 … answer_q10   Writes: verdict_json → QAResult
```

**Key ADK patterns:**

| Pattern | Purpose |
|---------|---------|
| `SequentialAgent` | Guarantees Q1 → … → Q10 execution order |
| `output_key` on each `LlmAgent` | Auto-saves LLM response into session state |
| `session.state` | Shared scratchpad — prior answers are automatically injected into each agent's context |
| Pre-seeded state | `process_id` written into session before the pipeline starts |

---

## Project structure

```
qa_pipeline/
├── main.py                  Entry point (CLI)
├── pipeline_runner.py       Execution engine: run, retry, parse results
├── models.py                QAVerdict, QAResult, QuestionAnswer
├── requirements.txt
├── pytest.ini
├── .env.example
│
├── config/
│   ├── settings.py          All config via .env
│   └── logging_setup.py     JSON logging (prod) / colored console (dev)
│
├── agents/
│   ├── questions.py         10 QuestionDef objects — the only file to edit for question changes
│   ├── data_fetcher.py      Step 0: fetches process data
│   ├── question_agents.py   Builds Q1–Q10 LlmAgents from questions.py
│   ├── verdict_synthesizer.py  Final JSON verdict agent
│   └── orchestrator.py      Assembles the SequentialAgent
│
├── tools/
│   └── fetch_tool.py        fetch_process_data() — replace body with your real data source
│
└── tests/
    └── test_pipeline.py     Unit tests (no API calls required)
```

---

## Quick start

```bash
# 1. Install
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# 2. Configure
cp .env.example .env
# Edit .env — set GOOGLE_API_KEY

# 3. Run
python main.py --process-id PROC-2024-001
python main.py --process-id PROC-2024-002 --output result.json --quiet
```

Demo IDs:

| ID | Process | Expected verdict |
|----|---------|-----------------|
| `PROC-2024-001` | Customer Onboarding | CONDITIONAL PASS |
| `PROC-2024-002` | Loan Approval | FAIL / REQUIRES ESCALATION |

---

## Tests

```bash
pytest tests/ -v
pytest tests/ -v --cov=. --cov-report=term-missing
```

---

## Customising questions

Edit `agents/questions.py`. Each `QuestionDef` has:

```python
QuestionDef(
    number=3,
    title="My Check",
    prompt="Based on Q1 and Q2, evaluate ...",
    depends_on=(1, 2),            # prior answers injected into context
    output_hint="PASS/FAIL with reason",
)
```

Everything else (agent creation, session state keys, verdict synthesis) adapts automatically.

---

## Connecting your real data source

Replace the body of `_load_from_source()` in `tools/fetch_tool.py`:

```python
def _load_from_source(process_id: str) -> dict | None:
    # SQL:        return db.fetchone("SELECT * FROM processes WHERE id = %s", process_id)
    # REST API:   return httpx.get(f"/api/processes/{process_id}").json()
    # Dataverse:  return dataverse_client.retrieve("qa_process", process_id)
    # SharePoint: return sp_client.get_item(list_name, process_id)
```

The return value must be a flat `dict` or `None` (not found).  
All keys you include will be available to every agent in the reasoning chain.

---

## Exit codes

| Code | Meaning |
|------|---------|
| 0 | PASS or CONDITIONAL PASS |
| 1 | Config error or pipeline failure |
| 2 | FAIL or REQUIRES ESCALATION |
| 130 | Interrupted |
