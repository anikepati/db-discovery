# EDR QA Process — Actimize Event Disposition Review

Standard Operating Procedure for Quality Assurance review of
Event Disposition Review (EDR) cases in Actimize.

## Event Creation

### Validate event description is complete
Validation: Check if the Event Description provided is complete in Actimize by selecting the reviewing ECN/Sample ID on EDR Script under Event Closed Status tab.
Check Logic: Match the below fields on Actimize with the Input File:
1. ECN #
2. Event Type & Subtype
3. Workflow Status
If all the above match: Y, otherwise N.

### Validate recommendation rationale aligns with risk action recommendation type
Validation: If the Event Type is anything apart from Priority FC Business Referral, ensure that the recommended action and the rationale aligns with each other.
Check Logic: If EDR Type = Priority FC Business Approval, then N/A.
If EDR Type = anything other than Priority FC Business Approval, then assess the Recommended Action and Rationale on Actimize. Both should be aligned.
If aligned then Y, otherwise N.
Notes: Example: Recommended Action - No further Action Required. In this case the rationale must also state the same thing.

### Validate recommendation rationale aligns with the event description
Validation: If the Event Type is anything apart from Priority FC Business Referral, ensure that the rationale and event description align.
Check Logic: If EDR Type = Priority FC Business Approval, then N/A.
If EDR Type = anything other than Priority FC Business Approval, then assess if the Recommended Rationale has come from an authorized group.
If aligned then Y, otherwise N.

## Level 1 Review (Priority FC Business)

### Validate L1 recommendation rationale aligns with risk action
Validation: Ensure the recommended action and the rationale align.
Check Logic: If EDR Type = anything other than Priority FC Business Approval, then N/A.
If EDR Type = Priority FC Business Approval, assess Recommended Action and Rationale. If aligned: Y, otherwise N.

### Validate L1 recommendation rationale is reasonable
Validation: Ensure the L1 rationale and event description align.
Check Logic: If EDR Type = anything other than Priority FC Business Approval, then N/A.
If EDR Type = Priority FC Business Approval, assess if Recommended Rationale came from authorized group. If aligned: Y otherwise N.

## Level 2 Review

### Validate L2 decision rationale aligns with risk decision type
Validation: Decision rationale should align with decision type.
Check Logic: If the L2 Decision is Accept, then L2 action would be blank and rationale aligns to L1 rationale.
If L2 Decision is Amend, L2 action will have the action mentioned.
If multiple L2 rows in Actimize, check LOB value and select required row.
If aligned: Y otherwise N.

### Validate L2 decision rationale is reasonable
Validation: L2 decision rationale should align with event description.
Check Logic: If L2 Decision is Accept, L2 action blank and rationale aligns to L1 recommended action.
If aligned: Y otherwise N.

### Validate L2 rationale does not list incorrect group
Validation: Ensure no reference to wrong recommending group.
Check Logic: The rationale should state the L1 recommending group or L1 action recommended.
If aligned: Y, otherwise N.

### Confirm elevated approval obtained if required
Validation: Check elevated approval decision is Accept.
Check Logic: If elevated approvals required (mentioned in Actimize), assess if rationale is aligned.
If elevated approvals blank: N/A. If aligned: Y, otherwise N.

## Initiation of Decision Execution

### Is the profile refresh referred to the appropriate group
Validation: Validate if profile refresh was referred to appropriate process.
Check Logic: If recommended action is Profile Refresh, then leave this validation blank for the human to validate / send an email to the appropriate group for the profile refresh report.
If not Profile Refresh: N/A.
Requires Human: Yes

### Is a risk rating override request present in Actimize
Validation: Validate if Risk Rating Override request was referred to appropriate process.
Check Logic: If recommended action is Increase Risk Rating, navigate to History tab in Actimize and identify the RRO # generated. If done: Y, otherwise send email.
If not Increase Risk Rating: N/A.

### Is the Exit referred to the appropriate group
Validation: Validate if customer exit request was referred to appropriate process.
Check Logic: If recommended action is Exit Decision, then leave this validation blank for the human to validate / send an email to appropriate group for exit report.
If not Exit Decision: N/A.
Requires Human: Yes
