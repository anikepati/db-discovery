"""
Main Orchestrator — entry point for the YAML Decision Tree Engine.
Supports both flat-list mode and DAG mode (auto-detected from YAML).

Usage:
  python main.py --config config/lam_conversion.yaml --dry-run        # flat mode
  python main.py --config config/lam_full_dag.yaml --dry-run           # DAG mode
"""

import argparse
import json
import logging
import sys
import time
import yaml
from pathlib import Path
from typing import List, Dict, Any

from engine.loader import load_config
from engine.evaluator import ConditionEvaluator, OperatorRegistry
from engine.action_dispatcher import ActionDispatcher
from engine.tree_walker import DecisionTreeWalker, generate_row_report
from engine.excel_reader import read_excel, validate_columns
from engine.column_extractor import extract_columns


def setup_logging(level: str = "INFO"):
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format="%(asctime)s │ %(levelname)-7s │ %(name)s │ %(message)s",
        datefmt="%H:%M:%S",
    )


def _load_raw_yaml(config_path: str) -> dict:
    with open(config_path, "r") as f:
        return yaml.safe_load(f)


def run_engine(config_path: str, dry_run_override: bool = None):
    start_time = time.time()
    logger = logging.getLogger("engine")

    logger.info("=" * 60)
    logger.info("YAML DECISION TREE ENGINE")
    logger.info("=" * 60)

    # Step 1: Load & Validate Config
    logger.info(f"Loading config: {config_path}")
    config = load_config(config_path)

    raw_yaml = _load_raw_yaml(config_path)
    has_dag = "dag" in raw_yaml

    if has_dag:
        logger.info("*** DAG MODE DETECTED ***")
    logger.info(f"Config loaded: {len(config.decision_trees)} decision trees")

    settings = config.settings
    dry_run = dry_run_override if dry_run_override is not None else settings.dry_run
    if dry_run:
        logger.info("*** DRY RUN MODE ***")

    setup_logging(settings.log_level)

    # Step 2: Extract & Validate Columns
    required_columns = extract_columns(config)
    logger.info(f"Required columns: {sorted(required_columns)}")
    missing = validate_columns(settings.excel_file, settings.sheet_name, list(required_columns))
    if missing:
        logger.error(f"MISSING COLUMNS in Excel: {missing}")
        sys.exit(1)
    logger.info("All required columns found ✓")

    # Step 3: Initialize Engine
    evaluator = ConditionEvaluator(OperatorRegistry())
    dispatcher = ActionDispatcher(dry_run=dry_run)
    context = {
        "api_base_url": settings.api_base_url,
        "db_connection_string": settings.db_connection_string,
        "db_table": settings.db_table,
        "row_id_column": settings.row_id_column,
    }
    walker = DecisionTreeWalker(evaluator, dispatcher, context)
    tree_map = {tree.id: tree for tree in config.decision_trees}

    # Step 3b: Initialize DAG if present
    dag_executor = None
    if has_dag:
        from engine.dag_executor import DAGExecutor
        dag_executor = DAGExecutor(raw_yaml["dag"])
        dag_executor.print_dag()

    # Step 4: Process Rows
    all_reports: List[Dict[str, Any]] = []
    row_count = error_count = 0

    logger.info("-" * 60)
    logger.info("PROCESSING ROWS")
    logger.info("-" * 60)

    for chunk in read_excel(settings.excel_file, settings.sheet_name, chunk_size=settings.batch_size):
        for row in chunk:
            row_count += 1
            row_id = str(row.get(settings.row_id_column, f"row_{row_count}"))
            logger.info(f"\n{'─' * 40}\nRow {row_count} | ID: {row_id}\n{'─' * 40}")

            if dag_executor:
                dag_report = dag_executor.execute_for_row(row, row_id, tree_map, walker)
                all_tree_results = []
                for node in dag_executor.nodes.values():
                    all_tree_results.extend(node.results)
                report = generate_row_report(row_id, all_tree_results)
                report["dag"] = dag_report
            else:
                tree_results = walker.walk_all_trees(config.decision_trees, row, row_id)
                report = generate_row_report(row_id, tree_results)

            all_reports.append(report)
            error_count += report["error_count"]

    # Step 5: Summary
    elapsed = time.time() - start_time
    summary = {
        "mode": "dag" if has_dag else "flat",
        "total_rows": row_count,
        "total_trees": len(config.decision_trees),
        "total_evaluations": sum(r["total_nodes_evaluated"] for r in all_reports),
        "total_errors": error_count,
        "elapsed_seconds": round(elapsed, 2),
        "dry_run": dry_run,
        "row_reports": all_reports,
    }
    if has_dag:
        summary["dag_layers"] = dag_executor.get_execution_plan()

    logger.info("\n" + "=" * 60)
    logger.info("EXECUTION SUMMARY")
    logger.info("=" * 60)
    logger.info(f"Mode:              {summary['mode'].upper()}")
    logger.info(f"Rows processed:    {summary['total_rows']}")
    logger.info(f"Trees per row:     {summary['total_trees']}")
    logger.info(f"Total evaluations: {summary['total_evaluations']}")
    logger.info(f"Errors:            {summary['total_errors']}")
    logger.info(f"Elapsed:           {summary['elapsed_seconds']}s")
    if has_dag:
        logger.info(f"DAG layers:        {len(summary['dag_layers'])}")
    logger.info("=" * 60)

    return summary


def main():
    parser = argparse.ArgumentParser(description="YAML Decision Tree Engine (DAG + flat)")
    parser.add_argument("--config", "-c", required=True, help="Path to YAML config")
    parser.add_argument("--dry-run", "-d", action="store_true", help="Log only, no side effects")
    parser.add_argument("--output", "-o", help="Save results to JSON")
    args = parser.parse_args()

    setup_logging()
    summary = run_engine(args.config, dry_run_override=args.dry_run or None)

    if args.output:
        Path(args.output).parent.mkdir(parents=True, exist_ok=True)
        file_summary = {k: v for k, v in summary.items() if k != "row_reports"}
        with open(args.output, "w") as f:
            json.dump(file_summary, f, indent=2, default=str)


if __name__ == "__main__":
    main()
