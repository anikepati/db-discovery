"""
SyntheticTestGenerator — AI-powered test case generation

Generates realistic enterprise scenarios for evaluating multi-agent
systems. Understands agent roles, tools, and business context to
create targeted test cases with expected outputs and KPI tags.
"""

from __future__ import annotations

import json
import os
import random
import re
from dataclasses import dataclass, field
from typing import Any

from core.gepa_adapter import AgentGenome, SystemGenome


# ---------------------------------------------------------------------------
# Domain Templates
# ---------------------------------------------------------------------------

DOMAIN_TEMPLATES: dict[str, list[dict]] = {
    "compliance": [
        {
            "pattern": "Check if transaction {tx_id} from {entity} for ${amount} complies with AML regulations",
            "expected_pattern": "Transaction analysis with risk score, flagged indicators, and compliance recommendation",
            "kpis": {"compliance_critical": True, "latency_sla_ms": 5000},
        },
        {
            "pattern": "Review account {acct_id} for suspicious activity in the last {days} days",
            "expected_pattern": "Activity summary with flagged patterns, risk assessment, and recommended actions",
            "kpis": {"compliance_critical": True, "accuracy_threshold": 0.95},
        },
        {
            "pattern": "Generate a regulatory report for {entity} covering {period}",
            "expected_pattern": "Structured report with findings, compliance status, and remediation items",
            "kpis": {"compliance_critical": True, "completeness_required": True},
        },
    ],
    "financial_analysis": [
        {
            "pattern": "Analyze the financial health of {company} based on their latest quarterly report",
            "expected_pattern": "Financial analysis with key ratios, trends, risk factors, and outlook",
            "kpis": {"accuracy_threshold": 0.9, "latency_sla_ms": 10000},
        },
        {
            "pattern": "Compare revenue growth between {company_a} and {company_b} over the last {years} years",
            "expected_pattern": "Comparative analysis with data points, growth rates, and competitive insights",
            "kpis": {"accuracy_threshold": 0.85},
        },
    ],
    "customer_service": [
        {
            "pattern": "Customer {name} is reporting {issue_type} with order #{order_id}. Resolve their issue",
            "expected_pattern": "Issue diagnosis, resolution steps, compensation if applicable, and follow-up plan",
            "kpis": {"latency_sla_ms": 3000, "satisfaction_target": 0.9},
        },
        {
            "pattern": "Escalate unresolved complaint from {name} about {product} — 3rd contact in {days} days",
            "expected_pattern": "Escalation with full context, priority assessment, proposed resolution, and SLA",
            "kpis": {"latency_sla_ms": 2000, "escalation_handled": True},
        },
    ],
    "data_processing": [
        {
            "pattern": "Extract and validate all {entity_type} records from the uploaded {file_type} file",
            "expected_pattern": "Extracted records with validation report, error summary, and clean dataset",
            "kpis": {"accuracy_threshold": 0.98, "latency_sla_ms": 15000},
        },
        {
            "pattern": "Map fields from {source_system} schema to {target_system} schema for {record_type} records",
            "expected_pattern": "Field mapping table with transformation rules, unmapped fields, and confidence scores",
            "kpis": {"accuracy_threshold": 0.95},
        },
    ],
    "general": [
        {
            "pattern": "Research {topic} and provide a comprehensive summary with recommendations",
            "expected_pattern": "Structured summary with key findings, analysis, and actionable recommendations",
            "kpis": {"completeness_required": True},
        },
        {
            "pattern": "Create a step-by-step plan for {task_description}",
            "expected_pattern": "Numbered plan with dependencies, timeline estimates, and risk factors",
            "kpis": {"latency_sla_ms": 8000},
        },
    ],
}

# Placeholder values for template expansion
PLACEHOLDERS = {
    "tx_id": lambda: f"TX-{random.randint(100000, 999999)}",
    "entity": lambda: random.choice(["Acme Corp", "GlobalTech Ltd", "Zenith Finance", "Atlas Holdings", "Meridian Partners"]),
    "amount": lambda: f"{random.randint(5000, 5000000):,}",
    "acct_id": lambda: f"ACCT-{random.randint(10000, 99999)}",
    "days": lambda: str(random.choice([7, 14, 30, 60, 90])),
    "period": lambda: random.choice(["Q1 2025", "Q2 2025", "FY 2024", "H1 2025"]),
    "company": lambda: random.choice(["Tesla", "Microsoft", "Anthropic", "Stripe", "Palantir"]),
    "company_a": lambda: random.choice(["Apple", "Google", "Amazon"]),
    "company_b": lambda: random.choice(["Meta", "Netflix", "Nvidia"]),
    "years": lambda: str(random.choice([2, 3, 5])),
    "name": lambda: random.choice(["Sarah Chen", "Marcus Johnson", "Aisha Patel", "Tom Weber", "Yuki Tanaka"]),
    "issue_type": lambda: random.choice(["delayed shipping", "defective product", "billing error", "missing items", "wrong item received"]),
    "order_id": lambda: str(random.randint(100000, 999999)),
    "product": lambda: random.choice(["Premium Plan", "Enterprise License", "Hardware Kit", "API Access"]),
    "entity_type": lambda: random.choice(["customer", "transaction", "employee", "vendor"]),
    "file_type": lambda: random.choice(["CSV", "JSON", "Excel", "PDF"]),
    "source_system": lambda: random.choice(["Salesforce", "SAP", "Oracle", "Workday"]),
    "target_system": lambda: random.choice(["Snowflake", "BigQuery", "Databricks", "PostgreSQL"]),
    "record_type": lambda: random.choice(["customer", "order", "invoice", "product"]),
    "topic": lambda: random.choice(["AI governance frameworks", "supply chain resilience", "zero-trust security", "ESG reporting standards"]),
    "task_description": lambda: random.choice(["migrating to microservices", "implementing CI/CD pipeline", "launching a new product", "SOC 2 compliance audit"]),
}


# ---------------------------------------------------------------------------
# Generator
# ---------------------------------------------------------------------------

class SyntheticTestGenerator:
    """
    Generates realistic test cases for multi-agent system evaluation.

    Two modes:
    1. Template-based: Fast, deterministic, uses domain templates
    2. AI-powered: Uses LLM to generate context-aware scenarios
    """

    def __init__(self, model_id: str = "gemini-2.0-flash"):
        self.model_id = model_id

    def generate(
        self,
        genome: SystemGenome | None = None,
        count: int = 30,
        domains: list[str] | None = None,
        use_ai: bool = True,
    ) -> list[dict]:
        """
        Generate test cases.

        Args:
            genome: Optional system genome for context-aware generation
            count: Number of test cases to generate
            domains: Specific domains to target (default: auto-detect from genome)
            use_ai: Whether to use LLM for enhanced generation

        Returns:
            List of test case dicts with input, expected_output, business_kpis
        """
        # Auto-detect relevant domains from agent instructions
        if not domains and genome:
            domains = self._detect_domains(genome)
        if not domains:
            domains = list(DOMAIN_TEMPLATES.keys())

        test_cases = []

        # Phase 1: Template-based generation
        template_count = count if not use_ai else count // 2
        test_cases.extend(self._generate_from_templates(domains, template_count, genome))

        # Phase 2: AI-enhanced generation
        if use_ai and genome:
            ai_count = count - len(test_cases)
            ai_cases = self._generate_with_ai(genome, ai_count, domains)
            test_cases.extend(ai_cases)

        # Ensure we hit the target count
        while len(test_cases) < count:
            test_cases.extend(self._generate_from_templates(domains, 1, genome))

        return test_cases[:count]

    def _detect_domains(self, genome: SystemGenome) -> list[str]:
        """Detect relevant domains from agent instructions and tools."""
        all_text = " ".join(
            f"{a.instruction} {a.description} {' '.join(a.tool_names)}"
            for a in genome.agents
        ).lower()

        detected = []
        domain_keywords = {
            "compliance": ["compliance", "aml", "kyc", "regulatory", "audit", "risk", "actimize", "edr"],
            "financial_analysis": ["financial", "revenue", "profit", "analysis", "quarterly", "earnings"],
            "customer_service": ["customer", "support", "ticket", "complaint", "resolution", "service"],
            "data_processing": ["data", "etl", "extract", "transform", "mapping", "schema", "csv", "json"],
        }

        for domain, keywords in domain_keywords.items():
            if any(kw in all_text for kw in keywords):
                detected.append(domain)

        if not detected:
            detected = ["general"]

        return detected

    def _generate_from_templates(
        self, domains: list[str], count: int, genome: SystemGenome | None
    ) -> list[dict]:
        """Generate test cases from domain templates."""
        cases = []
        available_templates = []
        for d in domains:
            available_templates.extend(DOMAIN_TEMPLATES.get(d, DOMAIN_TEMPLATES["general"]))

        for i in range(count):
            template = random.choice(available_templates)
            input_text = self._expand_template(template["pattern"])
            expected = self._expand_template(template["expected_pattern"])

            # Add tool context if genome available
            tool_hint = ""
            if genome:
                tools = []
                for a in genome.agents:
                    tools.extend(a.tool_names)
                if tools:
                    tool_hint = f" (Available tools: {', '.join(set(tools))})"

            cases.append({
                "id": f"tc_{i+1:03d}",
                "input": input_text + tool_hint,
                "expected_output": expected,
                "business_kpis": template.get("kpis", {}),
                "domain": self._detect_template_domain(template),
                "difficulty": random.choice(["easy", "medium", "hard"]),
                "generated_by": "template",
            })

        return cases

    def _expand_template(self, template: str) -> str:
        """Replace {placeholder} tokens with random values."""
        def replacer(match):
            key = match.group(1)
            if key in PLACEHOLDERS:
                return PLACEHOLDERS[key]()
            return match.group(0)

        return re.sub(r"\{(\w+)\}", replacer, template)

    def _detect_template_domain(self, template: dict) -> str:
        """Detect which domain a template belongs to."""
        for domain, templates in DOMAIN_TEMPLATES.items():
            if template in templates:
                return domain
        return "general"

    def _generate_with_ai(
        self, genome: SystemGenome, count: int, domains: list[str]
    ) -> list[dict]:
        """Use LLM to generate context-aware test cases."""
        if count <= 0:
            return []

        try:
            from google import genai
            client = genai.Client()

            agent_context = "\n".join(
                f"- {a.agent_name} ({a.agent_type}): {a.description}\n  Tools: {', '.join(a.tool_names) or 'none'}\n  Instruction preview: {a.instruction[:200]}"
                for a in genome.agents
            )

            prompt = f"""You are a QA engineer generating test cases for a multi-agent AI system.

AGENT TEAM:
{agent_context}

DOMAINS: {', '.join(domains)}

Generate exactly {count} test cases as a JSON array. Each test case must have:
- "id": unique identifier (tc_ai_001, tc_ai_002, etc.)
- "input": realistic user query that exercises the agent team
- "expected_output": description of what a correct response should contain
- "business_kpis": object with relevant KPI targets
- "domain": one of {json.dumps(domains)}
- "difficulty": "easy", "medium", or "hard"
- "generated_by": "ai"

Make scenarios realistic, enterprise-grade, and varied in complexity.
Include edge cases and multi-step workflows.
Return ONLY the JSON array, no markdown fences."""

            response = client.models.generate_content(
                model=self.model_id, contents=prompt
            )
            raw = response.text.strip()
            raw = re.sub(r"```json\s*", "", raw)
            raw = re.sub(r"```\s*$", "", raw)
            cases = json.loads(raw)
            if isinstance(cases, list):
                return cases[:count]
        except Exception as e:
            # Fallback to more templates
            return self._generate_from_templates(domains, count, genome)

        return []

    def generate_from_conversation(self, messages: list[dict]) -> dict:
        """Convert a live conversation into a golden test case."""
        if not messages:
            return {}

        user_inputs = [m["content"] for m in messages if m.get("role") == "user"]
        assistant_outputs = [m["content"] for m in messages if m.get("role") == "assistant"]

        return {
            "id": f"tc_conv_{random.randint(1000, 9999)}",
            "input": user_inputs[0] if user_inputs else "",
            "expected_output": assistant_outputs[-1] if assistant_outputs else "",
            "business_kpis": {},
            "domain": "conversation_recorded",
            "difficulty": "real_world",
            "generated_by": "conversation",
            "full_conversation": messages,
        }

    @staticmethod
    def load_from_file(filepath: str) -> list[dict]:
        """Load test cases from JSON or CSV file."""
        path_str = str(filepath)
        if path_str.endswith(".json"):
            with open(filepath, "r") as f:
                data = json.load(f)
                return data if isinstance(data, list) else [data]
        elif path_str.endswith(".csv"):
            import csv
            cases = []
            with open(filepath, "r") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    cases.append({
                        "id": row.get("id", f"tc_csv_{len(cases)+1}"),
                        "input": row.get("input", ""),
                        "expected_output": row.get("expected_output", ""),
                        "business_kpis": json.loads(row.get("business_kpis", "{}")),
                        "domain": row.get("domain", "imported"),
                        "difficulty": row.get("difficulty", "medium"),
                        "generated_by": "csv_import",
                    })
            return cases
        else:
            raise ValueError(f"Unsupported file type: {filepath}")
