"""
Generate test data for LAM Conversion decision trees.
Covers all conversion paths from the flowchart.
"""

import pandas as pd
from pathlib import Path


def generate_lam_data():
    rows = [
        # --- Section 2: Percentage Update ---
        # Row 1: Change in pct, provided → Update LAM
        {"LoanID": "LN-0001", "ChangeInPercentage": "Yes", "PercentageProvided": "Yes",
         "LogicalProgression": "Yes", "FromType": "SPEC", "ToType": "PRESOLD",
         "ConversionType": "SPEC_TO_PRESOLD",
         "ContractPriceProvided": "Yes", "WithinThreshold": "Yes",
         "PlanNameExistsInLAM": "Yes", "AppraisalValueMatched": "Yes",
         "AppraisalAvailable": "Yes", "CustomerBDRHasHardCost": "Yes",
         "CustomerBDRHasContractPrice": "Yes", "LAMCollateralValueBasis": "Standard",
         "PercentageCompletion": "75", "DateProvided": "2025-01-15",
         "ContractPrice": 450000, "CollateralType": "Residential",
         "ConversionDate": "2025-01-20", "HardCost": 320000, "AppraisalValue": 460000},

        # Row 2: Change in pct, NOT provided → Exception 1
        {"LoanID": "LN-0002", "ChangeInPercentage": "Yes", "PercentageProvided": "No",
         "LogicalProgression": "Yes", "FromType": "SPEC", "ToType": "MODEL",
         "ConversionType": "SPEC_TO_MODEL",
         "ContractPriceProvided": "No", "WithinThreshold": "No",
         "PlanNameExistsInLAM": "Yes", "AppraisalValueMatched": "Yes",
         "AppraisalAvailable": "Yes", "CustomerBDRHasHardCost": "No",
         "CustomerBDRHasContractPrice": "No", "LAMCollateralValueBasis": "Standard",
         "PercentageCompletion": None, "DateProvided": None,
         "ContractPrice": None, "CollateralType": "Residential",
         "ConversionDate": "2025-02-01", "HardCost": None, "AppraisalValue": 380000},

        # --- Section 3: Conversion paths ---

        # Row 3: Not logical progression → Exception 13
        {"LoanID": "LN-0003", "ChangeInPercentage": "No", "PercentageProvided": "No",
         "LogicalProgression": "No", "FromType": "PRESOLD", "ToType": "LAND",
         "ConversionType": "PRESOLD_TO_LAND",
         "ContractPriceProvided": "No", "WithinThreshold": "No",
         "PlanNameExistsInLAM": "No", "AppraisalValueMatched": "No",
         "AppraisalAvailable": "No", "CustomerBDRHasHardCost": "No",
         "CustomerBDRHasContractPrice": "No", "LAMCollateralValueBasis": "Standard",
         "PercentageCompletion": None, "DateProvided": None,
         "ContractPrice": None, "CollateralType": None,
         "ConversionDate": None, "HardCost": None, "AppraisalValue": None},

        # Row 4: SPEC→PRESOLD, contract OK → Update LAM
        {"LoanID": "LN-0004", "ChangeInPercentage": "No", "PercentageProvided": "No",
         "LogicalProgression": "Yes", "FromType": "SPEC", "ToType": "PRESOLD",
         "ConversionType": "SPEC_TO_PRESOLD",
         "ContractPriceProvided": "Yes", "WithinThreshold": "Yes",
         "PlanNameExistsInLAM": "Yes", "AppraisalValueMatched": "Yes",
         "AppraisalAvailable": "Yes", "CustomerBDRHasHardCost": "Yes",
         "CustomerBDRHasContractPrice": "Yes", "LAMCollateralValueBasis": "Standard",
         "PercentageCompletion": "60", "DateProvided": "2025-03-01",
         "ContractPrice": 520000, "CollateralType": "Residential",
         "ConversionDate": "2025-03-05", "HardCost": 400000, "AppraisalValue": 530000},

        # Row 5: MODEL→PRESOLD, contract NOT within threshold → Exception 2
        {"LoanID": "LN-0005", "ChangeInPercentage": "No", "PercentageProvided": "No",
         "LogicalProgression": "Yes", "FromType": "MODEL", "ToType": "PRESOLD",
         "ConversionType": "MODEL_TO_PRESOLD",
         "ContractPriceProvided": "Yes", "WithinThreshold": "No",
         "PlanNameExistsInLAM": "Yes", "AppraisalValueMatched": "Yes",
         "AppraisalAvailable": "Yes", "CustomerBDRHasHardCost": "Yes",
         "CustomerBDRHasContractPrice": "Yes", "LAMCollateralValueBasis": "Standard",
         "PercentageCompletion": None, "DateProvided": None,
         "ContractPrice": 800000, "CollateralType": "Residential",
         "ConversionDate": "2025-03-10", "HardCost": 500000, "AppraisalValue": 550000},

        # Row 6: SPEC→MODEL → Update LAM (simple)
        {"LoanID": "LN-0006", "ChangeInPercentage": "No", "PercentageProvided": "No",
         "LogicalProgression": "Yes", "FromType": "SPEC", "ToType": "MODEL",
         "ConversionType": "SPEC_TO_MODEL",
         "ContractPriceProvided": "No", "WithinThreshold": "No",
         "PlanNameExistsInLAM": "Yes", "AppraisalValueMatched": "Yes",
         "AppraisalAvailable": "Yes", "CustomerBDRHasHardCost": "No",
         "CustomerBDRHasContractPrice": "No", "LAMCollateralValueBasis": "Standard",
         "PercentageCompletion": None, "DateProvided": None,
         "ContractPrice": None, "CollateralType": "Residential",
         "ConversionDate": "2025-04-01", "HardCost": None, "AppraisalValue": 400000},

        # Row 7: LAND→LUD, plan exists, appraisal matched → Update LAM
        {"LoanID": "LN-0007", "ChangeInPercentage": "No", "PercentageProvided": "No",
         "LogicalProgression": "Yes", "FromType": "LAND", "ToType": "LUD",
         "ConversionType": "LAND_TO_LUD",
         "ContractPriceProvided": "No", "WithinThreshold": "No",
         "PlanNameExistsInLAM": "Yes", "AppraisalValueMatched": "Yes",
         "AppraisalAvailable": "Yes", "CustomerBDRHasHardCost": "No",
         "CustomerBDRHasContractPrice": "No", "LAMCollateralValueBasis": "Standard",
         "PercentageCompletion": None, "DateProvided": None,
         "ContractPrice": None, "CollateralType": "Land",
         "ConversionDate": "2025-04-10", "HardCost": None, "AppraisalValue": 200000},

        # Row 8: LAND→LUD, plan missing → Exception 3
        {"LoanID": "LN-0008", "ChangeInPercentage": "No", "PercentageProvided": "No",
         "LogicalProgression": "Yes", "FromType": "LAND", "ToType": "LUD",
         "ConversionType": "LAND_TO_LUD",
         "ContractPriceProvided": "No", "WithinThreshold": "No",
         "PlanNameExistsInLAM": "No", "AppraisalValueMatched": "No",
         "AppraisalAvailable": "Yes", "CustomerBDRHasHardCost": "No",
         "CustomerBDRHasContractPrice": "No", "LAMCollateralValueBasis": "Standard",
         "PercentageCompletion": None, "DateProvided": None,
         "ContractPrice": None, "CollateralType": "Land",
         "ConversionDate": None, "HardCost": None, "AppraisalValue": 180000},

        # Row 9: LAND→LUD, plan exists, appraisal NOT matched → Exception 4
        {"LoanID": "LN-0009", "ChangeInPercentage": "No", "PercentageProvided": "No",
         "LogicalProgression": "Yes", "FromType": "LAND", "ToType": "LUD",
         "ConversionType": "LAND_TO_LUD",
         "ContractPriceProvided": "No", "WithinThreshold": "No",
         "PlanNameExistsInLAM": "Yes", "AppraisalValueMatched": "No",
         "AppraisalAvailable": "Yes", "CustomerBDRHasHardCost": "No",
         "CustomerBDRHasContractPrice": "No", "LAMCollateralValueBasis": "Standard",
         "PercentageCompletion": None, "DateProvided": None,
         "ContractPrice": None, "CollateralType": "Land",
         "ConversionDate": None, "HardCost": None, "AppraisalValue": 195000},

        # Row 10: LOT→SPEC, full happy path → Update LAM
        {"LoanID": "LN-0010", "ChangeInPercentage": "No", "PercentageProvided": "No",
         "LogicalProgression": "Yes", "FromType": "LOT", "ToType": "SPEC",
         "ConversionType": "LOT_TO_SPEC",
         "ContractPriceProvided": "No", "WithinThreshold": "No",
         "PlanNameExistsInLAM": "Yes", "AppraisalValueMatched": "Yes",
         "AppraisalAvailable": "Yes", "CustomerBDRHasHardCost": "Yes",
         "CustomerBDRHasContractPrice": "No", "LAMCollateralValueBasis": "Standard",
         "PercentageCompletion": None, "DateProvided": None,
         "ContractPrice": None, "CollateralType": "Lot",
         "ConversionDate": "2025-05-01", "HardCost": 250000, "AppraisalValue": 300000},

        # Row 11: LOT→SPEC, no hard cost → Exception 7
        {"LoanID": "LN-0011", "ChangeInPercentage": "No", "PercentageProvided": "No",
         "LogicalProgression": "Yes", "FromType": "LOT", "ToType": "SPEC",
         "ConversionType": "LOT_TO_SPEC",
         "ContractPriceProvided": "No", "WithinThreshold": "No",
         "PlanNameExistsInLAM": "Yes", "AppraisalValueMatched": "Yes",
         "AppraisalAvailable": "Yes", "CustomerBDRHasHardCost": "No",
         "CustomerBDRHasContractPrice": "No", "LAMCollateralValueBasis": "Standard",
         "PercentageCompletion": None, "DateProvided": None,
         "ContractPrice": None, "CollateralType": "Lot",
         "ConversionDate": None, "HardCost": None, "AppraisalValue": 310000},

        # Row 12: LOT→PRESOLD, full happy path → Update LAM (4 fields)
        {"LoanID": "LN-0012", "ChangeInPercentage": "No", "PercentageProvided": "No",
         "LogicalProgression": "Yes", "FromType": "LOT", "ToType": "PRESOLD",
         "ConversionType": "LOT_TO_PRESOLD",
         "ContractPriceProvided": "Yes", "WithinThreshold": "Yes",
         "PlanNameExistsInLAM": "Yes", "AppraisalValueMatched": "Yes",
         "AppraisalAvailable": "Yes", "CustomerBDRHasHardCost": "Yes",
         "CustomerBDRHasContractPrice": "Yes", "LAMCollateralValueBasis": "Standard",
         "PercentageCompletion": "90", "DateProvided": "2025-05-15",
         "ContractPrice": 480000, "CollateralType": "Lot",
         "ConversionDate": "2025-05-20", "HardCost": 350000, "AppraisalValue": 490000},

        # Row 13: LOT→PRESOLD, no contract price → Exception 11
        {"LoanID": "LN-0013", "ChangeInPercentage": "No", "PercentageProvided": "No",
         "LogicalProgression": "Yes", "FromType": "LOT", "ToType": "PRESOLD",
         "ConversionType": "LOT_TO_PRESOLD",
         "ContractPriceProvided": "No", "WithinThreshold": "No",
         "PlanNameExistsInLAM": "Yes", "AppraisalValueMatched": "Yes",
         "AppraisalAvailable": "Yes", "CustomerBDRHasHardCost": "Yes",
         "CustomerBDRHasContractPrice": "No", "LAMCollateralValueBasis": "Standard",
         "PercentageCompletion": None, "DateProvided": None,
         "ContractPrice": None, "CollateralType": "Lot",
         "ConversionDate": None, "HardCost": 340000, "AppraisalValue": 480000},

        # Row 14: PRESOLD→SPEC, collateral basis NOT Custom → OK
        {"LoanID": "LN-0014", "ChangeInPercentage": "No", "PercentageProvided": "No",
         "LogicalProgression": "Yes", "FromType": "PRESOLD", "ToType": "SPEC",
         "ConversionType": "PRESOLD_TO_SPEC",
         "ContractPriceProvided": "No", "WithinThreshold": "No",
         "PlanNameExistsInLAM": "Yes", "AppraisalValueMatched": "Yes",
         "AppraisalAvailable": "Yes", "CustomerBDRHasHardCost": "No",
         "CustomerBDRHasContractPrice": "No", "LAMCollateralValueBasis": "Standard",
         "PercentageCompletion": None, "DateProvided": None,
         "ContractPrice": 500000, "CollateralType": "Presold",
         "ConversionDate": "2025-06-01", "HardCost": None, "AppraisalValue": 510000},

        # Row 15: PRESOLD→MODEL, collateral basis IS Custom → Exception 12
        {"LoanID": "LN-0015", "ChangeInPercentage": "No", "PercentageProvided": "No",
         "LogicalProgression": "Yes", "FromType": "PRESOLD", "ToType": "MODEL",
         "ConversionType": "PRESOLD_TO_MODEL",
         "ContractPriceProvided": "No", "WithinThreshold": "No",
         "PlanNameExistsInLAM": "Yes", "AppraisalValueMatched": "Yes",
         "AppraisalAvailable": "Yes", "CustomerBDRHasHardCost": "No",
         "CustomerBDRHasContractPrice": "No", "LAMCollateralValueBasis": "Custom",
         "PercentageCompletion": None, "DateProvided": None,
         "ContractPrice": 470000, "CollateralType": "Presold",
         "ConversionDate": "2025-06-10", "HardCost": None, "AppraisalValue": 475000},
    ]

    df = pd.DataFrame(rows)
    output_dir = Path("data")
    output_dir.mkdir(exist_ok=True)
    output_path = output_dir / "lam_data.xlsx"
    df.to_excel(output_path, index=False, sheet_name="Sheet1")
    print(f"✓ Generated {len(df)} LAM test rows → {output_path}")
    print(f"  Columns: {list(df.columns)}")
    print(f"\nConversion types covered:")
    for _, row in df.iterrows():
        print(f"  {row['LoanID']}: {row.get('FromType','?')}→{row.get('ToType','?')} | Logical={row.get('LogicalProgression','?')}")
    return output_path


if __name__ == "__main__":
    generate_lam_data()
