# Q02 Full Reference — Event Creation

## Question

If EDR event type is not Priority FC Business Referral, validate the recommendation rationale aligns with risk action recommendation type.

## Validation

Assess Recommended Action vs Rationale alignment.

## Check Logic (apply exactly)

If event_type = 'Priority FC Business Approval': answer N/A. Else assess whether recommended_rationale aligns with recommended_action. If aligned: Y. Else: N.

## Depends On

Q01

## Output Hint

State event_type, recommended_action, recommended_rationale, and alignment conclusion. Answer Y, N, or N/A.

## Requires Human Review

No — answer should be Y, N, or N/A only.

## DB Fields

- `event_type`
- `recommended_action`
- `recommended_rationale`
- `recommending_group`

## Authorization Grid (relevant for Q2, Q3, Q5, Q8)

See `skills/edr-ingest/references/schema.md` for the full authorization grid
mapping EDR type + brokerage type → authorized recommending groups.
