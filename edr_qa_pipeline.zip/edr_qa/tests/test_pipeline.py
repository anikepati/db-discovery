"""
EDR QA Pipeline test suite.

Run:   pytest tests/ -v
Cover: pytest tests/ -v --cov=.. --cov-report=term-missing
"""

import json
import sys
from datetime import datetime
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from fetch_tool import fetch_edr_data
from models import EDRQAResult, EDRVerdict, QAAnswer, QuestionResult, CategorySummary
from pipeline_runner import _parse_answer, _parse_verdict_json, _build_result
from questions import EDR_QUESTIONS, EDR_QUESTION_MAP, CATEGORIES


# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture
def ecn_priority_fc():
    return "ECN-2024-001"   # Priority FC Business Approval

@pytest.fixture
def ecn_risk_rating():
    return "ECN-2024-002"   # Increase Risk Rating

@pytest.fixture
def ecn_exit():
    return "ECN-2024-003"   # Exit Decision

@pytest.fixture
def raw_priority_fc(ecn_priority_fc):
    return json.loads(fetch_edr_data(ecn_priority_fc))

@pytest.fixture
def raw_risk_rating(ecn_risk_rating):
    return json.loads(fetch_edr_data(ecn_risk_rating))


# ── fetch_edr_data ────────────────────────────────────────────────────────────

class TestFetchTool:

    def test_returns_ok_for_known_ecn(self, ecn_priority_fc, raw_priority_fc):
        assert raw_priority_fc["status"] == "ok"
        assert raw_priority_fc["ecn_id"] == ecn_priority_fc

    def test_returns_error_for_unknown_ecn(self):
        result = json.loads(fetch_edr_data("ECN-DOES-NOT-EXIST"))
        assert result["status"] == "error"
        assert "available_ecns" in result

    def test_all_required_fields_present(self, raw_priority_fc):
        required = [
            "event_type", "brokerage_type", "recommended_action",
            "recommended_rationale", "recommending_group",
            "l1_recommended_action", "l1_rationale",
            "l2_decision", "l2_action", "l2_rationale",
            "elevated_approval_required", "final_recommended_action",
            "rro_number", "risk_rating_amended_in_l2",
        ]
        for field in required:
            assert field in raw_priority_fc, f"Missing Actimize field: {field}"

    def test_priority_fc_event_type(self, raw_priority_fc):
        assert raw_priority_fc["event_type"] == "Priority FC Business Approval"

    def test_risk_rating_ecn_has_rro_number(self, raw_risk_rating):
        assert raw_risk_rating["rro_number"] != ""

    def test_returns_valid_json_string(self, ecn_priority_fc):
        raw = fetch_edr_data(ecn_priority_fc)
        parsed = json.loads(raw)
        assert isinstance(parsed, dict)


# ── Question definitions ───────────────────────────────────────────────────────

class TestQuestions:

    def test_exactly_15_questions(self):
        assert len(EDR_QUESTIONS) == 15

    def test_numbered_1_to_15_in_order(self):
        assert [q.number for q in EDR_QUESTIONS] == list(range(1, 16))

    def test_question_map_matches_tuple(self):
        for q in EDR_QUESTIONS:
            assert EDR_QUESTION_MAP[q.number] is q

    def test_q1_has_no_dependencies(self):
        assert EDR_QUESTION_MAP[1].depends_on == ()

    def test_all_categories_are_valid(self):
        valid = set(CATEGORIES)
        for q in EDR_QUESTIONS:
            # Level 1 Review has a sub-label but must contain the base
            assert any(q.category.startswith(c) or c.startswith(q.category.split("(")[0].strip())
                      for c in valid), f"Q{q.number} category '{q.category}' not recognized"

    def test_no_forward_dependencies(self):
        for q in EDR_QUESTIONS:
            for dep in q.depends_on:
                assert dep < q.number, (
                    f"Q{q.number} depends on Q{dep} which comes after it — invalid DAG"
                )

    def test_no_self_dependencies(self):
        for q in EDR_QUESTIONS:
            assert q.number not in q.depends_on

    def test_all_fields_non_empty(self):
        for q in EDR_QUESTIONS:
            assert q.title.strip(),      f"Q{q.number} empty title"
            assert len(q.question) > 20, f"Q{q.number} question too short"
            assert q.validation.strip(), f"Q{q.number} empty validation"
            assert q.check.strip(),      f"Q{q.number} empty check logic"
            assert q.output_hint.strip(),f"Q{q.number} empty output_hint"

    def test_human_review_questions_have_appropriate_hints(self):
        """Questions 10, 12, 13, 15 involve Profile Refresh / Exit — must not auto-answer."""
        human_q_nums = {10, 12, 13, 15}
        for num in human_q_nums:
            q = EDR_QUESTION_MAP[num]
            hint_lower = q.output_hint.lower()
            assert "human" in hint_lower or "flag" in hint_lower, (
                f"Q{num} should mention human validation in output_hint"
            )


# ── QAAnswer enum ─────────────────────────────────────────────────────────────

class TestQAAnswer:

    def test_from_string_yes(self):
        assert QAAnswer.from_string("Y") == QAAnswer.YES
        assert QAAnswer.from_string("yes") == QAAnswer.YES

    def test_from_string_no(self):
        assert QAAnswer.from_string("N") == QAAnswer.NO
        assert QAAnswer.from_string("no") == QAAnswer.NO

    def test_from_string_na(self):
        assert QAAnswer.from_string("N/A") == QAAnswer.NA
        assert QAAnswer.from_string("na") == QAAnswer.NA

    def test_from_string_needs_human(self):
        assert QAAnswer.from_string("NEEDS_HUMAN") == QAAnswer.NEEDS_HUMAN

    def test_unknown_defaults_to_needs_human(self):
        assert QAAnswer.from_string("garbage") == QAAnswer.NEEDS_HUMAN


# ── EDRVerdict ────────────────────────────────────────────────────────────────

class TestEDRVerdict:

    def test_pass_is_passing(self):
        assert EDRVerdict.PASS.passed is True
        assert EDRVerdict.PASS_WITH_EXCEPTIONS.passed is True

    def test_fail_and_human_review_are_not_passing(self):
        assert EDRVerdict.FAIL.passed is False
        assert EDRVerdict.REQUIRES_HUMAN_REVIEW.passed is False


# ── _parse_answer ─────────────────────────────────────────────────────────────

class TestParseAnswer:

    def test_parses_structured_yes(self):
        raw = "REASONING:\nEvent type is Priority FC Business Approval.\n\nANSWER: Y"
        answer, reasoning, requires_human, human_action = _parse_answer(raw)
        assert answer == QAAnswer.YES
        assert "Priority FC" in reasoning
        assert requires_human is False

    def test_parses_na(self):
        raw = "REASONING:\nNot applicable.\n\nANSWER: N/A"
        answer, _, _, _ = _parse_answer(raw)
        assert answer == QAAnswer.NA

    def test_parses_needs_human_with_action(self):
        raw = (
            "REASONING:\nProfile Refresh applies.\n\n"
            "ANSWER: NEEDS_HUMAN\n"
            "HUMAN_ACTION: Send email to Profile Refresh team with ECN-2024-001."
        )
        answer, reasoning, requires_human, human_action = _parse_answer(raw)
        assert answer == QAAnswer.NEEDS_HUMAN
        assert requires_human is True
        assert "Profile Refresh team" in human_action

    def test_fallback_for_unstructured_response(self):
        raw = "The answer is Y based on the data."
        answer, reasoning, _, _ = _parse_answer(raw)
        assert reasoning == ""    # no REASONING: tag found


# ── _parse_verdict_json ───────────────────────────────────────────────────────

class TestParseVerdictJson:

    def test_parses_clean_json(self):
        data = {"verdict": "PASS", "overall_pass_rate": 100.0, "summary": "All clear."}
        assert _parse_verdict_json(json.dumps(data))["verdict"] == "PASS"

    def test_strips_markdown_fences(self):
        raw = "```json\n{\"verdict\": \"FAIL\", \"overall_pass_rate\": 60.0}\n```"
        assert _parse_verdict_json(raw)["verdict"] == "FAIL"

    def test_returns_empty_dict_on_bad_json(self):
        assert _parse_verdict_json("not json") == {}


# ── _build_result ─────────────────────────────────────────────────────────────

class TestBuildResult:

    def test_builds_from_empty_state(self):
        result = _build_result("ECN-TEST", "s-001", {}, datetime.utcnow(), 3.0)
        assert result.ecn_id == "ECN-TEST"
        assert len(result.question_results) == 15
        assert result.verdict == EDRVerdict.REQUIRES_HUMAN_REVIEW

    def test_builds_with_pass_verdict(self):
        vdata = {
            "verdict": "PASS",
            "overall_pass_rate": 100.0,
            "summary": "All 15 questions passed.",
            "failed_questions": [],
            "human_review_required": [],
            "category_results": {},
        }
        state = {"verdict_json": json.dumps(vdata)}
        result = _build_result("ECN-TEST", "s-002", state, datetime.utcnow(), 5.0)
        assert result.verdict == EDRVerdict.PASS
        assert result.passed is True
        assert result.overall_pass_rate == 100.0

    def test_answers_sorted_by_question_number(self):
        result = _build_result("ECN-TEST", "s-003", {}, datetime.utcnow(), 1.0)
        nums = [qr.number for qr in result.question_results]
        assert nums == sorted(nums)

    def test_one_line_contains_ecn_id(self):
        result = _build_result("ECN-2024-001", "s-004", {}, datetime.utcnow(), 2.5)
        assert "ECN-2024-001" in result.one_line()


# ── Agent creation (structural, no API calls) ─────────────────────────────────

class TestAgentCreation:

    def test_data_fetcher(self):
        from data_fetcher import create_data_fetcher_agent
        agent = create_data_fetcher_agent()
        assert agent.name == "DataFetcherAgent"
        assert agent.output_key == "edr_data"
        assert len(agent.tools) == 1

    def test_question_agents(self):
        from question_agents import create_all_question_agents
        agents = create_all_question_agents()
        assert len(agents) == 15
        for i, agent in enumerate(agents, 1):
            assert agent.name == f"QA_Q{i:02d}"
            assert agent.output_key == f"answer_q{i}"
            assert len(agent.tools) == 0

    def test_verdict_agent(self):
        from verdict_synthesizer import create_verdict_synthesizer_agent
        agent = create_verdict_synthesizer_agent()
        assert agent.name == "VerdictSynthesizerAgent"
        assert agent.output_key == "verdict_json"

    def test_pipeline_has_17_sub_agents(self):
        from orchestrator import create_pipeline
        pipeline = create_pipeline()
        # DataFetcher + 15 questions + VerdictSynthesizer = 17
        assert len(pipeline.sub_agents) == 17
        assert pipeline.sub_agents[0].name == "DataFetcherAgent"
        assert pipeline.sub_agents[-1].name == "VerdictSynthesizerAgent"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
