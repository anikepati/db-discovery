"""
agentforge_meta/core/mcp_factory.py
=====================================
In-memory MCP server factory — exact pattern from EDR QA v7.
"""
import asyncio
import json
import os
import yaml
from mcp.server import Server
from mcp import types as mcp_types
from agentforge_meta.core.runtime import YAMLFunctionRuntime, MCP_TOOL_TYPES


def _build_input_schema(fn_def: dict) -> dict:
    type_map = {
        "string": "string", "integer": "integer", "number": "number",
        "boolean": "boolean", "array": "array", "object": "object",
    }
    properties: dict = {}
    required:   list = []
    for name, schema in fn_def.get("inputs", {}).items():
        prop: dict = {"type": type_map.get(schema.get("type", "string"), "string")}
        if "default"     in schema: prop["default"]     = schema["default"]
        if "description" in schema: prop["description"] = schema["description"]
        properties[name] = prop
        if schema.get("required", False):
            required.append(name)
    return {"type": "object", "properties": properties, "required": required}


def create_mcp_server(yaml_path: str) -> Server:
    """Create in-memory MCP Server for tools in a YAML file."""
    runtime = YAMLFunctionRuntime(yaml_path)
    with open(yaml_path) as f:
        all_fns = yaml.safe_load(f).get("functions", [])
    mcp_fns     = [fn for fn in all_fns if fn.get("type") in MCP_TOOL_TYPES]
    server_name = os.path.basename(yaml_path).replace(".yaml", "")
    server      = Server(server_name)

    @server.list_tools()
    async def list_tools() -> list[mcp_types.Tool]:
        return [
            mcp_types.Tool(
                name=fn["id"],
                description=fn.get("description", fn["id"]),
                inputSchema=_build_input_schema(fn),
            )
            for fn in mcp_fns
        ]

    @server.call_tool()
    async def call_tool(name: str, arguments: dict) -> list[mcp_types.TextContent]:
        try:
            loop   = asyncio.get_event_loop()
            result = await loop.run_in_executor(
                None, lambda: runtime.execute(name, inputs=arguments)
            )
            return [mcp_types.TextContent(
                type="text",
                text=json.dumps(result, default=str, indent=2),
            )]
        except Exception as e:
            return [mcp_types.TextContent(
                type="text",
                text=json.dumps({"error": type(e).__name__, "detail": str(e)}),
            )]

    return server
