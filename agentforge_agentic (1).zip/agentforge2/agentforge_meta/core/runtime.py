"""
agentforge_meta/core/runtime.py
================================
YAMLFunctionRuntime — executes tools defined in YAML files.

Tool types:
  sql        — MS SQL / PostgreSQL via SQLAlchemy + pyodbc
  python     — RestrictedPython sandbox
  rest_api   — HTTP requests with typed auth (bearer, apigee, oauth2, api_key, basic)
  playwright — Playwright browser automation
  pyautogui  — Desktop automation via pyautogui + PIL

Secret resolution:
  {{ secrets.VAR }}  — injected from os.environ at execute() time
  {{ inputs.x }}     — from caller inputs at execute() time
  Never hardcoded. Never in source control.
"""

import asyncio
import json
import os
import time
from typing import Any

import sqlalchemy
import yaml
from dotenv import load_dotenv
from jinja2 import sandbox as jinja_sandbox

load_dotenv()

# ── RestrictedPython ──────────────────────────────────────────────────────────
try:
    import RestrictedPython
    _RESTRICTED = True
    _SAFE_BUILTINS = RestrictedPython.safe_builtins.copy()
    _SAFE_BUILTINS.update({
        k: v for k, v in {
            "len": len, "range": range, "enumerate": enumerate,
            "zip": zip, "map": map, "filter": filter,
            "sum": sum, "min": min, "max": max, "round": round,
            "list": list, "dict": dict, "set": set, "tuple": tuple,
            "str": str, "int": int, "float": float, "bool": bool,
            "sorted": sorted, "reversed": reversed,
            "isinstance": isinstance, "type": type,
            "abs": abs, "any": any, "all": all, "print": print,
        }.items()
    })
except ImportError:
    _RESTRICTED = False

_ALLOWED_IMPORTS = {
    "json", "re", "os", "math", "statistics", "datetime",
    "collections", "itertools", "functools", "pathlib",
    "subprocess", "sys", "yaml", "urllib", "urllib.request",
    "py_compile",
}

MCP_TOOL_TYPES = {"sql", "python", "rest_api", "playwright", "pyautogui"}


class YAMLFunctionRuntime:
    """
    Loads a YAML tool file and executes tools on demand.
    Called by mcp_factory.py to serve tools via in-memory MCP server.
    """

    def __init__(self, yaml_path: str) -> None:
        with open(yaml_path) as f:
            raw = yaml.safe_load(f)
        self.yaml_path = yaml_path
        self.jinja     = jinja_sandbox.SandboxedEnvironment()
        self.secrets   = {k: v for k, v in os.environ.items() if v}
        self.registry: dict[str, dict] = {
            fn["id"]: fn
            for fn in raw.get("functions", [])
            if fn.get("type") in MCP_TOOL_TYPES
        }
        # Build typed connection objects at load time
        self._connections: dict[str, Any] = {}
        for conn_def in raw.get("connections", []):
            self._connections[conn_def["name"]] = self._build_connection(conn_def)

    # ── Connection factory ────────────────────────────────────────────────────

    def _build_connection(self, conn_def: dict) -> Any:
        name      = conn_def["name"]
        conn_type = conn_def.get("type", "db")
        config    = conn_def.get("config", {})
        auth      = conn_def.get("auth", {})
        # Resolve secrets in auth
        auth = {k: self._resolve_secret(v) for k, v in auth.items()}

        if conn_type == "db":
            if auth.get("type") == "connection_string":
                conn_str = auth["value"]
            else:
                driver = config.get("driver", "mssql+pyodbc")
                host   = config.get("host", "localhost")
                port   = config.get("port", "")
                db     = config.get("database", "db")
                user   = auth.get("username", "")
                pwd    = auth.get("password", "")
                odbc   = config.get("odbc_driver", "ODBC Driver 18 for SQL Server")
                hp     = f"{host}:{port}" if port else host
                conn_str = f"{driver}://{user}:{pwd}@{hp}/{db}?driver={odbc.replace(' ', '+')}"
            return sqlalchemy.create_engine(conn_str, fast_executemany=True, pool_pre_ping=True)

        if conn_type == "rest_api":
            return {"type": "rest_api", "config": config, "auth": auth, "_token": None, "_expiry": 0.0}

        if conn_type == "playwright":
            return {"type": "playwright", "config": config, "auth": auth, "_page": None, "_pw": None}

        if conn_type == "pyautogui":
            return {"type": "pyautogui", "config": config}

        return {"type": conn_type, "config": config, "auth": auth}

    def _resolve_secret(self, value: Any) -> Any:
        """Resolve {{ secrets.VAR }} in a string."""
        if not isinstance(value, str):
            return value
        return self.jinja.from_string(value).render(secrets=self.secrets)

    # ── Input resolution ──────────────────────────────────────────────────────

    def _render(self, template: Any, inputs: dict) -> str:
        return self.jinja.from_string(str(template)).render(
            inputs=inputs, secrets=self.secrets
        )

    def _resolve_inputs(self, fn_def: dict, raw: dict) -> dict:
        resolved = {}
        for name, schema in fn_def.get("inputs", {}).items():
            if name in raw:
                resolved[name] = raw[name]
            elif "default" in schema:
                resolved[name] = schema["default"]
            elif schema.get("required", False):
                raise ValueError(f"[{fn_def['id']}] Missing required input: '{name}'")
        return resolved

    # ── Public execute ────────────────────────────────────────────────────────

    def execute(self, function_id: str, inputs: dict) -> Any:
        fn = self.registry.get(function_id)
        if not fn:
            raise ValueError(f"Unknown function: '{function_id}' in {self.yaml_path}")
        inputs  = self._resolve_inputs(fn, inputs)
        fn_type = fn.get("type")

        if fn_type == "sql":
            return self._run_sql(fn, inputs)
        elif fn_type == "python":
            return self._run_python(fn["python"], inputs)
        elif fn_type == "rest_api":
            return self._run_rest(fn, inputs)
        elif fn_type == "playwright":
            return self._run_playwright(fn, inputs)
        elif fn_type == "pyautogui":
            return self._run_pyautogui(fn, inputs)
        raise ValueError(f"Unsupported tool type: '{fn_type}'")

    # ── SQL ───────────────────────────────────────────────────────────────────

    def _run_sql(self, fn: dict, inputs: dict) -> list[dict]:
        conn_ref = fn.get("connection_ref", "")
        engine   = self._connections.get(conn_ref)
        if engine is None:
            # Legacy format: connection in config
            cfg      = fn["config"]
            conn_str = self._render(cfg["connection"], inputs)
            engine   = sqlalchemy.create_engine(conn_str)
        cfg    = fn["config"]
        query  = cfg["query"]
        params = {k: self._render(v, inputs) for k, v in cfg.get("params", {}).items()}
        with engine.connect() as conn:
            result = conn.execute(sqlalchemy.text(query), params)
            return [dict(row._mapping) for row in result]

    # ── REST API ──────────────────────────────────────────────────────────────

    def _run_rest(self, fn: dict, inputs: dict) -> dict:
        import urllib.request, urllib.error
        conn_ref = fn.get("connection_ref", "")
        conn     = self._connections.get(conn_ref, {})
        config   = fn.get("config", {})
        auth     = conn.get("auth", {})
        base_url = conn.get("config", {}).get("base_url", "").rstrip("/")

        method  = self._render(config.get("method", "GET"), inputs)
        path    = self._render(config.get("path", ""), inputs)
        body    = config.get("body")
        body    = json.loads(self._render(body, inputs)) if body else None

        token = self._get_rest_token(conn)
        hdrs  = {"Content-Type": "application/json"}
        auth_type = auth.get("type", "none")
        if token:
            if auth_type == "api_key":
                hdrs[auth.get("header", "X-API-Key")] = token
            elif auth_type == "basic":
                import base64
                c = base64.b64encode(f"{auth.get('username')}:{auth.get('password')}".encode()).decode()
                hdrs["Authorization"] = f"Basic {c}"
            else:
                hdrs["Authorization"] = f"Bearer {token}"

        url  = base_url + path
        data = json.dumps(body).encode() if body else None
        req  = urllib.request.Request(url, data=data, headers=hdrs, method=method.upper())
        try:
            resp = urllib.request.urlopen(req, timeout=conn.get("config", {}).get("timeout_seconds", 30))
            return json.loads(resp.read())
        except urllib.error.HTTPError as e:
            return {"__http_error": e.code, "__body": e.read().decode("utf-8", "replace")}

    def _get_rest_token(self, conn: dict) -> str | None:
        import urllib.request, urllib.parse
        auth = conn.get("auth", {})
        t    = auth.get("type", "none")
        if t == "bearer_token":
            return auth.get("token")
        if t == "api_key":
            return auth.get("value")
        if t in ("apigee_token", "oauth2_client_credentials"):
            if conn.get("_token") and time.time() < conn.get("_expiry", 0) - 30:
                return conn["_token"]
            data = urllib.parse.urlencode({
                "grant_type": "client_credentials",
                "client_id":     auth.get("client_id", ""),
                "client_secret": auth.get("client_secret", ""),
            }).encode()
            req  = urllib.request.Request(
                auth["token_url"], data=data,
                headers={"Content-Type": "application/x-www-form-urlencoded"}
            )
            resp = urllib.request.urlopen(req, timeout=15)
            body = json.loads(resp.read())
            conn["_token"]  = body["access_token"]
            conn["_expiry"] = time.time() + body.get("expires_in", 3600)
            return conn["_token"]
        return None

    # ── Playwright ────────────────────────────────────────────────────────────

    def _run_playwright(self, fn: dict, inputs: dict) -> dict:
        conn_ref = fn.get("connection_ref", "")
        conn     = self._connections.get(conn_ref, {})
        action   = fn.get("action", "")
        cfg      = {k: self._render(v, inputs) if isinstance(v, str) else v
                    for k, v in fn.get("config", {}).items()}

        try:
            from playwright.sync_api import sync_playwright
        except ImportError:
            raise RuntimeError("Install: pip install playwright && playwright install chromium")

        if conn.get("_page") is None:
            pw_ctx           = sync_playwright().__enter__()
            conn["_pw"]      = pw_ctx
            browser_name     = conn.get("config", {}).get("browser", "chromium")
            browser          = getattr(pw_ctx, browser_name).launch(
                headless=conn.get("config", {}).get("headless", True)
            )
            conn["_page"]    = browser.new_page()
            auth             = conn.get("auth", {})
            if auth.get("type") == "form_login":
                page = conn["_page"]
                page.goto(auth.get("login_url", ""))
                page.fill(auth.get("username_selector", "#username"), auth.get("username", ""))
                page.fill(auth.get("password_selector", "#password"), auth.get("password", ""))
                page.click(auth.get("submit_selector", "button[type=submit]"))
                page.wait_for_load_state("networkidle")

        page = conn["_page"]
        actions = {
            "navigate":          lambda: (page.goto(cfg.get("url", "")), {"url": page.url})[1],
            "click":             lambda: (page.click(cfg["selector"]), {"clicked": cfg["selector"]})[1],
            "fill":              lambda: (page.fill(cfg["selector"], cfg.get("value", "")), {"filled": cfg["selector"]})[1],
            "select":            lambda: (page.select_option(cfg["selector"], cfg.get("option", "")), {"selected": cfg["selector"]})[1],
            "screenshot":        lambda: (page.screenshot(path=cfg["filename"]), {"screenshot": cfg["filename"]})[1],
            "get_text":          lambda: {"text": page.inner_text(cfg["selector"])},
            "assert_text":       lambda: {"match": cfg.get("expected","").lower() in page.inner_text(cfg["selector"]).lower()},
            "wait_for_selector": lambda: (page.wait_for_selector(cfg["selector"], timeout=int(cfg.get("timeout_ms",5000))), {"found": cfg["selector"]})[1],
        }
        handler = actions.get(action)
        if handler is None:
            raise ValueError(f"Unknown playwright action: '{action}'")
        return handler()

    # ── pyautogui ────────────────────────────────────────────────────────────

    def _run_pyautogui(self, fn: dict, inputs: dict) -> dict:
        try:
            import pyautogui as pg
        except ImportError:
            raise RuntimeError("Install: pip install pyautogui pillow")

        conn_ref = fn.get("connection_ref", "")
        conn     = self._connections.get(conn_ref, {})
        action   = fn.get("action", "")
        cfg      = {k: self._render(v, inputs) if isinstance(v, str) else v
                    for k, v in fn.get("config", {}).items()}

        pg.FAILSAFE = conn.get("config", {}).get("failsafe", True)
        pg.PAUSE    = conn.get("config", {}).get("pause_seconds", 0.5)

        if action == "click":
            pg.click(int(cfg["x"]), int(cfg["y"])); return {"clicked": [cfg["x"], cfg["y"]]}
        elif action == "type_text":
            pg.typewrite(cfg["text"], interval=0.05); return {"typed": cfg["text"]}
        elif action == "press_key":
            pg.press(cfg["key"]); return {"pressed": cfg["key"]}
        elif action == "hotkey":
            pg.hotkey(*cfg["keys"].split("+")); return {"hotkey": cfg["keys"]}
        elif action == "screenshot":
            pg.screenshot(cfg["filename"]); return {"screenshot": cfg["filename"]}
        elif action == "find_image":
            loc = pg.locateCenterOnScreen(cfg["template"], confidence=float(cfg.get("confidence", 0.9)))
            return {"found": loc is not None, "x": loc.x if loc else None, "y": loc.y if loc else None}
        elif action == "click_image":
            loc = pg.locateCenterOnScreen(cfg["template"], confidence=float(cfg.get("confidence", 0.9)))
            if loc:
                pg.click(loc.x, loc.y); return {"clicked": True}
            return {"clicked": False, "error": f"Image not found: {cfg['template']}"}
        raise ValueError(f"Unknown pyautogui action: '{action}'")

    # ── Python (sandboxed) ────────────────────────────────────────────────────

    def _run_python(self, python_def: dict, inputs: dict) -> Any:
        code     = python_def["code"]
        local_ns = {"inputs": inputs, "result": None}
        if _RESTRICTED:
            def _safe_import(name, *a, **kw):
                if name.split(".")[0] not in _ALLOWED_IMPORTS:
                    raise ImportError(f"Import '{name}' not allowed in sandbox")
                return __import__(name, *a, **kw)
            compiled  = RestrictedPython.compile_restricted(code, "<yaml_tool>", "exec")
            global_ns = {
                "__builtins__":  _SAFE_BUILTINS,
                "__import__":    _safe_import,
                "_print_":       RestrictedPython.PrintCollector,
                "_getiter_":     iter,
                "_getattr_":     getattr,
                "_inplacevar_":  RestrictedPython.Guards.guarded_inplacevar,
            }
        else:
            imports  = {}
            for mod in ("json", "re", "os", "math", "datetime", "pathlib",
                        "subprocess", "sys", "yaml", "py_compile"):
                try: imports[mod] = __import__(mod)
                except ImportError: pass
            global_ns = {"__builtins__": __builtins__, **imports}
            compiled  = compile(code, "<yaml_tool>", "exec")
        exec(compiled, global_ns, local_ns)
        if local_ns.get("result") is None:
            raise ValueError("Python tool did not assign to `result`")
        return local_ns["result"]
