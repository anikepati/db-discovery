"""
Pipeline runner — executes the QA pipeline and returns a QAResult.

Responsibilities:
  - Create and seed the ADK session
  - Run the pipeline with retry logic
  - Stream events and log progress
  - Parse session state into a typed QAResult
"""

import asyncio
import json
import logging
import time
from datetime import datetime
from uuid import uuid4

from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types

from agents import create_pipeline
from agents.questions import QUESTION_MAP
from config import settings
from models import QAResult, QAVerdict, QuestionAnswer

logger = logging.getLogger(__name__)

_AGENT_LABELS = {
    "DataFetcherAgent": "📥  STEP 0 · Data Fetcher",
    "VerdictSynthesizerAgent": "⚖️   FINAL · Verdict Synthesizer",
}


def _agent_label(name: str) -> str:
    if name in _AGENT_LABELS:
        return _AGENT_LABELS[name]
    try:
        num = int(name.split("_")[1])
        q = QUESTION_MAP.get(num)
        return f"🔍  Q{num:02d} · {q.title if q else name}"
    except (IndexError, ValueError):
        return f"▶  {name}"


def _parse_answer(raw: str) -> tuple[str, str]:
    """Split a raw LLM response into (reasoning, answer). Works even if format is missing."""
    if "REASONING:" in raw and "ANSWER:" in raw:
        try:
            r_start = raw.index("REASONING:") + len("REASONING:")
            a_start = raw.index("ANSWER:")
            return raw[r_start:a_start].strip(), raw[a_start + len("ANSWER:"):].strip()
        except ValueError:
            pass
    return "", raw.strip()


def _parse_verdict_json(raw: str) -> dict:
    """Parse the verdict JSON, stripping markdown fences if present."""
    cleaned = raw.strip()
    if cleaned.startswith("```"):
        parts = cleaned.split("```")
        cleaned = parts[1].lstrip("json").strip() if len(parts) > 1 else cleaned
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError as exc:
        logger.warning("Could not parse verdict JSON: %s | raw[:200]=%s", exc, raw[:200])
        return {}


def _build_result(
    process_id: str,
    session_id: str,
    state: dict,
    started_at: datetime,
    duration: float,
) -> QAResult:
    """Convert raw session state into a typed QAResult."""

    answers: list[QuestionAnswer] = []
    for q in QUESTION_MAP.values():
        raw = state.get(f"answer_q{q.number}", "")
        reasoning, answer = _parse_answer(raw)
        answers.append(QuestionAnswer(
            number=q.number,
            title=q.title,
            question=q.prompt,
            depends_on=list(q.depends_on),
            reasoning=reasoning,
            answer=answer,
            raw_response=raw,
        ))
    answers.sort(key=lambda a: a.number)

    vdata = _parse_verdict_json(state.get("verdict_json", "{}"))
    verdict = QAVerdict.from_string(vdata.get("verdict", "inconclusive"))
    score = float(vdata.get("overall_score", 0.0))
    summary = vdata.get("executive_summary", "See individual answers for details.")
    blocking = [item.get("issue", str(item)) for item in vdata.get("blocking_issues", [])]
    actions = vdata.get("remediation_actions", [])
    next_steps = vdata.get("next_steps", [])

    return QAResult(
        process_id=process_id,
        session_id=session_id,
        verdict=verdict,
        overall_score=score,
        executive_summary=summary,
        blocking_issues=blocking,
        remediation_actions=actions,
        next_steps=next_steps,
        answers=answers,
        started_at=started_at,
        completed_at=datetime.utcnow(),
        duration_seconds=duration,
    )


class PipelineRunner:
    """Runs the QA pipeline for a given process_id."""

    def __init__(self) -> None:
        self._session_service = InMemorySessionService()
        self._pipeline = create_pipeline()
        self._runner = Runner(
            agent=self._pipeline,
            app_name=settings.app_name,
            session_service=self._session_service,
        )

    async def run(
        self,
        process_id: str,
        user_id: str | None = None,
        verbose: bool = True,
    ) -> QAResult:
        """
        Execute the full QA pipeline and return a typed result.

        Args:
            process_id: Business process ID to evaluate.
            user_id:    Optional identifier for session tracking.
            verbose:    Print per-agent progress to stdout.

        Raises:
            RuntimeError: If the pipeline fails after all retries.
        """
        user_id = user_id or f"user_{uuid4().hex[:8]}"
        started_at = datetime.utcnow()
        t0 = time.time()

        session = await self._session_service.create_session(
            app_name=settings.app_name,
            user_id=user_id,
            state={"process_id": process_id},
        )

        if verbose:
            _print_header(process_id, user_id, started_at)

        message = types.Content(
            role="user",
            parts=[types.Part(text=f"Run QA evaluation for process ID: {process_id}")],
        )

        last_exc: Exception | None = None
        for attempt in range(1, settings.max_retries + 1):
            try:
                await self._stream(session.id, user_id, message, process_id, verbose, attempt)
                break
            except Exception as exc:
                last_exc = exc
                logger.error(
                    "Pipeline attempt %d/%d failed: %s",
                    attempt, settings.max_retries, exc,
                    extra={"process_id": process_id},
                    exc_info=True,
                )
                if attempt < settings.max_retries:
                    delay = settings.retry_delay * attempt
                    logger.info("Retrying in %.1fs…", delay)
                    if verbose:
                        print(f"\n⟳  Retry {attempt}/{settings.max_retries} in {delay:.0f}s…\n")
                    await asyncio.sleep(delay)
                else:
                    raise RuntimeError(
                        f"Pipeline failed after {settings.max_retries} attempts."
                    ) from last_exc

        final_session = await self._session_service.get_session(
            app_name=settings.app_name,
            user_id=user_id,
            session_id=session.id,
        )

        result = _build_result(
            process_id=process_id,
            session_id=session.id,
            state=final_session.state,
            started_at=started_at,
            duration=time.time() - t0,
        )

        logger.info("Pipeline complete: %s", result.one_line_summary(), extra={"process_id": process_id})

        if verbose:
            _print_result(result)

        return result

    async def _stream(
        self,
        session_id: str,
        user_id: str,
        message: types.Content,
        process_id: str,
        verbose: bool,
        attempt: int,
    ) -> None:
        current_agent: str | None = None

        async for event in self._runner.run_async(
            user_id=user_id,
            session_id=session_id,
            new_message=message,
        ):
            if event.author and event.author != current_agent:
                current_agent = event.author
                label = _agent_label(current_agent)
                if verbose:
                    print(f"\n{'─' * 60}\n  {label}\n{'─' * 60}")
                logger.info("Agent started: %s", current_agent, extra={"process_id": process_id, "agent": current_agent})

            if event.get_function_calls():
                for call in event.get_function_calls():
                    if verbose:
                        print(f"  🔧 {call.name}({str(call.args)[:80]})")

            if event.is_final_response() and event.content:
                for part in event.content.parts:
                    if hasattr(part, "text") and part.text:
                        if verbose:
                            text = part.text.strip()
                            print(f"\n{text[:1200]}{'…' if len(text) > 1200 else ''}\n")
                        logger.info("Agent complete: %s", current_agent, extra={"process_id": process_id, "agent": current_agent})


# ── Pretty printing helpers ────────────────────────────────────────────────

def _print_header(process_id: str, user_id: str, started_at: datetime) -> None:
    print(f"\n{'═' * 60}")
    print(f"  QA PIPELINE  |  {process_id}  |  {started_at.strftime('%H:%M:%S UTC')}")
    print(f"{'═' * 60}\n")


def _print_result(result: QAResult) -> None:
    icons = {
        QAVerdict.PASS: "✅",
        QAVerdict.CONDITIONAL_PASS: "⚠️ ",
        QAVerdict.FAIL: "❌",
        QAVerdict.REQUIRES_ESCALATION: "🚨",
        QAVerdict.INCONCLUSIVE: "❓",
    }
    icon = icons.get(result.verdict, "❓")
    print(f"\n{'═' * 60}")
    print(f"  {icon}  {result.verdict.value.upper()}")
    print(f"  Score   : {result.overall_score:.1f} / 100")
    print(f"  Duration: {result.duration_seconds:.1f}s")
    print(f"{'═' * 60}")
    print(f"\n{result.executive_summary}\n")

    if result.blocking_issues:
        print(f"🚫 Blocking Issues ({len(result.blocking_issues)}):")
        for issue in result.blocking_issues:
            print(f"   • {issue}")
        print()

    if result.remediation_actions:
        print("🔧 Remediation Actions:")
        for a in result.remediation_actions[:5]:
            p = a.get("priority", "P?")
            action = a.get("action", str(a))
            deadline = a.get("deadline_days", "?")
            print(f"   [{p}] {action}  ({deadline}d)")
        print()

    if result.next_steps:
        print("➡️  Next Steps:")
        for i, step in enumerate(result.next_steps, 1):
            print(f"   {i}. {step}")
    print()
