"""
agents/agent.py
---------------
Builds and runs the RRO QA pipeline as an ADK SequentialAgent.

15 sub-agents in order:
  rro_ingest_agent  → fetches RRO record, outputs to conversation
  q01_agent         → Q1: required fields populated
  q02_agent         → Q2: discretionary rationale aligns with RRO sub-type
  q03_agent         → Q3: rationale reasonable (reasoning agent)
  q04_agent         → Q4: DFCL approvals (RRO Added)
  q05_agent         → Q5: active override in ECRM
  q06_agent         → Q6: new risk rating applied
  q07_agent         → Q7: removal rationale reasonable (RRO Removed)
  q08_agent         → Q8: supervisory review, reviewer ≠ submitter
  q09_agent         → Q9: DFCL approvals (RRO Removed)
  q10_agent         → Q10: override inactive in ECRM
  q11_agent         → Q11: risk rating reverted to pre-override
  q12_agent         → Q12: Actimize RRO status = Removed/Expired
  q13_agent         → Q13: Business Exception — LOB clarification
  rro_report_agent  → builds final JSON verdict

SequentialAgent passes full conversation history automatically.
No context.state. No edr_state tools. No manual state management.
"""

import logging
from contextlib import AsyncExitStack

from google.adk.agents import LlmAgent, SequentialAgent
from google.adk.tools.mcp_tool.mcp_toolset import MCPToolset
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types
from mcp.shared.memory import (
    create_connected_server_and_client_session as create_in_memory_pair,
)

import yaml as _yaml

from config import settings
from mcp_factory import create_mcp_server
from yaml_runtime import MCP_TOOL_TYPES
from tool_registry import ToolConfig
from audit.audit_writer import AuditWriter

logger = logging.getLogger(__name__)

_AGENT_ICONS = {
    "rro_ingest_agent":  "📥",
    "rro_report_agent":  "📊",
}


async def _build_agent(config: ToolConfig, exit_stack: AsyncExitStack) -> LlmAgent:
    with open(config.yaml_path) as f:
        all_fns = _yaml.safe_load(f).get("functions", [])

    mcp_fns = [fn for fn in all_fns if fn.get("type") in MCP_TOOL_TYPES]
    tools   = []

    if mcp_fns:
        server         = create_mcp_server(config.yaml_path)
        client_session = await exit_stack.enter_async_context(
            create_in_memory_pair(server)
        )
        mcp_tools = await exit_stack.enter_async_context(
            MCPToolset(client_session=client_session)
        )
        tools.extend(mcp_tools)

    return LlmAgent(
        name=config.name,
        model=config.model,
        description=config.description,
        instruction=config.instruction,
        tools=tools,
    )


async def run_rro_qa(
    ecn_id:       str,
    run_id:       str,
    output_path:  str,
    registry:     list[ToolConfig],
    audit:        AuditWriter,
    work_item_id: str = "",
    verbose:      bool = True,
) -> str:
    async with AsyncExitStack() as stack:

        sub_agents: list[LlmAgent] = []
        for cfg in registry:
            sub_agents.append(await _build_agent(cfg, stack))

        pipeline = SequentialAgent(
            name="rro_qa_pipeline",
            sub_agents=sub_agents,
        )

        session_service = InMemorySessionService()
        await session_service.create_session(
            app_name=settings.app_name,
            user_id=run_id,
            session_id=run_id,
        )

        runner = Runner(
            agent=pipeline,
            app_name=settings.app_name,
            session_service=session_service,
        )

        user_msg = f"Run RRO QA for ECN: {ecn_id}. Output path: {output_path}."
        if work_item_id:
            user_msg += f" Work Item ID: {work_item_id}."

        message = types.Content(
            role="user",
            parts=[types.Part(text=user_msg)],
        )

        if verbose:
            print(f"\n{'─' * 64}")
            print(f"  🚀  RRO QA v1  |  ECN: {ecn_id}")
            print(f"  Run    : {run_id}")
            print(f"  Pattern: SequentialAgent — 15 agents, conversation history")
            print(f"  Agents : 1 ingest + 13 Q agents (Q1–Q13) + 1 report")
            print(f"{'─' * 64}")

        response_text  = ""
        current_author = None

        async for event in runner.run_async(
            user_id=run_id,
            session_id=run_id,
            new_message=message,
        ):
            author = getattr(event, "author", None)

            if author and author != current_author:
                if current_author and current_author != "rro_qa_pipeline":
                    audit.write_agent_record(
                        agent_name=current_author,
                        status="success",
                        response_text=response_text,
                    )
                current_author = author
                if author != "rro_qa_pipeline":
                    audit.agent_started(author)

                if verbose and author != "rro_qa_pipeline":
                    q_num = None
                    if author.startswith("q") and author.endswith("_agent"):
                        try: q_num = int(author[1:3])
                        except ValueError: pass
                    icon = _AGENT_ICONS.get(author, f"Q{q_num:02d}" if q_num else "▶")
                    print(f"\n  {icon}  {author}")

            if event.get_function_calls() and verbose:
                for call in event.get_function_calls():
                    print(f"       🔧 {call.name}({str(call.args)[:60]})")

            if event.is_final_response() and event.content:
                for part in event.content.parts:
                    if hasattr(part, "text") and part.text:
                        response_text = part.text.strip()
                        if verbose:
                            preview = response_text[:200]
                            print(f"       → {preview}{'…' if len(response_text) > 200 else ''}")

        if current_author and current_author != "rro_qa_pipeline":
            audit.write_agent_record(
                agent_name=current_author,
                status="success",
                response_text=response_text,
            )

        return response_text
