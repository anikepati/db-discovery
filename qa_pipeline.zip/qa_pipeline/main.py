"""
QA Pipeline - Main Entry Point
Production entry point with CLI argument support.

Usage:
    python main.py --process-id PROC-2024-001
    python main.py --process-id PROC-2024-002 --output results.json
    python main.py --process-id PROC-2024-001 --quiet
"""

import argparse
import asyncio
import json
import sys
import os
from datetime import datetime
from pathlib import Path

# Ensure project root is on path
sys.path.insert(0, str(Path(__file__).parent))

from config import setup_logging, app_config, get_logger
from pipeline_runner import QAPipelineRunner
from models import QAPipelineResult


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="QA Pipeline — Agentic QA Process Evaluator using Google ADK",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python main.py --process-id PROC-2024-001
  python main.py --process-id PROC-2024-002 --output results/output.json
  python main.py --process-id PROC-2024-001 --quiet --output result.json

Available Process IDs (demo):
  PROC-2024-001  → Customer Onboarding Workflow  (expected: CONDITIONAL PASS)
  PROC-2024-002  → Loan Approval Pipeline         (expected: FAIL / ESCALATION)
        """,
    )
    parser.add_argument(
        "--process-id",
        required=True,
        help="Process ID to evaluate (e.g., PROC-2024-001)",
    )
    parser.add_argument(
        "--output",
        default=None,
        help="Path to save JSON results (optional)",
    )
    parser.add_argument(
        "--quiet",
        action="store_true",
        help="Suppress verbose pipeline output",
    )
    parser.add_argument(
        "--user-id",
        default=None,
        help="User ID for session tracking (optional)",
    )
    return parser.parse_args()


def save_results(result: QAPipelineResult, output_path: str) -> None:
    """Save pipeline results to a JSON file."""
    os.makedirs(Path(output_path).parent, exist_ok=True) if Path(output_path).parent.name else None

    output = {
        "pipeline_run": {
            "process_id": result.process_id,
            "session_id": result.session_id,
            "started_at": result.started_at.isoformat(),
            "completed_at": result.completed_at.isoformat(),
            "duration_seconds": result.total_duration_seconds,
        },
        "verdict": {
            "verdict": result.verdict.value,
            "overall_score": result.overall_score,
            "passed": result.passed,
            "executive_summary": result.verdict_reasoning,
            "critical_issues": result.critical_issues,
            "recommendations": result.recommendations,
            "next_steps": result.next_steps,
        },
        "answers": [
            {
                "question_number": a.question_number,
                "question_text": a.question_text,
                "depends_on": a.depends_on,
                "reasoning": a.reasoning,
                "answer": a.answer,
                "answered_at": a.answered_at.isoformat(),
            }
            for a in result.answers
        ],
    }

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(output, f, indent=2, ensure_ascii=False)

    print(f"\n💾 Results saved to: {output_path}")


async def main() -> int:
    args = parse_args()

    # Initialize logging
    setup_logging(
        log_level=app_config.log_level,
        log_dir=app_config.log_dir,
        app_name=app_config.app_name,
        environment=app_config.environment,
    )
    logger = get_logger("main")

    # Validate config
    try:
        app_config.validate()
    except ValueError as e:
        print(f"\n❌ Configuration Error: {e}\n", file=sys.stderr)
        return 1

    logger.info(
        f"QA Pipeline starting",
        extra={"process_id": args.process_id, "environment": app_config.environment},
    )

    # Run pipeline
    runner = QAPipelineRunner()
    try:
        result = await runner.run(
            process_id=args.process_id,
            user_id=args.user_id,
            verbose=not args.quiet,
        )
    except RuntimeError as e:
        print(f"\n❌ Pipeline Failed: {e}\n", file=sys.stderr)
        logger.error(f"Pipeline failed: {e}", exc_info=True)
        return 1
    except KeyboardInterrupt:
        print("\n\n⏹  Pipeline interrupted by user.\n")
        return 130

    # Save results if requested
    if args.output:
        save_results(result, args.output)
    elif not args.quiet:
        # Always offer a default output path
        default_output = f"results_{args.process_id}_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.json"
        save_prompt = input(f"\nSave results to '{default_output}'? [y/N]: ").strip().lower()
        if save_prompt == "y":
            save_results(result, default_output)

    # Exit code based on verdict
    return 0 if result.passed else 2


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)
