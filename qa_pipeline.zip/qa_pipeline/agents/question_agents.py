"""
QA Pipeline - Question Agents
Dynamically creates all 10 LLM agents for the QA reasoning chain.
Each agent reads prior answers from session state and writes its own answer back.
"""

import logging

from google.adk.agents import LlmAgent

from config.settings import agent_config
from agents.questions import QA_QUESTIONS, QuestionDefinition
from tools.state_tools import (
    QA_DATA_KEY,
    make_answer_key,
)

logger = logging.getLogger(__name__)


def _build_dependency_section(question: QuestionDefinition) -> str:
    """Build the prior answers context section for the agent instruction."""
    if not question.depends_on:
        return (
            "## Prior Context\n"
            "This is Question 1 — no prior answers are needed. "
            "Reason purely from the QA process data."
        )

    deps_list = ", ".join([f"Q{n}" for n in question.depends_on])
    state_keys = "\n".join(
        [f"  - Q{n} answer → session state key: '{make_answer_key(n)}'"
         for n in question.depends_on]
    )

    return f"""## Prior Context Required
This question depends on answers from: {deps_list}

These answers are automatically available in your session context.
Reference them when forming your analysis:
{state_keys}

Build on these answers — do not re-derive what was already established.
"""


def _build_question_agent_instruction(question: QuestionDefinition) -> str:
    """Generate the full instruction prompt for a question agent."""
    dependency_section = _build_dependency_section(question)

    return f"""You are QA Reasoning Agent — Question {question.number}: {question.title}

You are part of a sequential QA pipeline. You will receive the full QA process dataset 
and any required prior answers in your context. Reason carefully and systematically.

## Your Question
{question.question}

## QA Process Data
The full QA dataset is available in session state under key: '{QA_DATA_KEY}'
It is automatically injected into your context. Use all relevant fields.

{dependency_section}

## Evaluation Criteria
{question.evaluation_criteria}

## Output Format Requirements
{question.expected_output_format}

ALWAYS structure your response EXACTLY as:

REASONING:
[Your step-by-step analysis here. Reference specific data values. Show your logic.
If you depend on prior answers, reference them explicitly. Be thorough — at least 3-5 sentences.]

ANSWER:
[Your clear, definitive answer here. Follow the output format requirements above.
This section will be used by subsequent agents as context.]

## Rules
- Use actual data values from the QA dataset (not generic statements)
- Reference prior answers explicitly when you depend on them
- If data is ambiguous, state your assumption clearly
- Be decisive — provide a clear verdict or classification as required
- Do not repeat prior answers verbatim — synthesize them
"""


def create_question_agent(question: QuestionDefinition) -> LlmAgent:
    """Create an LlmAgent for a single QA question."""
    instruction = _build_question_agent_instruction(question)
    output_key = make_answer_key(question.number)

    agent = LlmAgent(
        name=f"QuestionAgent_{question.number:02d}",
        model=agent_config.model,
        instruction=instruction,
        tools=[],  # No tools needed — data is in session state context
        output_key=output_key,
        description=(
            f"Q{question.number}: {question.title}. "
            f"Depends on: {question.depends_on or 'none'}."
        ),
    )

    logger.debug(
        f"Created QuestionAgent_{question.number:02d} "
        f"(output_key={output_key}, depends_on={question.depends_on})"
    )
    return agent


def create_all_question_agents() -> list[LlmAgent]:
    """Create all 10 question agents in order."""
    agents = [create_question_agent(q) for q in sorted(QA_QUESTIONS, key=lambda x: x.number)]
    logger.info(f"Created {len(agents)} question agents")
    return agents
