"""
QA Pipeline - Orchestrator
Assembles the full sequential agent pipeline in the correct execution order.

Pipeline order:
  1. DataFetcherAgent       → Fetches QA data for the Process ID
  2. QuestionAgent_01–10    → Sequential reasoning chain (each builds on prior)
  3. VerdictSynthesizerAgent → Produces final structured JSON verdict
"""

import logging

from google.adk.agents import SequentialAgent

from agents.data_fetcher import create_data_fetcher_agent
from agents.question_agents import create_all_question_agents
from agents.verdict_synthesizer import create_verdict_synthesizer_agent

logger = logging.getLogger(__name__)


def create_qa_pipeline() -> SequentialAgent:
    """
    Build and return the complete QA pipeline as a SequentialAgent.

    Returns:
        SequentialAgent containing all sub-agents in execution order.
    """
    logger.info("Assembling QA Pipeline...")

    data_fetcher = create_data_fetcher_agent()
    question_agents = create_all_question_agents()
    verdict_synthesizer = create_verdict_synthesizer_agent()

    all_agents = [data_fetcher, *question_agents, verdict_synthesizer]

    pipeline = SequentialAgent(
        name="QAPipelineOrchestrator",
        description=(
            "End-to-end QA evaluation pipeline. "
            "Fetches process data, runs 10 sequential reasoning questions, "
            "and produces a structured verdict."
        ),
        sub_agents=all_agents,
    )

    agent_names = [a.name for a in all_agents]
    logger.info(
        f"QA Pipeline assembled with {len(all_agents)} agents: {agent_names}"
    )

    return pipeline
