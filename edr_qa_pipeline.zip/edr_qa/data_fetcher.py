"""DataFetcherAgent — fetches Actimize EDR data for the given ECN ID."""

import logging

from google.adk.agents import LlmAgent

from config import settings
from fetch_tool import fetch_edr_data_tool

logger = logging.getLogger(__name__)

_INSTRUCTION = """
You are the EDR QA Data Fetcher. Your only job is to retrieve Actimize EDR data.

Steps:
1. Read the ecn_id from session state.
2. Call fetch_edr_data with that ecn_id.
3. If result contains "status": "error", respond with:
   FETCH FAILED: <error message>
   Stop. Do not proceed.
4. If successful, respond with:
   FETCH OK: <ecn_number>
   Then list these key values:
     - Event Type: <event_type>
     - Brokerage Type: <brokerage_type>
     - Recommended Action: <recommended_action>
     - L2 Decision: <l2_decision>
     - Final Recommended Action: <final_recommended_action>
     - Elevated Approval Required: <elevated_approval_required>
     - RRO Number: <rro_number> (or 'none')

Do not perform any QA analysis — that is for the question agents.
Do not invent or assume any values.
"""


def create_data_fetcher_agent() -> LlmAgent:
    return LlmAgent(
        name="DataFetcherAgent",
        model=settings.model,
        instruction=_INSTRUCTION,
        tools=[fetch_edr_data_tool],
        output_key="edr_data",
        description="Fetches Actimize EDR data by ECN ID and stores it in session state.",
    )
