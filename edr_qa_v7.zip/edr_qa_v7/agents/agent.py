"""
agents/agent.py
---------------
Builds and runs the EDR QA pipeline as an ADK SequentialAgent.

SequentialAgent runs all 17 sub-agents in order and passes the full
conversation history to each one — no manual state management needed.

  IngestAgent output  → in conversation when Q01 runs
  Q01 output          → in conversation when Q02 runs
  ...
  Q15 output          → in conversation when ReportAgent runs

Each agent is a pure LlmAgent:
  - Reasoning from conversation history (no state tools)
  - Tools bound from YAML via in-memory MCP (sql / python only)
  - Model set per agent in ToolConfig (Gemini Flash or Claude claude-sonnet-4-6)

No orchestrator. No AgentTool delegation. No context.state.
The SequentialAgent IS the pipeline.
"""

import logging
from contextlib import AsyncExitStack

from google.adk.agents import LlmAgent, SequentialAgent
from google.adk.tools.mcp_tool.mcp_toolset import MCPToolset
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types
from mcp.shared.memory import (
    create_connected_server_and_client_session as create_in_memory_pair,
)

from config import settings
from mcp_factory import create_mcp_server
from yaml_runtime import MCP_TOOL_TYPES
from tool_registry import ToolConfig
from audit.audit_writer import AuditWriter

import yaml as _yaml

logger = logging.getLogger(__name__)

_AGENT_ICONS = {
    "ingest_agent":  "📥",
    "report_agent":  "📊",
}


# ── Per-agent builder ─────────────────────────────────────────────────────────

async def _build_agent(
    config:     ToolConfig,
    exit_stack: AsyncExitStack,
) -> LlmAgent:
    """
    Build one LlmAgent from a ToolConfig.

    Tools are loaded from config.yaml_path via in-memory MCP server.
    Only sql / python tools are served through MCP.
    If the YAML has no MCP tools (empty or edr_state-only), no MCP
    server is created — the agent has zero tools, which is valid for
    Q agents that reason purely from conversation history.
    """
    with open(config.yaml_path) as f:
        all_fns = _yaml.safe_load(f).get("functions", [])

    mcp_fns = [fn for fn in all_fns if fn.get("type") in MCP_TOOL_TYPES]
    tools   = []

    if mcp_fns:
        server         = create_mcp_server(config.yaml_path)
        client_session = await exit_stack.enter_async_context(
            create_in_memory_pair(server)
        )
        mcp_tools = await exit_stack.enter_async_context(
            MCPToolset(client_session=client_session)
        )
        tools.extend(mcp_tools)

    agent = LlmAgent(
        name=config.name,
        model=config.model,
        description=config.description,
        instruction=config.instruction,
        tools=tools,
    )

    logger.debug(
        "Built %s | model=%s | tools=%d",
        config.name, config.model, len(tools),
    )
    return agent


# ── Main run ──────────────────────────────────────────────────────────────────

async def run_edr_qa(
    ecn_id:      str,
    run_id:      str,
    output_path: str,
    registry:    list[ToolConfig],
    audit:       AuditWriter,
    verbose:     bool = True,
) -> str:
    """
    Run the full 17-agent EDR QA pipeline for one ECN.

    Each run gets its own ADK session. SequentialAgent manages
    conversation history — each agent sees all prior outputs.
    Concurrent runs for different ECNs are fully isolated.
    """
    async with AsyncExitStack() as stack:

        # Build all 17 sub-agents
        sub_agents: list[LlmAgent] = []
        for cfg in registry:
            sub_agents.append(await _build_agent(cfg, stack))

        # SequentialAgent — runs sub_agents in order, passes conversation through
        pipeline = SequentialAgent(
            name="edr_qa_pipeline",
            sub_agents=sub_agents,
        )

        session_service = InMemorySessionService()
        await session_service.create_session(
            app_name=settings.app_name,
            user_id=run_id,
            session_id=run_id,
        )

        runner = Runner(
            agent=pipeline,
            app_name=settings.app_name,
            session_service=session_service,
        )

        # Single message — SequentialAgent routes it through all 17 agents
        message = types.Content(
            role="user",
            parts=[types.Part(text=(
                f"Run EDR QA for ECN: {ecn_id}. Output path: {output_path}."
            ))],
        )

        if verbose:
            print(f"\n{'─' * 62}")
            print(f"  🚀  EDR QA v7  |  {ecn_id}")
            print(f"  Run    : {run_id}")
            print(f"  Pattern: SequentialAgent — conversation history, no state")
            print(f"  Agents : {len(sub_agents)} (1 ingest + 15 Q + 1 report)")
            print(f"{'─' * 62}")

        response_text  = ""
        current_author = None

        async for event in runner.run_async(
            user_id=run_id,
            session_id=run_id,
            new_message=message,
        ):
            author = getattr(event, "author", None)

            # Agent transition — write audit record for completed agent
            if author and author != current_author:
                if current_author and current_author != "edr_qa_pipeline":
                    audit.write_agent_record(
                        agent_name=current_author,
                        status="success",
                        response_text=response_text,
                    )
                current_author = author
                if author != "edr_qa_pipeline":
                    audit.agent_started(author)

                if verbose and author != "edr_qa_pipeline":
                    q_num = None
                    if author.startswith("q") and author.endswith("_agent"):
                        try: q_num = int(author[1:3])
                        except ValueError: pass
                    icon = _AGENT_ICONS.get(author, f"Q{q_num:02d}" if q_num else "▶")
                    print(f"\n  {icon}  {author}")

                logger.info("Agent: %s", author,
                            extra={"run_id": run_id, "ecn_id": ecn_id})

            # Tool calls
            if event.get_function_calls() and verbose:
                for call in event.get_function_calls():
                    print(f"       🔧 {call.name}({str(call.args)[:60]})")

            # Capture response text
            if event.is_final_response() and event.content:
                for part in event.content.parts:
                    if hasattr(part, "text") and part.text:
                        response_text = part.text.strip()
                        if verbose:
                            preview = response_text[:200]
                            print(f"       → {preview}{'…' if len(response_text) > 200 else ''}")

        # Write audit for last agent
        if current_author and current_author != "edr_qa_pipeline":
            audit.write_agent_record(
                agent_name=current_author,
                status="success",
                response_text=response_text,
            )

        return response_text
