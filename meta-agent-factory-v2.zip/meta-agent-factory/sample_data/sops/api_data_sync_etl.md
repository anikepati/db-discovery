# SOP: Nightly Data Sync — CRM to Data Warehouse ETL

## Version: 3.0
## Domain: Data Engineering / ETL
## Last Updated: 2025-07-01

## Prerequisites
- API access to CRM REST API (v2)
- Database write access to Data Warehouse (PostgreSQL)
- AWS S3 bucket access for staging files
- Valid API key stored in environment variable CRM_API_KEY
- Database connection string in environment variable DW_CONNECTION_STRING

## Procedure

### Step 1: Health Check
1. Send GET request to `https://api.crm.company.com/v2/health`
2. Verify response status code is 200
3. Check response body contains `{"status": "healthy"}`
4. Send test query to Data Warehouse: `SELECT 1`
5. Verify database responds within 5 seconds
6. **Error Handling**: If either check fails, abort pipeline and send alert

### Step 2: Extract Customer Data
1. Send GET request to `https://api.crm.company.com/v2/customers?modified_since={last_sync_timestamp}&page_size=500`
2. Set Authorization header: `Bearer ${CRM_API_KEY}`
3. Parse JSON response to get customer records
4. If `next_page_token` exists in response, fetch next page
5. Repeat until all pages fetched
6. Save combined records to `staging/customers_{date}.json`
7. **Expected**: Log total record count

### Step 3: Extract Order Data
1. Send GET request to `https://api.crm.company.com/v2/orders?modified_since={last_sync_timestamp}&page_size=500`
2. Set Authorization header: `Bearer ${CRM_API_KEY}`
3. Parse JSON response to get order records
4. Paginate through all results
5. Save to `staging/orders_{date}.json`
6. **Expected**: Log total record count

### Step 4: Transform Customer Data
1. Read `staging/customers_{date}.json`
2. Apply field mappings from `field_mapping.json` reference file
3. Transform date fields to ISO 8601 format
4. Normalize phone numbers to E.164 format
5. Validate email formats (discard invalid)
6. Remove duplicate records (by customer_id)
7. Generate SHA-256 hash for PII fields (for audit)
8. Save transformed data to `staging/customers_transformed_{date}.json`
9. **Validation**: Record count should match extract ± discarded invalids

### Step 5: Transform Order Data
1. Read `staging/orders_{date}.json`
2. Apply field mappings from `field_mapping.json`
3. Calculate order totals (line items × quantity × unit price)
4. Apply currency conversion using `currency_rates.json` reference
5. Map status codes using `status_codes.json` reference
6. Save to `staging/orders_transformed_{date}.json`

### Step 6: Upload to S3 Staging
1. Upload `staging/customers_transformed_{date}.json` to `s3://company-dw-staging/customers/`
2. Upload `staging/orders_transformed_{date}.json` to `s3://company-dw-staging/orders/`
3. Verify uploads with HEAD request to confirm file exists
4. **Expected**: Both files accessible in S3

### Step 7: Load to Data Warehouse
1. Connect to PostgreSQL Data Warehouse using `${DW_CONNECTION_STRING}`
2. Begin transaction
3. Execute `COPY` command to load customers into `staging.customers` table
4. Execute `COPY` command to load orders into `staging.orders` table
5. Run merge query: `CALL sp_merge_customers()`
6. Run merge query: `CALL sp_merge_orders()`
7. Commit transaction
8. **Error Handling**: On any error, ROLLBACK transaction

### Step 8: Validation Queries
1. Run: `SELECT COUNT(*) FROM staging.customers WHERE load_date = CURRENT_DATE`
2. Run: `SELECT COUNT(*) FROM staging.orders WHERE load_date = CURRENT_DATE`
3. Compare counts with extract counts
4. Run data quality check: `CALL sp_data_quality_check(CURRENT_DATE)`
5. **Expected**: Quality check returns no critical errors

### Step 9: Update Sync Metadata
1. Update last_sync_timestamp in `sync_metadata` table
2. Insert pipeline run record with:
   - run_id, start_time, end_time
   - records_extracted, records_transformed, records_loaded
   - status (success/partial/failed)
   - error_details (if any)

### Step 10: Cleanup and Notification
1. Delete local staging files older than 7 days
2. Send summary email via `https://api.company.com/notifications/email`
3. Post summary to Slack channel via webhook
4. **Expected**: Cleanup complete, notifications sent

## Error Handling
- API rate limits: Implement exponential backoff (max 5 retries)
- Database locks: Wait 30 seconds and retry (max 3 retries)
- S3 upload failures: Retry with multipart upload
- Any critical failure: Send PagerDuty alert

## Output
- Updated Data Warehouse tables
- Pipeline run metadata record
- Summary email and Slack notification
- Staging files in S3 (retained 30 days)
