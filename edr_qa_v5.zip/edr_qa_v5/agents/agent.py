"""
agents/agent.py
---------------
Builds the 17-agent EDR QA pipeline and runs it.

Architecture:
  ┌────────────────────────────────────────────────────────────┐
  │  run_edr_qa(ecn_id, run_id, output_path, audit)            │
  │                                                            │
  │  ADK InMemorySessionService — context.state lives here     │
  │  Initial state: {ecn_id, run_id}                          │
  │                                                            │
  │  17 sub-agents (all share the same session/state):         │
  │  ├─ ingest_agent     → fetch SQL + store to context.state  │
  │  ├─ q01_agent        → read state → reason → write state   │
  │  ├─ q02_agent        → read state → reason → write state   │
  │  │   ...                                                   │
  │  ├─ q15_agent        → read state → reason → write state   │
  │  └─ report_agent     → read state → compute → write file   │
  │                                                            │
  │  orchestrator delegates via AgentTool (chat messages)      │
  │  in strict order: ingest → q01 → ... → q15 → report        │
  └────────────────────────────────────────────────────────────┘

FunctionTool + ToolContext:
  All state read/write goes through tools in agents/tools.py.
  ADK injects ToolContext into any tool function that declares it
  as a parameter — tools then access context.state directly.

Skill instructions:
  Each agent's instruction is loaded from its SKILL.md body via
  AgentConfig.load_instruction() — no hardcoded prompts here.
"""

import logging
from pathlib import Path

from dotenv import load_dotenv
from google.adk.agents import LlmAgent
from google.adk.tools import FunctionTool
from google.adk.tools.agent_tool import AgentTool
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types

from config import settings
from agents.registry import AGENT_REGISTRY, AgentConfig
from agents.tools import (
    fetch_edr_data, store_edr_data, get_edr_data,
    get_prior_answers, answer_question, store_answer,
    get_all_answers, store_verdict, build_report,
)
from audit.audit_writer import AuditWriter

load_dotenv()
logger = logging.getLogger(__name__)

# All FunctionTools — filtered per agent by tool_names in registry
_ALL_TOOLS: dict[str, FunctionTool] = {
    "fetch_edr_data":    FunctionTool(fetch_edr_data),
    "store_edr_data":    FunctionTool(store_edr_data),
    "get_edr_data":      FunctionTool(get_edr_data),
    "get_prior_answers": FunctionTool(get_prior_answers),
    "answer_question":   FunctionTool(answer_question),
    "store_answer":      FunctionTool(store_answer),
    "get_all_answers":   FunctionTool(get_all_answers),
    "store_verdict":     FunctionTool(store_verdict),
    "build_report":      FunctionTool(build_report),
}


def _build_sub_agent(cfg: AgentConfig) -> LlmAgent:
    """Build one specialist LlmAgent from its AgentConfig + SKILL.md instruction."""
    tools       = [_ALL_TOOLS[name] for name in cfg.tool_names if name in _ALL_TOOLS]
    instruction = cfg.load_instruction()
    description = cfg.load_description()

    return LlmAgent(
        name=cfg.name,
        model=settings.adk_model,
        description=description,
        instruction=instruction,
        tools=tools,
    )


def _build_orchestrator(sub_agents: list[LlmAgent]) -> LlmAgent:
    """Build the orchestrator that delegates to 17 sub-agents in strict order."""
    agent_list = "\n".join(
        f"  {i+1:02d}. {cfg.name} — {cfg.load_description()[:80]}"
        for i, cfg in enumerate(AGENT_REGISTRY)
    )
    q_sequence = " → ".join(
        cfg.name for cfg in AGENT_REGISTRY
        if cfg.name not in ("report_agent",)
    )

    return LlmAgent(
        name="edr_qa_orchestrator",
        model=settings.adk_model,
        description="Orchestrates the full EDR QA pipeline across 17 specialist agents",
        instruction=f"""You are the EDR QA Pipeline Orchestrator.

Run all 17 agents in STRICT ORDER for the given ECN. Never skip, reorder, or parallelize.

Pipeline sequence:
{agent_list}

Execution rules:
1. Delegate to ingest_agent first. Pass the ecn_id.
   Wait for "INGEST OK". If "INGEST FAILED" — stop and report.

2. Delegate to q01_agent through q15_agent in ORDER (01 → 02 → ... → 15).
   Pass the ecn_id to each. Each agent reads EDR data and prior answers
   from context.state automatically — you do not need to pass data between agents.
   Never stop early because of a N or NEEDS_HUMAN answer.
   Wait for each agent to respond before delegating to the next.

3. Delegate to report_agent last. Pass the output_path.
   Wait for "REPORT WRITTEN".

Final response format:
  EDR QA PIPELINE COMPLETE
  ECN:     <ecn_id>
  Verdict: <verdict>
  Pass:    <overall_pass_rate>%
  Failed:  <failed_questions or NONE>
  Human:   <human_review_count> items requiring action
  Report:  <output_path>

Rules:
- Run ALL 17 agents regardless of intermediate results.
- Never fabricate results — only report what agents return.
- context.state is shared across all agents automatically — do not copy data between messages.
""",
        tools=[AgentTool(agent=a) for a in sub_agents],
    )


async def run_edr_qa(
    ecn_id:      str,
    run_id:      str,
    output_path: str,
    audit:       AuditWriter,
    verbose:     bool = True,
) -> str:
    """
    Run the full EDR QA pipeline for one ECN.

    context.state is seeded with ecn_id and run_id before the run starts.
    All 17 agents share the same ADK session and therefore the same context.state.
    IngestAgent writes edr_data → Q agents read it → ReportAgent reads all answers.

    Returns the orchestrator's final response text.
    """
    # 1. Build all 17 sub-agents from SKILL.md instructions
    sub_agents = [_build_sub_agent(cfg) for cfg in AGENT_REGISTRY]
    logger.info("Built %d sub-agents", len(sub_agents))

    # 2. Build orchestrator
    orchestrator = _build_orchestrator(sub_agents)

    # 3. Create ADK session — seed context.state with run metadata
    session_svc = InMemorySessionService()
    session     = await session_svc.create_session(
        app_name=settings.app_name,
        user_id=run_id,
        session_id=run_id,
        state={
            "ecn_id":   ecn_id,
            "run_id":   run_id,
            "edr_data": {},
            "answers":  {},
            "verdict":  None,
        },
    )

    runner = Runner(
        agent=orchestrator,
        app_name=settings.app_name,
        session_service=session_svc,
    )

    # 4. Initial user message to orchestrator
    message = types.Content(
        role="user",
        parts=[types.Part(text=(
            f"Run the full EDR QA pipeline for ECN: {ecn_id}. "
            f"Output path: {output_path}."
        ))],
    )

    if verbose:
        print(f"\n{'─' * 62}")
        print(f"  📋  EDR QA v5  |  {ecn_id}  |  {run_id}")
        print(f"{'─' * 62}")

    # 5. Stream events
    response_text  = ""
    current_author = None
    _ICONS = {
        "ingest_agent":       "📥",
        "report_agent":       "📊",
        "edr_qa_orchestrator": "🎯",
    }

    async for event in runner.run_async(
        user_id=run_id,
        session_id=run_id,
        new_message=message,
    ):
        author = event.author

        # Track agent transitions
        if author and author != current_author:
            if current_author:
                audit.write_agent_record(
                    agent_name=current_author,
                    status="success",
                    response_text=response_text,
                )
            current_author = author
            audit.agent_started(current_author)

            if verbose:
                q_match = current_author.startswith("q") and current_author.endswith("_agent")
                icon = _ICONS.get(current_author, "🔍" if q_match else "▶")
                print(f"\n  {icon}  {current_author}")

            logger.info("Agent active: %s", current_author,
                       extra={"run_id": run_id, "ecn_id": ecn_id})

        # Show tool calls
        if event.get_function_calls() and verbose:
            for call in event.get_function_calls():
                args_preview = str(call.args)[:60]
                print(f"       🔧 {call.name}({args_preview}{'…' if len(str(call.args)) > 60 else ''})")

        # Capture final response
        if event.is_final_response() and event.content:
            for part in event.content.parts:
                if hasattr(part, "text") and part.text:
                    response_text = part.text.strip()
                    if verbose and current_author == "edr_qa_orchestrator":
                        print(f"\n{response_text[:2000]}\n")

    # Write audit for last agent
    if current_author:
        audit.write_agent_record(
            agent_name=current_author,
            status="success",
            response_text=response_text,
        )

    return response_text
