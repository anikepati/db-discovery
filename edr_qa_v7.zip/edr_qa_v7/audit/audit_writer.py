"""
audit_writer.py
---------------
Writes per-run, per-agent audit records.

One folder per run:
  audit/
    run_20260228_143022_ECN-2024-001/
      00_run_manifest.json      ← created at run start
      01_ingest_agent.json      ← written when agent completes
      02_qa_reasoning_agent.json
      03_report_agent.json
      04_run_summary.json       ← written at run end

Each agent file contains:
  - run_id, ecn_id, agent_name
  - started_at, completed_at, duration_ms
  - attempt number (1-based, >1 = retry)
  - status: success | failed | retried
  - response text (truncated to 4000 chars)
  - state_snapshot at completion

All files are plain JSON — queryable and replayable without any tooling.
"""

import json
import logging
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


class AuditWriter:
    """
    Writes structured audit files for one pipeline run.
    Thread-safe — uses atomic file writes.
    """

    _AGENT_ORDER = {
        "ingest_agent":       "01",
        "qa_reasoning_agent": "02",
        "report_agent":       "03",
    }

    def __init__(self, run_id: str, ecn_id: str, audit_dir: str = "audit") -> None:
        self.run_id    = run_id
        self.ecn_id    = ecn_id
        self.run_dir   = Path(audit_dir) / run_id
        self.run_dir.mkdir(parents=True, exist_ok=True)
        self._timings: dict[str, datetime] = {}

    # ── Run lifecycle ─────────────────────────────────────────────────────────

    def write_manifest(self, ecn_id: str, questions_count: int = 15) -> None:
        """Write run manifest at start of pipeline."""
        manifest = {
            "run_id":           self.run_id,
            "ecn_id":           ecn_id,
            "started_at":       datetime.now(timezone.utc).isoformat(),
            "questions_count":  questions_count,
            "pipeline_version": "v4",
            "agents":           list(self._AGENT_ORDER.keys()),
        }
        self._write("00_run_manifest.json", manifest)
        logger.info("Audit manifest written", extra={"run_id": self.run_id, "ecn_id": ecn_id})

    def write_run_summary(
        self,
        verdict:          str,
        pass_rate:        float,
        failed_questions: list[int],
        human_items:      list[dict],
        duration_seconds: float,
        state_snapshot:   dict[str, Any],
    ) -> None:
        """Write final summary at end of pipeline."""
        summary = {
            "run_id":            self.run_id,
            "ecn_id":            self.ecn_id,
            "completed_at":      datetime.now(timezone.utc).isoformat(),
            "duration_seconds":  round(duration_seconds, 2),
            "verdict":           verdict,
            "overall_pass_rate": pass_rate,
            "failed_questions":  failed_questions,
            "human_review_count": len(human_items),
            "human_review_items": human_items,
            "state_snapshot":    state_snapshot,
        }
        self._write("04_run_summary.json", summary)
        logger.info(
            "Audit summary written: %s %.1f%%",
            verdict, pass_rate,
            extra={"run_id": self.run_id},
        )

    # ── Agent lifecycle ───────────────────────────────────────────────────────

    def agent_started(self, agent_name: str) -> None:
        """Record agent start time."""
        self._timings[agent_name] = datetime.now(timezone.utc)

    def write_agent_record(
        self,
        agent_name:     str,
        status:         str,         # "success" | "failed" | "retried"
        response_text:  str,
        attempt:        int = 1,
        error:          str = "",
        state_snapshot: dict[str, Any] | None = None,
    ) -> None:
        """Write per-agent audit record."""
        started = self._timings.get(agent_name, datetime.now(timezone.utc))
        completed = datetime.now(timezone.utc)
        duration_ms = int((completed - started).total_seconds() * 1000)

        prefix = self._AGENT_ORDER.get(agent_name, "99")
        record = {
            "run_id":         self.run_id,
            "ecn_id":         self.ecn_id,
            "agent_name":     agent_name,
            "attempt":        attempt,
            "status":         status,
            "started_at":     started.isoformat(),
            "completed_at":   completed.isoformat(),
            "duration_ms":    duration_ms,
            "response_text":  response_text[:4000],
            "error":          error,
            "state_snapshot": state_snapshot or {},
        }
        filename = f"{prefix}_{agent_name}.json"
        self._write(filename, record)
        logger.info(
            "Audit record written: agent=%s status=%s duration=%dms",
            agent_name, status, duration_ms,
            extra={"run_id": self.run_id, "agent": agent_name},
        )

    # ── Internal ──────────────────────────────────────────────────────────────

    def _write(self, filename: str, data: dict) -> None:
        """Atomic JSON write — write to temp then rename."""
        path = self.run_dir / filename
        tmp  = path.with_suffix(".tmp")
        try:
            tmp.write_text(json.dumps(data, indent=2, default=str), encoding="utf-8")
            tmp.replace(path)
        except Exception as e:
            logger.error("Failed to write audit file %s: %s", filename, e)
            try:
                tmp.unlink(missing_ok=True)
            except Exception:
                pass

    def audit_path(self) -> str:
        """Return the path of this run's audit folder."""
        return str(self.run_dir)
