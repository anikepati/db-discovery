# 🧬 GEPA Forge — Enterprise Google ADK Playground (Full Feature Edition)

**Automatic genetic-Pareto evolution for Google ADK multi-agent systems.**

Your pure Python agents + custom tools stay **100% unchanged**.
GEPA Forge gives you a clean, professional ADK web experience plus powerful enterprise tools
that automatically improve your agents in minutes.

---

## ✨ Complete Feature List

### 1. Agent Studio (Visual Builder)
- Exact look & feel of official Google ADK web interface
- Import any existing Python file (`my_team.py`)
- Live agent graph (root + sub-agents) with Plotly + NetworkX
- Rich prompt editor for every agent
- One-click import from Prompt Library
- Full tool support — custom tools work out-of-the-box

### 2. Evaluation Lab (Test Data Management)
- **Synthetic Test Case Generator** — AI creates 30+ realistic enterprise scenarios in one click
- Drag & drop JSON/CSV test cases (input + expected output + business KPIs)
- Record live conversations as golden test cases
- Domain-aware generation (compliance, finance, customer service, data)
- Full multi-agent end-to-end execution (traces + tool calls captured)

### 3. Evolution Dashboard (The Core Innovation)
- One-click "Evolve Multi-Agent System" (configurable 2–30 generations)
- **Live progress chart** (Plotly) — best & average fitness per generation
- **Pareto frontier visualization** — multi-objective scatter plot
- **KPI radar chart** — before/after comparison across all business metrics
- Before/after comparison of entire team (prompts + delegation logic + tool usage)
- **Business KPI scoring** (accuracy, cost, latency, compliance, revenue impact, tool efficiency, delegation quality)

### 4. Enterprise Tools (4 Sub-tabs)

#### 🛡️ Safety & Quality Gate
- Automatic pre-flight safety checker
- PII detection, hallucination risk, compliance scan, injection check
- Tool misuse patterns, instruction quality validation
- Cross-agent delegation consistency checks
- Downloadable safety report

#### 📊 Benchmark Reports
- Auto-generated **PDF + CSV** report after every evolution
- Full metrics, improvement percentages, per-agent changes
- Generation-by-generation trace table
- One-click download

#### 📜 History & Reproducibility
- All past evolutions saved in **SQLite**
- View, reload, or compare any previous run
- Generation traces with fitness breakdowns
- Best genome persistence

#### 📚 Prompt Library
- 8 built-in enterprise templates (Financial Analyst, Compliance Checker, QA Agent, etc.)
- Store and reuse custom SOPs/roles/guardrails
- One-click import into any agent
- Search, filter by category, variable substitution

---

## Architecture

```
Streamlit UI (4 tabs)
   ↓
EnterpriseGEPAAdapter (ADK + genetic-Pareto bridge)
   ↓
AgentGraphParser → Genome Extraction
   ↓
GeneticOperators (mutation + crossover)
   ↓
FitnessEvaluator (LLM-as-judge + heuristic fallback)
   ↓
ParetoRanker (non-dominated sorting)
   ↓
SafetyChecker + Business KPI Scoring
   ↓
SQLite History + PDF/CSV Reports + Plotly Charts
```

---

## Installation

```bash
git clone <your-repo> && cd gepa-forge
pip install -r requirements.txt
cp .env.example .env
# Edit .env with your GOOGLE_API_KEY
streamlit run app.py
```

---

## Quick Start

1. Open **Agent Studio** → import your existing ADK multi-agent Python file
2. Go to **Evaluation Lab** → generate synthetic test cases or upload your own
3. Click **🚀 Evolve Multi-Agent System**
4. Watch the **Evolution Dashboard** with live charts
5. Apply the best version and download the **Benchmark Report**

Your tools work perfectly during the entire process.

---

## Folder Structure

```
gepa-forge/
├── app.py                           # Main Streamlit application
├── agents/
│   └── example_multi_agent.py       # Example compliance team
├── core/
│   ├── __init__.py
│   ├── gepa_adapter.py              # ADK + genetic-Pareto bridge (830+ lines)
│   ├── synthetic_generator.py       # AI test case generator
│   ├── safety_checker.py            # Pre-flight safety scanner
│   ├── benchmark_report.py          # PDF + CSV report generator
│   └── prompt_library.py            # Reusable prompt templates
├── data/
│   └── test_cases.json              # Sample test cases
├── exports/                         # Generated reports
├── evolution_history.db             # Auto-created SQLite
├── requirements.txt
├── .env.example
└── README.md
```

---

## Key Design Decisions

- **Zero code change after deployment**: Evolution only modifies agent instructions via GEPA — your tools, agent classes, and pipeline structure remain untouched.
- **Multi-objective optimization**: Pareto-optimal selection across 7 business KPIs, not just accuracy.
- **LLM-as-judge + heuristic fallback**: Fitness evaluation uses Gemini when available, degrades gracefully to rule-based scoring.
- **8 mutation strategies**: `rephrase_concise`, `add_constraint`, `add_example`, `change_persona`, `strengthen_delegation`, `add_error_handling`, `optimize_tool_usage`, `add_compliance_guardrail`.
- **Safety gate**: Critical issues block evolved genomes from being applied — falls back to original.

---

## Supported Agent Types

| Type | Supported |
|---|---|
| `LlmAgent` / `Agent` | ✅ Full instruction evolution |
| `SequentialAgent` | ✅ Pipeline order preserved |
| `ParallelAgent` | ✅ Branch structure preserved |
| `SupervisorAgent` | ✅ Delegation logic evolved |
| `LoopAgent` | ✅ Loop behavior preserved |
| Custom tools | ✅ Executed live during evolution |

---

## License

MIT
