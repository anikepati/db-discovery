"""Structured logging: JSON in production, colored console in development."""

import json
import logging
import logging.handlers
import os
import sys
from datetime import datetime, timezone


class _JSONFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "msg": record.getMessage(),
        }
        for key in ("process_id", "agent", "question"):
            if hasattr(record, key):
                payload[key] = getattr(record, key)
        if record.exc_info:
            payload["exc"] = self.formatException(record.exc_info)
        return json.dumps(payload)


class _ConsoleFormatter(logging.Formatter):
    _COLORS = {"DEBUG": "\033[36m", "INFO": "\033[32m", "WARNING": "\033[33m",
               "ERROR": "\033[31m", "CRITICAL": "\033[35m", "RESET": "\033[0m"}

    def format(self, record: logging.LogRecord) -> str:
        c, r = self._COLORS.get(record.levelname, ""), self._COLORS["RESET"]
        ts = datetime.now().strftime("%H:%M:%S")
        extras = " ".join(
            f"{k}={getattr(record, k)}"
            for k in ("process_id", "agent", "question")
            if hasattr(record, k)
        )
        suffix = f"  [{extras}]" if extras else ""
        return f"{c}{ts} {record.levelname:<8}{r} {record.name:<28} {record.getMessage()}{suffix}"


def configure_logging(log_level: str, log_dir: str, app_name: str, is_production: bool) -> None:
    """Configure root logger. Call once at application startup."""
    os.makedirs(log_dir, exist_ok=True)
    level = getattr(logging, log_level.upper(), logging.INFO)

    root = logging.getLogger()
    root.setLevel(logging.DEBUG)
    root.handlers.clear()

    # Console
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(level)
    ch.setFormatter(_JSONFormatter() if is_production else _ConsoleFormatter())
    root.addHandler(ch)

    # Rotating file — full debug log
    fh = logging.handlers.RotatingFileHandler(
        os.path.join(log_dir, f"{app_name}.log"),
        maxBytes=50 * 1024 * 1024, backupCount=5, encoding="utf-8",
    )
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(_JSONFormatter())
    root.addHandler(fh)

    # Rotating file — errors only
    eh = logging.handlers.RotatingFileHandler(
        os.path.join(log_dir, f"{app_name}_errors.log"),
        maxBytes=10 * 1024 * 1024, backupCount=3, encoding="utf-8",
    )
    eh.setLevel(logging.ERROR)
    eh.setFormatter(_JSONFormatter())
    root.addHandler(eh)

    # Suppress noisy third-party loggers
    for name in ("httpx", "httpcore", "google"):
        logging.getLogger(name).setLevel(logging.WARNING)
