"""
tool_registry.py
----------------
15 ToolConfig entries — one per sub-agent in the SequentialAgent pipeline.

Execution order = registry order:
  [0]     rro_ingest_agent      — Gemini Flash, sql tool
  [1-13]  q01..q13_agent        — Claude claude-sonnet-4-6, tools from YAML (empty by default)
  [14]    rro_report_agent      — Claude claude-sonnet-4-6, python build_report tool

Q agent instructions are auto-generated from rro_questions.py.
Full question definition (text, check logic, validation, category,
depends_on, rro_type, requires_human) is always in sync with source of truth.
"""

from dataclasses import dataclass, field
from pathlib import Path

from rro_questions import RRO_QUESTIONS, RROQuestion

INGEST_MODEL = "gemini-2.0-flash"
QA_MODEL     = "claude-sonnet-4-6"

CATEGORY_ORDER = [
    "Override Application - Addition",
    "Override Review and Approval",
    "Override Processing",
    "Override Removal",
    "Business Exception",
]


@dataclass
class ToolConfig:
    name:        str
    yaml_path:   str
    description: str
    instruction: str
    model:       str = field(default=INGEST_MODEL)


# ── IngestAgent ───────────────────────────────────────────────────────────────

def _ingest_config() -> ToolConfig:
    return ToolConfig(
        name="rro_ingest_agent",
        yaml_path="tools/rro_ingest_tools.yaml",
        model=INGEST_MODEL,
        description=(
            "Fetches the complete RRO record for a given ECN from the Actimize "
            "MS SQL view vw_get_qa_rro_data. Outputs all fields as structured "
            "text into the conversation for all downstream Q agents."
        ),
        instruction="""You are the RRO Ingest Agent.

Your job: fetch the RRO record for the given ECN and output it clearly
so all downstream Q agents can read it from the conversation history.

Steps:
1. Call fetch_rro_data with ecn_id (and work_item_id if provided).
2. If result is empty or contains an error — respond:
   INGEST FAILED: <reason>
   Then stop.
3. Output the full RRO record as structured text:

   INGEST OK
   ══════════════════════════════════════════
   RRO RECORD: <ecn_number>
   ══════════════════════════════════════════
   Work Item ID:                  <work_item_id>
   Status:                        <status>
   Submitting Group:              <submitting_group>
   RRO Type:                      <rro_type>
   RRO Sub-Type:                  <rro_sub_type>
   Discretionary Rationale:       <discretionary_rationale>
   RR Override Value:             <rr_override_value>
   Customer Legal Name:           <customer_legal_name>
   WCS ID:                        <wcs_id>
   Shared Customer Flag:          <shared_customer_flag>

   DFCL Details:                  <dfcl_details>
   DFCL Primary Approval:         <dfcl_primary_approval>
   DFCL Shared Approval:          <dfcl_shared_approval>

   L1 Reviewer Name:              <l1_reviewer_name>
   L1 Submitter Name:             <l1_submitter_name>
   L1 Supervisory Comments:       <l1_supervisory_comments>

   RRO Number:                    <rro_number>
   RRO Status:                    <rro_status>
   RRO Expiry Date:               <rro_expiry_date>
   ECRM Active Override Flag:     <ecrm_active_override_flag>
   ECRM Risk Rating Override:     <ecrm_risk_rating_override_value>
   Pre-Override Risk Rating:      <pre_override_risk_rating>
   Actimize RRO Status:           <actimize_rro_status>

   Removal Rationale:             <removal_rationale>
   Created By:                    <created_by>
   Created Date:                  <created_date>
   Last Modified Date:            <last_modified_date>
   ══════════════════════════════════════════

Rules:
- Output every field, write "none" for empty values.
- Do not analyse or evaluate the data. Q agents do that.
- This output is the only source of RRO data for all 13 Q agents.
""",
    )


# ── Q Agent instruction builder ───────────────────────────────────────────────

def _build_q_instruction(q: RROQuestion) -> str:
    dep_str = ", ".join(f"Q{d}" for d in q.depends_on) if q.depends_on else "none"
    rro_scope = f"Applies to: {q.rro_type}" if q.rro_type else "Applies to: RRO Added and RRO Removed"

    dep_note = (
        f"\nThis question depends on: {dep_str}.\n"
        "Read those answers from the conversation history above before reasoning.\n"
        if q.depends_on else
        "\nThis is an independent question — no prior answers required.\n"
    )

    human_block = ""
    if q.requires_human:
        human_block = """
⚠️  HUMAN ACTION MAY BE REQUIRED:
If the condition in the Check Logic applies:
  answer:         NEEDS_HUMAN
  requires_human: true
  human_action:   the exact action required (e.g. email LOB, manual verification)
Only answer N/A if the condition clearly does NOT apply to this RRO record.
"""

    notes_block = f"\nNotes / Scenarios:\n{q.notes}\n" if q.notes else ""

    return f"""You are the RRO QA Agent for Question {q.number} of 13.
Category: {q.category}
{rro_scope}
Depends on: {dep_str}
{dep_note}
══════════════════════════════════════════════
QUESTION {q.number}: {q.question}
══════════════════════════════════════════════

What to Validate:
{q.validation}

Check Logic (apply precisely):
{q.check}
{notes_block}{human_block}
══════════════════════════════════════════════
STEPS — follow in exact order:
══════════════════════════════════════════════

1. READ the RRO record from the conversation history above (output by rro_ingest_agent).
   If the RRO record is not in the conversation:
   → respond: Q{q.number:02d} [ERROR]: RRO data not found in conversation history.

2. READ prior Q agent answers from conversation history if depends_on is not none.
   Locate outputs of: {dep_str if q.depends_on else "none"}

3. REASON about Question {q.number}:
   - Apply the Check Logic above to the actual field values from the RRO record.
   - Reference specific field values by name.
     e.g. "rro_type = Discretionary, therefore supervisory approval is required..."
   - Work step by step — minimum 3 sentences.
   - Arrive at exactly one of: Y | N | N/A | NEEDS_HUMAN

4. RESPOND in exactly this format:
   Q{q.number:02d} [{q.category}]
   ANSWER: <Y | N | N/A | NEEDS_HUMAN>
   REASONING: <full step-by-step reasoning referencing actual field values>{"" if not q.requires_human else chr(10) + "   HUMAN_ACTION: <exact action required>"}
   REQUIRES_HUMAN: <true | false>
   CATEGORY: {q.category}
   RRO_TYPE: {q.rro_type or "both"}

══════════════════════════════════════════════
RULES:
- Only answer Question {q.number}. Never answer any other question.
- Never fabricate field values. Only use what is in the RRO record above.
- Always output the full structured response — downstream agents parse it.
- If a required field is missing from the RRO record, note it and answer NEEDS_HUMAN.
"""


# ── Q Agent ToolConfig ────────────────────────────────────────────────────────

def _question_config(q: RROQuestion) -> ToolConfig:
    dep_str = str(list(q.depends_on)) if q.depends_on else "none"
    return ToolConfig(
        name=f"q{q.number:02d}_agent",
        yaml_path=f"tools/rro_q{q.number:02d}_tools.yaml",
        model=QA_MODEL,
        description=(
            f"Answers RRO QA Question {q.number} ({q.category}). "
            f"Reads RRO data and prior answers from conversation history. "
            f"RRO Type: {q.rro_type or 'both'}. Depends on: {dep_str}."
        ),
        instruction=_build_q_instruction(q),
    )


# ── ReportAgent ───────────────────────────────────────────────────────────────

def _report_config() -> ToolConfig:
    return ToolConfig(
        name="rro_report_agent",
        yaml_path="tools/rro_report_tools.yaml",
        model=QA_MODEL,
        description=(
            "Reads all 13 QA answers from conversation history, calls "
            "build_rro_report to compute verdict and write the JSON report."
        ),
        instruction="""You are the RRO QA Report Agent.

Your job: collect all 13 answers from the conversation history and call
build_rro_report to write the final JSON verdict file.

Steps:
1. READ the conversation history. Find the output of every Q agent (Q01..Q13).
   Each responded in the format:
     Q{N} [Category]
     ANSWER: Y | N | N/A | NEEDS_HUMAN
     REASONING: ...
     REQUIRES_HUMAN: true | false
     CATEGORY: ...
     RRO_TYPE: ...

2. READ the RRO RECORD section from rro_ingest_agent's output for edr_data fields.

3. CONSTRUCT the answers dict:
   {
     "q1":  {"answer": "Y",  "reasoning": "...", "requires_human": false,
             "human_action": "", "category": "Override Application - Addition",
             "rro_type": "RRO_ADDED"},
     ...
     "q13": {...}
   }
   If any Q agent is missing: include as NEEDS_HUMAN with
   human_action: "Q{N} did not respond — manual review required"

4. CONSTRUCT rro_data from the RRO RECORD in conversation:
   {"ecn_number": "...", "rro_type": "...", "rro_sub_type": "...",
    "rro_number": "...", "status": "..."}

5. Call build_rro_report with answers, rro_data, and output_path.

6. Respond:
   REPORT WRITTEN
   Path:    <output_path>
   Verdict: <verdict>
   Pass:    <pass_rate>%
   Failed:  <failed_questions or none>
   Human:   <human_count> items requiring action

Rules:
- Collect ALL 13 answers before calling build_rro_report.
- Never fabricate answers — only use what Q agents actually output.
- If build_rro_report errors: respond "REPORT FAILED: <e>".
""",
    )


# ── Public API ────────────────────────────────────────────────────────────────

def build_registry() -> list[ToolConfig]:
    """15-entry registry in SequentialAgent execution order."""
    registry: list[ToolConfig] = [_ingest_config()]
    for q in RRO_QUESTIONS:
        registry.append(_question_config(q))
    registry.append(_report_config())
    return registry


def validate_yaml_files(registry: list[ToolConfig]) -> None:
    missing = [c.yaml_path for c in registry if not Path(c.yaml_path).exists()]
    if missing:
        raise FileNotFoundError(
            "Missing YAML files (run: python tool_generator.py):\n"
            + "\n".join(f"  {p}" for p in missing)
        )
