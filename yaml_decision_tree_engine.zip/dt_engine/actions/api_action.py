"""
API Action Handler — HTTP calls with retry logic.
"""

import logging
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

try:
    import httpx
    HTTP_CLIENT = "httpx"
except ImportError:
    HTTP_CLIENT = "requests"


def call_api(
    url: str,
    method: str = "POST",
    payload: Optional[Dict[str, Any]] = None,
    headers: Optional[Dict[str, str]] = None,
    timeout: int = 30,
    retries: int = 3,
) -> Dict[str, Any]:
    default_headers = {"Content-Type": "application/json"}
    if headers:
        default_headers.update(headers)

    for attempt in range(1, retries + 1):
        try:
            logger.info(f"  [API] {method} {url} | attempt {attempt}/{retries}")

            if HTTP_CLIENT == "httpx":
                with httpx.Client(timeout=timeout) as client:
                    resp = client.request(method=method.upper(), url=url, json=payload, headers=default_headers)
                    status_code = resp.status_code
                    body = resp.text
            else:
                import requests as req
                resp = req.request(method=method.upper(), url=url, json=payload, headers=default_headers, timeout=timeout)
                status_code = resp.status_code
                body = resp.text

            if status_code in (200, 201, 202, 204):
                return {"status": "success", "status_code": status_code, "response_body": body}
            else:
                logger.warning(f"  [API] HTTP {status_code} on attempt {attempt}")
                if attempt == retries:
                    return {"status": "failed", "status_code": status_code, "response_body": body}

        except Exception as e:
            logger.error(f"  [API] Error on attempt {attempt}: {e}")
            if attempt == retries:
                return {"status": "error", "status_code": None, "error": str(e)}

    return {"status": "error", "error": "exhausted retries"}
