"""
EDR QA Pipeline — entry point.

Usage:
    python main.py --ecn-id ECN-2024-001
    python main.py --ecn-id ECN-2024-002 --output result.json --quiet

Exit codes:
    0   PASS or PASS_WITH_EXCEPTIONS
    1   Config error or pipeline failure
    2   FAIL or REQUIRES_HUMAN_REVIEW
  130   Interrupted
"""

import argparse
import asyncio
import json
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from config import settings, configure_logging
from models import EDRQAResult
from pipeline_runner import EDRPipelineRunner


def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="EDR QA Pipeline — Agentic EDR Review using Google ADK",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Demo ECN IDs:\n"
            "  ECN-2024-001  Priority FC Business Approval  (expected: PASS)\n"
            "  ECN-2024-002  Increase Risk Rating            (expected: REQUIRES_HUMAN_REVIEW)\n"
            "  ECN-2024-003  Exit Decision                   (expected: REQUIRES_HUMAN_REVIEW)\n"
        ),
    )
    p.add_argument("--ecn-id", required=True, help="ECN identifier to evaluate")
    p.add_argument("--output", default=None, help="Save JSON result to this path")
    p.add_argument("--quiet", action="store_true", help="Suppress per-agent output")
    p.add_argument("--user-id", default=None, help="User ID for session tracking")
    return p.parse_args()


def _save(result: EDRQAResult, path: str) -> None:
    output = {
        "run": {
            "ecn_id": result.ecn_id,
            "session_id": result.session_id,
            "started_at": result.started_at.isoformat(),
            "completed_at": result.completed_at.isoformat(),
            "duration_seconds": result.duration_seconds,
        },
        "verdict": {
            "verdict": result.verdict.value,
            "overall_pass_rate": result.overall_pass_rate,
            "passed": result.passed,
            "summary": result.summary,
            "failed_questions": result.failed_questions,
            "human_review_required": result.human_review_required,
        },
        "category_summaries": [
            {
                "name": cs.name,
                "total": cs.total,
                "pass": cs.yes_count,
                "fail": cs.no_count,
                "na": cs.na_count,
                "needs_human": cs.human_count,
                "pass_rate": cs.pass_rate,
            }
            for cs in result.category_summaries
        ],
        "answers": [
            {
                "number": qr.number,
                "category": qr.category,
                "question": qr.question,
                "answer": qr.answer.value,
                "reasoning": qr.reasoning,
                "requires_human": qr.requires_human,
                "human_action": qr.human_action,
            }
            for qr in result.question_results
        ],
    }
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(f"\n💾  Saved to {path}")


async def main() -> int:
    args = _parse_args()

    try:
        settings.validate()
    except ValueError as exc:
        print(f"\n❌  Config error: {exc}\n", file=sys.stderr)
        return 1

    configure_logging()

    try:
        runner = EDRPipelineRunner()
        result = await runner.run(
            ecn_id=args.ecn_id,
            user_id=args.user_id,
            verbose=not args.quiet,
        )
    except RuntimeError as exc:
        print(f"\n❌  Pipeline failed: {exc}\n", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\n\n⏹  Interrupted.\n")
        return 130

    if args.output:
        _save(result, args.output)
    elif not args.quiet:
        ts = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        default = f"edr_result_{args.ecn_id}_{ts}.json"
        if input(f"\nSave results to '{default}'? [y/N]: ").strip().lower() == "y":
            _save(result, default)

    return 0 if result.passed else 2


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
