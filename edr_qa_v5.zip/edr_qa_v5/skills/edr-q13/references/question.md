# Q13 Full Reference — Initiation of Decision Execution

## Question

Profile Refresh: Validate if profile refresh request was referred to the appropriate process for execution.

## Validation

Human must validate if decision changed to Profile Refresh during review.

## Check Logic (apply exactly)

If final_recommended_action changed to 'Profile Refresh' during risk review:   NEEDS_HUMAN — human must validate referral to appropriate process. Else: N/A.

## Depends On

Q10

## Output Hint

If decision changed to Profile Refresh: NEEDS_HUMAN. Else N/A.

## Requires Human Review

Yes — if condition applies, answer must be NEEDS_HUMAN with HUMAN_ACTION specified.

## DB Fields

- `final_recommended_action`
- `recommended_action`
- `l2_action`

## Authorization Grid (relevant for Q2, Q3, Q5, Q8)

See `skills/edr-ingest/references/schema.md` for the full authorization grid
mapping EDR type + brokerage type → authorized recommending groups.
