"""
EDR QA Pipeline v6 — CLI entry point.

Usage:
    python main.py --ecn-id ECN-2024-001
    python main.py --ecn-id ECN-2024-002 --output result.json --quiet
    python main.py --concurrent
    python main.py --generate-only

Architecture summary:
    17 pure ADK LlmAgents. Zero Anthropic SDK calls. Zero chat completion code.
    Tools defined in YAML. Reasoning by agent model. State via context.state.
    Change question logic → edit questions.py → regenerate. No code changes.
"""

import argparse
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from config import settings, configure_logging
from pipeline_runner import PipelineRunner
from tool_generator import generate_all_question_yamls

DEMO_ECNS = ["ECN-2024-001", "ECN-2024-002", "ECN-2024-003"]


def _args():
    p = argparse.ArgumentParser(
        description="EDR QA v6 — 17 pure ADK agents, context.state, YAML tools",
    )
    p.add_argument("--ecn-id",        default=None)
    p.add_argument("--output",        default=None)
    p.add_argument("--quiet",         action="store_true")
    p.add_argument("--concurrent",    action="store_true",
                   help="Run 3 demo ECNs concurrently (each isolated session)")
    p.add_argument("--generate-only", action="store_true",
                   help="Pre-generate Q01..Q15 YAML files and exit")
    return p.parse_args()


async def run_single(ecn_id, output, quiet) -> int:
    try:
        result = await PipelineRunner().run(
            ecn_id=ecn_id, output_path=output, verbose=not quiet
        )
        return 0 if result.passed else 2
    except RuntimeError as e:
        print(f"\n❌  {e}\n", file=sys.stderr)
        return 1


async def run_concurrent(quiet) -> int:
    print("\n🚀  Launching 3 concurrent EDR QA runs (isolated sessions)…\n")
    runner  = PipelineRunner()
    results = await asyncio.gather(*[
        runner.run(ecn_id=ecn, verbose=not quiet)
        for ecn in DEMO_ECNS
    ], return_exceptions=True)

    print(f"\n{'═' * 62}\n  CONCURRENT RESULTS\n{'═' * 62}")
    code = 0
    for ecn, res in zip(DEMO_ECNS, results):
        if isinstance(res, Exception):
            print(f"  ❌  {ecn}: FAILED — {res}")
            code = 1
        else:
            icon = "✅" if res.passed else ("👤" if "HUMAN" in res.verdict.value else "❌")
            print(f"  {icon}  {ecn}: {res.verdict.value} ({res.overall_pass_rate:.1f}%)")
            if not res.passed:
                code = max(code, 2)
    print()
    return code


async def main() -> int:
    args = _args()

    if args.generate_only:
        configure_logging()
        paths = generate_all_question_yamls(force=True)
        print(f"✅  Generated {len(paths)} question YAML files in tools/")
        return 0

    try:
        settings.validate()
    except ValueError as e:
        print(f"\n❌  Config error: {e}\n", file=sys.stderr)
        return 1

    configure_logging()

    try:
        if args.concurrent:
            return await run_concurrent(args.quiet)
        elif args.ecn_id:
            return await run_single(args.ecn_id, args.output, args.quiet)
        else:
            print("❌  Provide --ecn-id <ECN> or --concurrent\n", file=sys.stderr)
            return 1
    except KeyboardInterrupt:
        print("\n⏹  Interrupted.\n")
        return 130


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
