# Power Platform Environment Provisioning -- Desktop Automation

Automated provisioning workflow for Power Platform environments
using pyautogui desktop automation.
System: Power Platform Admin Center (desktop application)

## Application Launch

### Launch Power Platform Admin Center
Check Logic: Launch application at ${APP_EXE_PATH}.
Wait for window title: Power Platform Admin Center.
Take screenshot: screenshots/01_app_launched.png

## Environment Creation

### Navigate to Environments section
Check Logic: Click image controls/environments_nav.png with confidence 0.9.
Wait for window title contains: Environments.
Take screenshot: screenshots/02_environments_page.png

### Click New Environment button
Check Logic: Click image controls/new_environment_btn.png with confidence 0.85.
Wait for image controls/create_env_dialog.png within 5000ms.
Take screenshot: screenshots/03_new_env_dialog.png

### Fill environment name
Check Logic: Click image controls/env_name_field.png with confidence 0.9.
Type text with env_name value.
Press key: tab.
Take screenshot: screenshots/04_name_entered.png

### Select environment type
Check Logic: Click image controls/env_type_dropdown.png with confidence 0.9.
Wait 500ms for dropdown to open.
Click image controls/sandbox_option.png with confidence 0.85.
Take screenshot: screenshots/05_type_selected.png

### Select region
Check Logic: Click image controls/region_dropdown.png with confidence 0.9.
Click image controls/us_east_option.png with confidence 0.85.
Take screenshot: screenshots/06_region_selected.png

## Confirmation

### Click Save and verify provisioning started
Check Logic: Click image controls/save_btn.png with confidence 0.9.
Wait for image controls/provisioning_spinner.png within 3000ms.
Take screenshot: screenshots/07_provisioning_started.png
Assert window title contains: Provisioning.

### Wait for environment to become active
Check Logic: Wait for image controls/active_status.png within 120000ms.
Take screenshot: screenshots/08_environment_active.png
Assert image controls/active_status.png is visible.

### Record environment URL
Check Logic: Click image controls/environment_url_field.png with confidence 0.9.
Press hotkey: ctrl+a, ctrl+c.
Take screenshot: screenshots/09_url_copied.png
