"""
Pipeline runner — executes the EDR QA pipeline and returns a typed EDRQAResult.
"""

import asyncio
import json
import logging
import time
from datetime import datetime
from uuid import uuid4

from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types

from config import settings
from models import (
    EDRQAResult, EDRVerdict, QAAnswer, QuestionResult, CategorySummary,
)
from orchestrator import create_pipeline
from questions import EDR_QUESTION_MAP

logger = logging.getLogger(__name__)


def _parse_answer(raw: str) -> tuple[QAAnswer, str, bool, str]:
    """
    Parse a question agent's raw response.

    Returns: (answer, reasoning, requires_human, human_action)
    """
    reasoning, answer_str, human_action = "", raw.strip(), ""

    if "REASONING:" in raw:
        try:
            r_start = raw.index("REASONING:") + len("REASONING:")
            # reasoning ends at ANSWER:
            a_idx = raw.find("ANSWER:", r_start)
            reasoning = raw[r_start: a_idx if a_idx != -1 else None].strip()
        except ValueError:
            pass

    if "ANSWER:" in raw:
        try:
            a_start = raw.index("ANSWER:") + len("ANSWER:")
            h_idx = raw.find("HUMAN_ACTION:", a_start)
            answer_str = raw[a_start: h_idx if h_idx != -1 else None].strip().split("\n")[0].strip()
        except ValueError:
            pass

    if "HUMAN_ACTION:" in raw:
        try:
            h_start = raw.index("HUMAN_ACTION:") + len("HUMAN_ACTION:")
            human_action = raw[h_start:].strip()
        except ValueError:
            pass

    answer = QAAnswer.from_string(answer_str)
    requires_human = answer == QAAnswer.NEEDS_HUMAN
    return answer, reasoning, requires_human, human_action


def _parse_verdict_json(raw: str) -> dict:
    cleaned = raw.strip()
    if cleaned.startswith("```"):
        parts = cleaned.split("```")
        cleaned = parts[1].lstrip("json").strip() if len(parts) > 1 else cleaned
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError as e:
        logger.warning("Could not parse verdict JSON: %s", e)
        return {}


def _build_result(
    ecn_id: str,
    session_id: str,
    state: dict,
    started_at: datetime,
    duration: float,
) -> EDRQAResult:
    """Convert raw session state into a typed EDRQAResult."""

    # Parse all 15 question answers
    question_results: list[QuestionResult] = []
    for q in EDR_QUESTION_MAP.values():
        raw = state.get(f"answer_q{q.number}", "")
        answer, reasoning, requires_human, human_action = _parse_answer(raw)
        question_results.append(QuestionResult(
            number=q.number,
            category=q.category,
            question=q.question,
            answer=answer,
            reasoning=reasoning,
            raw_response=raw,
            requires_human=requires_human,
            human_action=human_action,
        ))
    question_results.sort(key=lambda r: r.number)

    # Parse verdict JSON
    vdata = _parse_verdict_json(state.get("verdict_json", "{}"))

    # Derive verdict enum
    verdict_str = vdata.get("verdict", "REQUIRES_HUMAN_REVIEW")
    try:
        verdict = EDRVerdict(verdict_str)
    except ValueError:
        verdict = EDRVerdict.REQUIRES_HUMAN_REVIEW

    # Category summaries
    cat_data: dict = vdata.get("category_results", {})
    category_summaries: list[CategorySummary] = []
    for name, data in cat_data.items():
        category_summaries.append(CategorySummary(
            name=name,
            total=len(data.get("questions", [])),
            yes_count=data.get("pass", 0),
            no_count=data.get("fail", 0),
            na_count=data.get("na", 0),
            human_count=data.get("needs_human", 0),
        ))

    failed = vdata.get("failed_questions", [])
    human_items = vdata.get("human_review_required", [])
    human_nums = [h.get("question", 0) for h in human_items]

    return EDRQAResult(
        ecn_id=ecn_id,
        session_id=session_id,
        verdict=verdict,
        overall_pass_rate=float(vdata.get("overall_pass_rate", 0.0)),
        summary=vdata.get("summary", "See individual answers for details."),
        category_summaries=category_summaries,
        question_results=question_results,
        failed_questions=failed,
        human_review_required=human_nums,
        started_at=started_at,
        completed_at=datetime.utcnow(),
        duration_seconds=duration,
        raw_edr_data=state.get("edr_data", {}),
    )


# ── Display helpers ───────────────────────────────────────────────────────────

_AGENT_LABELS = {
    "DataFetcherAgent":     "📥  STEP 0  · Data Fetcher",
    "VerdictSynthesizerAgent": "⚖️   FINAL  · Verdict Synthesizer",
}

def _label(name: str) -> str:
    if name in _AGENT_LABELS:
        return _AGENT_LABELS[name]
    try:
        num = int(name.split("_Q")[1])
        q = EDR_QUESTION_MAP.get(num)
        cat = f"[{q.category}]" if q else ""
        return f"🔍  Q{num:02d}  {cat}"
    except (IndexError, ValueError):
        return f"▶  {name}"


def _print_header(ecn_id: str, started_at: datetime) -> None:
    print(f"\n{'═' * 65}")
    print(f"  EDR QA PIPELINE  |  {ecn_id}  |  {started_at.strftime('%H:%M:%S UTC')}")
    print(f"{'═' * 65}\n")


def _print_result(result: EDRQAResult) -> None:
    icons = {
        EDRVerdict.PASS: "✅",
        EDRVerdict.PASS_WITH_EXCEPTIONS: "⚠️ ",
        EDRVerdict.FAIL: "❌",
        EDRVerdict.REQUIRES_HUMAN_REVIEW: "👤",
    }
    icon = icons.get(result.verdict, "❓")
    print(f"\n{'═' * 65}")
    print(f"  {icon}  {result.verdict.value}")
    print(f"  ECN          : {result.ecn_id}")
    print(f"  Pass Rate    : {result.overall_pass_rate:.1f}%")
    print(f"  Duration     : {result.duration_seconds:.1f}s")
    print(f"{'═' * 65}")
    print(f"\n{result.summary}\n")

    if result.category_summaries:
        print("📊 Category Breakdown:")
        for cs in result.category_summaries:
            bar = f"Y:{cs.yes_count} N:{cs.no_count} N/A:{cs.na_count} 👤:{cs.human_count}"
            print(f"   {cs.name:<42}  {bar}")
        print()

    if result.failed_questions:
        print(f"❌ Failed Questions: {result.failed_questions}")
        print()

    if result.human_review_required:
        print(f"👤 Human Review Required — Questions: {result.human_review_required}")
        for qr in result.question_results:
            if qr.requires_human and qr.human_action:
                print(f"   Q{qr.number}: {qr.human_action}")
        print()


# ── Runner class ──────────────────────────────────────────────────────────────

class EDRPipelineRunner:
    """Runs the EDR QA pipeline for a given ECN ID."""

    def __init__(self) -> None:
        self._session_service = InMemorySessionService()
        self._pipeline = create_pipeline()
        self._runner = Runner(
            agent=self._pipeline,
            app_name=settings.app_name,
            session_service=self._session_service,
        )

    async def run(
        self,
        ecn_id: str,
        user_id: str | None = None,
        verbose: bool = True,
    ) -> EDRQAResult:
        """
        Execute the full EDR QA pipeline for a given ECN.

        Args:
            ecn_id:   ECN identifier (e.g. 'ECN-2024-001').
            user_id:  Optional session tracking identifier.
            verbose:  Print per-agent progress to stdout.

        Raises:
            RuntimeError: If the pipeline fails after all retries.
        """
        user_id = user_id or f"user_{uuid4().hex[:8]}"
        started_at = datetime.utcnow()
        t0 = time.time()

        session = await self._session_service.create_session(
            app_name=settings.app_name,
            user_id=user_id,
            state={"ecn_id": ecn_id},
        )

        if verbose:
            _print_header(ecn_id, started_at)

        message = types.Content(
            role="user",
            parts=[types.Part(text=f"Run EDR QA evaluation for ECN: {ecn_id}")],
        )

        last_exc: Exception | None = None
        for attempt in range(1, settings.max_retries + 1):
            try:
                await self._stream(session.id, user_id, message, ecn_id, verbose)
                break
            except Exception as exc:
                last_exc = exc
                logger.error(
                    "Attempt %d/%d failed: %s", attempt, settings.max_retries, exc,
                    extra={"ecn_id": ecn_id}, exc_info=True,
                )
                if attempt < settings.max_retries:
                    delay = settings.retry_delay * attempt
                    if verbose:
                        print(f"\n⟳  Retry {attempt}/{settings.max_retries} in {delay:.0f}s…\n")
                    await asyncio.sleep(delay)
                else:
                    raise RuntimeError(
                        f"EDR QA pipeline failed after {settings.max_retries} attempts."
                    ) from last_exc

        final = await self._session_service.get_session(
            app_name=settings.app_name,
            user_id=user_id,
            session_id=session.id,
        )

        result = _build_result(
            ecn_id=ecn_id,
            session_id=session.id,
            state=final.state,
            started_at=started_at,
            duration=time.time() - t0,
        )

        logger.info("Pipeline complete: %s", result.one_line(), extra={"ecn_id": ecn_id})

        if verbose:
            _print_result(result)

        return result

    async def _stream(
        self,
        session_id: str,
        user_id: str,
        message: types.Content,
        ecn_id: str,
        verbose: bool,
    ) -> None:
        current: str | None = None

        async for event in self._runner.run_async(
            user_id=user_id,
            session_id=session_id,
            new_message=message,
        ):
            if event.author and event.author != current:
                current = event.author
                if verbose:
                    print(f"\n{'─' * 65}\n  {_label(current)}\n{'─' * 65}")
                logger.info("Agent started: %s", current, extra={"ecn_id": ecn_id, "agent": current})

            if event.get_function_calls():
                for call in event.get_function_calls():
                    if verbose:
                        print(f"  🔧 {call.name}({str(call.args)[:80]})")

            if event.is_final_response() and event.content:
                for part in event.content.parts:
                    if hasattr(part, "text") and part.text:
                        if verbose:
                            text = part.text.strip()
                            print(f"\n{text[:1500]}{'…' if len(text) > 1500 else ''}\n")
                        logger.info("Agent complete: %s", current, extra={"ecn_id": ecn_id, "agent": current})
