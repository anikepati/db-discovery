# AgentForge -- SOP.md to Google ADK Pipeline

Real agentic system: six ADK LlmAgents read your SOP, reason about it,
plan the pipeline, write all code, validate, self-correct, and test.

## How it actually works

AgentForge IS a Google ADK SequentialAgent pipeline.
Each meta-agent communicates through conversation history -- the same pattern
the pipelines it generates use.

```
User message (SOP text)
       |
       v
IntentAgent     (claude-sonnet-4-6)   -- reads SOP, emits INTENT_SPEC JSON
       |                                  no tools, pure reasoning
       v
PlannerAgent    (claude-sonnet-4-6)   -- reads INTENT_SPEC, emits AGENT_PLAN JSON
       |                                  no tools, pure reasoning
       v
GeneratorAgent  (claude-sonnet-4-6)   -- reads AGENT_PLAN, calls write_file tool
       |       <--> ValidatorAgent       calls check_python_syntax, check_yaml_syntax
       |        (LoopAgent, max 3x)      emits VALIDATION_REPORT
       v                                  if failed: GeneratorAgent re-reads fix_request
MockDataAgent   (claude-sonnet-4-6)   -- writes mock_data.json + mock_runner.py + tests
       |                                  calls write_file tool
       v
WriterAgent     (claude-sonnet-4-6)   -- calls run_pytest + run_mock_test tools
                                         emits DELIVERY_MANIFEST
```

The GeneratorAgent calls `write_file` for every pipeline file it generates.
The ValidatorAgent calls `check_python_syntax` and `check_yaml_syntax` to verify them.
If validation fails, the generator sees the `fix_request` in conversation and retries.

## Installation

```bash
pip install google-adk google-genai mcp anthropic
pip install sqlalchemy pyodbc jinja2 python-dotenv pyyaml RestrictedPython
pip install openpyxl  # for Excel SOPs
pip install pytest pytest-asyncio

# For thin_client surface pipelines
pip install playwright && playwright install chromium

# For thick_client surface pipelines  
pip install pyautogui pillow pygetwindow
```

## Set API keys

```bash
export ANTHROPIC_API_KEY=your_anthropic_key
export GOOGLE_API_KEY=your_google_key
```

## Generate a pipeline

### System mode -- SQL/API backend agents

```bash
# EDR QA compliance pipeline (SQL-backed)
python run.py --sop sops/edr_qa.md --name edr_qa --mode system

# Case API validation pipeline (REST API-backed)
python run.py --sop sops/case_api_validation.md --name case_api --mode surface --surface api_system
```

### Surface mode -- UI automation agents

```bash
# Browser automation (Playwright, auto-detected)
python run.py --sop sops/portal_onboarding.md --name portal_auto --mode surface

# Desktop automation (pyautogui, forced)
python run.py --sop sops/power_platform_provisioning.md --name pp_provision --mode surface --surface thick_client

# Force QA/QC check agent surface
python run.py --sop sops/rro_qa.md --name rro_qa --mode surface --surface qa_qc
```

### Dry run (no files written)

```bash
python run.py --sop sops/edr_qa.md --name edr_qa --mode system --dry-run
```

## Run the generated pipeline

```bash
cd output/edr_qa

# 1. Configure
cp .env.example .env
nano .env               # fill GOOGLE_API_KEY, ANTHROPIC_API_KEY, MSSQL_CONN

# 2. Generate empty step YAML files
python tool_generator.py

# 3. Test without a real database
python mock/mock_runner.py

# 4. Run tests
pytest tests/ -v

# 5. Run against real data
python main.py --ecn-id ECN-2024-001
```

## Two modes explained

### --mode system
Generates DB/API backend agents.
- IngestAgent fetches record from SQL or REST API
- N check agents reason from conversation history (no tools by default)
- ReportAgent computes verdict and writes JSON
- Best for: compliance checks, QA review, data validation

### --mode surface
Generates UI automation agents.
Auto-detects surface type from SOP vocabulary:
- `qa_qc` -- Y/N compliance checks (validate, check, Actimize, EDR, RRO)
- `thin_client` -- Playwright browser (click, navigate, fill, selector)
- `thick_client` -- pyautogui desktop (pyautogui, Win32, SAP, .exe, image)
- `api_system` -- REST API calls (endpoint, HTTP, OpenAPI, bearer, OAuth)
- `general` -- mixed workflow (approve, route, notify, escalate)

## SOP format guide

AgentForge accepts four SOP formats:

### Format 1: Header-based (recommended)
```markdown
## Category Name

### Step action description
Validation: What to validate.
Check Logic: If X then Y. If Z then N/A.
Notes: Examples.
Requires Human: Yes
```

### Format 2: Table
```markdown
| Category | Question | Check Logic | Notes | Requires Human |
|---|---|---|---|---|
| Event Creation | Validate ECN | If match: Y | | No |
```

### Format 3: Numbered list
```
1. Navigate to login page and authenticate.
2. Click New Customer and verify form loads.
3. Fill customer details and submit.
```

### Format 4: Excel (.xlsx)
```bash
python run.py --sop process.xlsx --name my_pipeline --mode system
```
Columns recognized: Category, Question/Action, Validation,
Check Logic/Check to be performed, Notes, Requires Human.

## Zero-code-change after generation

| Change | What to do | Files changed |
|---|---|---|
| Update check logic | Edit questions.py -> python tool_generator.py | 0 Python files |
| Add tool to step N | Add to STEP_EXTRA_TOOLS in tool_generator.py | 1 config dict |
| Add new step | Add to questions.py -> python tool_generator.py | 0 Python files |
| Swap model | Change STEP_MODEL in tool_registry.py | 1 constant |
| New environment | Copy .env.example -> .env, fill values | 0 Python files |

## Project structure

```
agentforge2/
  run.py                          -- single entry point
  agentforge_meta/
    agents/
      pipeline.py                 -- 6-agent ADK SequentialAgent meta-pipeline
      instructions.py             -- LLM instructions for all 6 agents
    core/
      runtime.py                  -- YAMLFunctionRuntime (sql/rest_api/playwright/pyautogui/python)
      mcp_factory.py              -- in-memory MCP server factory
    tools/
      meta_tools.yaml             -- tools the meta-agents use (write_file, check_syntax, run_pytest)
  sops/
    edr_qa.md                     -- sample: EDR QA compliance (system mode)
    portal_onboarding.md          -- sample: portal browser automation (surface/thin_client)
    power_platform_provisioning.md -- sample: desktop automation (surface/thick_client)
    case_api_validation.md        -- sample: REST API validation (surface/api_system)
```

## Generated pipeline structure

Every generated pipeline has this structure:

```
output/<name>/
  questions.py          -- source of truth: one dataclass per step
  tool_generator.py     -- regenerates step YAML files
  tool_registry.py      -- ToolConfig per agent, instructions from check_logic
  tools/
    ingest_tools.yaml   -- typed connection + fetch tool
    <n>_step01_tools.yaml .. <n>_stepNN_tools.yaml  -- empty by default
    report_tools.yaml   -- Python build_report tool
  agents/
    agent.py            -- SequentialAgent builder (exact EDR QA v7 pattern)
  audit/
    audit_writer.py     -- per-agent JSON records
  pipeline_runner.py    -- PipelineRunner.run() with retry
  main.py               -- CLI entry point
  config.py             -- Settings from env vars
  models.py             -- Verdict enum, PipelineResult
  mock/
    mock_data.json       -- 4 mock records exercising check logic
    mock_runner.py       -- patches yaml_runtime, no real DB needed
  tests/
    test_pipeline.py     -- pytest suite
  .env.example
  requirements.txt
  README.md
```
