# Q06 Full Reference — Level 2 Review

## Question

Validate the decision rationale aligns with the risk decision type.

## Validation

Assess L2 decision, action, rationale alignment.

## Check Logic (apply exactly)

If l2_decision = 'Accept': l2_action should be blank, l2_rationale aligns to L1. If l2_decision = 'Amend': l2_action should be populated. If l2_multiple_rows = True: check l2_lob value. If all conditions met: Y. Else: N.

## Depends On

Q04, Q05

## Output Hint

State l2_decision, l2_action (blank or populated), l2_rationale alignment to L1. Note l2_lob if multiple rows. Answer Y or N.

## Requires Human Review

No — answer should be Y, N, or N/A only.

## DB Fields

- `l2_decision`
- `l2_action`
- `l2_rationale`
- `l2_lob`
- `l2_multiple_rows`
- `l1_recommended_action`
- `l1_rationale`

## Authorization Grid (relevant for Q2, Q3, Q5, Q8)

See `skills/edr-ingest/references/schema.md` for the full authorization grid
mapping EDR type + brokerage type → authorized recommending groups.
