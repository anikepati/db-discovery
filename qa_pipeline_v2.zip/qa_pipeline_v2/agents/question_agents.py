"""
Question agent factory.

create_question_agent() builds one LlmAgent per QuestionDef.
create_all_question_agents() returns all 10 in order.

Each agent:
  - Reads 'process_data' from session state (injected automatically by ADK)
  - Reads its required prior answers from session state (answer_q1, answer_q2, …)
  - Writes its own answer to session state via output_key = 'answer_q<N>'
"""

import logging

from google.adk.agents import LlmAgent

from config import settings
from agents.questions import QUESTIONS, QuestionDef

logger = logging.getLogger(__name__)

_PROCESS_DATA_KEY = "process_data"


def _prior_answers_section(q: QuestionDef) -> str:
    """Build the 'Prior Answers' section of the instruction, or omit it for Q1."""
    if not q.depends_on:
        return ""

    lines = [
        "",
        "## Prior Answers You Must Use",
        "These answers are already stored in your session context. "
        "Reference them explicitly — do not re-derive what was already established.",
    ]
    for dep in q.depends_on:
        lines.append(f"  - Q{dep} answer  →  session state key: 'answer_q{dep}'")
    return "\n".join(lines)


def _build_instruction(q: QuestionDef) -> str:
    prior_section = _prior_answers_section(q)

    return f"""You are QA Reasoning Agent for Question {q.number}: {q.title}

## Process Data
The full process dataset is in your session context under the key '{_PROCESS_DATA_KEY}'.
Use specific values from that data — do not make up numbers.
{prior_section}

## Your Question
{q.prompt}

## Required Output Format
Structure your response exactly as:

REASONING:
<Step-by-step analysis referencing actual data values.
If you depend on prior answers, reference them explicitly.
Minimum 3–5 sentences.>

ANSWER:
{q.output_hint}

## Rules
- Use actual numbers from the process data (not placeholders like "X%" or "N/A")
- Be decisive — provide a clear verdict or classification
- Do not repeat prior answers verbatim; synthesise them
- If data is missing or ambiguous, state your assumption clearly
"""


def create_question_agent(q: QuestionDef) -> LlmAgent:
    """Create a single question agent for the given QuestionDef."""
    agent = LlmAgent(
        name=f"QuestionAgent_{q.number:02d}",
        model=settings.model,
        instruction=_build_instruction(q),
        tools=[],
        output_key=f"answer_q{q.number}",
        description=f"Q{q.number}: {q.title}. Depends on: {list(q.depends_on) or 'none'}.",
    )
    logger.debug("Created %s", agent.name)
    return agent


def create_all_question_agents() -> list[LlmAgent]:
    """Return all 10 question agents in execution order."""
    agents = [create_question_agent(q) for q in QUESTIONS]
    logger.info("Created %d question agents", len(agents))
    return agents
