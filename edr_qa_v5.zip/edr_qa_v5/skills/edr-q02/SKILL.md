---
name: edr-q02
description: >
  EDR QA Question 2 of 15 (Event Creation): If EDR event type is not Priority FC Business Referral, validate the recommendation rationale aligns with risk action re.
  Reads EDR data from context.state, reasons using Claude claude-sonnet-4-6, writes
  answer to context.state["answers"]["q2"]. Use only in EDR QA pipeline.
license: Proprietary
metadata:
  author: edr-qa-team
  version: "5.0"
  pipeline: edr-qa-v5
  question_number: "2"
  category: "Event Creation"
  requires_human: "false"
compatibility: Requires ADK ToolContext, Anthropic API, context.state with edr_data populated
allowed-tools: get_edr_data get_prior_answers answer_question store_answer
---

# EDR QA — Question 2: Event Creation

**If EDR event type is not Priority FC Business Referral, validate the recommendation rationale aligns with risk action recommendation type.**

## Dependencies

Depends on: Q01

Prior answers for dependent questions MUST be in `context.state["answers"]` before this agent runs.

## Steps

1. Call `get_edr_data()` — reads `context.state["edr_data"]` (populated by IngestAgent)
2. Call `get_prior_answers()` — reads `context.state["answers"]` for dependent Q answers
3. Call `answer_question(question_number=2, edr_data=<step1>, prior_answers=<step2>)`
   - This calls Claude claude-sonnet-4-6 with the check logic and EDR data
   - Returns: `answer`, `reasoning`, `requires_human`, `human_action`
4. Call `store_answer(question_number=2, answer=..., reasoning=..., ...)` 
   - Writes to `context.state["answers"]["q2"]`
5. Respond with exactly:

```
Q02 [Event Creation]: <answer>
REASONING: <1-2 sentence summary>
```

## Check Logic

```
If event_type = 'Priority FC Business Approval': answer N/A. Else assess whether recommended_rationale aligns with recommended_action. If aligned: Y. Else: N.
```

## Validation

Assess Recommended Action vs Rationale alignment.

## Output Format

State event_type, recommended_action, recommended_rationale, and alignment conclusion. Answer Y, N, or N/A.

Valid answers: `Y` | `N` | `N/A` | `NEEDS_HUMAN`

## DB Fields Used

| Column | Notes |
|--------|-------|
| `event_type` |
| `recommended_action` |
| `recommended_rationale` |
| `recommending_group` |

## Gotchas

- Always call `get_edr_data()` first — never use stale data from a prior step.
- Always call `get_prior_answers()` before `answer_question` — dependency answers may affect the result.
- Never skip this question even if a dependency answered N or NEEDS_HUMAN.
- Do NOT write to `context.state` directly — use `store_answer` tool only.
- See [references/question.md](references/question.md) for full question text and validation grid.
