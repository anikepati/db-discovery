"""
Domain models for EDR QA v4.

RunState is the per-run shared in-memory dict passed into every
YAML tool execution. It is the single source of truth for all
state within one pipeline run.
"""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any


# ── Enums ─────────────────────────────────────────────────────────────────────

class QAAnswer(str, Enum):
    YES         = "Y"
    NO          = "N"
    NA          = "N/A"
    NEEDS_HUMAN = "NEEDS_HUMAN"

    @classmethod
    def from_string(cls, raw: str) -> "QAAnswer":
        v = raw.strip().upper()
        return {
            "Y": cls.YES, "YES": cls.YES,
            "N": cls.NO,  "NO":  cls.NO,
            "N/A": cls.NA, "NA": cls.NA,
            "NEEDS_HUMAN": cls.NEEDS_HUMAN,
        }.get(v, cls.NEEDS_HUMAN)


class Verdict(str, Enum):
    PASS                  = "PASS"
    FAIL                  = "FAIL"
    PASS_WITH_EXCEPTIONS  = "PASS_WITH_EXCEPTIONS"
    REQUIRES_HUMAN_REVIEW = "REQUIRES_HUMAN_REVIEW"

    @property
    def passed(self) -> bool:
        return self in (Verdict.PASS, Verdict.PASS_WITH_EXCEPTIONS)

    @classmethod
    def from_string(cls, raw: str) -> "Verdict":
        try:
            return cls(raw.strip().upper().replace(" ", "_"))
        except ValueError:
            return cls.REQUIRES_HUMAN_REVIEW


# ── Shared per-run state ──────────────────────────────────────────────────────

class RunState:
    """
    Thread-safe per-run in-memory state dict.

    Scoped to one ECN run — created by pipeline_runner, injected into
    YAMLFunctionRuntime so every edr_state tool reads/writes the same object.

    Structure:
        run_id    : str
        ecn_id    : str
        edr_data  : dict        ← written by IngestAgent
        answers   : dict        ← written by QAReasoningAgent {"q1": {...}, ...}
        verdict   : dict | None ← written by ReportAgent
        metadata  : dict        ← timing, token counts, agent statuses
    """

    def __init__(self, run_id: str, ecn_id: str) -> None:
        self.run_id  = run_id
        self.ecn_id  = ecn_id
        self._lock   = threading.RLock()
        self._state: dict[str, Any] = {
            "run_id":   run_id,
            "ecn_id":   ecn_id,
            "edr_data": {},
            "answers":  {},
            "verdict":  None,
            "metadata": {
                "started_at": datetime.utcnow().isoformat(),
                "agents":     {},
            },
        }

    # ── Dotted-key access (supports "answers.q3.answer") ─────────────────────

    def get(self, key: str, default: Any = None) -> Any:
        """Read a value by dotted key e.g. 'answers.q3' or 'edr_data'."""
        with self._lock:
            parts = key.split(".")
            node = self._state
            for p in parts:
                if not isinstance(node, dict) or p not in node:
                    return default
                node = node[p]
            return node

    def set(self, key: str, value: Any) -> None:
        """Write a value by dotted key. Creates intermediate dicts as needed."""
        with self._lock:
            parts = key.split(".")
            node = self._state
            for p in parts[:-1]:
                if p not in node or not isinstance(node[p], dict):
                    node[p] = {}
                node = node[p]
            node[parts[-1]] = value

    def merge(self, key: str, value: dict) -> None:
        """Merge a dict into an existing dict value at key."""
        with self._lock:
            existing = self.get(key) or {}
            existing.update(value)
            self.set(key, existing)

    def snapshot(self) -> dict[str, Any]:
        """Return a deep copy of the full state (for audit/serialisation)."""
        import copy
        with self._lock:
            return copy.deepcopy(self._state)

    def to_dict(self) -> dict[str, Any]:
        return self.snapshot()


# ── Result types ──────────────────────────────────────────────────────────────

@dataclass
class QuestionResult:
    number:         int
    category:       str
    question:       str
    depends_on:     list[int]
    answer:         QAAnswer
    reasoning:      str
    requires_human: bool = False
    human_action:   str  = ""


@dataclass
class EDRQAResult:
    run_id:             str
    ecn_id:             str
    verdict:            Verdict
    overall_pass_rate:  float
    question_results:   list[QuestionResult]
    failed_questions:   list[int]
    human_review_items: list[dict[str, Any]]
    output_path:        str
    started_at:         datetime
    completed_at:       datetime
    duration_seconds:   float

    @property
    def passed(self) -> bool:
        return self.verdict.passed

    def one_line(self) -> str:
        return (
            f"[{self.verdict.value}] run:{self.run_id} ecn:{self.ecn_id} | "
            f"pass:{self.overall_pass_rate:.1f}% | "
            f"failed:Q{self.failed_questions} | "
            f"human:{len(self.human_review_items)} | "
            f"{self.duration_seconds:.1f}s"
        )
