"""
Config Loader - YAML-driven configuration management.
Single source of truth for all factory behavior.
"""

from __future__ import annotations
import os
import yaml
from pathlib import Path
from typing import Any, Optional


class MAFConfig:
    """Meta Agent Factory configuration manager."""

    _instance: Optional[MAFConfig] = None
    _config: dict[str, Any] = {}

    def __new__(cls, config_path: Optional[str] = None) -> MAFConfig:
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self, config_path: Optional[str] = None):
        if config_path and not self._config:
            self.load(config_path)

    def load(self, config_path: str) -> None:
        """Load configuration from YAML file with env var interpolation."""
        path = Path(config_path)
        if not path.exists():
            raise FileNotFoundError(f"Config not found: {config_path}")

        with open(path) as f:
            raw = f.read()

        # Environment variable interpolation: ${VAR_NAME} or ${VAR_NAME:default}
        import re
        def _env_replace(match):
            var = match.group(1)
            if ":" in var:
                name, default = var.split(":", 1)
                return os.environ.get(name, default)
            return os.environ.get(var, match.group(0))

        interpolated = re.sub(r'\$\{([^}]+)\}', _env_replace, raw)
        self._config = yaml.safe_load(interpolated)

    @property
    def factory(self) -> dict[str, Any]:
        return self._config.get("factory", {})

    @property
    def models(self) -> dict[str, Any]:
        return self._config.get("models", {})

    @property
    def pipeline(self) -> dict[str, Any]:
        return self._config.get("pipeline", {})

    @property
    def automation_modes(self) -> dict[str, Any]:
        return self._config.get("automation_modes", {})

    @property
    def data_detection(self) -> dict[str, Any]:
        return self._config.get("data_detection", {})

    @property
    def generation(self) -> dict[str, Any]:
        return self._config.get("generation", {})

    @property
    def validation(self) -> dict[str, Any]:
        return self._config.get("validation", {})

    def get_model_config(self, tier: str) -> dict[str, Any]:
        """Get model config by tier (fast_io or reasoning)."""
        return self.models.get(tier, {})

    def get_mode_keywords(self, mode: str) -> list[str]:
        """Get keyword list for a specific automation mode."""
        return self.automation_modes.get(mode, {}).get("keywords", [])

    def get_mode_tools(self, mode: str) -> list[dict]:
        """Get tool definitions for a specific automation mode."""
        return self.automation_modes.get(mode, {}).get("tools", [])

    def get_agent_config(self, agent_name: str) -> dict[str, Any]:
        """Get config for a specific pipeline agent."""
        for agent in self.pipeline.get("agents", []):
            if agent["name"] == agent_name:
                return agent
        return {}

    def get_pii_keywords(self) -> list[str]:
        """Get PII detection keywords."""
        return self.data_detection.get("pii_keywords", [])

    def to_dict(self) -> dict[str, Any]:
        return self._config.copy()

    @classmethod
    def reset(cls):
        """Reset singleton (for testing)."""
        cls._instance = None
        cls._config = {}
