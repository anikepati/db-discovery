"""
SafetyChecker — Pre-flight Safety & Quality Gate

Automatically scans evolved agent instructions for:
- PII exposure risks
- Hallucination-prone patterns
- Compliance gaps
- Prompt injection vulnerabilities
- Tool misuse patterns
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from typing import Any

from core.gepa_adapter import AgentGenome, SystemGenome


# ---------------------------------------------------------------------------
# Issue Data Structures
# ---------------------------------------------------------------------------

@dataclass
class SafetyIssue:
    """A single identified safety/quality issue."""
    severity: str  # "critical", "warning", "info"
    category: str  # "pii", "hallucination", "compliance", "injection", "tool_misuse"
    agent_name: str
    description: str
    recommendation: str
    line_preview: str = ""

    def as_dict(self) -> dict:
        return {
            "severity": self.severity,
            "category": self.category,
            "agent_name": self.agent_name,
            "description": self.description,
            "recommendation": self.recommendation,
            "line_preview": self.line_preview,
        }


@dataclass
class SafetyReport:
    """Complete safety scan report."""
    issues: list[SafetyIssue] = field(default_factory=list)
    passed: bool = True
    scan_summary: dict[str, int] = field(default_factory=dict)

    @property
    def critical_issues(self) -> list[SafetyIssue]:
        return [i for i in self.issues if i.severity == "critical"]

    @property
    def warnings(self) -> list[SafetyIssue]:
        return [i for i in self.issues if i.severity == "warning"]

    @property
    def info_items(self) -> list[SafetyIssue]:
        return [i for i in self.issues if i.severity == "info"]

    def as_dict(self) -> dict:
        return {
            "passed": self.passed,
            "total_issues": len(self.issues),
            "critical": len(self.critical_issues),
            "warnings": len(self.warnings),
            "info": len(self.info_items),
            "scan_summary": self.scan_summary,
            "issues": [i.as_dict() for i in self.issues],
        }


# ---------------------------------------------------------------------------
# Pattern Definitions
# ---------------------------------------------------------------------------

PII_PATTERNS = [
    (r"\b\d{3}-\d{2}-\d{4}\b", "SSN pattern detected"),
    (r"\b\d{16}\b", "Potential credit card number"),
    (r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b", "Email address pattern"),
    (r"\b\d{3}[-.\s]?\d{3}[-.\s]?\d{4}\b", "Phone number pattern"),
    (r"\b(?:password|passwd|secret|api[_-]?key|token)\s*[:=]\s*\S+", "Credential pattern"),
]

HALLUCINATION_PATTERNS = [
    (r"\balways\s+(?:returns?|provides?|gives?)\s+(?:exact|precise|perfect)", "Overly deterministic language"),
    (r"\b(?:never|always|guaranteed|100%|certainly)\b", "Absolute certainty language (potential hallucination risk)"),
    (r"\bI (?:know|am certain|can confirm)\b", "First-person certainty claims"),
    (r"\b(?:as of|current(?:ly)?|latest|today)\s+(?:the|as)", "Temporal claims that may become stale"),
]

COMPLIANCE_GAPS = [
    ("audit", "No audit trail instruction found — add logging/audit requirements"),
    ("retention", "No data retention policy mentioned — specify data handling rules"),
    ("consent", "No user consent handling — add consent verification for data processing"),
    ("escalation", "No escalation path defined — add human-in-the-loop escalation criteria"),
    ("error", "No error handling guidance — add failure mode instructions"),
]

INJECTION_PATTERNS = [
    (r"ignore\s+(?:previous|all|above)\s+instructions?", "Potential prompt injection vulnerability"),
    (r"you\s+are\s+now\s+(?:a|an)\s+", "Role override pattern"),
    (r"(?:system|admin)\s*:\s*", "System prompt injection pattern"),
    (r"```\s*(?:python|bash|sh|cmd)", "Code execution pattern in instructions"),
    (r"\beval\b|\bexec\b|\bos\.system\b", "Dangerous code execution pattern"),
]

TOOL_MISUSE_PATTERNS = [
    (r"(?:call|use|invoke)\s+(?:all|every)\s+tool", "Indiscriminate tool usage instruction"),
    (r"(?:unlimited|infinite|no\s+limit)\s+(?:calls?|requests?|retries?)", "Unbounded resource usage"),
    (r"(?:bypass|skip|ignore)\s+(?:validation|check|verify)", "Safety bypass instruction"),
]


# ---------------------------------------------------------------------------
# Checker Implementation
# ---------------------------------------------------------------------------

class SafetyChecker:
    """
    Pre-flight safety scanner for multi-agent system genomes.

    Checks:
    1. PII exposure in instructions
    2. Hallucination-prone language patterns
    3. Compliance gaps (missing audit, retention, escalation)
    4. Prompt injection vulnerabilities
    5. Tool misuse patterns
    """

    def __init__(
        self,
        pii_threshold: float = 0.8,
        hallucination_threshold: float = 0.7,
        compliance_threshold: float = 0.9,
    ):
        self.pii_threshold = float(os.getenv("SAFETY_PII_THRESHOLD", str(pii_threshold)))
        self.hallucination_threshold = float(os.getenv("SAFETY_HALLUCINATION_THRESHOLD", str(hallucination_threshold)))
        self.compliance_threshold = float(os.getenv("SAFETY_COMPLIANCE_THRESHOLD", str(compliance_threshold)))

    def check_genome(self, genome: SystemGenome) -> SafetyReport:
        """Run all safety checks on a system genome."""
        report = SafetyReport()

        for agent in genome.agents:
            self._check_pii(agent, report)
            self._check_hallucination_risk(agent, report)
            self._check_compliance_gaps(agent, report)
            self._check_injection_risk(agent, report)
            self._check_tool_misuse(agent, report)
            self._check_instruction_quality(agent, report)

        # Cross-agent checks
        self._check_delegation_consistency(genome, report)
        self._check_tool_coverage(genome, report)

        # Compute summary
        report.scan_summary = {
            "agents_scanned": len(genome.agents),
            "pii_issues": sum(1 for i in report.issues if i.category == "pii"),
            "hallucination_risks": sum(1 for i in report.issues if i.category == "hallucination"),
            "compliance_gaps": sum(1 for i in report.issues if i.category == "compliance"),
            "injection_risks": sum(1 for i in report.issues if i.category == "injection"),
            "tool_misuse": sum(1 for i in report.issues if i.category == "tool_misuse"),
            "quality_issues": sum(1 for i in report.issues if i.category == "quality"),
        }

        report.passed = len(report.critical_issues) == 0
        return report

    def _check_pii(self, agent: AgentGenome, report: SafetyReport) -> None:
        """Check for PII patterns in instructions."""
        text = f"{agent.instruction} {agent.description}"
        for pattern, description in PII_PATTERNS:
            matches = re.findall(pattern, text, re.IGNORECASE)
            if matches:
                report.issues.append(SafetyIssue(
                    severity="critical",
                    category="pii",
                    agent_name=agent.agent_name,
                    description=f"PII risk: {description}",
                    recommendation="Remove or mask PII data from agent instructions. Use environment variables or secure vaults for sensitive data.",
                    line_preview=matches[0][:50] if matches else "",
                ))

    def _check_hallucination_risk(self, agent: AgentGenome, report: SafetyReport) -> None:
        """Check for hallucination-prone language patterns."""
        text = agent.instruction
        matches_found = 0
        for pattern, description in HALLUCINATION_PATTERNS:
            matches = re.findall(pattern, text, re.IGNORECASE)
            if matches:
                matches_found += 1
                if matches_found >= 2:  # Only flag if multiple patterns
                    report.issues.append(SafetyIssue(
                        severity="warning",
                        category="hallucination",
                        agent_name=agent.agent_name,
                        description=f"Hallucination risk: {description}",
                        recommendation="Use hedging language (e.g., 'based on available data', 'according to the provided information') instead of absolute claims.",
                        line_preview=matches[0][:50] if matches else "",
                    ))

    def _check_compliance_gaps(self, agent: AgentGenome, report: SafetyReport) -> None:
        """Check for missing compliance elements."""
        text = f"{agent.instruction} {agent.description}".lower()
        for keyword, description in COMPLIANCE_GAPS:
            if keyword not in text and agent.agent_type in ("LlmAgent", "Agent"):
                report.issues.append(SafetyIssue(
                    severity="info",
                    category="compliance",
                    agent_name=agent.agent_name,
                    description=description,
                    recommendation=f"Consider adding '{keyword}' handling to agent instructions.",
                ))

    def _check_injection_risk(self, agent: AgentGenome, report: SafetyReport) -> None:
        """Check for prompt injection vulnerabilities."""
        text = agent.instruction
        for pattern, description in INJECTION_PATTERNS:
            if re.search(pattern, text, re.IGNORECASE):
                report.issues.append(SafetyIssue(
                    severity="critical",
                    category="injection",
                    agent_name=agent.agent_name,
                    description=f"Injection risk: {description}",
                    recommendation="Review and sanitize instruction content. Add input validation and output filtering.",
                ))

    def _check_tool_misuse(self, agent: AgentGenome, report: SafetyReport) -> None:
        """Check for tool misuse patterns."""
        text = agent.instruction
        for pattern, description in TOOL_MISUSE_PATTERNS:
            if re.search(pattern, text, re.IGNORECASE):
                report.issues.append(SafetyIssue(
                    severity="warning",
                    category="tool_misuse",
                    agent_name=agent.agent_name,
                    description=f"Tool misuse risk: {description}",
                    recommendation="Add explicit tool usage limits, validation steps, and error handling.",
                ))

    def _check_instruction_quality(self, agent: AgentGenome, report: SafetyReport) -> None:
        """Check instruction quality and completeness."""
        instruction = agent.instruction.strip()

        if not instruction and agent.agent_type in ("LlmAgent", "Agent"):
            report.issues.append(SafetyIssue(
                severity="warning",
                category="quality",
                agent_name=agent.agent_name,
                description="Agent has empty instruction",
                recommendation="Add clear, detailed instructions defining the agent's role and behavior.",
            ))
        elif len(instruction) < 50 and agent.agent_type in ("LlmAgent", "Agent"):
            report.issues.append(SafetyIssue(
                severity="info",
                category="quality",
                agent_name=agent.agent_name,
                description=f"Agent instruction is very short ({len(instruction)} chars)",
                recommendation="Consider expanding instructions with more specific guidance, examples, and edge case handling.",
            ))

        if len(instruction) > 5000:
            report.issues.append(SafetyIssue(
                severity="info",
                category="quality",
                agent_name=agent.agent_name,
                description=f"Agent instruction is very long ({len(instruction)} chars) — may cause context window issues",
                recommendation="Consider breaking instruction into smaller, focused sub-agent instructions.",
            ))

    def _check_delegation_consistency(self, genome: SystemGenome, report: SafetyReport) -> None:
        """Check that delegation references are consistent."""
        agent_names = {a.agent_name for a in genome.agents}
        for agent in genome.agents:
            for sub_name in agent.sub_agent_names:
                if sub_name not in agent_names:
                    report.issues.append(SafetyIssue(
                        severity="warning",
                        category="quality",
                        agent_name=agent.agent_name,
                        description=f"References sub-agent '{sub_name}' which is not defined in the system",
                        recommendation="Verify sub-agent names match actual agent definitions.",
                    ))

    def _check_tool_coverage(self, genome: SystemGenome, report: SafetyReport) -> None:
        """Check that tools referenced by agents are available."""
        all_tools = set()
        for agent in genome.agents:
            all_tools.update(agent.tool_names)

        if not all_tools and any(a.agent_type in ("LlmAgent", "Agent") for a in genome.agents):
            report.issues.append(SafetyIssue(
                severity="info",
                category="quality",
                agent_name="(system-wide)",
                description="No tools defined for any agent in the system",
                recommendation="Consider adding tools to enhance agent capabilities.",
            ))


def format_safety_report(report: SafetyReport) -> str:
    """Format safety report as readable text."""
    lines = []
    status = "✅ PASSED" if report.passed else "❌ FAILED"
    lines.append(f"Safety Scan Result: {status}")
    lines.append(f"Total Issues: {len(report.issues)}")
    lines.append(f"  Critical: {len(report.critical_issues)}")
    lines.append(f"  Warnings: {len(report.warnings)}")
    lines.append(f"  Info: {len(report.info_items)}")
    lines.append("")

    for issue in report.issues:
        icon = {"critical": "🔴", "warning": "🟡", "info": "🔵"}.get(issue.severity, "⚪")
        lines.append(f"{icon} [{issue.severity.upper()}] {issue.category} — {issue.agent_name}")
        lines.append(f"   {issue.description}")
        lines.append(f"   → {issue.recommendation}")
        if issue.line_preview:
            lines.append(f"   Preview: {issue.line_preview}")
        lines.append("")

    return "\n".join(lines)
