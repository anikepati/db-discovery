---
name: edr-q08
description: >
  EDR QA Question 8 of 15 (Level 2 Review): Validate Level 2 Rationale does not list incorrect group that made recommendation..
  Reads EDR data from context.state, reasons using Claude claude-sonnet-4-6, writes
  answer to context.state["answers"]["q8"]. Use only in EDR QA pipeline.
license: Proprietary
metadata:
  author: edr-qa-team
  version: "5.0"
  pipeline: edr-qa-v5
  question_number: "8"
  category: "Level 2 Review"
  requires_human: "false"
compatibility: Requires ADK ToolContext, Anthropic API, context.state with edr_data populated
allowed-tools: get_edr_data get_prior_answers answer_question store_answer
---

# EDR QA — Question 8: Level 2 Review

**Validate Level 2 Rationale does not list incorrect group that made recommendation.**

## Dependencies

Depends on: Q06, Q07

Prior answers for dependent questions MUST be in `context.state["answers"]` before this agent runs.

## Steps

1. Call `get_edr_data()` — reads `context.state["edr_data"]` (populated by IngestAgent)
2. Call `get_prior_answers()` — reads `context.state["answers"]` for dependent Q answers
3. Call `answer_question(question_number=8, edr_data=<step1>, prior_answers=<step2>)`
   - This calls Claude claude-sonnet-4-6 with the check logic and EDR data
   - Returns: `answer`, `reasoning`, `requires_human`, `human_action`
4. Call `store_answer(question_number=8, answer=..., reasoning=..., ...)` 
   - Writes to `context.state["answers"]["q8"]`
5. Respond with exactly:

```
Q08 [Level 2 Review]: <answer>
REASONING: <1-2 sentence summary>
```

## Check Logic

```
l2_rationale should reference l1_recommended_action or the authorized recommending_group for this event_type/brokerage_type. If correct group referenced: Y. Else: N.
```

## Validation

Confirm L2 rationale references the correct L1 recommending group.

## Output Format

Identify group mentioned in l2_rationale. Confirm it matches authorized group per EDR type/brokerage. Answer Y or N.

Valid answers: `Y` | `N` | `N/A` | `NEEDS_HUMAN`

## DB Fields Used

| Column | Notes |
|--------|-------|
| `l2_rationale` |
| `recommending_group` |
| `event_type` |
| `brokerage_type` |
| `l1_recommended_action` |

## Gotchas

- Always call `get_edr_data()` first — never use stale data from a prior step.
- Always call `get_prior_answers()` before `answer_question` — dependency answers may affect the result.
- Never skip this question even if a dependency answered N or NEEDS_HUMAN.
- Do NOT write to `context.state` directly — use `store_answer` tool only.
- See [references/question.md](references/question.md) for full question text and validation grid.
