"""
Data Point Extractor — Rule-based data point detection from SOP text.

Pre-processes SOPs to identify data points before the LLM-based DataPointAgent
runs, providing a baseline that the agent enriches.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from models.schemas import DataPoint, DataPointType
from utils.config_loader import MAFConfig


@dataclass
class DataPointExtractor:
    """Rule-based data point extraction from SOP markdown."""

    config: MAFConfig = field(default_factory=lambda: MAFConfig())
    _counter: int = 0

    def _next_id(self) -> str:
        self._counter += 1
        return f"dp_{self._counter:03d}"

    def extract(self, sop_text: str, reference_files: dict[str, Any] = None) -> list[DataPoint]:
        """
        Extract data points from SOP text and reference files.

        Args:
            sop_text: Raw SOP markdown
            reference_files: Dict of filename→parsed content

        Returns:
            List of detected DataPoint objects
        """
        self._counter = 0
        data_points: list[DataPoint] = []

        # ── Extract from SOP text ──
        data_points.extend(self._extract_form_fields(sop_text))
        data_points.extend(self._extract_credentials(sop_text))
        data_points.extend(self._extract_api_params(sop_text))
        data_points.extend(self._extract_file_references(sop_text))
        data_points.extend(self._extract_outputs(sop_text))

        # ── Extract from reference files ──
        if reference_files:
            data_points.extend(self._extract_from_references(reference_files))

        # ── Deduplicate ──
        seen_names = set()
        unique_points = []
        for dp in data_points:
            if dp.name not in seen_names:
                seen_names.add(dp.name)
                unique_points.append(dp)

        # ── Flag PII ──
        pii_keywords = self.config.get_pii_keywords()
        for dp in unique_points:
            name_lower = dp.name.lower()
            desc_lower = dp.description.lower()
            for kw in pii_keywords:
                if kw in name_lower or kw in desc_lower:
                    dp.pii_flag = True
                    break

        return unique_points

    def _extract_form_fields(self, text: str) -> list[DataPoint]:
        """Extract data points from form field references."""
        points = []
        
        # Pattern: Enter/Type/Fill "Field Name" | Enter "Field Name" in the field
        patterns = [
            r'[Ee]nter\s+"([^"]+)"',
            r'[Ee]nter\s+(?:the\s+)?(\w[\w\s]+?)\s+in\s+the',
            r'[Tt]ype\s+(?:the\s+)?(\w[\w\s]+?)\s+(?:in|into)',
            r'[Ff]ill\s+(?:in\s+)?(?:the\s+)?"?(\w[\w\s]+?)"?\s+field',
            r'"([^"]+)"\s+field',
            r'"([^"]+)"\s+dropdown',
            r'"([^"]+)"\s+checkbox',
        ]

        for pattern in patterns:
            matches = re.findall(pattern, text)
            for match in matches:
                name = self._normalize_field_name(match)
                if len(name) > 2 and name not in ("the", "and", "for"):
                    points.append(DataPoint(
                        dp_id=self._next_id(),
                        name=name,
                        dp_type=DataPointType.INPUT,
                        data_format=self._infer_format(name, match),
                        description=f"Form field: {match.strip()}",
                        required=True,
                    ))

        # Select/dropdown patterns
        select_matches = re.findall(
            r'[Ss]elect\s+"?([^"]+?)"?\s+from\s+(?:the\s+)?"?([^"]+?)"?\s+dropdown',
            text
        )
        for value, field_name in select_matches:
            name = self._normalize_field_name(field_name)
            points.append(DataPoint(
                dp_id=self._next_id(),
                name=name,
                dp_type=DataPointType.INPUT,
                data_format="enum",
                description=f"Dropdown selection: {field_name}",
                required=True,
                sample_values=[value.strip()],
            ))

        return points

    def _extract_credentials(self, text: str) -> list[DataPoint]:
        """Extract credential data points."""
        points = []
        cred_patterns = [
            (r'username', "username", "Login username"),
            (r'password', "password", "Login password"),
            (r'[Aa][Pp][Ii][\s_-]?[Kk]ey', "api_key", "API authentication key"),
            (r'[Tt]oken', "auth_token", "Authentication token"),
            (r'[Ss]ecret', "client_secret", "Client secret"),
        ]

        for pattern, name, desc in cred_patterns:
            if re.search(pattern, text):
                points.append(DataPoint(
                    dp_id=self._next_id(),
                    name=name,
                    dp_type=DataPointType.CREDENTIAL,
                    data_format="string",
                    description=desc,
                    required=True,
                    pii_flag=True,
                    source="environment_variable",
                ))

        return points

    def _extract_api_params(self, text: str) -> list[DataPoint]:
        """Extract data points from API endpoint references."""
        points = []

        # URL query parameters
        params = re.findall(r'[?&](\w+)=\{?(\w+)\}?', text)
        for param_name, param_value in params:
            points.append(DataPoint(
                dp_id=self._next_id(),
                name=self._normalize_field_name(param_name),
                dp_type=DataPointType.INPUT,
                data_format="string",
                description=f"API query parameter: {param_name}",
                required=True,
            ))

        # Environment variable references
        env_vars = re.findall(r'\$\{(\w+)\}', text)
        for var in env_vars:
            points.append(DataPoint(
                dp_id=self._next_id(),
                name=var.lower(),
                dp_type=DataPointType.CREDENTIAL if "key" in var.lower() or "password" in var.lower() or "secret" in var.lower() else DataPointType.INPUT,
                data_format="string",
                description=f"Environment variable: {var}",
                required=True,
                source="environment_variable",
            ))

        return points

    def _extract_file_references(self, text: str) -> list[DataPoint]:
        """Extract data points from file path references."""
        points = []

        file_refs = re.findall(r'`([^`]+\.\w{2,4})`', text)
        for file_ref in file_refs:
            if any(ext in file_ref for ext in [".json", ".csv", ".xml", ".yaml", ".txt"]):
                points.append(DataPoint(
                    dp_id=self._next_id(),
                    name=self._normalize_field_name(file_ref.split("/")[-1].split(".")[0]),
                    dp_type=DataPointType.REFERENCE,
                    data_format="file_path",
                    description=f"File reference: {file_ref}",
                    required=True,
                    source=file_ref,
                ))

        return points

    def _extract_outputs(self, text: str) -> list[DataPoint]:
        """Extract output data points."""
        points = []

        output_patterns = [
            r'[Oo]utput[s]?.*?:\s*\n((?:\s*-\s*.+\n)+)',
            r'[Ee]xpected.*?:\s*"?(.+?)"?\s*(?:message|with)',
            r'[Gg]enerates?\s+(?:a\s+)?(\w[\w\s]+?)(?:\.|$)',
        ]

        for pattern in output_patterns:
            matches = re.findall(pattern, text)
            for match in matches:
                if "-" in match:  # Bullet list
                    items = re.findall(r'-\s+(.+)', match)
                    for item in items:
                        name = self._normalize_field_name(item.strip())
                        if len(name) > 2:
                            points.append(DataPoint(
                                dp_id=self._next_id(),
                                name=name,
                                dp_type=DataPointType.OUTPUT,
                                data_format="string",
                                description=f"Pipeline output: {item.strip()}",
                                required=False,
                            ))

        return points

    def _extract_from_references(self, ref_files: dict[str, Any]) -> list[DataPoint]:
        """Extract data points from JSON reference file structures."""
        points = []

        for filename, content in ref_files.items():
            if isinstance(content, dict):
                # Look for mapping arrays
                for key, value in content.items():
                    if isinstance(value, list) and value:
                        first_item = value[0]
                        if isinstance(first_item, dict):
                            # Extract source/target field mappings
                            source = first_item.get("source_field")
                            target = first_item.get("target_field")
                            if source and target:
                                for item in value:
                                    s = item.get("source_field", "")
                                    t = item.get("target_field", "")
                                    points.append(DataPoint(
                                        dp_id=self._next_id(),
                                        name=self._normalize_field_name(t),
                                        dp_type=DataPointType.REFERENCE,
                                        data_format=item.get("data_type", "string"),
                                        description=f"Mapped from {s} → {t} (ref: {filename})",
                                        required=item.get("required", False),
                                        source=filename,
                                    ))

        return points

    @staticmethod
    def _normalize_field_name(raw: str) -> str:
        """Normalize a field name to snake_case."""
        cleaned = re.sub(r'[^\w\s]', '', raw.strip())
        cleaned = re.sub(r'\s+', '_', cleaned)
        return cleaned.lower()[:50]

    @staticmethod
    def _infer_format(name: str, raw: str) -> str:
        """Infer data format from field name and context."""
        name_lower = name.lower()
        raw_lower = raw.lower()
        
        if "email" in name_lower:
            return "email"
        if "phone" in name_lower or "ph_" in name_lower:
            return "phone"
        if "date" in name_lower or "dt" in name_lower:
            return "date"
        if "zip" in name_lower or "postal" in name_lower:
            return "zip_code"
        if "amount" in name_lower or "limit" in name_lower or "price" in name_lower:
            return "decimal"
        if "count" in name_lower or "number" in name_lower or "qty" in name_lower:
            return "integer"
        if "url" in name_lower or "http" in raw_lower:
            return "url"
        if any(fmt in raw_lower for fmt in ["mm/dd", "yyyy", "iso 8601"]):
            return "date"
        if any(fmt in raw_lower for fmt in ["format:", "pattern:", "regex:"]):
            return "formatted_string"

        return "string"
