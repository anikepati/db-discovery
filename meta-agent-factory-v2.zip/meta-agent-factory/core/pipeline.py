"""
Meta Agent Factory — Core Pipeline Orchestrator

Assembles the 8-agent SequentialAgent pipeline with LoopAgent retry wrapper.
Config-first: all behavior driven by maf_config.yaml.
"""

from __future__ import annotations

import json
import logging
import os
from pathlib import Path
from typing import Any, Optional

from google.adk.agents import SequentialAgent, LoopAgent, LlmAgent
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService

from agents import (
    build_ingest_agent,
    build_analyzer_agent,
    build_datapoint_agent,
    build_planner_agent,
    build_generator_agent,
    build_mockdata_agent,
    build_validator_agent,
    build_writer_agent,
)
from utils.config_loader import MAFConfig

logger = logging.getLogger("MetaAgentFactory")


class MetaAgentFactory:
    """
    Enterprise Meta-Agent Factory.
    
    Ingests SOP Markdown + JSON references → analyzes automation mode →
    extracts data points → generates complete ADK agent pipelines with sample data.
    
    Architecture:
        SequentialAgent (root)
        ├── IngestAgent (gemini-flash)
        ├── AnalyzerAgent (claude-sonnet)
        ├── DataPointAgent (claude-sonnet)
        ├── PlannerAgent (claude-sonnet)
        ├── LoopAgent (retry wrapper)
        │   ├── GeneratorAgent (claude-sonnet)
        │   └── ValidatorAgent (claude-sonnet)
        ├── MockDataAgent (gemini-flash)
        └── WriterAgent (gemini-flash)
    """

    def __init__(self, config_path: str = "configs/maf_config.yaml"):
        self.config = MAFConfig(config_path)
        self._setup_logging()
        self.root_agent = self._build_pipeline()
        logger.info("MetaAgentFactory initialized with config: %s", config_path)

    def _setup_logging(self):
        log_level = self.config.factory.get("log_level", "INFO")
        logging.basicConfig(
            level=getattr(logging, log_level),
            format="[MAF %(levelname)s] %(name)s | %(message)s",
        )

    def _get_model(self, tier: str) -> str:
        """Resolve model ID from config tier."""
        model_config = self.config.get_model_config(tier)
        return model_config.get("model_id", "gemini-2.0-flash")

    def _build_pipeline(self) -> SequentialAgent:
        """Build the complete 8-agent pipeline with retry loop."""
        fast_model = self._get_model("fast_io")
        reasoning_model = self._get_model("reasoning")

        # ── Stage 1: Ingestion ──
        ingest_agent = build_ingest_agent(model=fast_model)

        # ── Stage 2: Analysis ──
        analyzer_agent = build_analyzer_agent(model=reasoning_model)

        # ── Stage 3: Data Extraction ──
        datapoint_agent = build_datapoint_agent(model=reasoning_model)

        # ── Stage 4: Planning ──
        planner_agent = build_planner_agent(model=reasoning_model)

        # ── Stage 5+6: Generation + Validation (with retry loop) ──
        generator_agent = build_generator_agent(model=reasoning_model)
        validator_agent = build_validator_agent(model=reasoning_model)

        retry_config = self.config.pipeline.get("retry", {})
        max_retries = retry_config.get("max_attempts", 3)

        gen_validate_loop = LoopAgent(
            name="GenerateValidateLoop",
            description="Retry loop: generate code → validate → retry if validation fails",
            sub_agents=[generator_agent, validator_agent],
            max_iterations=max_retries,
        )

        # ── Stage 7: Mock Data ──
        mockdata_agent = build_mockdata_agent(model=fast_model)

        # ── Stage 8: Writer ──
        writer_agent = build_writer_agent(model=fast_model)

        # ── Assemble Root Pipeline ──
        root = SequentialAgent(
            name="MetaAgentFactoryPipeline",
            description=(
                "Enterprise meta-agent pipeline: SOP → Analysis → Data Points → "
                "Plan → Generate+Validate → Sample Data → Write Output"
            ),
            sub_agents=[
                ingest_agent,
                analyzer_agent,
                datapoint_agent,
                planner_agent,
                gen_validate_loop,
                mockdata_agent,
                writer_agent,
            ],
        )

        logger.info(
            "Pipeline built: %d stages, retry_max=%d, fast_model=%s, reasoning_model=%s",
            7, max_retries, fast_model, reasoning_model,
        )
        return root

    async def run(
        self,
        sop_path: str,
        ref_paths: Optional[list[str]] = None,
        output_dir: str = "./generated",
    ) -> dict[str, Any]:
        """
        Execute the factory pipeline.

        Args:
            sop_path: Path to SOP markdown file
            ref_paths: Optional list of JSON reference file paths
            output_dir: Directory for generated output
            
        Returns:
            Output manifest with all generated files and metadata
        """
        # ── Load Inputs ──
        sop_markdown = Path(sop_path).read_text(encoding="utf-8")
        
        reference_files = {}
        if ref_paths:
            for ref_path in ref_paths:
                p = Path(ref_path)
                if p.suffix == ".json":
                    reference_files[p.name] = json.loads(p.read_text(encoding="utf-8"))
                else:
                    reference_files[p.name] = p.read_text(encoding="utf-8")

        logger.info("Loaded SOP: %s (%d chars)", sop_path, len(sop_markdown))
        logger.info("Loaded %d reference files", len(reference_files))

        # ── Setup Runner ──
        session_service = InMemorySessionService()
        runner = Runner(
            agent=self.root_agent,
            app_name="meta_agent_factory",
            session_service=session_service,
        )

        session = await session_service.create_session(
            app_name="meta_agent_factory",
            user_id="maf_operator",
            state={
                "raw_sop_markdown": sop_markdown,
                "reference_files": reference_files,
                "output_dir": output_dir,
                "config": self.config.to_dict(),
            },
        )

        logger.info("Session created: %s", session.id)

        # ── Execute Pipeline ──
        from google.adk.models import Content, Part

        user_message = Content(
            role="user",
            parts=[Part(text=(
                f"Process this SOP and generate a complete ADK agent pipeline.\n\n"
                f"SOP Content:\n{sop_markdown}\n\n"
                f"Reference Files:\n{json.dumps(reference_files, indent=2)}\n\n"
                f"Output Directory: {output_dir}"
            ))],
        )

        results = []
        async for event in runner.run_async(
            session_id=session.id,
            user_id="maf_operator",
            new_message=user_message,
        ):
            if hasattr(event, "content") and event.content:
                text = event.content.parts[0].text if event.content.parts else ""
                author = getattr(event, "author", "unknown")
                logger.info("[%s] Output: %s...", author, text[:150])
                results.append({"author": author, "output": text})

        # ── Extract Output ──
        final_state = session.state
        output_manifest = final_state.get("output_manifest", {})

        # ── Write Files to Disk ──
        if output_manifest and isinstance(output_manifest, dict):
            await self._write_output(output_manifest, output_dir)

        logger.info("Pipeline complete. Output: %s", output_dir)
        return {
            "manifest": output_manifest,
            "pipeline_results": results,
            "session_state_keys": list(final_state.keys()),
        }

    async def _write_output(self, manifest: dict, output_dir: str) -> None:
        """Write generated files to the output directory."""
        out_path = Path(output_dir)
        out_path.mkdir(parents=True, exist_ok=True)

        files = manifest.get("files", [])
        if isinstance(files, list):
            for file_entry in files:
                file_path = out_path / file_entry.get("path", "unknown.txt")
                file_path.parent.mkdir(parents=True, exist_ok=True)
                file_path.write_text(
                    file_entry.get("content", ""),
                    encoding="utf-8",
                )
                logger.info("Written: %s", file_path)
        elif isinstance(files, dict):
            for filename, content in files.items():
                file_path = out_path / filename
                file_path.parent.mkdir(parents=True, exist_ok=True)
                file_path.write_text(content, encoding="utf-8")
                logger.info("Written: %s", file_path)

    def get_pipeline_info(self) -> dict[str, Any]:
        """Return pipeline metadata for inspection."""
        return {
            "factory_name": self.config.factory.get("name"),
            "version": self.config.factory.get("version"),
            "pipeline_type": "SequentialAgent",
            "total_agents": 8,
            "stages": [
                "IngestAgent → ParsedSOP",
                "AnalyzerAgent → ModeClassification + StepAnalysis",
                "DataPointAgent → DataSchema",
                "PlannerAgent → PipelineSpec",
                "GenerateValidateLoop → GeneratedCode (with retry)",
                "MockDataAgent → SampleData",
                "WriterAgent → OutputManifest",
            ],
            "models": {
                "fast_io": self._get_model("fast_io"),
                "reasoning": self._get_model("reasoning"),
            },
            "automation_modes": ["BROWSER", "THICK_CLIENT", "SYSTEM", "HYBRID"],
            "config": self.config.to_dict(),
        }
