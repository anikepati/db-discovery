"""
Application configuration loaded from environment variables.
Copy .env.example to .env and fill in your values before running.
"""

import os
from dataclasses import dataclass, field
from typing import Optional

from dotenv import load_dotenv

load_dotenv()


@dataclass(frozen=True)
class Settings:
    # Required
    google_api_key: str = field(default_factory=lambda: os.getenv("GOOGLE_API_KEY", ""))

    # Agent
    model: str = field(default_factory=lambda: os.getenv("AGENT_MODEL", "gemini-2.0-flash"))
    max_retries: int = field(default_factory=lambda: int(os.getenv("AGENT_MAX_RETRIES", "3")))
    retry_delay: float = field(default_factory=lambda: float(os.getenv("AGENT_RETRY_DELAY", "2.0")))

    # App
    app_name: str = field(default_factory=lambda: os.getenv("APP_NAME", "qa_pipeline"))
    environment: str = field(default_factory=lambda: os.getenv("ENVIRONMENT", "development"))
    log_level: str = field(default_factory=lambda: os.getenv("LOG_LEVEL", "INFO"))
    log_dir: str = field(default_factory=lambda: os.getenv("LOG_DIR", "logs"))

    def validate(self) -> None:
        if not self.google_api_key:
            raise ValueError(
                "GOOGLE_API_KEY is not set. Add it to your .env file."
            )

    @property
    def is_production(self) -> bool:
        return self.environment.lower() == "production"


settings = Settings()
