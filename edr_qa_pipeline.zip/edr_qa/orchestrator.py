"""
Pipeline orchestrator — assembles all agents into a SequentialAgent.

Execution order:
  DataFetcherAgent → QA_Q01 … QA_Q15 → VerdictSynthesizerAgent
"""

import logging

from google.adk.agents import SequentialAgent

from data_fetcher import create_data_fetcher_agent
from question_agents import create_all_question_agents
from verdict_synthesizer import create_verdict_synthesizer_agent

logger = logging.getLogger(__name__)


def create_pipeline() -> SequentialAgent:
    sub_agents = [
        create_data_fetcher_agent(),
        *create_all_question_agents(),
        create_verdict_synthesizer_agent(),
    ]

    pipeline = SequentialAgent(
        name="EDRQAPipeline",
        sub_agents=sub_agents,
        description=(
            "End-to-end EDR QA pipeline: fetches Actimize data, answers all 15 QA "
            "questions in sequence, and produces a structured QA verdict."
        ),
    )

    logger.info(
        "EDR QA Pipeline assembled — %d agents: %s",
        len(sub_agents), [a.name for a in sub_agents],
    )
    return pipeline
