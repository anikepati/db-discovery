# QA Pipeline — Agentic QA Process Evaluator

A production-grade agentic QA pipeline built with **Google Agent Development Kit (ADK)**.  
Evaluates business processes through a **10-question sequential reasoning chain** where each answer builds on prior ones.

---

## Architecture

```
QAPipelineOrchestrator (SequentialAgent)
│
├── [Step 0]  DataFetcherAgent
│             └── Fetches QA data by Process ID → stores in session state
│
├── [Step 1]  QuestionAgent_01: Process Status & Eligibility
│             └── Reads: qa_raw_data → writes: answer_q1
│
├── [Step 2]  QuestionAgent_02: Compliance Framework & Obligations
│             └── Reads: answer_q1 → writes: answer_q2
│
├── [Step 3]  QuestionAgent_03: Compliance Score Evaluation
│             └── Reads: answer_q1, answer_q2 → writes: answer_q3
│
├── [Step 4]  QuestionAgent_04: Risk Assessment & Severity
│             └── Reads: answer_q1, answer_q3 → writes: answer_q4
│
├── [Step 5]  QuestionAgent_05: Security Controls Assessment
│             └── Reads: answer_q4 → writes: answer_q5
│
├── [Step 6]  QuestionAgent_06: Performance & SLA Compliance
│             └── Reads: answer_q1, answer_q4 → writes: answer_q6
│
├── [Step 7]  QuestionAgent_07: Audit Trail & Policy Violations
│             └── Reads: answer_q3, answer_q5 → writes: answer_q7
│
├── [Step 8]  QuestionAgent_08: Aggregated Risk & Violation Summary
│             └── Reads: answer_q3..q7 → writes: answer_q8
│
├── [Step 9]  QuestionAgent_09: Remediation Plan & Timeline
│             └── Reads: answer_q8 → writes: answer_q9
│
├── [Step 10] QuestionAgent_10: Final QA Verdict
│             └── Reads: answer_q1..q9 → writes: answer_q10
│
└── [Final]   VerdictSynthesizerAgent
              └── Reads: ALL answers → writes: final_verdict_json
```

### Key ADK Patterns Used

| Pattern | Purpose |
|---------|---------|
| `SequentialAgent` | Guarantees Q1 → Q2 → ... → Q10 execution order |
| `output_key` | Each LlmAgent auto-saves its response to session state |
| `session.state` | Shared memory — the "reasoning scratchpad" across all agents |
| Pre-seeded state | `process_id` injected before pipeline starts |
| Instruction prompting | Each agent explicitly references prior state keys in its prompt |

---

## Project Structure

```
qa_pipeline/
├── main.py                      # CLI entry point
├── pipeline_runner.py           # Core execution engine
├── models.py                    # Domain models (dataclasses)
├── requirements.txt
├── pytest.ini
├── .env.example                 # Environment template
│
├── config/
│   ├── __init__.py
│   ├── settings.py              # App/DB/Agent configuration
│   └── logging_config.py       # Structured JSON logging
│
├── agents/
│   ├── __init__.py
│   ├── questions.py             # All 10 question definitions + dependencies
│   ├── data_fetcher.py          # Step 0: Data fetch agent
│   ├── question_agents.py       # Steps 1-10: Question reasoning agents
│   ├── verdict_synthesizer.py   # Final: JSON verdict agent
│   └── orchestrator.py          # SequentialAgent assembly
│
├── tools/
│   ├── __init__.py
│   ├── fetch_tools.py           # Data fetching tools (replace with real DB/API)
│   └── state_tools.py           # State management utilities
│
├── tests/
│   ├── __init__.py
│   └── test_pipeline.py         # Full test suite (unit + integration)
│
└── logs/                        # Auto-created at runtime
```

---

## Quick Start

### 1. Prerequisites

- Python 3.11+
- Google API Key with Gemini access

### 2. Install Dependencies

```bash
cd qa_pipeline
python -m venv .venv
source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

### 3. Configure Environment

```bash
cp .env.example .env
# Edit .env and set GOOGLE_API_KEY=your_key_here
```

### 4. Run the Pipeline

```bash
# Run with verbose output (default)
python main.py --process-id PROC-2024-001

# Run quietly and save results to JSON
python main.py --process-id PROC-2024-002 --quiet --output results/output.json

# Show all options
python main.py --help
```

### Demo Process IDs

| Process ID | Name | Expected Verdict |
|-----------|------|-----------------|
| `PROC-2024-001` | Customer Onboarding Workflow | CONDITIONAL PASS |
| `PROC-2024-002` | Loan Approval Pipeline | FAIL / ESCALATION |

---

## Running Tests

```bash
# Run all tests
pytest tests/ -v

# With coverage report
pytest tests/ -v --cov=. --cov-report=term-missing

# Run specific test class
pytest tests/ -v -k "TestFetchTools"
```

---

## Output Format

The pipeline produces:
1. **Real-time console output** — per-agent progress and answers
2. **JSON result file** (optional) — structured output for downstream systems

### JSON Output Schema

```json
{
  "pipeline_run": {
    "process_id": "PROC-2024-001",
    "session_id": "...",
    "started_at": "2024-12-01T10:00:00",
    "duration_seconds": 45.2
  },
  "verdict": {
    "verdict": "CONDITIONAL_PASS",
    "overall_score": 72.5,
    "passed": true,
    "executive_summary": "...",
    "critical_issues": [],
    "recommendations": ["[P1] Fix MFA..."],
    "next_steps": ["Schedule follow-up review in 30 days"]
  },
  "answers": [
    {
      "question_number": 1,
      "question_text": "...",
      "depends_on": [],
      "reasoning": "...",
      "answer": "ELIGIBLE — process is active in production..."
    }
    // ... Q2 through Q10
  ]
}
```

---

## Customization

### Adding / Modifying Questions

Edit `agents/questions.py`:

```python
QuestionDefinition(
    number=3,
    title="My Custom Check",
    question="Based on Q1 and Q2, evaluate...",
    depends_on=[1, 2],                  # Which prior answers are needed
    evaluation_criteria="Check for...", # What the agent should evaluate
    expected_output_format="PASS/FAIL with reason",
)
```

### Connecting a Real Data Source

Replace the mock in `tools/fetch_tools.py`:

```python
async def fetch_qa_process_data(process_id: str) -> str:
    # Replace with your actual implementation:
    
    # Option A: Database
    async with db.connect() as conn:
        row = await conn.fetchone(
            "SELECT * FROM qa_processes WHERE id = $1", process_id
        )
    
    # Option B: REST API
    async with httpx.AsyncClient() as client:
        response = await client.get(f"https://your-api.com/processes/{process_id}")
        data = response.json()
    
    # Option C: Power Platform / SharePoint
    # ... your enterprise data source here
    
    return json.dumps({"status": "success", **data})
```

### Using Persistent Sessions

Swap `InMemorySessionService` with a database-backed session service:

```python
# In pipeline_runner.py
from google.adk.sessions import DatabaseSessionService

self.session_service = DatabaseSessionService(
    connection_string=db_config.connection_string
)
```

---

## Exit Codes

| Code | Meaning |
|------|---------|
| `0` | Pipeline completed — verdict is PASS or CONDITIONAL PASS |
| `1` | Pipeline error (config issue, API error, etc.) |
| `2` | Pipeline completed — verdict is FAIL or REQUIRES ESCALATION |
| `130` | Interrupted (Ctrl+C) |

---

## Production Deployment Notes

- Set `ENVIRONMENT=production` for JSON-only log output
- Use `LOG_LEVEL=WARNING` in production to reduce noise
- Replace `InMemorySessionService` with a persistent session store for multi-instance deployments
- Add rate limiting and circuit breakers around `fetch_qa_process_data` for production data sources
- Consider `AGENT_MODEL=gemini-1.5-pro` for more complex processes requiring deeper reasoning
