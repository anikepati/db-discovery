"""
Data fetching tool for the QA pipeline.

fetch_process_data() is the single tool given to DataFetcherAgent.
It returns a JSON string that gets stored in session state and read by all
downstream question agents via their output_key / session state.

To connect a real data source, replace the body of _load_from_source().
The return schema (the dict passed to json.dumps) must remain stable.
"""

import json
import logging
from typing import Any

from google.adk.tools import FunctionTool

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Mock data store — replace _load_from_source() with your DB / API call
# ---------------------------------------------------------------------------

_MOCK_DB: dict[str, dict[str, Any]] = {
    "PROC-2024-001": {
        "process_name": "Customer Onboarding Workflow",
        "business_unit": "Retail Banking",
        "owner": "Jane Smith",
        "status": "active",
        "version": "3.2.1",
        "environment": "production",
        "tags": ["customer-facing", "regulated", "kyc"],
        # Compliance
        "compliance_framework": "SOX",
        "compliance_score": 72.5,
        "open_findings": 4,
        "critical_findings": 1,
        "certifications": ["ISO27001", "PCI-DSS"],
        "compliance_exceptions": ["Manual override allowed for VIP customers"],
        # Risk
        "inherent_risk": "high",
        "residual_risk": "medium",
        "risk_score": 6.8,
        "risk_categories": ["Operational", "Compliance", "Reputational"],
        "mitigating_controls": [
            "Four-eyes approval for high-value accounts",
            "Daily reconciliation reports",
            "Automated KYC checks",
        ],
        # Performance
        "avg_completion_time_min": 45.2,
        "sla_threshold_min": 60.0,
        "sla_breaches_30d": 12,
        "error_rate_pct": 2.3,
        "throughput_per_day": 450,
        "availability_pct": 99.1,
        # Security
        "encryption_at_rest": True,
        "encryption_in_transit": True,
        "mfa_enabled": True,
        "pen_test_days_ago": 45,
        "open_vulnerabilities": 3,
        "critical_vulnerabilities": 0,
        "data_classification": "confidential",
        "privileged_user_count": 5,
        # Audit
        "changes_30d": 23,
        "unauthorized_access_attempts": 2,
        "policy_violations_90d": 1,
        "last_reviewed_by": "QA Team Alpha",
        "last_review_outcome": "Conditional Pass",
        "recent_findings": [
            {"date": "2024-10-15", "severity": "medium",
             "description": "Missing escalation path for failed KYC checks"},
            {"date": "2024-11-02", "severity": "low",
             "description": "12 SLA breaches in October due to system slowdown"},
        ],
    },
    "PROC-2024-002": {
        "process_name": "Loan Approval Pipeline",
        "business_unit": "Consumer Lending",
        "owner": "Bob Johnson",
        "status": "pending_review",
        "version": "1.0.0",
        "environment": "staging",
        "tags": ["financial", "regulated", "high-risk"],
        # Compliance
        "compliance_framework": "GDPR",
        "compliance_score": 48.0,
        "open_findings": 8,
        "critical_findings": 3,
        "certifications": [],
        "compliance_exceptions": [],
        # Risk
        "inherent_risk": "critical",
        "residual_risk": "high",
        "risk_score": 8.9,
        "risk_categories": ["Credit", "Compliance", "Operational", "Legal"],
        "mitigating_controls": ["Manual approval required above $50k"],
        # Performance
        "avg_completion_time_min": 120.0,
        "sla_threshold_min": 90.0,
        "sla_breaches_30d": 35,
        "error_rate_pct": 8.7,
        "throughput_per_day": 80,
        "availability_pct": 96.5,
        # Security
        "encryption_at_rest": False,
        "encryption_in_transit": True,
        "mfa_enabled": False,
        "pen_test_days_ago": 200,
        "open_vulnerabilities": 12,
        "critical_vulnerabilities": 2,
        "data_classification": "restricted",
        "privileged_user_count": 15,
        # Audit
        "changes_30d": 67,
        "unauthorized_access_attempts": 11,
        "policy_violations_90d": 9,
        "last_reviewed_by": "External Audit Firm",
        "last_review_outcome": "Fail",
        "recent_findings": [
            {"date": "2024-11-20", "severity": "critical",
             "description": "PII data not encrypted at rest"},
            {"date": "2024-11-18", "severity": "critical",
             "description": "No MFA enforced for privileged users"},
            {"date": "2024-11-10", "severity": "high",
             "description": "GDPR consent records incomplete for 34% of records"},
        ],
    },
}


def _load_from_source(process_id: str) -> dict[str, Any] | None:
    """
    Load raw process data from your data source.

    Replace this function body with your real implementation:
      - SQL database:  return await db.fetchone("SELECT ...", process_id)
      - REST API:      return httpx.get(f"/api/processes/{process_id}").json()
      - SharePoint:    return sp_client.get_list_item(process_id)
      - Power Platform: return dataverse_client.retrieve(process_id)
    """
    return _MOCK_DB.get(process_id)


# ---------------------------------------------------------------------------
# Tool function — this is what the DataFetcherAgent calls
# ---------------------------------------------------------------------------

def fetch_process_data(process_id: str) -> str:
    """
    Fetch all QA evaluation data for a given Process ID.

    Returns a JSON string with a 'status' field ('ok' or 'error').
    On success, all process fields are included at the top level.
    On error, an 'error' field describes the problem.

    Args:
        process_id: Unique identifier for the business process (e.g. 'PROC-2024-001').
    """
    logger.info("Fetching process data", extra={"process_id": process_id})

    data = _load_from_source(process_id)

    if data is None:
        available = list(_MOCK_DB.keys())
        logger.warning("Process not found", extra={"process_id": process_id})
        return json.dumps({
            "status": "error",
            "error": f"Process '{process_id}' not found.",
            "available_ids": available,
        })

    result = {"status": "ok", "process_id": process_id, **data}
    logger.info("Process data fetched successfully", extra={"process_id": process_id})
    return json.dumps(result, indent=2, default=str)


fetch_process_data_tool = FunctionTool(func=fetch_process_data)
