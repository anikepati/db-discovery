"""runtime/mcp_factory.py"""
import asyncio, json, yaml
from mcp.server import Server
from mcp import types as mcp_types
from runtime.yaml_runtime import YAMLFunctionRuntime, MCP_TOOL_TYPES


def _build_schema(fn_def):
    type_map = {"string":"string","integer":"integer","number":"number",
                "boolean":"boolean","array":"array","object":"object"}
    props, req = {}, []
    for name, schema in fn_def.get("inputs", {}).items():
        prop = {"type": type_map.get(schema.get("type","string"),"string")}
        if "default"     in schema: prop["default"]     = schema["default"]
        if "description" in schema: prop["description"] = schema["description"]
        props[name] = prop
        if schema.get("required", False): req.append(name)
    return {"type":"object","properties":props,"required":req}


def create_mcp_server(yaml_path: str) -> Server:
    runtime = YAMLFunctionRuntime(yaml_path)
    with open(yaml_path) as f:
        all_fns = yaml.safe_load(f).get("functions", [])
    mcp_fns     = [fn for fn in all_fns if fn.get("type") in MCP_TOOL_TYPES]
    server_name = yaml_path.replace("/","_").replace(".yaml","")
    server      = Server(server_name)

    @server.list_tools()
    async def list_tools():
        return [
            mcp_types.Tool(name=fn["id"],
                           description=fn.get("description", fn["id"]),
                           inputSchema=_build_schema(fn))
            for fn in mcp_fns
        ]

    @server.call_tool()
    async def call_tool(name: str, arguments: dict):
        try:
            loop   = asyncio.get_event_loop()
            result = await loop.run_in_executor(
                None, lambda: runtime.execute(name, inputs=arguments)
            )
            return [mcp_types.TextContent(type="text", text=json.dumps(result, default=str, indent=2))]
        except Exception as e:
            return [mcp_types.TextContent(type="text", text=json.dumps({"error": str(e)}))]

    return server
