"""
DataFetcherAgent — Step 0 of the QA pipeline.

Calls fetch_process_data() with the process_id from session state,
then stores the result in session state under the key 'process_data'
via output_key. All downstream question agents read from that key.
"""

import logging

from google.adk.agents import LlmAgent

from config import settings
from tools import fetch_process_data_tool

logger = logging.getLogger(__name__)

_INSTRUCTION = """
You are the QA Pipeline Data Fetcher. Your only job is to retrieve process data.

Steps:
1. Read the process_id from session state (it was pre-loaded before you started).
2. Call fetch_process_data with that process_id.
3. If the result contains "status": "error", respond with:
   FETCH FAILED: <error message>
   Do not proceed further.
4. If successful, respond with:
   FETCH OK: <process_name> (<process_id>)
   Then list these key values on separate lines:
     - Status: <status>
     - Environment: <environment>
     - Compliance score: <compliance_score>
     - Risk score: <risk_score>
     - Open findings: <open_findings> (<critical_findings> critical)

Do not analyse or evaluate the data — that is the job of the question agents.
Do not invent or assume any values — use only what the tool returns.
"""


def create_data_fetcher_agent() -> LlmAgent:
    return LlmAgent(
        name="DataFetcherAgent",
        model=settings.model,
        instruction=_INSTRUCTION,
        tools=[fetch_process_data_tool],
        output_key="process_data",
        description="Fetches QA process data by Process ID and stores it in session state.",
    )
